# Admin Security Implementation

## Overview
This document outlines the comprehensive admin security system implemented for Wish a Wash, ensuring that only Reece Dixon and Charlie Blunden can access admin features.

## Security Architecture

### 1. Role-Based Access Control (RBAC)
- **Admin Role**: Only users with `role = 'admin'` can access admin features
- **Customer Role**: Default role for all customers
- **Valeter Role**: For service providers

### 2. Admin Email Whitelist
Only these specific emails can have admin access:
- `reece@wishawash.com` (Reece Dixon)
- `charlie@wishawash.com` (Charlie Blunden)

### 3. Multi-Layer Security

#### Frontend Protection
- **AdminGate Component**: Wraps admin UI elements
- **Route Guards**: Admin layout redirects non-admins
- **AuthContext**: Centralized role checking

#### Backend Protection
- **Row Level Security (RLS)**: Database-level access control
- **Edge Functions**: Server-side admin validation
- **SQL Functions**: `is_admin()` function for role checking

## Implementation Details

### Database Schema
```sql
-- Admin function
CREATE OR REPLACE FUNCTION is_admin(uid UUID)
RETURNS BOOLEAN 
LANGUAGE SQL 
STABLE 
AS $$
  SELECT EXISTS(
    SELECT 1 FROM profiles 
    WHERE id = uid AND role = 'admin'
  );
$$;

-- RLS Policies
CREATE POLICY "Only admins can access refund requests" ON refund_requests
  FOR ALL USING (is_admin(auth.uid()));
```

### Frontend Components

#### AdminGate Component
```typescript
export const AdminGate: React.FC<AdminGateProps> = ({ children, fallback = null }) => {
  const { hasAdminAccess } = useAuth();
  
  if (!hasAdminAccess()) {
    return <>{fallback}</>;
  }
  
  return <>{children}</>;
};
```

#### Admin Layout Guard
```typescript
export default function AdminLayout() {
  const { user, hasAdminAccess, isLoading } = useAuth();
  
  if (!user || !hasAdminAccess()) {
    return <Redirect href="/(customer)" />;
  }
  
  return <View style={{ flex: 1 }}>{/* Admin content */}</View>;
}
```

### AuthContext Integration
```typescript
const hasAdminAccess = (): boolean => {
  if (!user) return false;
  return user.role === 'admin';
};
```

## Setup Instructions

### 1. Supabase Setup
1. Run the `supabase-schema.sql` file in your Supabase SQL editor
2. This creates:
   - Admin function `is_admin()`
   - RLS policies for all tables
   - Admin user profiles

### 2. Environment Variables
```bash
# .env
EXPO_PUBLIC_SUPABASE_URL=your_supabase_url
EXPO_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
EXPO_PUBLIC_USE_REAL=true
```

### 3. Edge Functions Deployment
```bash
# Deploy admin functions
supabase functions deploy admin-refund
```

## Testing

### Test Admin Access
1. Login as `reece@wishawash.com` with password `admin123`
2. Should see admin dashboard toggle in profile
3. Should be able to access `/admin-dashboard`

### Test Non-Admin Access
1. Login as any other user
2. Should NOT see admin options
3. Attempting to access `/admin-dashboard` should redirect to home

### Test API Security
1. Try to access admin endpoints without admin role
2. Should receive 403 Forbidden response

## Security Features

### 1. Frontend Security
- ✅ Admin UI hidden from non-admins
- ✅ Route-level protection
- ✅ Component-level protection with AdminGate

### 2. Backend Security
- ✅ Database RLS policies
- ✅ Edge function admin checks
- ✅ SQL function role validation

### 3. Data Protection
- ✅ Admin-only tables protected
- ✅ User data isolation
- ✅ Audit trails for admin actions

## Admin Features

### Available Admin Functions
1. **User Management**
   - View all users (customers and valeters)
   - Suspend/unsuspend users
   - Edit user details

2. **Financial Management**
   - Process refund requests
   - View financial analytics
   - Manage commission rates

3. **System Reports**
   - View system reports
   - Assign reports to team members
   - Resolve issues

4. **Analytics**
   - Business analytics
   - User behavior insights
   - Performance metrics

## Troubleshooting

### Common Issues

#### 1. Admin Access Not Working
- Check if user email is in admin whitelist
- Verify role is set to 'admin' in database
- Check AuthContext is properly initialized

#### 2. RLS Policies Blocking Access
- Ensure `is_admin()` function exists
- Check RLS policies are enabled
- Verify user authentication is working

#### 3. Edge Functions Returning 403
- Check Authorization header is present
- Verify user has admin role
- Check function deployment status

### Debug Commands
```sql
-- Check user role
SELECT id, email, role FROM profiles WHERE email = 'reece@wishawash.com';

-- Test admin function
SELECT is_admin('user-uuid-here');

-- Check RLS policies
SELECT * FROM pg_policies WHERE tablename = 'refund_requests';
```

## Security Best Practices

### 1. Regular Audits
- Monitor admin access logs
- Review admin actions regularly
- Update admin user list as needed

### 2. Access Control
- Never expose admin endpoints publicly
- Always validate admin status server-side
- Use principle of least privilege

### 3. Data Protection
- Encrypt sensitive admin data
- Implement audit logging
- Regular security updates

## Support

For admin access issues:
1. Check this documentation
2. Verify Supabase setup
3. Test with known admin accounts
4. Contact development team

## Future Enhancements

### Planned Features
- [ ] Admin activity logging
- [ ] Multi-factor authentication for admins
- [ ] Admin role hierarchy
- [ ] Automated security monitoring
- [ ] Admin session management

### Security Improvements
- [ ] Rate limiting for admin endpoints
- [ ] IP whitelisting for admin access
- [ ] Enhanced audit trails
- [ ] Real-time security alerts
