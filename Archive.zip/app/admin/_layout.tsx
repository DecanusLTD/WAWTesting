import React, { useEffect } from 'react';
import { Redirect } from 'expo-router';
import { useAuth } from '../auth-context';
import { View, Text, ActivityIndicator } from 'react-native';

export default function AdminLayout() {
  const { user, hasAdminAccess, isLoading } = useAuth();

  // Show loading while checking auth
  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#0A1929' }}>
        <ActivityIndicator size="large" color="#87CEEB" />
        <Text style={{ color: '#F9FAFB', marginTop: 10 }}>Checking access...</Text>
      </View>
    );
  }

  // Redirect non-admin users
  if (!user || !hasAdminAccess()) {
    console.log('Admin access denied for user:', user?.email);
    return <Redirect href="/(customer)" />;
  }

  // Admin access granted - render the admin layout
  return (
    <View style={{ flex: 1 }}>
      {/* This will render the admin dashboard */}
    </View>
  );
}
