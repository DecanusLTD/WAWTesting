import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from './auth-context';
import { supabase } from '../src/lib/api/real/supabaseClient';
import { rewardSystem } from '../src/services/RewardSystem';

const { width } = Dimensions.get('window');

type DbStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled';

type DbBooking = {
  id: string;
  user_id: string;
  valeter_id: string | null;
  service_type: string;
  scheduled_at: string; // ISO
  created_at: string;   // ISO
  status: DbStatus;
  price: number | null;
  valeter_rating: number | null;
  location_address: string | null;
};

type Period = 'week' | 'month' | 'year';

type Stats = {
  earnings: number; // valeter: sum(price of completed); customer: total spent (completed)
  jobs: number;     // count of bookings in period (or completed if valeter)
  rating: number;   // average valeter_rating (non-null)
  hours: number;    // proxy: completed jobs count (since no completed_at)
  topServices: Array<{ name: string; count: number; revenue: number }>;
  peakHours: Array<{ hour: string; jobs: number }>;
  locations: Array<{ name: string; jobs: number; revenue: number }>;
};

const periods: { id: Period; label: string }[] = [
  { id: 'week', label: 'This Week' },
  { id: 'month', label: 'This Month' },
  { id: 'year', label: 'This Year' },
];

export default function DetailedStats() {
  const router = useRouter();
  const { user } = useAuth();
  const isValeter = user?.userType === 'valeter';

  const [selectedPeriod, setSelectedPeriod] = useState<Period>('week');
  const [loading, setLoading] = useState<boolean>(true);
  const [stats, setStats] = useState<Stats>({
    earnings: 0,
    jobs: 0,
    rating: 0,
    hours: 0,
    topServices: [],
    peakHours: [],
    locations: [],
  });

  // Rewards can stay from your local system (unrelated to bookings)
  const userRewards = rewardSystem.getUserRewards(user?.id || '', user?.userType || 'customer');

  const { timeMinISO } = useMemo(() => {
    const now = new Date();
    const start = new Date(now);
    if (selectedPeriod === 'week') {
      start.setDate(now.getDate() - 7);
    } else if (selectedPeriod === 'month') {
      start.setMonth(now.getMonth() - 1);
    } else {
      start.setFullYear(now.getFullYear() - 1);
    }
    return { timeMinISO: start.toISOString() };
  }, [selectedPeriod]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!user?.id) return;

      setLoading(true);
      try {
        // Base query by role
        const base = supabase
          .from('bookings')
          .select('id,user_id,valeter_id,service_type,scheduled_at,created_at,status,price,valeter_rating,location_address')
          .gte('created_at', timeMinISO) // filter by created_at window
          .order('created_at', { ascending: false })
          .limit(1000);

        const query = isValeter ? base.eq('valeter_id', user.id) : base.eq('user_id', user.id);

        const { data, error } = await query;
        if (error) throw error;

        const rows = (data || []) as DbBooking[];

        // If valeter, we focus on completed for earnings/jobs/hours; if customer, same for "spent"
        const completedRows = rows.filter(r => r.status === 'completed');
        const relevantRows = isValeter ? completedRows : rows; // customers may want all bookings this period

        // earnings / spent
        const earnings = (isValeter ? completedRows : completedRows).reduce((sum, r) => sum + Number(r.price || 0), 0);

        // jobs
        const jobs = isValeter ? completedRows.length : rows.length;

        // hours (proxy): completed jobs count for valeter; 0 for customers
        const hours = isValeter ? completedRows.length : 0;

        // rating (average of non-null valeter_rating from completed rows preferably)
        const ratingsPool = completedRows.map(r => r.valeter_rating).filter((n): n is number => typeof n === 'number');
        const rating = ratingsPool.length
          ? Math.round((ratingsPool.reduce((a, b) => a + b, 0) / ratingsPool.length) * 10) / 10
          : 0;

        // top services
        const svcMap = new Map<string, { name: string; count: number; revenue: number }>();
        for (const r of relevantRows) {
          const key = r.service_type || 'Unknown';
          const curr = svcMap.get(key) || { name: key, count: 0, revenue: 0 };
          curr.count += 1;
          curr.revenue += Number(r.price || 0);
          svcMap.set(key, curr);
        }
        const topServices = [...svcMap.values()]
          .sort((a, b) => b.count - a.count)
          .slice(0, 5);

        // peak hours (based on scheduled_at hour buckets in local time)
        const hourBuckets = new Map<string, number>();
        for (const r of relevantRows) {
          const d = new Date(r.scheduled_at || r.created_at);
          const h = d.getHours();
          // group in 2-hour buckets (e.g., "8-10")
          const startH = Math.floor(h / 2) * 2;
          const label = `${startH}-${startH + 2} ${startH < 12 ? 'AM' : 'PM'}`.replace('0-2 AM', '12-2 AM');
          hourBuckets.set(label, (hourBuckets.get(label) || 0) + 1);
        }
        const peakHours = [...hourBuckets.entries()]
          .map(([hour, jobs]) => ({ hour, jobs }))
          .sort((a, b) => b.jobs - a.jobs)
          .slice(0, 5);

        // locations (simple tally by address)
        const locMap = new Map<string, { name: string; jobs: number; revenue: number }>();
        for (const r of relevantRows) {
          const key = r.location_address || 'Unknown';
          const curr = locMap.get(key) || { name: key, jobs: 0, revenue: 0 };
          curr.jobs += 1;
          curr.revenue += Number(r.price || 0);
          locMap.set(key, curr);
        }
        const locations = [...locMap.values()]
          .sort((a, b) => b.jobs - a.jobs)
          .slice(0, 5);

        if (!cancelled) {
          setStats({
            earnings: Math.round(earnings * 100) / 100,
            jobs,
            rating,
            hours,
            topServices,
            peakHours,
            locations,
          });
        }
      } catch (e: any) {
        console.log('detailed stats error:', e?.message || e);
        if (!cancelled) Alert.alert('Error', 'Could not load analytics.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [user?.id, isValeter, timeMinISO]);

  const StatCard = ({ title, value, subtitle, icon, color }: any) => (
    <View style={[styles.statCard, { borderLeftColor: color }]}>
      <View style={styles.statHeader}>
        <Text style={styles.statIcon}>{icon}</Text>
        <Text style={styles.statTitle}>{title}</Text>
      </View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statSubtitle}>{subtitle}</Text>
    </View>
  );

  const ProgressBar = ({ value, max, color }: any) => (
    <View style={styles.progressContainer}>
      <View style={[styles.progressBar, { backgroundColor: 'rgba(255, 255, 255, 0.1)' }]}>
        <View
          style={[
            styles.progressFill,
            {
              width: `${Math.min(100, Math.round((value / Math.max(1, max)) * 100))}%`,
              backgroundColor: color,
            },
          ]}
        />
      </View>
      <Text style={styles.progressText}>{value}/{max}</Text>
    </View>
  );

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator />
          <Text style={{ color: '#87CEEB', marginTop: 12 }}>Loading analytics…</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Detailed Analytics</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Period Selector */}
        <View style={styles.periodSelector}>
          {periods.map((period) => (
            <TouchableOpacity
              key={period.id}
              style={[
                styles.periodButton,
                selectedPeriod === period.id && styles.selectedPeriodButton,
              ]}
              onPress={() => setSelectedPeriod(period.id)}
            >
              <Text
                style={[
                  styles.periodText,
                  selectedPeriod === period.id && styles.selectedPeriodText,
                ]}
              >
                {period.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Main Stats Grid */}
        <View style={styles.statsGrid}>
          <StatCard
            title={isValeter ? 'Total Earnings' : 'Total Spent'}
            value={`£${stats.earnings.toFixed(2)}`}
            subtitle={`${selectedPeriod} total`}
            icon="💰"
            color="#4CAF50"
          />
          <StatCard
            title={isValeter ? 'Jobs Completed' : 'Services Booked'}
            value={stats.jobs}
            subtitle="services"
            icon="✅"
            color="#2196F3"
          />
          <StatCard
            title="Average Rating"
            value={stats.rating || '—'}
            subtitle="out of 5 stars"
            icon="⭐"
            color="#FF9800"
          />
          {isValeter && (
            <StatCard
              title="Hours Worked (est.)"
              value={`${stats.hours}h`}
              subtitle="proxy: #completed jobs"
              icon="⏰"
              color="#9C27B0"
            />
          )}
        </View>

        {/* Rewards Progress */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Rewards Progress</Text>
          <View style={styles.rewardsCard}>
            <View style={styles.rewardsHeader}>
              <Text style={styles.rewardsLevel}>{userRewards.level} Level</Text>
              <Text style={styles.rewardsPoints}>{userRewards.points} Points</Text>
            </View>
            <ProgressBar
              value={userRewards.points}
              max={userRewards.points + userRewards.pointsToNextLevel}
              color="#87CEEB"
            />
            <Text style={styles.rewardsNext}>
              {userRewards.pointsToNextLevel} points to {userRewards.nextLevel}
            </Text>
          </View>
        </View>

        {/* Top Services */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Top Services</Text>
          <View style={styles.servicesCard}>
            {stats.topServices.length === 0 ? (
              <Text style={{ color: '#9CA3AF' }}>No data for this period.</Text>
            ) : (
              stats.topServices.map((service) => (
                <View key={service.name} style={styles.serviceRow}>
                  <View style={styles.serviceInfo}>
                    <Text style={styles.serviceName}>{service.name}</Text>
                    <Text style={styles.serviceCount}>{service.count} services</Text>
                  </View>
                  <Text style={styles.serviceRevenue}>£{service.revenue.toFixed(2)}</Text>
                </View>
              ))
            )}
          </View>
        </View>

        {/* Peak Hours */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Peak Hours</Text>
          <View style={styles.peakHoursCard}>
            {stats.peakHours.length === 0 ? (
              <Text style={{ color: '#9CA3AF' }}>No data for this period.</Text>
            ) : (
              stats.peakHours.map((peak, index) => {
                const maxJobs = Math.max(...stats.peakHours.map(p => p.jobs));
                return (
                  <View key={`${peak.hour}-${index}`} style={styles.peakRow}>
                    <Text style={styles.peakHour}>{peak.hour}</Text>
                    <View style={styles.peakBarContainer}>
                      <View
                        style={[
                          styles.peakBar,
                          {
                            width: `${(peak.jobs / Math.max(1, maxJobs)) * 100}%`,
                            backgroundColor: index === 0 ? '#4CAF50' : index === 1 ? '#2196F3' : '#FF9800',
                          },
                        ]}
                      />
                    </View>
                    <Text style={styles.peakJobs}>{peak.jobs} jobs</Text>
                  </View>
                );
              })
            )}
          </View>
        </View>

        {/* Top Locations */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Top Locations</Text>
          <View style={styles.locationsCard}>
            {stats.locations.length === 0 ? (
              <Text style={{ color: '#9CA3AF' }}>No data for this period.</Text>
            ) : (
              stats.locations.map((loc) => (
                <View key={loc.name} style={styles.locationRow}>
                  <View style={styles.locationInfo}>
                    <Text style={styles.locationName}>{loc.name}</Text>
                    <Text style={styles.locationJobs}>{loc.jobs} jobs</Text>
                  </View>
                  <Text style={styles.locationRevenue}>£{loc.revenue.toFixed(2)}</Text>
                </View>
              ))
            )}
          </View>
        </View>

        {/* Recent Activity (from rewards system) */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Activity</Text>
          <View style={styles.activityCard}>
            {userRewards.recentEarnings.slice(0, 5).map((earning: any) => (
              <View key={earning.id} style={styles.activityRow}>
                <Text style={styles.activityIcon}>🎁</Text>
                <View style={styles.activityInfo}>
                  <Text style={styles.activityReason}>{earning.reason}</Text>
                  <Text style={styles.activityDate}>{earning.date}</Text>
                </View>
                <Text style={styles.activityPoints}>+{earning.amount} pts</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Export Options (placeholder) */}
        <View style={styles.section}>
          <TouchableOpacity style={styles.exportButton}>
            <Text style={styles.exportButtonText}>📊 Export Report</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  scrollView: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 20, borderBottomWidth: 1, borderBottomColor: '#1E3A8A',
  },
  backButton: { padding: 8 },
  backButtonText: { color: '#87CEEB', fontSize: 16 },
  headerTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: 'bold' },
  placeholder: { width: 60 },

  periodSelector: { flexDirection: 'row', padding: 20, gap: 12 },
  periodButton: {
    flex: 1, paddingVertical: 12, paddingHorizontal: 16, borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.05)', alignItems: 'center',
  },
  selectedPeriodButton: { backgroundColor: '#87CEEB' },
  periodText: { color: '#E5E7EB', fontSize: 14, fontWeight: '600' },
  selectedPeriodText: { color: '#0A1929' },

  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', padding: 20, gap: 12 },
  statCard: {
    width: (width - 52) / 2,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12, padding: 16, borderLeftWidth: 4,
  },
  statHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  statIcon: { fontSize: 20, marginRight: 8 },
  statTitle: { color: '#E5E7EB', fontSize: 12, fontWeight: '600' },
  statValue: { color: '#F9FAFB', fontSize: 24, fontWeight: 'bold', marginBottom: 4 },
  statSubtitle: { color: '#87CEEB', fontSize: 12 },

  section: { padding: 20 },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: 'bold', marginBottom: 16 },

  rewardsCard: { backgroundColor: 'rgba(255, 255, 255, 0.05)', borderRadius: 12, padding: 16 },
  rewardsHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  rewardsLevel: { color: '#87CEEB', fontSize: 16, fontWeight: '600' },
  rewardsPoints: { color: '#F9FAFB', fontSize: 18, fontWeight: 'bold' },
  progressContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  progressBar: { flex: 1, height: 8, borderRadius: 4, marginRight: 12 },
  progressFill: { height: '100%', borderRadius: 4 },
  progressText: { color: '#87CEEB', fontSize: 12, fontWeight: '600' },
  rewardsNext: { color: '#E5E7EB', fontSize: 12 },

  servicesCard: { backgroundColor: 'rgba(255, 255, 255, 0.05)', borderRadius: 12, padding: 16 },
  serviceRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  serviceInfo: { flex: 1 },
  serviceName: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
  serviceCount: { color: '#87CEEB', fontSize: 12 },
  serviceRevenue: { color: '#4CAF50', fontSize: 16, fontWeight: 'bold' },

  peakHoursCard: { backgroundColor: 'rgba(255, 255, 255, 0.05)', borderRadius: 12, padding: 16 },
  peakRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  peakHour: { color: '#F9FAFB', fontSize: 14, width: 90 },
  peakBarContainer: {
    flex: 1, height: 20, backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 10, marginHorizontal: 12, overflow: 'hidden',
  },
  peakBar: { height: '100%', borderRadius: 10 },
  peakJobs: { color: '#87CEEB', fontSize: 12, width: 60, textAlign: 'right' },

  locationsCard: { backgroundColor: 'rgba(255, 255, 255, 0.05)', borderRadius: 12, padding: 16 },
  locationRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  locationInfo: { flex: 1 },
  locationName: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
  locationJobs: { color: '#87CEEB', fontSize: 12 },
  locationRevenue: { color: '#4CAF50', fontSize: 16, fontWeight: 'bold' },

  activityCard: { backgroundColor: 'rgba(255, 255, 255, 0.05)', borderRadius: 12, padding: 16 },
  activityRow: {
    flexDirection: 'row', alignItems: 'center', paddingVertical: 8,
    borderBottomWidth: 1, borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  activityIcon: { fontSize: 20, marginRight: 12 },
  activityInfo: { flex: 1 },
  activityReason: { color: '#F9FAFB', fontSize: 14, fontWeight: '600' },
  activityDate: { color: '#87CEEB', fontSize: 12 },
  activityPoints: { color: '#4CAF50', fontSize: 14, fontWeight: 'bold' },

  exportButton: { backgroundColor: '#87CEEB', paddingVertical: 16, paddingHorizontal: 24, borderRadius: 12, alignItems: 'center' },
  exportButtonText: { color: '#0A1929', fontSize: 16, fontWeight: 'bold' },
});