import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  Alert,
  TextInput,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './auth-context';
import { supabase } from '../src/lib/api/real/supabaseClient';
import { pricingEngine } from '../src/utils/pricing-engine';

interface ServiceOption {
  id: 'wash' | 'valet' | 'priority_wash';
  name: string;
  description: string;
  price: number;
  duration: string;
  icon: string;
}

const serviceOptions: ServiceOption[] = [
  { id: 'wash', name: 'Basic Wash', description: 'Exterior wash and dry', price: 20, duration: '30 min', icon: '🚗' },
  { id: 'valet', name: 'Full Valet', description: 'Interior and exterior deep clean', price: 35, duration: '45 min', icon: '✨' },
  { id: 'priority_wash', name: 'Priority Wash', description: 'Express service with priority booking', price: 45, duration: '15 min', icon: '⚡' },
];

export default function BookingScreen() {
    console.log('📍 Rendering BookingScreen.tsx');
  const { user } = useAuth();
  const [selectedService, setSelectedService] = useState<ServiceOption | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<string>('');
  const [isBooking, setIsBooking] = useState(false);

  const devAlert = (title: string, payload: any) => {
    // Always show details to diagnose; you can gate with __DEV__ if you want
    const pretty = typeof payload === 'string' ? payload : JSON.stringify(payload, null, 2);
    Alert.alert(title, pretty.slice(0, 1500)); // keep it readable
  };

  const preflight = async () => {
    try {
      const [{ data: sess }, { data: u }] = await Promise.all([
        supabase.auth.getSession(),
        supabase.auth.getUser(),
      ]);
      devAlert('Auth preflight', {
        hasSession: !!sess?.session,
        auth_uid: u?.user?.id,
        email: u?.user?.email,
      });

      // Try a harmless select to check RLS/connectivity
      const { error, status } = await supabase.from('bookings').select('id').limit(1);
      if (error) devAlert('Select test failed', { code: (error as any).code, message: error.message, details: (error as any).details, status });
      else devAlert('Select test ok', { status });
    } catch (e: any) {
      devAlert('Preflight crash', e?.message || e);
    }
  };

const handleBookService = async () => {
  if (isBooking) return;

  if (!selectedService || !selectedLocation) {
    Alert.alert('Error', 'Please select a service and location');
    return;
  }
  if (!user) {
    Alert.alert('Error', 'You must be logged in to book a service.');
    return;
  }

  try {
    setIsBooking(true);

    // Dynamic pricing (your existing logic)
    const timeOfDay = pricingEngine.getTimeOfDay();
    const dayOfWeek = pricingEngine.getDayOfWeek();
    const demand = pricingEngine.getDemandLevel('London', timeOfDay, dayOfWeek);
    const priceBreakdown = pricingEngine.calculatePrice({
      location: 'London',
      timeOfDay,
      dayOfWeek,
      demand,
      weather: 'sunny',
      vehicleSize: 'medium',
      serviceType: selectedService.id,
    });
    const finalPrice = Math.round(priceBreakdown.totalPrice);

    // Minimal payload that matches your schema
    const payload = {
      user_id: user.id,
      service_type: selectedService.id,         // 'wash' | 'valet' | 'priority_wash'
      scheduled_at: new Date().toISOString(),   // now, for demo
      status: 'scheduled',                      // must match enum exactly
      price: finalPrice,
      valeter_id: null,                         // stays null until claimed
      // If you added location columns, include them here:
      // location_address: selectedLocation,
      // location_lat: 51.5074,
      // location_lng: -0.1278,
    };

    // ✅ Do NOT call .select() here — it can fail under RLS and make you think the insert failed.
    // Use returning:'minimal' to avoid a post-insert select.
    const { error } = await supabase
      .from('bookings')
      .insert([payload], { returning: 'minimal' });

    if (error) {
      // Surface full error
      devAlert('Insert error', {
        code: (error as any).code,
        message: error.message,
        details: (error as any).details,
        hint: (error as any).hint,
      });
      Alert.alert('Booking Failed', error.message || 'Failed to book service. Please try again.');
      return;
    }

    // Success — no select needed
    Alert.alert(
      'Booking Successful!',
      `Your ${selectedService.name} has been booked for £${finalPrice}. We're finding you a valeter...`,
      [{ text: 'Track Service', onPress: () => router.push('/tracking') }]
    );
  } catch (err: any) {
    // Catch anything unexpected (including network issues)
    devAlert('Unexpected error', err?.message || JSON.stringify(err));
    Alert.alert('Error', err?.message || 'Something went wrong while booking.');
  } finally {
    setIsBooking(false);
  }
};

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Book a Service</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Dev helper: DB preflight */}
        <TouchableOpacity onPress={preflight} style={styles.devButton}>
          <Text style={styles.devButtonText}>🔍 Test DB (dev)</Text>
        </TouchableOpacity>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Choose Your Service</Text>
          <View style={styles.serviceOptionsContainer}>
            {serviceOptions.map((service) => (
              <TouchableOpacity
                key={service.id}
                style={[styles.serviceCard, selectedService?.id === service.id && styles.selectedServiceCard]}
                onPress={() => setSelectedService(service)}
                disabled={isBooking}
              >
                <Text style={styles.serviceIcon}>{service.icon}</Text>
                <View style={styles.serviceInfo}>
                  <Text style={styles.serviceName}>{service.name}</Text>
                  <Text style={styles.serviceDescription}>{service.description}</Text>
                  <Text style={styles.servicePrice}>From £{service.price}</Text>
                  <Text style={styles.serviceTime}>~{service.duration}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Where are you?</Text>
          <View style={styles.locationInputContainer}>
            <Text style={styles.locationIcon}>📍</Text>
            <TextInput
              style={styles.locationInput}
              placeholder="Enter your location (e.g., London, UK)"
              placeholderTextColor="#B0E0E6"
              value={selectedLocation}
              onChangeText={setSelectedLocation}
              editable={!isBooking}
            />
          </View>
        </View>

        {selectedService && selectedLocation ? (
          <TouchableOpacity style={styles.bookButton} onPress={handleBookService} disabled={isBooking}>
            <Text style={styles.bookButtonText}>
              {isBooking ? 'Booking…' : `Book ${selectedService.name} - £${selectedService.price}`}
            </Text>
          </TouchableOpacity>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  scrollView: { flex: 1 },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 20, paddingTop: 20, paddingBottom: 10,
  },
  backButton: { padding: 10 },
  backButtonText: { color: '#87CEEB', fontSize: 16, fontWeight: 'bold' },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#87CEEB' },
  placeholder: { width: 50 },
  section: { padding: 20 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', color: '#87CEEB', marginBottom: 15 },
  serviceOptionsContainer: { gap: 15 },
  serviceCard: {
    flexDirection: 'row', backgroundColor: '#1E3A8A', padding: 20, borderRadius: 15,
    alignItems: 'center', borderWidth: 2, borderColor: 'transparent',
  },
  selectedServiceCard: { borderColor: '#87CEEB', backgroundColor: '#2E4A8A' },
  serviceIcon: { fontSize: 30, marginRight: 15 },
  serviceInfo: { flex: 1 },
  serviceName: { fontSize: 18, fontWeight: 'bold', color: '#87CEEB', marginBottom: 5 },
  serviceDescription: { fontSize: 14, color: '#B0E0E6', marginBottom: 5 },
  servicePrice: { fontSize: 16, fontWeight: 'bold', color: '#87CEEB' },
  serviceTime: { fontSize: 12, color: '#B0E0E6' },
  locationInputContainer: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#1E3A8A',
    paddingHorizontal: 15, paddingVertical: 15, borderRadius: 15,
  },
  locationIcon: { fontSize: 20, marginRight: 10 },
  locationInput: { flex: 1, fontSize: 16, color: '#fff' },
  bookButton: { backgroundColor: '#87CEEB', margin: 20, padding: 15, borderRadius: 15, alignItems: 'center' },
  bookButtonText: { color: '#0A1929', fontSize: 18, fontWeight: 'bold' },

  // Dev helper button
  devButton: {
    marginHorizontal: 20, marginBottom: 10, paddingVertical: 10, borderRadius: 10,
    backgroundColor: '#274b91', alignItems: 'center',
  },
  devButtonText: { color: '#fff', fontWeight: '600' },
});