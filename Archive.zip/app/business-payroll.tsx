import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import { useAuth } from './auth-context';

const { width, height } = Dimensions.get('window');

interface PayrollRecord {
  id: string;
  employeeName: string;
  period: string;
  jobsCompleted: number;
  hoursWorked: number;
  basePay: number;
  bonuses: number;
  deductions: number;
  netPay: number;
  status: 'pending' | 'paid' | 'processing';
  paymentMethod: string;
  paidDate?: string;
}

interface PayrollSummary {
  totalPayroll: number;
  totalJobs: number;
  totalHours: number;
  averagePay: number;
  pendingPayments: number;
}

export default function BusinessPayroll() {
  const { user } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState('current');
  const [payrollRecords, setPayrollRecords] = useState<PayrollRecord[]>([]);
  const [payrollSummary, setPayrollSummary] = useState<PayrollSummary>({
    totalPayroll: 0,
    totalJobs: 0,
    totalHours: 0,
    averagePay: 0,
    pendingPayments: 0,
  });

  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    // Load mock payroll data
    const mockPayrollRecords: PayrollRecord[] = [
      {
        id: '1',
        employeeName: 'Mike Johnson',
        period: 'Jan 15-21, 2024',
        jobsCompleted: 12,
        hoursWorked: 24,
        basePay: 480.00,
        bonuses: 120.00,
        deductions: 0,
        netPay: 600.00,
        status: 'paid',
        paymentMethod: 'Bank Transfer',
        paidDate: '2024-01-22',
      },
      {
        id: '2',
        employeeName: 'Sarah Williams',
        period: 'Jan 15-21, 2024',
        jobsCompleted: 8,
        hoursWorked: 18,
        basePay: 360.00,
        bonuses: 80.00,
        deductions: 0,
        netPay: 440.00,
        status: 'paid',
        paymentMethod: 'Bank Transfer',
        paidDate: '2024-01-22',
      },
      {
        id: '3',
        employeeName: 'David Brown',
        period: 'Jan 15-21, 2024',
        jobsCompleted: 10,
        hoursWorked: 20,
        basePay: 400.00,
        bonuses: 100.00,
        deductions: 0,
        netPay: 500.00,
        status: 'pending',
        paymentMethod: 'Bank Transfer',
      },
      {
        id: '4',
        employeeName: 'Emma Davis',
        period: 'Jan 15-21, 2024',
        jobsCompleted: 6,
        hoursWorked: 12,
        basePay: 240.00,
        bonuses: 60.00,
        deductions: 0,
        netPay: 300.00,
        status: 'processing',
        paymentMethod: 'Bank Transfer',
      },
    ];

    setPayrollRecords(mockPayrollRecords);

    // Calculate summary
    const totalPayroll = mockPayrollRecords.reduce((sum, record) => sum + record.netPay, 0);
    const totalJobs = mockPayrollRecords.reduce((sum, record) => sum + record.jobsCompleted, 0);
    const totalHours = mockPayrollRecords.reduce((sum, record) => sum + record.hoursWorked, 0);
    const averagePay = totalPayroll / mockPayrollRecords.length;
    const pendingPayments = mockPayrollRecords.filter(record => record.status === 'pending').length;

    setPayrollSummary({
      totalPayroll,
      totalJobs,
      totalHours,
      averagePay,
      pendingPayments,
    });

    // Start animations
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handlePeriodChange = async (period: string) => {
    await hapticFeedback.selection();
    setSelectedPeriod(period);
  };

  const handleProcessPayroll = async () => {
    await hapticFeedback.impact('medium');
    Alert.alert(
      'Process Payroll',
      'Process payroll for all pending payments?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Process',
          onPress: () => {
            setPayrollRecords(prev => prev.map(record => 
              record.status === 'pending' ? { ...record, status: 'processing' } : record
            ));
            Alert.alert('Success', 'Payroll processing initiated. Payments will be completed within 24 hours.');
          }
        }
      ]
    );
  };

  const handleViewPayslip = async (recordId: string) => {
    await hapticFeedback.impact('medium');
    Alert.alert('View Payslip', 'This would open a detailed payslip for the selected employee.');
  };

  const handleExportPayroll = async () => {
    await hapticFeedback.impact('medium');
    Alert.alert('Export Payroll', 'Payroll data exported successfully!');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return '#10B981';
      case 'processing': return '#F59E0B';
      case 'pending': return '#EF4444';
      default: return '#6B7280';
    }
  };

  const getStatusText = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Payroll Management</Text>
        <TouchableOpacity style={styles.exportButton} onPress={handleExportPayroll}>
          <Text style={styles.exportButtonText}>📊</Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Period Selector */}
          <View style={styles.periodSelector}>
            <TouchableOpacity
              style={[styles.periodButton, selectedPeriod === 'current' && styles.activePeriodButton]}
              onPress={() => handlePeriodChange('current')}
            >
              <Text style={[styles.periodButtonText, selectedPeriod === 'current' && styles.activePeriodButtonText]}>
                Current
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.periodButton, selectedPeriod === 'previous' && styles.activePeriodButton]}
              onPress={() => handlePeriodChange('previous')}
            >
              <Text style={[styles.periodButtonText, selectedPeriod === 'previous' && styles.activePeriodButtonText]}>
                Previous
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.periodButton, selectedPeriod === 'month' && styles.activePeriodButton]}
              onPress={() => handlePeriodChange('month')}
            >
              <Text style={[styles.periodButtonText, selectedPeriod === 'month' && styles.activePeriodButtonText]}>
                This Month
              </Text>
            </TouchableOpacity>
          </View>

          {/* Payroll Summary */}
          <View style={styles.summarySection}>
            <Text style={styles.sectionTitle}>Payroll Summary</Text>
            <View style={styles.summaryGrid}>
              <View style={styles.summaryCard}>
                <Text style={styles.summaryValue}>£{payrollSummary.totalPayroll.toFixed(2)}</Text>
                <Text style={styles.summaryLabel}>Total Payroll</Text>
                <Text style={styles.summarySubtext}>This period</Text>
              </View>
              
              <View style={styles.summaryCard}>
                <Text style={styles.summaryValue}>{payrollSummary.totalJobs}</Text>
                <Text style={styles.summaryLabel}>Total Jobs</Text>
                <Text style={styles.summarySubtext}>Completed</Text>
              </View>
              
              <View style={styles.summaryCard}>
                <Text style={styles.summaryValue}>{payrollSummary.totalHours}h</Text>
                <Text style={styles.summaryLabel}>Total Hours</Text>
                <Text style={styles.summarySubtext}>Worked</Text>
              </View>
              
              <View style={styles.summaryCard}>
                <Text style={styles.summaryValue}>£{payrollSummary.averagePay.toFixed(2)}</Text>
                <Text style={styles.summaryLabel}>Average Pay</Text>
                <Text style={styles.summarySubtext}>Per employee</Text>
              </View>
            </View>
          </View>

          {/* Pending Payments */}
          {payrollSummary.pendingPayments > 0 && (
            <View style={styles.pendingSection}>
              <View style={styles.pendingHeader}>
                <Text style={styles.pendingTitle}>Pending Payments</Text>
                <Text style={styles.pendingCount}>{payrollSummary.pendingPayments} payments</Text>
              </View>
              <TouchableOpacity
                style={styles.processButton}
                onPress={handleProcessPayroll}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={['#10B981', '#059669']}
                  style={styles.processButtonGradient}
                >
                  <Text style={styles.processButtonText}>Process Payroll</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          )}

          {/* Payroll Records */}
          <View style={styles.recordsSection}>
            <Text style={styles.sectionTitle}>Employee Payroll</Text>
            <View style={styles.recordsList}>
              {payrollRecords.map((record) => (
                <View key={record.id} style={styles.recordCard}>
                  <View style={styles.recordHeader}>
                    <View style={styles.employeeInfo}>
                      <Text style={styles.employeeName}>{record.employeeName}</Text>
                      <Text style={styles.periodText}>{record.period}</Text>
                    </View>
                    <View style={[
                      styles.statusBadge,
                      { backgroundColor: getStatusColor(record.status) }
                    ]}>
                      <Text style={styles.statusText}>{getStatusText(record.status)}</Text>
                    </View>
                  </View>

                  <View style={styles.recordDetails}>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>Jobs Completed:</Text>
                      <Text style={styles.detailValue}>{record.jobsCompleted}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>Hours Worked:</Text>
                      <Text style={styles.detailValue}>{record.hoursWorked}h</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>Base Pay:</Text>
                      <Text style={styles.detailValue}>£{record.basePay.toFixed(2)}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>Bonuses:</Text>
                      <Text style={styles.detailValue}>£{record.bonuses.toFixed(2)}</Text>
                    </View>
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>Deductions:</Text>
                      <Text style={styles.detailValue}>£{record.deductions.toFixed(2)}</Text>
                    </View>
                    <View style={[styles.detailRow, styles.netPayRow]}>
                      <Text style={styles.netPayLabel}>Net Pay:</Text>
                      <Text style={styles.netPayValue}>£{record.netPay.toFixed(2)}</Text>
                    </View>
                  </View>

                  <View style={styles.recordFooter}>
                    <Text style={styles.paymentMethod}>Payment: {record.paymentMethod}</Text>
                    {record.paidDate && (
                      <Text style={styles.paidDate}>Paid: {record.paidDate}</Text>
                    )}
                  </View>

                  <View style={styles.recordActions}>
                    <TouchableOpacity
                      style={styles.actionButton}
                      onPress={() => handleViewPayslip(record.id)}
                    >
                      <Text style={styles.actionButtonText}>View Payslip</Text>
                    </TouchableOpacity>
                    {record.status === 'pending' && (
                      <TouchableOpacity
                        style={[styles.actionButton, styles.payButton]}
                        onPress={() => Alert.alert('Pay Employee', `Process payment for ${record.employeeName}?`)}
                      >
                        <Text style={[styles.actionButtonText, styles.payButtonText]}>Pay Now</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Quick Actions */}
          <View style={styles.quickActionsSection}>
            <Text style={styles.sectionTitle}>Quick Actions</Text>
            <View style={styles.quickActionsGrid}>
              <TouchableOpacity
                style={styles.quickActionCard}
                onPress={() => Alert.alert('Add Employee', 'Add new employee to payroll system.')}
              >
                <LinearGradient
                  colors={['#10B981', '#059669']}
                  style={styles.quickActionGradient}
                >
                  <Text style={styles.quickActionIcon}>👤</Text>
                  <Text style={styles.quickActionTitle}>Add Employee</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.quickActionCard}
                onPress={() => Alert.alert('Payroll Settings', 'Configure payroll settings and tax rates.')}
              >
                <LinearGradient
                  colors={['#8B5CF6', '#7C3AED']}
                  style={styles.quickActionGradient}
                >
                  <Text style={styles.quickActionIcon}>⚙️</Text>
                  <Text style={styles.quickActionTitle}>Settings</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.quickActionCard}
                onPress={() => Alert.alert('Tax Reports', 'Generate tax reports and summaries.')}
              >
                <LinearGradient
                  colors={['#F59E0B', '#D97706']}
                  style={styles.quickActionGradient}
                >
                  <Text style={styles.quickActionIcon}>📋</Text>
                  <Text style={styles.quickActionTitle}>Tax Reports</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.quickActionCard}
                onPress={() => Alert.alert('Payment History', 'View complete payment history.')}
              >
                <LinearGradient
                  colors={['#06B6D4', '#0891B2']}
                  style={styles.quickActionGradient}
                >
                  <Text style={styles.quickActionIcon}>📊</Text>
                  <Text style={styles.quickActionTitle}>History</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  exportButton: {
    padding: 8,
  },
  exportButtonText: {
    fontSize: 20,
  },
  content: {
    flex: 1,
  },
  periodSelector: {
    flexDirection: 'row',
    padding: 20,
    gap: 8,
  },
  periodButton: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 8,
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  activePeriodButton: {
    backgroundColor: '#87CEEB',
  },
  periodButtonText: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
  },
  activePeriodButtonText: {
    color: '#0A1929',
  },
  summarySection: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  summaryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  summaryCard: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  summaryValue: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  summaryLabel: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  summarySubtext: {
    color: '#B0E0E6',
    fontSize: 12,
  },
  pendingSection: {
    margin: 20,
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.3)',
  },
  pendingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  pendingTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  pendingCount: {
    color: '#EF4444',
    fontSize: 14,
    fontWeight: '600',
  },
  processButton: {
    borderRadius: 8,
    overflow: 'hidden',
  },
  processButtonGradient: {
    paddingVertical: 12,
    alignItems: 'center',
  },
  processButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  recordsSection: {
    padding: 20,
  },
  recordsList: {
    gap: 12,
  },
  recordCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  recordHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  employeeInfo: {
    flex: 1,
  },
  employeeName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  periodText: {
    color: '#87CEEB',
    fontSize: 12,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  recordDetails: {
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  detailLabel: {
    color: '#B0E0E6',
    fontSize: 14,
  },
  detailValue: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  netPayRow: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(135, 206, 235, 0.3)',
    paddingTop: 8,
    marginTop: 8,
  },
  netPayLabel: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  netPayValue: {
    color: '#F59E0B',
    fontSize: 16,
    fontWeight: 'bold',
  },
  recordFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  paymentMethod: {
    color: '#87CEEB',
    fontSize: 12,
  },
  paidDate: {
    color: '#10B981',
    fontSize: 12,
  },
  recordActions: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  payButton: {
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
  },
  payButtonText: {
    color: '#10B981',
  },
  quickActionsSection: {
    padding: 20,
    paddingBottom: 40,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  quickActionCard: {
    width: '48%',
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 8,
  },
  quickActionGradient: {
    padding: 16,
    alignItems: 'center',
  },
  quickActionIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  quickActionTitle: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
