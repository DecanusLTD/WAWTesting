import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Animated,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import ExpoMap from './components/ExpoMap';
import { supabase } from '../src/lib/api/real/supabaseClient';
import { useAuth } from './auth-context';

type DbStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled';

type DbBooking = {
  id: string;
  user_id: string;
  service_type: string;
  scheduled_at: string;
  status: DbStatus;
  price: number;
  location_address: string | null;
  location_lat: number | null;
  location_lng: number | null;
  valeter_id: string | null;
  progress_percent?: number | null; // <-- optional, if you add this column
  eta_minutes?: number | null;      // <-- optional, if you add this column
  created_at: string;
  updated_at: string;
};

type UiStatus = 'assigned' | 'en_route' | 'arrived' | 'in_progress' | 'completed';

interface ServiceStatus {
  id: string;
  status: UiStatus;
  driverId: string | null;
  driverName: string;
  vehicleInfo: string;
  currentLocation: string;
  serviceType: string;
  price: number;
  subtitle: string;        // <-- use this everywhere for text
  progressPercent: number; // <-- single source of truth for progress bar
}

interface LiveLocation {
  latitude: number;
  longitude: number;
  address: string;
}

/** Decide precise UI, progress, subtitle ONLY from DB row */
function decideUiFromRow(row: DbBooking): { ui: UiStatus; progress: number; subtitle: string } {
  const serverProgress =
    typeof row.progress_percent === 'number'
      ? Math.max(0, Math.min(100, row.progress_percent))
      : null;

  // scheduled + no valeter => still matching
  if (row.status === 'scheduled' && !row.valeter_id) {
    return {
      ui: 'assigned',
      progress: serverProgress ?? 10,
      subtitle: 'Connecting you to valeters',
    };
  }

  // scheduled + valeter assigned => en_route
  if (row.status === 'scheduled' && row.valeter_id) {
    const eta =
      typeof row.eta_minutes === 'number' && row.eta_minutes >= 0
        ? `ETA: ${row.eta_minutes} min`
        : 'Driver en route';
    return {
      ui: 'en_route',
      progress: serverProgress ?? 30,
      subtitle: eta,
    };
  }

  if (row.status === 'in_progress') {
    return {
      ui: 'in_progress',
      progress: serverProgress ?? 85,
      subtitle: 'Service in progress',
    };
  }

  if (row.status === 'completed') {
    return {
      ui: 'completed',
      progress: serverProgress ?? 100,
      subtitle: 'Service completed',
    };
  }

  if (row.status === 'cancelled') {
    return {
      ui: 'assigned',
      progress: serverProgress ?? 0,
      subtitle: 'Booking cancelled',
    };
  }

  return {
    ui: 'assigned',
    progress: serverProgress ?? 10,
    subtitle: 'Preparing…',
  };
}

export default function TrackingScreen() {
  const { user } = useAuth();
  const { bookingId } = useLocalSearchParams();
  const hasBookingId = useMemo(() => typeof bookingId === 'string' && bookingId.length > 0, [bookingId]);

  // animations
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState<boolean>(true);
  const [activeBookingId, setActiveBookingId] = useState<string | null>(hasBookingId ? String(bookingId) : null);

  const [serviceStatus, setServiceStatus] = useState<ServiceStatus | null>(null);

  const [userLocation, setUserLocation] = useState<LiveLocation | null>(null);
  const [valeterLocation, setValeterLocation] = useState<LiveLocation | null>(null);
  const [showMap, setShowMap] = useState(true);

  const canCancel = (s: ServiceStatus | null) => {
    if (!s) return false;
    // Cancel only while not started or before arrival: mapped UI states
    // 'assigned' (matching) or 'en_route' are safe to cancel
    return s.status === 'assigned' || s.status === 'en_route';
  };

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 450, useNativeDriver: true }),
    ]).start();
  }, []);

  // Bootstrap: use bookingId if provided; otherwise load latest booking for this user
  useEffect(() => {
    let unsubscribe: (() => void) | undefined;

    (async () => {
      try {
        setLoading(true);

        let id = activeBookingId;
        if (!id) {
          if (!user?.id) {
            setLoading(false);
            return;
          }
          const { data, error } = await supabase
            .from('bookings')
            .select('id')
            .eq('user_id', user.id)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle<{ id: string }>();

          if (error) throw error;
          if (!data) {
            setLoading(false);
            return;
          }
          id = data.id;
          setActiveBookingId(id);
        }

        await loadBooking(id!);
        unsubscribe = subscribeBooking(id!);
      } catch (e: any) {
        console.log('[Tracking] bootstrap error:', e?.message || e);
        Alert.alert('Error', 'Could not load your booking.');
      } finally {
        setLoading(false);
      }
    })();

    return () => {
      if (unsubscribe) unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeBookingId, user?.id]);

  /** one-time fetch */
  const loadBooking = async (id: string) => {
    const { data, error } = await supabase
      .from('bookings')
      .select('id, service_type, status, price, location_address, location_lat, location_lng, valeter_id, progress_percent, eta_minutes')
      .eq('id', id)
      .maybeSingle<DbBooking>();

    if (error) throw error;
    if (!data) {
      Alert.alert('Not found', 'We could not find that booking.');
      return;
    }
    applyBookingRow(data);
  };

  /** realtime subscription — DB is the only source of truth */
  const subscribeBooking = (id: string) => {
    const channel = supabase
      .channel(`booking-${id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'bookings', filter: `id=eq.${id}` },
        (payload) => {
          const row = (payload.new || payload.old) as DbBooking | undefined;
          if (row) applyBookingRow(row);
        }
      )
      .subscribe();

    return () => supabase.removeChannel(channel);
  };

  /** apply DB row to UI (no simulation, no auto changes) */
  const applyBookingRow = (row: DbBooking) => {
    const decision = decideUiFromRow(row);

    const addr = row.location_address ?? 'Service location';
    const lat = (row.location_lat ?? 51.5074) as number;
    const lng = (row.location_lng ?? -0.1278) as number;

    setServiceStatus({
      id: row.id,
      status: decision.ui,
      driverId: row.valeter_id,
      driverName: row.valeter_id ? 'Your Valeter' : 'Awaiting Valeter',
      vehicleInfo: row.valeter_id ? 'Valeter Van • Assigned' : 'Valeter • Pending',
      currentLocation: addr,
      serviceType: row.service_type || 'Car Wash',
      price: Number(row.price ?? 0),
      subtitle: decision.subtitle,          // <-- use this in UI
      progressPercent: decision.progress,   // <-- use this for progress bar
    });

    const userLoc: LiveLocation = { latitude: lat, longitude: lng, address: addr };
    setUserLocation(userLoc);

    setValeterLocation(
      row.valeter_id
        ? { ...userLoc, address: 'Valeter location (awaiting GPS feed)' }
        : { ...userLoc, address: 'Awaiting valeter' }
    );

    Animated.timing(progressAnim, { toValue: decision.progress, duration: 400, useNativeDriver: false }).start();
  };

  const getStatusColor = (status: UiStatus) => {
    switch (status) {
      case 'assigned':    return '#6B7280'; // grey for matching
      case 'en_route':    return '#87CEEB';
      case 'arrived':     return '#32CD32';
      case 'in_progress': return '#FFD700';
      case 'completed':   return '#4CAF50';
      default:            return '#87CEEB';
    }
  };

  const handleToggleMap = () => setShowMap((v) => !v);
  const handleViewReceipt = () => router.push('/owner-dashboard');
  const handleCancelService = () => {
    if (!serviceStatus || !activeBookingId) return;

    if (!canCancel(serviceStatus)) {
      Alert.alert('Cannot cancel', 'This booking can no longer be cancelled.');
      return;
    }

    Alert.alert(
      'Cancel Service',
      'Are you sure you want to cancel this service?',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, Cancel',
          style: 'destructive',
          onPress: async () => {
            try {
              // Optimistic: update local UI immediately
              setServiceStatus(prev =>
                prev
                  ? {
                      ...prev,
                      status: 'assigned',           // UI mapping shows neutral state
                      subtitle: 'Booking cancelled',
                      progressPercent: 0,
                    }
                  : prev
              );

              const { error } = await supabase
                .from('bookings')
                .update({
                  status: 'cancelled',
                  updated_at: new Date().toISOString(),
                  // Optional: reset progress if you store it
                  // progress_percent: 0
                })
                .eq('id', activeBookingId);

              if (error) {
                console.log('[Cancel] supabase error:', error);
                Alert.alert('Cancel failed', error.message || 'Could not cancel this booking.');
                // (Optional) revert optimistic update by reloading the row
                await loadBooking(activeBookingId);
                return;
              }

              Alert.alert('Cancelled', 'Your booking has been cancelled.');
              // You can stay on the page and let realtime reflect, or navigate away:
              // router.back();
            } catch (e: any) {
              console.log('[Cancel] unexpected error:', e?.message || e);
              Alert.alert('Cancel failed', 'Something went wrong. Please try again.');
            }
          },
        },
      ]
    );
  };

  // UI states
  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator />
        <Text style={{ color: '#87CEEB', marginTop: 12 }}>Loading booking…</Text>
      </View>
    );
  }

  if (!activeBookingId) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ color: '#87CEEB', fontSize: 16, marginBottom: 8 }}>No booking selected</Text>
        <TouchableOpacity onPress={() => router.back()}>
          <Text style={{ color: '#fff', textDecorationLine: 'underline' }}>Go back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (!serviceStatus || !userLocation || !valeterLocation) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator />
        <Text style={{ color: '#87CEEB', marginTop: 12 }}>Preparing tracking…</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <Animated.View style={[styles.header, { opacity: fadeAnim }]}>
        <View style={styles.headerTop}>
          <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Live Service Tracking</Text>
          <View style={styles.placeholder} />
        </View>
      </Animated.View>

      <ScrollView style={styles.scrollContainer} showsVerticalScrollIndicator={false}>
        <Animated.View
          style={[styles.contentContainer, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}
        >
          {/* Map */}
          {showMap && (
            <View style={styles.mapContainer}>
              <ExpoMap
                valeterLocation={valeterLocation}
                userLocation={userLocation}
                showMap={showMap}
                isCustomerView
              />
              <View style={styles.mapOverlay}>
                <View style={styles.mapStatusBar}>
                  <Text style={styles.mapStatusText}>
                    {serviceStatus.driverId ? '🔄 Waiting for driver GPS…' : '🔍 Matching valeters…'}
                  </Text>
                  <Text style={styles.mapStatusSubtext}>{valeterLocation.address}</Text>
                </View>
              </View>
            </View>
          )}

          {/* Progress */}
          <View style={styles.progressCard}>
            <View style={styles.progressHeader}>
              <Text style={styles.progressTitle}>Service Progress</Text>
              <Text style={styles.progressPercentage}>{Math.round(serviceStatus.progressPercent)}%</Text>
            </View>
            <View style={styles.progressBarContainer}>
              <Animated.View
                style={[
                  styles.progressBar,
                  {
                    width: progressAnim.interpolate({ inputRange: [0, 100], outputRange: ['0%', '100%'] }),
                    backgroundColor: getStatusColor(serviceStatus.status),
                  },
                ]}
              />
            </View>
            {/* Always show the DB-driven subtitle, not a generic label */}
            <Text style={styles.progressStatus}>{serviceStatus.subtitle}</Text>
          </View>

          {/* Details */}
          <View style={styles.serviceDetailsCard}>
            <Text style={styles.serviceDetailsTitle}>Service Details</Text>
            <Row label="Service Type" value={serviceStatus.serviceType} />
            <Row label="Location" value={userLocation.address} />
            <Row label="Price" value={`£${serviceStatus.price.toFixed(2)}`} />
          </View>

          {/* Status */}
          <View style={styles.statusCard}>
            <View style={styles.statusHeader}>
              <View style={styles.statusIconContainer}>
                <Text style={styles.statusIcon}>
                  {serviceStatus.status === 'assigned' ? '👤' :
                   serviceStatus.status === 'en_route' ? '🚗' :
                   serviceStatus.status === 'arrived' ? '📍' :
                   serviceStatus.status === 'in_progress' ? '🧽' : '✅'}
                </Text>
              </View>
              <View style={styles.statusInfo}>
                {/* Title can be coarse… */}
                <Text style={styles.statusText}>
                  {serviceStatus.driverId
                    ? (serviceStatus.status === 'en_route' ? 'Driver En Route' :
                       serviceStatus.status === 'in_progress' ? 'Service in Progress' :
                       serviceStatus.status === 'completed' ? 'Service Completed' :
                       'Driver Assigned')
                    : 'Matching Valeters'}
                </Text>
                {/* …but always show the precise subtitle from DB decision */}
                <Text style={{ color: '#B0E0E6', marginTop: 4 }}>{serviceStatus.subtitle}</Text>
              </View>
            </View>
            <View style={[styles.statusProgress, { backgroundColor: getStatusColor(serviceStatus.status) }]} />
          </View>

          {/* Actions */}
         <View style={styles.actionButtons}>
           {serviceStatus.status === 'completed' ? (
             <TouchableOpacity style={styles.primaryButton} onPress={handleViewReceipt}>
               <Text style={styles.primaryButtonText}>View Receipt</Text>
             </TouchableOpacity>
           ) : (
             <TouchableOpacity
               style={[
                 styles.cancelButton,
                 !canCancel(serviceStatus) && { opacity: 0.5 }
               ]}
               disabled={!canCancel(serviceStatus)}
               onPress={handleCancelService}
             >
               <Text style={styles.cancelButtonText}>
                 {serviceStatus.status === 'in_progress' ? 'Service In Progress' :
                  serviceStatus.subtitle === 'Booking cancelled' ? 'Cancelled' :
                  'Cancel Service'}
               </Text>
             </TouchableOpacity>
           )}
           <TouchableOpacity style={[styles.primaryButton, { marginTop: 12 }]} onPress={handleToggleMap}>
             <Text style={styles.primaryButtonText}>{showMap ? 'Hide Map' : 'Show Map'}</Text>
           </TouchableOpacity>
         </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const Row = ({ label, value }: { label: string; value: string }) => (
  <View style={styles.serviceDetailsRow}>
    <Text style={styles.serviceDetailsLabel}>{label}:</Text>
    <Text style={styles.serviceDetailsValue}>{value}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  header: {
    backgroundColor: '#1E3A8A',
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  backButton: { padding: 10 },
  backButtonText: { color: '#87CEEB', fontSize: 16, fontWeight: '600' },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#fff' },
  placeholder: { width: 60 },
  scrollContainer: { flex: 1 },
  contentContainer: { padding: 20 },

  mapContainer: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    marginBottom: 20,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    height: 250,
  },
  mapOverlay: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: 'rgba(10,25,41,0.9)', padding: 15 },
  mapStatusBar: { alignItems: 'center' },
  mapStatusText: { color: '#87CEEB', fontSize: 16, fontWeight: 'bold', marginBottom: 4 },
  mapStatusSubtext: { color: '#B0E0E6', fontSize: 14 },

  progressCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 8,
  },
  progressHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
  progressTitle: { fontSize: 18, color: '#87CEEB', fontWeight: 'bold' },
  progressPercentage: { fontSize: 18, color: '#F9FAFB', fontWeight: 'bold' },
  progressBarContainer: { height: 8, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 4, marginBottom: 10, overflow: 'hidden' },
  progressBar: { height: '100%', borderRadius: 4 },
  progressStatus: { fontSize: 14, color: '#B0E0E6', textAlign: 'center' },

  statusCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 8,
  },
  statusHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  statusIconContainer: {
    width: 60, height: 60, borderRadius: 30, backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center', alignItems: 'center', marginRight: 15,
  },
  statusIcon: { fontSize: 28 },
  statusInfo: { flex: 1 },
  statusText: { fontSize: 20, color: '#fff', fontWeight: 'bold' },
  statusProgress: { height: 4, borderRadius: 2, width: '100%' },

  serviceDetailsCard: {
    backgroundColor: 'rgba(30,58,138,0.3)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.1)',
  },
  serviceDetailsTitle: { fontSize: 18, fontWeight: 'bold', color: '#87CEEB', marginBottom: 15, textAlign: 'center' },
  serviceDetailsRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    marginBottom: 12, paddingBottom: 8, borderBottomWidth: 1, borderBottomColor: 'rgba(135, 206, 235, 0.1)',
  },
  serviceDetailsLabel: { fontSize: 14, color: '#B0E0E6', fontWeight: '500' },
  serviceDetailsValue: { fontSize: 14, color: '#fff', fontWeight: '600', textAlign: 'right', flex: 1, marginLeft: 10 },

  actionButtons: { marginBottom: 20 },
  primaryButton: { backgroundColor: '#87CEEB', borderRadius: 12, padding: 18, alignItems: 'center' },
  primaryButtonText: { color: '#0A1929', fontSize: 18, fontWeight: 'bold' },
  cancelButton: {
    backgroundColor: 'rgba(244, 67, 54, 0.2)', borderRadius: 12, padding: 18, alignItems: 'center',
    borderWidth: 1, borderColor: '#F44336', marginBottom: 12,
  },
  cancelButtonText: { color: '#F44336', fontSize: 18, fontWeight: 'bold' },
});