import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  SafeAreaView,
  Modal,
  TextInput,
  Switch,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './auth-context';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

export default function PrivacySettings() {
  const { user, updatePassword, updateProfile } = useAuth();
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // Privacy settings state
  const [privacySettings, setPrivacySettings] = useState({
    profileVisibility: true,
    locationSharing: true,
    pushNotifications: true,
    emailNotifications: true,
    smsNotifications: false,
    dataAnalytics: true,
    marketingEmails: false,
    thirdPartySharing: false,
  });

  const handlePasswordChange = async () => {
    if (!currentPassword || !newPassword || !confirmPassword) {
      await hapticFeedback.notification('error');
      Alert.alert('Error', 'Please fill in all password fields');
      return;
    }

    if (newPassword !== confirmPassword) {
      await hapticFeedback.notification('error');
      Alert.alert('Error', 'New passwords do not match');
      return;
    }

    if (newPassword.length < 8) {
      await hapticFeedback.notification('error');
      Alert.alert('Error', 'Password must be at least 8 characters long');
      return;
    }

    setIsChangingPassword(true);
    
    try {
      await updatePassword(currentPassword, newPassword);
      await hapticFeedback.notification('success');
      Alert.alert('Success', 'Password updated successfully');
      setShowPasswordModal(false);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (error) {
      await hapticFeedback.notification('error');
      Alert.alert('Error', 'Failed to update password. Please check your current password.');
    } finally {
      setIsChangingPassword(false);
    }
  };

  const handlePrivacySettingChange = async (setting: string, value: boolean) => {
    await hapticFeedback.selection();
    setPrivacySettings(prev => ({ ...prev, [setting]: value }));
    
    // Save to backend (simulated)
    console.log(`Privacy setting ${setting} changed to ${value}`);
  };

  const handleDeleteAccount = async () => {
    await hapticFeedback.notification('warning');
    Alert.alert(
      'Delete Account',
      'This action cannot be undone. All your data will be permanently deleted.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              // Simulate account deletion
              await new Promise(resolve => setTimeout(resolve, 2000));
              await hapticFeedback.notification('success');
              Alert.alert('Account Deleted', 'Your account has been successfully deleted.');
              router.replace('/');
            } catch (error) {
              await hapticFeedback.notification('error');
              Alert.alert('Error', 'Failed to delete account. Please try again.');
            }
          }
        }
      ]
    );
  };

  const handleExportData = async () => {
    await hapticFeedback.impact('medium');
    Alert.alert(
      'Export Data',
      'Your data will be exported and sent to your email address. This may take a few minutes.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Export',
          onPress: async () => {
            try {
              // Simulate data export
              await new Promise(resolve => setTimeout(resolve, 3000));
              await hapticFeedback.notification('success');
              Alert.alert('Data Exported', 'Your data has been exported and sent to your email.');
            } catch (error) {
              await hapticFeedback.notification('error');
              Alert.alert('Error', 'Failed to export data. Please try again.');
            }
          }
        }
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Privacy & Security</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Account Security */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🔒 Account Security</Text>
          
          <TouchableOpacity 
            style={styles.settingCard}
            onPress={() => setShowPasswordModal(true)}
          >
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Change Password</Text>
              <Text style={styles.settingDescription}>Update your account password</Text>
            </View>
            <Text style={styles.settingArrow}>→</Text>
          </TouchableOpacity>

          <View style={styles.settingCard}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Two-Factor Authentication</Text>
              <Text style={styles.settingDescription}>Add an extra layer of security</Text>
            </View>
            <Switch
              value={false}
              onValueChange={() => Alert.alert('Coming Soon', 'Two-factor authentication will be available soon!')}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={false ? '#f4f3f4' : '#f5dd4b'}
            />
          </View>
        </View>

        {/* Privacy Controls */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>👁️ Privacy Controls</Text>
          
          <View style={styles.settingCard}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Profile Visibility</Text>
              <Text style={styles.settingDescription}>Show your profile to other users</Text>
            </View>
            <Switch
              value={privacySettings.profileVisibility}
              onValueChange={(value) => handlePrivacySettingChange('profileVisibility', value)}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={privacySettings.profileVisibility ? '#f5dd4b' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingCard}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Location Sharing</Text>
              <Text style={styles.settingDescription}>Share your location for services</Text>
            </View>
            <Switch
              value={privacySettings.locationSharing}
              onValueChange={(value) => handlePrivacySettingChange('locationSharing', value)}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={privacySettings.locationSharing ? '#f5dd4b' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingCard}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Data Analytics</Text>
              <Text style={styles.settingDescription}>Help improve our services</Text>
            </View>
            <Switch
              value={privacySettings.dataAnalytics}
              onValueChange={(value) => handlePrivacySettingChange('dataAnalytics', value)}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={privacySettings.dataAnalytics ? '#f5dd4b' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingCard}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Third-Party Sharing</Text>
              <Text style={styles.settingDescription}>Share data with trusted partners</Text>
            </View>
            <Switch
              value={privacySettings.thirdPartySharing}
              onValueChange={(value) => handlePrivacySettingChange('thirdPartySharing', value)}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={privacySettings.thirdPartySharing ? '#f5dd4b' : '#f4f3f4'}
            />
          </View>
        </View>

        {/* Notifications */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🔔 Notifications</Text>
          
          <View style={styles.settingCard}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Push Notifications</Text>
              <Text style={styles.settingDescription}>Receive app notifications</Text>
            </View>
            <Switch
              value={privacySettings.pushNotifications}
              onValueChange={(value) => handlePrivacySettingChange('pushNotifications', value)}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={privacySettings.pushNotifications ? '#f5dd4b' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingCard}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Email Notifications</Text>
              <Text style={styles.settingDescription}>Receive email updates</Text>
            </View>
            <Switch
              value={privacySettings.emailNotifications}
              onValueChange={(value) => handlePrivacySettingChange('emailNotifications', value)}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={privacySettings.emailNotifications ? '#f5dd4b' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingCard}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>SMS Notifications</Text>
              <Text style={styles.settingDescription}>Receive text messages</Text>
            </View>
            <Switch
              value={privacySettings.smsNotifications}
              onValueChange={(value) => handlePrivacySettingChange('smsNotifications', value)}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={privacySettings.smsNotifications ? '#f5dd4b' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingCard}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Marketing Emails</Text>
              <Text style={styles.settingDescription}>Receive promotional content</Text>
            </View>
            <Switch
              value={privacySettings.marketingEmails}
              onValueChange={(value) => handlePrivacySettingChange('marketingEmails', value)}
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={privacySettings.marketingEmails ? '#f5dd4b' : '#f4f3f4'}
            />
          </View>
        </View>

        {/* Data Management */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📊 Data Management</Text>
          
          <TouchableOpacity style={styles.settingCard} onPress={handleExportData}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Export My Data</Text>
              <Text style={styles.settingDescription}>Download all your data</Text>
            </View>
            <Text style={styles.settingArrow}>→</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.settingCard}
            onPress={() => router.push('/privacy-policy')}
          >
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Privacy Policy</Text>
              <Text style={styles.settingDescription}>Read our privacy policy</Text>
            </View>
            <Text style={styles.settingArrow}>→</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.settingCard}
            onPress={() => router.push('/terms-of-service')}
          >
            <View style={styles.settingInfo}>
              <Text style={styles.settingTitle}>Terms of Service</Text>
              <Text style={styles.settingDescription}>Read our terms of service</Text>
            </View>
            <Text style={styles.settingArrow}>→</Text>
          </TouchableOpacity>
        </View>

        {/* Danger Zone */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>⚠️ Danger Zone</Text>
          
          <TouchableOpacity 
            style={[styles.settingCard, styles.dangerCard]}
            onPress={() => setShowDeleteModal(true)}
          >
            <View style={styles.settingInfo}>
              <Text style={[styles.settingTitle, styles.dangerText]}>Delete Account</Text>
              <Text style={[styles.settingDescription, styles.dangerText]}>Permanently delete your account and all data</Text>
            </View>
            <Text style={[styles.settingArrow, styles.dangerText]}>→</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Password Change Modal */}
      <Modal
        visible={showPasswordModal}
        animationType="slide"
        transparent={true}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Change Password</Text>
            
            <TextInput
              style={styles.input}
              placeholder="Current Password"
              placeholderTextColor="#9CA3AF"
              value={currentPassword}
              onChangeText={setCurrentPassword}
              secureTextEntry
            />
            
            <TextInput
              style={styles.input}
              placeholder="New Password"
              placeholderTextColor="#9CA3AF"
              value={newPassword}
              onChangeText={setNewPassword}
              secureTextEntry
            />
            
            <TextInput
              style={styles.input}
              placeholder="Confirm New Password"
              placeholderTextColor="#9CA3AF"
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              secureTextEntry
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => setShowPasswordModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.saveButton, isChangingPassword && styles.saveButtonDisabled]}
                onPress={handlePasswordChange}
                disabled={isChangingPassword}
              >
                <Text style={styles.saveButtonText}>
                  {isChangingPassword ? 'Updating...' : 'Update Password'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    paddingTop: 10,
  },
  backButton: {
    padding: 10,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 60,
  },
  section: {
    padding: 20,
    paddingBottom: 10,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  settingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
  },
  dangerCard: {
    backgroundColor: '#DC2626',
  },
  settingInfo: {
    flex: 1,
  },
  settingTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  dangerText: {
    color: '#FFFFFF',
  },
  settingDescription: {
    color: '#87CEEB',
    fontSize: 14,
  },
  settingArrow: {
    color: '#87CEEB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 30,
    width: '90%',
    maxWidth: 400,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 25,
  },
  input: {
    backgroundColor: '#0A1929',
    borderRadius: 8,
    padding: 15,
    color: '#F9FAFB',
    fontSize: 16,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#87CEEB',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 15,
    marginTop: 10,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#6B7280',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
  saveButton: {
    flex: 1,
    backgroundColor: '#10B981',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
