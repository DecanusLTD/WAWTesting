import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator, StyleSheet, Text } from 'react-native';
import { Redirect } from 'expo-router';
import { useAuth } from './auth-context';

const LOGIN_ROUTE = '/login'; // change to '/(auth)/login' if your login file is in app/(auth)/login.tsx

export default function Index() {
  const { user, isLoading } = useAuth();
  const [forceLogin, setForceLogin] = useState(false);

  // Safety valve: if auth is "loading" for too long, go to login anyway
  useEffect(() => {
    console.log('[index] isLoading:', isLoading, 'user:', !!user);
    if (user) return;
    const t = setTimeout(() => {
      console.log('[index] forcing login after timeout');
      setForceLogin(true);
    }, 2000); // 2s feels snappy; bump to 3000 if you prefer
    return () => clearTimeout(t);
  }, [user, isLoading]);

  // If logged in, go to the right dashboard
  if (user) {
    // If you want to split by role:
    // return <Redirect href={user.userType === 'valeter' ? '/driver-dashboard' : '/owner-dashboard'} />;
    return <Redirect href="/owner-dashboard" />;
  }

  // Not logged in yet:
  if (!isLoading || forceLogin) {
    return <Redirect href={LOGIN_ROUTE} />;
  }

  // Still waiting briefly → show loader
  return (
    <View style={styles.loader}>
      <ActivityIndicator />
      <Text style={styles.text}>Loading auth…</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  loader: { flex: 1, backgroundColor: '#0A1929', alignItems: 'center', justifyContent: 'center' },
  text: { color: '#87CEEB', marginTop: 8 },
});