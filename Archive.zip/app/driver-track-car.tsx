import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  // Dimensions,
  Animated,
  ScrollView,
  Alert,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './auth-context';
import { chatService } from '../src/utils/ChatService';
// import * as Haptics from 'expo-haptics';

// const { width, height } = Dimensions.get('window');

interface CustomerLocation {
  id: string;
  name: string;
  address: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  estimatedTime: string;
  distance: string;
  status: 'active' | 'completed' | 'cancelled';
}

export default function DriverTrackCarScreen() {
  const { user } = useAuth();
  const [isTracking, setIsTracking] = useState(false);
  const [currentLocation, _setCurrentLocation] = useState('Canary Wharf, London');
  const [customerLocation, setCustomerLocation] = useState<CustomerLocation | null>(null);
  const [navigationSteps, setNavigationSteps] = useState<string[]>([]);
  const [estimatedArrival, setEstimatedArrival] = useState('12 min');

  // Animation values
  const pulseAnim = new Animated.Value(1);
  // const slideAnim = new Animated.Value(0);

  useEffect(() => {
    // Simulate live tracking data
    if (isTracking) {
      const interval = setInterval(() => {
        // Simulate GPS updates
        setEstimatedArrival(prev => {
          const time = parseInt(prev.split(' ')[0]);
          return time > 1 ? `${time - 1} min` : 'Arrived';
        });
      }, 30000); // Update every 30 seconds

      return () => clearInterval(interval);
    }
    return undefined;
  }, [isTracking]);

  useEffect(() => {
    // Pulse animation for tracking indicator
    if (isTracking) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.2,
            duration: 1000,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 1000,
            useNativeDriver: true,
          }),
        ])
      ).start();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isTracking]);

  const startTracking = () => {
    // Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setIsTracking(true);
    
    // Simulate customer location data
    setCustomerLocation({
      id: '1',
      name: 'Sarah Johnson',
      address: '25 Bank Street, Canary Wharf, London E14 5LE',
      coordinates: { lat: 51.5054, lng: -0.0235 },
      estimatedTime: '12 min',
      distance: '2.3 km',
      status: 'active',
    });

    // Simulate navigation steps
    setNavigationSteps([
      'Turn right onto Bank Street',
      'Continue straight for 0.5 km',
      'Turn left onto Westferry Road',
      'Continue for 1.2 km',
      'Turn right onto Marsh Wall',
      'Destination on your right',
    ]);

    Alert.alert('Tracking Started', 'Live GPS tracking is now active');
  };

  const stopTracking = () => {
    // Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setIsTracking(false);
    setCustomerLocation(null);
    setNavigationSteps([]);
    setEstimatedArrival('12 min');
    Alert.alert('Tracking Stopped', 'Live tracking has been disabled');
  };

  const handleCallCustomer = () => {
    // Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Alert.alert('Call Customer', 'Calling Sarah Johnson...');
  };

  const handleMessageCustomer = () => {
    // Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    
    // Find or create conversation with the customer
    if (user && customerLocation) {
      let conversation = chatService.getConversationByParticipants(user.id, customerLocation.id);
      
      if (!conversation) {
        // Create new conversation
        conversation = chatService.createConversation(
          customerLocation.id,
          user.id,
          customerLocation.name,
          `${user.firstName} ${user.lastName}`
        );
      }
      
      // Navigate to chat screen
      router.push({
        pathname: '/chat-screen',
        params: { conversationId: conversation.id }
      });
    } else {
      Alert.alert('Error', 'Unable to start chat. Please try again.');
    }
  };

  const handleArrived = () => {
    // Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    Alert.alert('Arrived', 'You have arrived at the customer location');
    setIsTracking(false);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Track Car</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView style={styles.scrollContainer} contentContainerStyle={styles.scrollContent}>
        {/* Live Map Simulation */}
        <View style={styles.mapContainer}>
          <View style={styles.mapHeader}>
            <Text style={styles.mapTitle}>Live GPS Tracking</Text>
            <Animated.View style={[styles.trackingIndicator, { transform: [{ scale: pulseAnim }] }]}>
              <Text style={styles.trackingDot}>{isTracking ? '🔴' : '⚪'}</Text>
            </Animated.View>
          </View>
          
          <View style={styles.mapContent}>
            <Text style={styles.mapText}>🗺️ Interactive Map View</Text>
            <Text style={styles.mapSubtext}>Real-time GPS navigation</Text>
            
            {isTracking && (
              <View style={styles.locationInfo}>
                <Text style={styles.locationTitle}>📍 Current Location</Text>
                <Text style={styles.locationText}>{currentLocation}</Text>
              </View>
            )}
          </View>
        </View>

        {/* Customer Information */}
        {customerLocation && (
          <View style={styles.customerCard}>
            <Text style={styles.sectionTitle}>Customer Details</Text>
            
            <View style={styles.customerInfo}>
              <View style={styles.customerAvatar}>
                <Text style={styles.avatarText}>👤</Text>
              </View>
              <View style={styles.customerDetails}>
                <Text style={styles.customerName}>{customerLocation.name}</Text>
                <Text style={styles.customerAddress}>{customerLocation.address}</Text>
                <Text style={styles.customerDistance}>{customerLocation.distance} away</Text>
              </View>
            </View>

            <View style={styles.actionButtons}>
              <TouchableOpacity style={styles.actionButton} onPress={handleCallCustomer}>
                <Text style={styles.actionButtonText}>📞 Call</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionButton} onPress={handleMessageCustomer}>
                <Text style={styles.actionButtonText}>💬 Message</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Navigation Steps */}
        {navigationSteps.length > 0 && (
          <View style={styles.navigationCard}>
            <Text style={styles.sectionTitle}>Turn-by-Turn Navigation</Text>
            
            <View style={styles.etaContainer}>
              <Text style={styles.etaText}>ETA: {estimatedArrival}</Text>
            </View>

            <View style={styles.stepsContainer}>
              {navigationSteps.map((step, index) => (
                <View key={index} style={styles.stepItem}>
                  <View style={styles.stepNumber}>
                    <Text style={styles.stepNumberText}>{index + 1}</Text>
                  </View>
                  <Text style={styles.stepText}>{step}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Control Buttons */}
        <View style={styles.controlContainer}>
          {!isTracking ? (
            <TouchableOpacity style={styles.startButton} onPress={startTracking}>
              <Text style={styles.startButtonText}>🚗 Start Tracking</Text>
            </TouchableOpacity>
          ) : (
            <View style={styles.controlButtons}>
              <TouchableOpacity style={styles.stopButton} onPress={stopTracking}>
                <Text style={styles.stopButtonText}>⏹️ Stop Tracking</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.arrivedButton} onPress={handleArrived}>
                <Text style={styles.arrivedButtonText}>✅ Arrived</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Status Information */}
        <View style={styles.statusCard}>
          <Text style={styles.statusTitle}>Tracking Status</Text>
          <Text style={styles.statusText}>
            {isTracking 
              ? '🟢 Live GPS tracking active - Following route to customer' 
              : '⚪ GPS tracking inactive - Ready to start navigation'
            }
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#1E3A8A',
  },
  backButton: {
    padding: 10,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 60,
  },
  scrollContainer: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  mapContainer: {
    backgroundColor: '#1E3A8A',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
  },
  mapHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  mapTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  trackingIndicator: {
    alignItems: 'center',
  },
  trackingDot: {
    fontSize: 20,
  },
  mapContent: {
    alignItems: 'center',
    paddingVertical: 30,
  },
  mapText: {
    color: '#FFFFFF',
    fontSize: 24,
    marginBottom: 8,
  },
  mapSubtext: {
    color: '#B0E0E6',
    fontSize: 14,
  },
  locationInfo: {
    marginTop: 20,
    alignItems: 'center',
  },
  locationTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 5,
  },
  locationText: {
    color: '#B0E0E6',
    fontSize: 14,
  },
  customerCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  customerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  customerAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  avatarText: {
    fontSize: 24,
  },
  customerDetails: {
    flex: 1,
  },
  customerName: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  customerAddress: {
    color: '#B0E0E6',
    fontSize: 14,
    marginBottom: 2,
  },
  customerDistance: {
    color: '#87CEEB',
    fontSize: 12,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  navigationCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
  },
  etaContainer: {
    backgroundColor: '#87CEEB',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 15,
    alignItems: 'center',
  },
  etaText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
  stepsContainer: {
    gap: 12,
  },
  stepItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepNumber: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  stepNumberText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: 'bold',
  },
  stepText: {
    color: '#FFFFFF',
    fontSize: 14,
    flex: 1,
  },
  controlContainer: {
    marginBottom: 20,
  },
  startButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: 'center',
  },
  startButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  controlButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  stopButton: {
    flex: 1,
    backgroundColor: '#F44336',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: 'center',
  },
  stopButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  arrivedButton: {
    flex: 1,
    backgroundColor: '#4CAF50',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: 'center',
  },
  arrivedButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  statusCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 16,
    padding: 20,
  },
  statusTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  statusText: {
    color: '#B0E0E6',
    fontSize: 14,
    lineHeight: 20,
  },
});
