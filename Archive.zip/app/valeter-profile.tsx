import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  Image,
  TextInput,
  Modal,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from './auth-context';
import { valeterVerificationService, ValeterProfileData, ValeterDocument } from '../src/services/ValeterVerificationService';

export default function ValeterProfile() {
  const router = useRouter();
  const { user, logout } = useAuth();
  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showDocumentModal, setShowDocumentModal] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<ValeterDocument | null>(null);

  useEffect(() => {
    if (user) {
      const valeterProfile = valeterVerificationService.getValeterProfile(user.id);
      setProfile(valeterProfile || null);
    }
  }, [user]);

  const handleSaveProfile = () => {
    if (!profile || !user) return;

    valeterVerificationService.updateValeterProfile(user.id, profile);
    setIsEditing(false);
    Alert.alert('Success', 'Profile updated successfully!');
  };

  const handleLogout = () => {
    console.log('Valeter Profile: Logout button pressed');
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: async () => {
            console.log('Valeter Profile: Logout confirmed, calling logout function');
            try {
              await logout();
              console.log('Valeter Profile: Logout successful, navigating to home');
              router.replace('/');
              // Force a page refresh to ensure clean state
              setTimeout(() => {
                router.replace('/');
              }, 100);
            } catch (error) {
              console.error('Valeter Profile: Logout error:', error);
              Alert.alert('Logout Error', 'Failed to logout. Please try again.');
            }
          }
        }
      ]
    );
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      'Delete Account',
      'This action cannot be undone. Are you sure you want to delete your account?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            Alert.alert('Account Deleted', 'Your account has been deleted.');
          }
        }
      ]
    );
  };

  const handleUploadDocument = (document: ValeterDocument) => {
    setSelectedDocument(document);
    setShowDocumentModal(true);
  };

  const simulateDocumentUpload = () => {
    if (!selectedDocument || !user) return;

    // Simulate file upload
    Alert.alert('Uploading...', 'Document upload in progress...');
    
    setTimeout(() => {
      valeterVerificationService.uploadDocument(
        user.id,
        selectedDocument.type,
        'https://example.com/document.pdf'
      );
      
      setShowDocumentModal(false);
      setSelectedDocument(null);
      
      // Refresh profile
      const updatedProfile = valeterVerificationService.getValeterProfile(user.id);
      setProfile(updatedProfile || null);
      
      Alert.alert('Success', `${selectedDocument.name} uploaded successfully!`);
    }, 2000);
  };

  const getVerificationProgress = () => {
    if (!user) return { total: 0, completed: 0, percentage: 0, missing: [] };
    return valeterVerificationService.getVerificationProgress(user.id);
  };

  const getComplianceStatus = () => {
    if (!user) return { compliant: false, issues: [], recommendations: [] };
    return valeterVerificationService.isLegallyCompliant(user.id);
  };

  if (!profile) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading profile...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const progress = getVerificationProgress();
  const compliance = getComplianceStatus();

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Valeter Profile</Text>
          <TouchableOpacity onPress={() => setIsEditing(!isEditing)} style={styles.editButton}>
            <Text style={styles.editButtonText}>{isEditing ? 'Cancel' : 'Edit'}</Text>
          </TouchableOpacity>
        </View>

        {/* Profile Photo Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Profile Photo</Text>
          <View style={styles.photoSection}>
            {profile.profilePhoto ? (
              <Image source={{ uri: profile.profilePhoto }} style={styles.profilePhoto} />
            ) : (
              <View style={styles.photoPlaceholder}>
                <Text style={styles.photoPlaceholderText}>📷</Text>
                <Text style={styles.photoPlaceholderSubtext}>Add Photo</Text>
              </View>
            )}
            <View style={styles.photoInfo}>
              <Text style={styles.photoRequirement}>
                Clear headshot against plain background required
              </Text>
              {profile.verificationBadge && (
                <View style={styles.verifiedBadge}>
                  <Text style={styles.verifiedIcon}>✓</Text>
                  <Text style={styles.verifiedText}>Verified</Text>
                </View>
              )}
            </View>
          </View>
        </View>

        {/* Verification Progress */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Verification Progress</Text>
          <View style={styles.progressCard}>
            <View style={styles.progressHeader}>
              <Text style={styles.progressText}>
                {progress.completed} of {progress.total} completed
              </Text>
              <Text style={styles.progressPercentage}>{progress.percentage}%</Text>
            </View>
            <View style={styles.progressBar}>
              <View 
                style={[
                  styles.progressFill, 
                  { width: `${progress.percentage}%` }
                ]} 
              />
            </View>
            {progress.missing.length > 0 && (
              <Text style={styles.missingText}>
                Missing: {progress.missing.join(', ')}
              </Text>
            )}
          </View>
        </View>

        {/* Personal Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Personal Information</Text>
          <View style={styles.infoCard}>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Name:</Text>
              {isEditing ? (
                <TextInput
                  style={styles.infoInput}
                  value={profile.name}
                  onChangeText={(text) => setProfile({ ...profile, name: text })}
                  placeholder="Enter your name"
                />
              ) : (
                <Text style={styles.infoValue}>{profile.name}</Text>
              )}
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Bio:</Text>
              {isEditing ? (
                <TextInput
                  style={[styles.infoInput, styles.bioInput]}
                  value={profile.bio}
                  onChangeText={(text) => setProfile({ ...profile, bio: text })}
                  placeholder="Tell customers about yourself"
                  multiline
                />
              ) : (
                <Text style={styles.infoValue}>{profile.bio}</Text>
              )}
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Experience:</Text>
              {isEditing ? (
                <TextInput
                  style={styles.infoInput}
                  value={profile.experience}
                  onChangeText={(text) => setProfile({ ...profile, experience: text })}
                  placeholder="e.g., 3+ years"
                />
              ) : (
                <Text style={styles.infoValue}>{profile.experience}</Text>
              )}
            </View>
          </View>
        </View>

        {/* Vehicle Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Vehicle Information</Text>
          <View style={styles.infoCard}>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Make:</Text>
              {isEditing ? (
                <TextInput
                  style={styles.infoInput}
                  value={profile.vehicleDetails.make}
                  onChangeText={(text) => setProfile({
                    ...profile,
                    vehicleDetails: { ...profile.vehicleDetails, make: text }
                  })}
                  placeholder="e.g., Ford"
                />
              ) : (
                <Text style={styles.infoValue}>{profile.vehicleDetails.make || 'Not set'}</Text>
              )}
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Model:</Text>
              {isEditing ? (
                <TextInput
                  style={styles.infoInput}
                  value={profile.vehicleDetails.model}
                  onChangeText={(text) => setProfile({
                    ...profile,
                    vehicleDetails: { ...profile.vehicleDetails, model: text }
                  })}
                  placeholder="e.g., Transit"
                />
              ) : (
                <Text style={styles.infoValue}>{profile.vehicleDetails.model || 'Not set'}</Text>
              )}
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Registration:</Text>
              {isEditing ? (
                <TextInput
                  style={styles.infoInput}
                  value={profile.vehicleDetails.registration}
                  onChangeText={(text) => setProfile({
                    ...profile,
                    vehicleDetails: { ...profile.vehicleDetails, registration: text }
                  })}
                  placeholder="e.g., AB12 CDE"
                />
              ) : (
                <Text style={styles.infoValue}>{profile.vehicleDetails.registration || 'Not set'}</Text>
              )}
            </View>
          </View>
        </View>

        {/* Required Documents */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Required Documents</Text>
          <View style={styles.documentsCard}>
            {profile.documents.map((document) => (
              <TouchableOpacity
                key={document.id}
                style={styles.documentItem}
                onPress={() => handleUploadDocument(document)}
              >
                <View style={styles.documentInfo}>
                  <Text style={styles.documentName}>{document.name}</Text>
                  <Text style={styles.documentDescription}>{document.description}</Text>
                </View>
                <View style={[
                  styles.documentStatus,
                  { backgroundColor: 
                    document.status === 'approved' ? '#4CAF50' :
                    document.status === 'pending' ? '#FF9800' :
                    document.status === 'rejected' ? '#EF4444' : '#666'
                  }
                ]}>
                  <Text style={styles.documentStatusText}>
                    {document.status === 'approved' ? '✓' :
                     document.status === 'pending' ? '⏳' :
                     document.status === 'rejected' ? '✗' : '📄'}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Legal Compliance */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Legal Compliance</Text>
          <View style={[
            styles.complianceCard,
            { backgroundColor: compliance.compliant ? 'rgba(76, 175, 80, 0.1)' : 'rgba(239, 68, 68, 0.1)' }
          ]}>
            <View style={styles.complianceHeader}>
              <Text style={styles.complianceIcon}>
                {compliance.compliant ? '✅' : '⚠️'}
              </Text>
              <Text style={styles.complianceTitle}>
                {compliance.compliant ? 'Legally Compliant' : 'Compliance Issues'}
              </Text>
            </View>
            
            {compliance.issues.length > 0 && (
              <View style={styles.complianceIssues}>
                <Text style={styles.complianceSubtitle}>Issues to resolve:</Text>
                {compliance.issues.map((issue, index) => (
                  <Text key={index} style={styles.complianceIssue}>• {issue}</Text>
                ))}
              </View>
            )}
            
            {compliance.recommendations.length > 0 && (
              <View style={styles.complianceRecommendations}>
                <Text style={styles.complianceSubtitle}>Recommendations:</Text>
                {compliance.recommendations.map((rec, index) => (
                  <Text key={index} style={styles.complianceRecommendation}>• {rec}</Text>
                ))}
              </View>
            )}
          </View>
        </View>

        {/* Save Button */}
        {isEditing && (
          <View style={styles.section}>
            <TouchableOpacity style={styles.saveButton} onPress={handleSaveProfile}>
              <Text style={styles.saveButtonText}>Save Changes</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Account Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Actions</Text>
          
          <TouchableOpacity style={styles.settingItem} onPress={handleLogout}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🚪</Text>
              <Text style={[styles.settingText, styles.logoutText]}>Logout</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem} onPress={handleDeleteAccount}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🗑️</Text>
              <Text style={[styles.settingText, styles.deleteText]}>Delete Account</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem} onPress={() => router.push('/logout-test')}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🧪</Text>
              <Text style={styles.settingText}>Test Logout</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem} onPress={() => router.push('/privacy-settings')}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>⚙️</Text>
              <Text style={styles.settingText}>Privacy & Security Settings</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View style={styles.appInfoSection}>
          <Text style={styles.appInfoText}>Wish a Wash v1.0.0</Text>
          <Text style={styles.appInfoText}>© 2024 Wish a Wash. All rights reserved.</Text>
        </View>
      </ScrollView>

      {/* Document Upload Modal */}
      <Modal
        visible={showDocumentModal}
        transparent={true}
        animationType="slide"
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Upload {selectedDocument?.name}</Text>
            <Text style={styles.modalDescription}>{selectedDocument?.description}</Text>
            
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={simulateDocumentUpload}
              >
                <Text style={styles.modalButtonText}>Upload Document</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonCancel]}
                onPress={() => setShowDocumentModal(false)}
              >
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  editButton: {
    padding: 8,
  },
  editButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  photoSection: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  profilePhoto: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 16,
  },
  photoPlaceholder: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  photoPlaceholderText: {
    fontSize: 24,
    marginBottom: 4,
  },
  photoPlaceholderSubtext: {
    color: '#87CEEB',
    fontSize: 12,
  },
  photoInfo: {
    flex: 1,
  },
  photoRequirement: {
    color: '#E5E7EB',
    fontSize: 14,
    marginBottom: 8,
  },
  verifiedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#4CAF50',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  verifiedIcon: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
    marginRight: 4,
  },
  verifiedText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  progressCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  progressText: {
    color: '#E5E7EB',
    fontSize: 14,
  },
  progressPercentage: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  progressBar: {
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 4,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#87CEEB',
    borderRadius: 4,
  },
  missingText: {
    color: '#EF4444',
    fontSize: 12,
  },
  infoCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  infoLabel: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    width: 100,
  },
  infoValue: {
    color: '#F9FAFB',
    fontSize: 14,
    flex: 1,
  },
  infoInput: {
    color: '#F9FAFB',
    fontSize: 14,
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#87CEEB',
    paddingVertical: 4,
  },
  bioInput: {
    height: 60,
    textAlignVertical: 'top',
  },
  documentsCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  documentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  documentInfo: {
    flex: 1,
  },
  documentName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  documentDescription: {
    color: '#87CEEB',
    fontSize: 12,
  },
  documentStatus: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  documentStatusText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  complianceCard: {
    borderRadius: 12,
    padding: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#87CEEB',
  },
  complianceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  complianceIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  complianceTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  complianceSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginTop: 8,
    marginBottom: 4,
  },
  complianceIssues: {
    marginBottom: 12,
  },
  complianceIssue: {
    color: '#EF4444',
    fontSize: 12,
    marginBottom: 2,
  },
  complianceRecommendations: {
    marginBottom: 8,
  },
  complianceRecommendation: {
    color: '#4CAF50',
    fontSize: 12,
    marginBottom: 2,
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 18,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 24,
    margin: 20,
    width: '90%',
    maxWidth: 400,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  modalDescription: {
    color: '#E5E7EB',
    fontSize: 14,
    marginBottom: 20,
  },
  modalActions: {
    flexDirection: 'row',
    gap: 12,
  },
  modalButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalButtonCancel: {
    backgroundColor: '#666',
  },
  modalButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    fontSize: 20,
    marginRight: 16,
    width: 24,
    textAlign: 'center',
  },
  settingText: {
    color: '#F9FAFB',
    fontSize: 16,
    flex: 1,
  },
  logoutText: {
    color: '#EF4444',
  },
  deleteText: {
    color: '#EF4444',
  },
  settingArrow: {
    color: '#87CEEB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  appInfoSection: {
    padding: 20,
    alignItems: 'center',
  },
  appInfoText: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 4,
  },
});
