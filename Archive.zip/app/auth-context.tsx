import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Session, User as SbUser } from '@supabase/supabase-js';
import { supabase } from '../src/lib/api/real/supabaseClient'; // <- make sure this path is correct
import { makeRedirectUri } from 'expo-auth-session';
import * as WebBrowser from 'expo-web-browser';

WebBrowser.maybeCompleteAuthSession();

/** Your app user model (kept compatible with your existing code) */
export interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  userType: 'customer' | 'valeter';
  role: 'customer' | 'valeter' | 'admin';
  isEmailVerified: boolean;
  createdAt: Date;
  updatedAt: Date;
  // Valeter specific fields
  isVerified?: boolean;
  documentsUploaded?: boolean;
  insuranceVerified?: boolean;
  licenseVerified?: boolean;
  backgroundCheckPassed?: boolean;
}

/** What we expose to the app (kept same signatures as your mock) */
interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  register: (userData: Omit<User, 'id' | 'isEmailVerified' | 'createdAt' | 'updatedAt' | 'role'> & { password: string }) => Promise<boolean>;
  updateUser: (updates: Partial<User>) => Promise<void>;
  updatePassword: (currentPassword: string, newPassword: string) => Promise<void>; // currentPassword not used with Supabase
  updateProfile: (updates: Partial<User>) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  autoLoginCustomer: () => Promise<void>;
  autoLoginValeter: () => Promise<void>;
  hasAdminAccess: () => boolean;
  isBusinessOwner: () => boolean;
  markWelcomeSeen: (userType: 'customer' | 'valeter') => Promise<void>;
  hasSeenWelcome: (userType: 'customer' | 'valeter') => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

/** Admin emails */
const ADMIN_EMAILS = [
  'reece@wishawash.com',
  'charlie@wishawash.com'
];

/**
 * We store extra profile fields in a Supabase table called `profiles`.
 * Shape expected:
 * - id (uuid, primary key) = auth uid
 * - email (text)
 * - name (text)
 * - phone (text)
 * - user_type ('customer'|'valeter')
 * - role ('customer'|'valeter'|'admin')
 * - is_verified, documents_uploaded, insurance_verified, license_verified, background_check_passed (bool)
 * - created_at, updated_at (timestamp)
 */
type ProfileRow = {
  id: string;
  email: string | null;
  name: string | null;
  phone: string | null;
  user_type: 'customer' | 'valeter' | null;
  role: 'customer' | 'valeter' | 'admin' | null;
  is_verified: boolean | null;
  documents_uploaded: boolean | null;
  insurance_verified: boolean | null;
  license_verified: boolean | null;
  background_check_passed: boolean | null;
  created_at: string | null;
  updated_at: string | null;
};

/** Small helper to guarantee we never hang forever */
const withTimeout = <T,>(p: Promise<T>, ms = 12000) =>
  Promise.race<T>([
    p,
    new Promise<T>((_, rej) => setTimeout(() => rej(new Error('timeout')), ms)) as Promise<T>,
  ]);

function sbUserToAppUser(sb: SbUser, profile?: ProfileRow | null): User {
  const now = new Date();
  const created = profile?.created_at ? new Date(profile.created_at) : now;
  const updated = profile?.updated_at ? new Date(profile.updated_at) : now;

  // Decide role: profile.role OR admin if email in ADMIN_EMAILS
  const email = sb.email ?? profile?.email ?? '';
  const adminRole: User['role'] = ADMIN_EMAILS.includes(email) ? 'admin' : (profile?.role ?? 'customer');

  return {
    id: sb.id,
    email,
    name: (profile?.name ?? '') || (sb.user_metadata?.name ?? '') || '',
    phone: (profile?.phone ?? '') || (sb.user_metadata?.phone ?? '') || '',
    userType: (profile?.user_type ?? 'customer') as User['userType'],
    role: adminRole,
    isEmailVerified: !!sb.email_confirmed_at,
    createdAt: created,
    updatedAt: updated,
    isVerified: !!profile?.is_verified,
    documentsUploaded: !!profile?.documents_uploaded,
    insuranceVerified: !!profile?.insurance_verified,
    licenseVerified: !!profile?.license_verified,
    backgroundCheckPassed: !!profile?.background_check_passed,
  };
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const redirectTo = makeRedirectUri({ scheme: 'wishawash' }); // <- set your app scheme in app.json

  /** Fetch profile from DB; if missing, create a minimal one */
  const fetchAndEnsureProfile = async (sbUser: SbUser): Promise<User> => {
    try {
      const sel = await withTimeout(
        supabase
          .from('profiles')
          .select('*')
          .eq('id', sbUser.id)
          .maybeSingle<ProfileRow>(),
        8000
      );

      const data = (sel as any).data as ProfileRow | null;
      const error = (sel as any).error;
      if (error) console.log('[auth] fetch profile error:', error);

      let profile = data ?? null;

      if (!profile) {
        const seed: Partial<ProfileRow> = {
          id: sbUser.id,
          email: sbUser.email ?? '',
          user_type: 'customer',
          role: ADMIN_EMAILS.includes(sbUser.email ?? '') ? 'admin' : 'customer',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };

        const ins = await withTimeout(
          supabase.from('profiles').insert(seed).select().maybeSingle<ProfileRow>(),
          8000
        );
        if ((ins as any).error) console.log('[auth] create profile error:', (ins as any).error);
        profile = (ins as any).data ?? null;
      }

      return sbUserToAppUser(sbUser, profile);
    } catch (e: any) {
      console.warn('[auth] profile fetch/seed timeout or error:', e?.message || e);
      // Fallback to minimal user so the app stays usable
      return sbUserToAppUser(sbUser, null as any);
    }
  };

  /** Load session + set minimal user fast, enrich in background */
  useEffect(() => {
    console.log('[auth] init effect');
    let mounted = true;

    (async () => {
      try {
        const { data } = await withTimeout(supabase.auth.getSession(), 8000);
        if (!mounted) return;

        console.log('[auth] getSession -> hasUser?', !!data?.session?.user);
        setSession(data.session ?? null);

        if (data.session?.user) {
          // Set a minimal user immediately so UI can proceed
          setUser(sbUserToAppUser(data.session.user, null));

          // Enrich in background
          (async () => {
            try {
              const enriched = await fetchAndEnsureProfile(data.session!.user);
              if (mounted) setUser(enriched);
            } catch (e: any) {
              console.warn('[auth] enrich (init) failed:', e?.message || e);
            }
          })();
        } else {
          setUser(null);
        }
      } catch (e: any) {
        console.warn('[auth] getSession failed:', e?.message || e);
      } finally {
        if (mounted) setIsLoading(false);
      }
    })();

    const { data: sub } = supabase.auth.onAuthStateChange((evt, newSession) => {
      console.log('[auth] onAuthStateChange:', evt, 'user?', !!newSession?.user);
      setSession(newSession ?? null);

      const sbUser = newSession?.user ?? null;
      if (!sbUser) {
        setUser(null);
        return;
      }

      // Set minimal user first (non-blocking)
      setUser(sbUserToAppUser(sbUser, null));

      // Then enrich without blocking UI
      (async () => {
        try {
          const enriched = await fetchAndEnsureProfile(sbUser);
          setUser(enriched);
        } catch (e: any) {
          console.warn('[auth] enrich (listener) failed:', e?.message || e);
        }
      })();
    });

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  /** Login with email/password (returns boolean, but with strong logs & timeout) */
  const login: AuthContextType['login'] = async (email, password) => {
    setIsLoading(true);
    try {
      const normalized = email.trim().toLowerCase();
      console.log('[auth] login start', { email: normalized });

      const { data, error } = await withTimeout(
        supabase.auth.signInWithPassword({ email: normalized, password }),
        12000
      );

      if (error) {
        console.error('[auth] signIn error:', error.message);
        return false;
      }
      console.log('[auth] signIn ok -> user?', !!data?.user);
      // session listener will populate user
      return true;
    } catch (e: any) {
      console.error('[auth] signIn exception:', e?.message || e);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  /** Logout */
  const logout: AuthContextType['logout'] = async () => {
    try {
      console.log('[auth] signOut');
      await withTimeout(supabase.auth.signOut(), 8000);
      setUser(null);
    } catch (e: any) {
      console.log('logout error:', e?.message || e);
    }
  };

  /** Register (creates auth user + seed profile) */
  const register: AuthContextType['register'] = async (userData) => {
    setIsLoading(true);
    try {
      const role: User['role'] = ADMIN_EMAILS.includes(userData.email) ? 'admin' : userData.userType;

      const { data, error } = await withTimeout(
        supabase.auth.signUp({
          email: userData.email.trim().toLowerCase(),
          password: userData.password,
          options: {
            emailRedirectTo: redirectTo,
            data: {
              name: userData.name,
              phone: userData.phone,
              user_type: userData.userType,
              role,
            },
          },
        }),
        12000
      );

      if (error) {
        console.log('[auth] signUp error:', error.message);
        return false;
      }

      // After signUp, Supabase may or may not create a session immediately (depends on email confirmation).
      // We still seed a profile row, but it’s okay if it races—fetchAndEnsureProfile will create it later if needed.
      const currentUser = (await supabase.auth.getUser()).data.user;
      if (currentUser) {
        await withTimeout(
          supabase.from('profiles').upsert({
            id: currentUser.id,
            email: currentUser.email,
            name: userData.name,
            phone: userData.phone,
            user_type: userData.userType,
            role,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }),
          8000
        );
      }

      console.log('[auth] signUp ok -> user?', !!data?.user);
      return true;
    } catch (e: any) {
      console.log('register error:', e?.message || e);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  /** Update profile fields in the DB and local state */
  const updateUser: AuthContextType['updateUser'] = async (updates) => {
    if (!user) return;

    const patch: Partial<ProfileRow> = {
      name: updates.name ?? undefined,
      phone: updates.phone ?? undefined,
      user_type: (updates.userType as ProfileRow['user_type']) ?? undefined,
      role: (updates.role as ProfileRow['role']) ?? undefined,
      is_verified: updates.isVerified ?? undefined,
      documents_uploaded: updates.documentsUploaded ?? undefined,
      insurance_verified: updates.insuranceVerified ?? undefined,
      license_verified: updates.licenseVerified ?? undefined,
      background_check_passed: updates.backgroundCheckPassed ?? undefined,
      updated_at: new Date().toISOString(),
    };

    try {
      const res = await withTimeout(
        supabase
          .from('profiles')
          .update(patch)
          .eq('id', user.id)
          .select()
          .maybeSingle<ProfileRow>(),
        8000
      );

      const error = (res as any).error;
      const data = (res as any).data as ProfileRow | null;

      if (error) {
        console.log('update profile error:', error);
        return;
      }

      setUser(prev =>
        prev ? sbUserToAppUser({ ...((session?.user as SbUser) || { id: user.id } as SbUser) }, data ?? null) : prev
      );
    } catch (e: any) {
      console.log('updateUser error:', e?.message || e);
    }
  };

  /** Alias to updateUser to keep your original API */
  const updateProfile: AuthContextType['updateProfile'] = async (updates) => {
    return updateUser(updates);
  };

  /** Supabase doesn’t require the current password to set a new password if the user has a session */
  const updatePassword: AuthContextType['updatePassword'] = async (_currentPassword, newPassword) => {
    if (!session) throw new Error('No active session');
    const { error } = await withTimeout(supabase.auth.updateUser({ password: newPassword }), 8000);
    if (error) throw new Error(error.message);
  };

  /** Send password reset email (magic link will bounce back via your app scheme) */
  const resetPassword: AuthContextType['resetPassword'] = async (email) => {
    const { error } = await withTimeout(
      supabase.auth.resetPasswordForEmail(email.trim().toLowerCase(), { redirectTo }),
      12000
    );
    if (error) throw new Error(error.message);
  };

  /** Demo helpers: try to sign into known test accounts (create them in Supabase first) */
  const autoLoginCustomer: AuthContextType['autoLoginCustomer'] = async () => {
    await login('customer@test.com', 'password123');
  };
  const autoLoginValeter: AuthContextType['autoLoginValeter'] = async () => {
    await login('valeter@test.com', 'password123');
  };

  /** Roles/flags */
  const hasAdminAccess = (): boolean => (user?.role === 'admin') ?? false;

  const isBusinessOwner = (): boolean => {
    // mirror your old logic if you later store a flag; keeping a placeholder here
    // for now return true if their name looks like a business account:
    return Boolean(user?.name && user.name.toLowerCase().includes('ltd'));
  };

  /** Local-only “welcome seen” helpers (same as your mock) */
  const markWelcomeSeen = async (userType: 'customer' | 'valeter'): Promise<void> => {
    try { await AsyncStorage.setItem(`welcome_seen_${userType}`, 'true'); } catch {}
  };
  const hasSeenWelcome = async (userType: 'customer' | 'valeter'): Promise<boolean> => {
    try { return (await AsyncStorage.getItem(`welcome_seen_${userType}`)) === 'true'; } catch { return false; }
  };

  const value = useMemo<AuthContextType>(() => ({
    user,
    isLoading,
    login,
    logout,
    register,
    updateUser,
    updatePassword,
    updateProfile,
    resetPassword,
    autoLoginCustomer,
    autoLoginValeter,
    hasAdminAccess,
    isBusinessOwner,
    markWelcomeSeen,
    hasSeenWelcome,
  }), [user, isLoading, session]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};

export default AuthProvider;