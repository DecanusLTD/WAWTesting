import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import { useAuth } from './auth-context';

const { width, height } = Dimensions.get('window');

interface AnalyticsData {
  period: string;
  revenue: number;
  jobs: number;
  growth: number;
}

interface TeamPerformance {
  name: string;
  jobs: number;
  revenue: number;
  rating: number;
  efficiency: number;
}

export default function BusinessAnalytics() {
  const { user } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData[]>([]);
  const [teamPerformance, setTeamPerformance] = useState<TeamPerformance[]>([]);

  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    // Load mock analytics data
    const mockAnalyticsData: AnalyticsData[] = [
      { period: 'Jan', revenue: 12450, jobs: 89, growth: 12 },
      { period: 'Feb', revenue: 13890, jobs: 102, growth: 15 },
      { period: 'Mar', revenue: 15420, jobs: 115, growth: 18 },
      { period: 'Apr', revenue: 14230, jobs: 98, growth: 8 },
      { period: 'May', revenue: 16890, jobs: 127, growth: 22 },
      { period: 'Jun', revenue: 15420, jobs: 115, growth: 18 },
    ];

    const mockTeamPerformance: TeamPerformance[] = [
      { name: 'Mike Johnson', jobs: 156, revenue: 2840, rating: 4.9, efficiency: 95 },
      { name: 'Sarah Williams', jobs: 89, revenue: 1620, rating: 4.7, efficiency: 88 },
      { name: 'David Brown', jobs: 134, revenue: 2180, rating: 4.8, efficiency: 92 },
      { name: 'Emma Davis', jobs: 67, revenue: 980, rating: 4.6, efficiency: 85 },
    ];

    setAnalyticsData(mockAnalyticsData);
    setTeamPerformance(mockTeamPerformance);

    // Start animations
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handlePeriodChange = async (period: string) => {
    await hapticFeedback.selection();
    setSelectedPeriod(period);
  };

  const handleExportData = async () => {
    await hapticFeedback.impact('medium');
    Alert.alert('Export Data', 'Analytics data exported successfully!');
  };

  const handleViewDetailedReport = async () => {
    await hapticFeedback.impact('medium');
    router.push('/business-detailed-report');
  };

  const totalRevenue = analyticsData.reduce((sum, data) => sum + data.revenue, 0);
  const totalJobs = analyticsData.reduce((sum, data) => sum + data.jobs, 0);
  const averageGrowth = analyticsData.reduce((sum, data) => sum + data.growth, 0) / analyticsData.length;

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Business Analytics</Text>
        <TouchableOpacity style={styles.exportButton} onPress={handleExportData}>
          <Text style={styles.exportButtonText}>📊</Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Period Selector */}
          <View style={styles.periodSelector}>
            <TouchableOpacity
              style={[styles.periodButton, selectedPeriod === 'week' && styles.activePeriodButton]}
              onPress={() => handlePeriodChange('week')}
            >
              <Text style={[styles.periodButtonText, selectedPeriod === 'week' && styles.activePeriodButtonText]}>
                Week
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.periodButton, selectedPeriod === 'month' && styles.activePeriodButton]}
              onPress={() => handlePeriodChange('month')}
            >
              <Text style={[styles.periodButtonText, selectedPeriod === 'month' && styles.activePeriodButtonText]}>
                Month
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.periodButton, selectedPeriod === 'quarter' && styles.activePeriodButton]}
              onPress={() => handlePeriodChange('quarter')}
            >
              <Text style={[styles.periodButtonText, selectedPeriod === 'quarter' && styles.activePeriodButtonText]}>
                Quarter
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.periodButton, selectedPeriod === 'year' && styles.activePeriodButton]}
              onPress={() => handlePeriodChange('year')}
            >
              <Text style={[styles.periodButtonText, selectedPeriod === 'year' && styles.activePeriodButtonText]}>
                Year
              </Text>
            </TouchableOpacity>
          </View>

          {/* Key Metrics */}
          <View style={styles.metricsSection}>
            <Text style={styles.sectionTitle}>Key Performance Metrics</Text>
            <View style={styles.metricsGrid}>
              <View style={styles.metricCard}>
                <Text style={styles.metricValue}>£{totalRevenue.toLocaleString()}</Text>
                <Text style={styles.metricLabel}>Total Revenue</Text>
                <Text style={styles.metricGrowth}>+{averageGrowth.toFixed(1)}% avg growth</Text>
              </View>
              
              <View style={styles.metricCard}>
                <Text style={styles.metricValue}>{totalJobs}</Text>
                <Text style={styles.metricLabel}>Total Jobs</Text>
                <Text style={styles.metricGrowth}>{(totalJobs / analyticsData.length).toFixed(0)} avg/month</Text>
              </View>
              
              <View style={styles.metricCard}>
                <Text style={styles.metricValue}>£{(totalRevenue / totalJobs).toFixed(0)}</Text>
                <Text style={styles.metricLabel}>Avg Job Value</Text>
                <Text style={styles.metricGrowth}>Per completed job</Text>
              </View>
              
              <View style={styles.metricCard}>
                <Text style={styles.metricValue}>4.8⭐</Text>
                <Text style={styles.metricLabel}>Customer Rating</Text>
                <Text style={styles.metricGrowth}>Excellent service</Text>
              </View>
            </View>
          </View>

          {/* Revenue Trend */}
          <View style={styles.trendSection}>
            <Text style={styles.sectionTitle}>Revenue Trend</Text>
            <View style={styles.trendChart}>
              {analyticsData.map((data, index) => (
                <View key={data.period} style={styles.trendBar}>
                  <View 
                    style={[
                      styles.trendBarFill, 
                      { 
                        height: (data.revenue / Math.max(...analyticsData.map(d => d.revenue))) * 100,
                        backgroundColor: data.growth > 15 ? '#10B981' : data.growth > 10 ? '#F59E0B' : '#EF4444'
                      }
                    ]} 
                  />
                  <Text style={styles.trendLabel}>{data.period}</Text>
                  <Text style={styles.trendValue}>£{(data.revenue / 1000).toFixed(1)}k</Text>
                </View>
              ))}
            </View>
          </View>

          {/* Team Performance */}
          <View style={styles.teamSection}>
            <Text style={styles.sectionTitle}>Team Performance</Text>
            <View style={styles.teamList}>
              {teamPerformance.map((member, index) => (
                <View key={member.name} style={styles.teamMemberCard}>
                  <View style={styles.memberRank}>
                    <Text style={styles.rankNumber}>#{index + 1}</Text>
                  </View>
                  <View style={styles.memberInfo}>
                    <Text style={styles.memberName}>{member.name}</Text>
                    <View style={styles.memberStats}>
                      <Text style={styles.memberStat}>{member.jobs} jobs</Text>
                      <Text style={styles.memberStat}>•</Text>
                      <Text style={styles.memberStat}>£{member.revenue}</Text>
                      <Text style={styles.memberStat}>•</Text>
                      <Text style={styles.memberStat}>{member.rating}⭐</Text>
                    </View>
                  </View>
                  <View style={styles.memberEfficiency}>
                    <Text style={styles.efficiencyValue}>{member.efficiency}%</Text>
                    <Text style={styles.efficiencyLabel}>Efficiency</Text>
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Insights */}
          <View style={styles.insightsSection}>
            <Text style={styles.sectionTitle}>Business Insights</Text>
            <View style={styles.insightsList}>
              <View style={styles.insightCard}>
                <Text style={styles.insightIcon}>📈</Text>
                <View style={styles.insightContent}>
                  <Text style={styles.insightTitle}>Revenue Growth</Text>
                  <Text style={styles.insightDescription}>
                    Your business has grown {averageGrowth.toFixed(1)}% on average this period. 
                    Consider expanding your team to capitalize on demand.
                  </Text>
                </View>
              </View>

              <View style={styles.insightCard}>
                <Text style={styles.insightIcon}>👥</Text>
                <View style={styles.insightContent}>
                  <Text style={styles.insightTitle}>Team Performance</Text>
                  <Text style={styles.insightDescription}>
                    Mike Johnson is your top performer with 156 jobs and £2,840 revenue. 
                    Consider training programs for other team members.
                  </Text>
                </View>
              </View>

              <View style={styles.insightCard}>
                <Text style={styles.insightIcon}>⭐</Text>
                <View style={styles.insightContent}>
                  <Text style={styles.insightTitle}>Customer Satisfaction</Text>
                  <Text style={styles.insightDescription}>
                    Your 4.8⭐ rating indicates excellent service quality. 
                    Focus on maintaining this high standard to retain customers.
                  </Text>
                </View>
              </View>
            </View>
          </View>

          {/* Action Buttons */}
          <View style={styles.actionSection}>
            <TouchableOpacity
              style={styles.actionButton}
              onPress={handleViewDetailedReport}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={['#8B5CF6', '#7C3AED']}
                style={styles.actionButtonGradient}
              >
                <Text style={styles.actionButtonText}>View Detailed Report</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  exportButton: {
    padding: 8,
  },
  exportButtonText: {
    fontSize: 20,
  },
  content: {
    flex: 1,
  },
  periodSelector: {
    flexDirection: 'row',
    padding: 20,
    gap: 8,
  },
  periodButton: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 8,
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  activePeriodButton: {
    backgroundColor: '#87CEEB',
  },
  periodButtonText: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
  },
  activePeriodButtonText: {
    color: '#0A1929',
  },
  metricsSection: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  metricCard: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  metricValue: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  metricLabel: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  metricGrowth: {
    color: '#10B981',
    fontSize: 12,
  },
  trendSection: {
    padding: 20,
  },
  trendChart: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    height: 120,
    paddingHorizontal: 10,
  },
  trendBar: {
    flex: 1,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  trendBarFill: {
    width: 20,
    borderRadius: 10,
    marginBottom: 8,
  },
  trendLabel: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 4,
  },
  trendValue: {
    color: '#F9FAFB',
    fontSize: 10,
    fontWeight: '600',
  },
  teamSection: {
    padding: 20,
  },
  teamList: {
    gap: 12,
  },
  teamMemberCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  memberRank: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  rankNumber: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
  memberInfo: {
    flex: 1,
  },
  memberName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  memberStats: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  memberStat: {
    color: '#B0E0E6',
    fontSize: 12,
    marginRight: 4,
  },
  memberEfficiency: {
    alignItems: 'center',
  },
  efficiencyValue: {
    color: '#10B981',
    fontSize: 16,
    fontWeight: 'bold',
  },
  efficiencyLabel: {
    color: '#87CEEB',
    fontSize: 10,
  },
  insightsSection: {
    padding: 20,
  },
  insightsList: {
    gap: 12,
  },
  insightCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  insightIcon: {
    fontSize: 24,
    marginRight: 12,
    marginTop: 2,
  },
  insightContent: {
    flex: 1,
  },
  insightTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  insightDescription: {
    color: '#B0E0E6',
    fontSize: 14,
    lineHeight: 20,
  },
  actionSection: {
    padding: 20,
    paddingBottom: 40,
  },
  actionButton: {
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  actionButtonGradient: {
    paddingVertical: 16,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
