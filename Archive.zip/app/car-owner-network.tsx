import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  TextInput,
  FlatList,
  Image,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from './auth-context';

interface CarOwner {
  id: string;
  name: string;
  profilePicture?: string;
  carDetails: {
    make: string;
    model: string;
    year: number;
    color: string;
    modifications: string[];
  };
  location: string;
  isOnline: boolean;
  lastSeen: string;
  isConnected: boolean;
  socialMedia: {
    instagram?: string;
    facebook?: string;
    twitter?: string;
  };
  interests: string[];
  totalWashes: number;
  memberSince: string;
}

interface CarMeetup {
  id: string;
  title: string;
  description: string;
  location: string;
  date: Date;
  attendees: string[];
  maxAttendees: number;
  organizer: string;
  eventType: 'meetup' | 'show' | 'track_day' | 'charity_wash';
  featured: boolean;
  imageUrl?: string;
}

interface CarEvent {
  id: string;
  title: string;
  description: string;
  location: string;
  startDate: Date;
  endDate: Date;
  eventType: 'car_show' | 'meetup' | 'track_day' | 'charity_event';
  organizer: string;
  attendees: string[];
  maxAttendees: number;
  entryFee: number;
  featured: boolean;
  imageUrl?: string;
}

export default function CarOwnerNetwork() {
  const router = useRouter();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTab, setSelectedTab] = useState<'owners' | 'meetups' | 'events'>('owners');
  const [carOwners, setCarOwners] = useState<CarOwner[]>([]);
  const [meetups, setMeetups] = useState<CarMeetup[]>([]);
  const [events, setEvents] = useState<CarEvent[]>([]);
  const [showCleanestCarModal, setShowCleanestCarModal] = useState(false);
  const [connectedSocialMedia, setConnectedSocialMedia] = useState<{
    instagram?: string;
    facebook?: string;
    twitter?: string;
  }>({});

  useEffect(() => {
    loadNetworkData();
  }, []);

  const loadNetworkData = () => {
    // Simulate car owners data
    const mockCarOwners: CarOwner[] = [
      {
        id: '1',
        name: 'Alex Thompson',
        profilePicture: 'https://via.placeholder.com/100',
        carDetails: {
          make: 'BMW',
          model: 'M3',
          year: 2021,
          color: 'Alpine White',
          modifications: ['Carbon Fiber Lip', 'Exhaust System', 'Wheels']
        },
        location: 'London',
        isOnline: true,
        lastSeen: '2 minutes ago',
        isConnected: true,
        socialMedia: {
          instagram: '@alex_m3',
          facebook: 'Alex Thompson'
        },
        interests: ['Track Days', 'Car Shows', 'Detailing'],
        totalWashes: 45,
        memberSince: '2023'
      },
      {
        id: '2',
        name: 'Sarah Chen',
        profilePicture: 'https://via.placeholder.com/100',
        carDetails: {
          make: 'Porsche',
          model: '911',
          year: 2022,
          color: 'GT Silver',
          modifications: ['Sport Exhaust', 'Carbon Package']
        },
        location: 'Manchester',
        isOnline: true,
        lastSeen: '5 minutes ago',
        isConnected: false,
        socialMedia: {
          instagram: '@sarah_porsche',
          twitter: '@sarah_cars'
        },
        interests: ['Luxury Cars', 'Photography', 'Road Trips'],
        totalWashes: 32,
        memberSince: '2023'
      },
      {
        id: '3',
        name: 'Mike Johnson',
        profilePicture: 'https://via.placeholder.com/100',
        carDetails: {
          make: 'Audi',
          model: 'RS6',
          year: 2023,
          color: 'Nardo Gray',
          modifications: ['Lowering Springs', 'Intake System', 'Tune']
        },
        location: 'Birmingham',
        isOnline: false,
        lastSeen: '1 hour ago',
        isConnected: true,
        socialMedia: {
          instagram: '@mike_rs6',
          facebook: 'Mike Johnson'
        },
        interests: ['Performance', 'Wagons', 'Family Cars'],
        totalWashes: 28,
        memberSince: '2022'
      }
    ];

    // Simulate meetups data
    const mockMeetups: CarMeetup[] = [
      {
        id: '1',
        title: 'Sunday Morning Coffee & Cars',
        description: 'Weekly meetup for coffee and car chat. All makes and models welcome!',
        location: 'London Bridge Car Park',
        date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Next Sunday
        attendees: ['1', '2'],
        maxAttendees: 50,
        organizer: 'Alex Thompson',
        eventType: 'meetup',
        featured: true
      },
      {
        id: '2',
        title: 'BMW M Series Meet',
        description: 'Exclusive meetup for BMW M series owners. Show off your M car!',
        location: 'Manchester Arena Car Park',
        date: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 2 weeks
        attendees: ['1'],
        maxAttendees: 30,
        organizer: 'Sarah Chen',
        eventType: 'meetup',
        featured: false
      }
    ];

    // Simulate events data
    const mockEvents: CarEvent[] = [
      {
        id: '1',
        title: 'Cleanest Car of the Month Competition',
        description: 'Monthly competition to find the cleanest car. Winner gets a free premium wash!',
        location: 'Various Locations',
        startDate: new Date(),
        endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
        eventType: 'car_show',
        organizer: 'Wish a Wash',
        attendees: ['1', '2', '3'],
        maxAttendees: 100,
        entryFee: 0,
        featured: true
      },
      {
        id: '2',
        title: 'Charity Car Wash Event',
        description: 'Join us for a charity car wash event. All proceeds go to local children\'s hospital.',
        location: 'Central London',
        startDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000 + 8 * 60 * 60 * 1000), // 8 hours
        eventType: 'charity_event',
        organizer: 'Wish a Wash',
        attendees: ['1', '2'],
        maxAttendees: 200,
        entryFee: 10,
        featured: true
      }
    ];

    setCarOwners(mockCarOwners);
    setMeetups(mockMeetups);
    setEvents(mockEvents);
  };

  const handleConnect = (ownerId: string) => {
    setCarOwners(prev => 
      prev.map(owner => 
        owner.id === ownerId ? { ...owner, isConnected: true } : owner
      )
    );
    Alert.alert('Connected!', 'You are now connected with this car owner.');
  };

  const handleDisconnect = (ownerId: string) => {
    Alert.alert(
      'Disconnect',
      'Are you sure you want to disconnect from this car owner?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Disconnect',
          style: 'destructive',
          onPress: () => {
            setCarOwners(prev => 
              prev.map(owner => 
                owner.id === ownerId ? { ...owner, isConnected: false } : owner
              )
            );
          }
        }
      ]
    );
  };

  const handleJoinMeetup = (meetupId: string) => {
    const meetup = meetups.find(m => m.id === meetupId);
    if (!meetup) return;

    if (meetup.attendees.includes(user?.id || '')) {
      Alert.alert('Already Joined', 'You are already attending this meetup.');
      return;
    }

    if (meetup.attendees.length >= meetup.maxAttendees) {
      Alert.alert('Full', 'This meetup is at maximum capacity.');
      return;
    }

    setMeetups(prev => 
      prev.map(m => 
        m.id === meetupId 
          ? { ...m, attendees: [...m.attendees, user?.id || ''] }
          : m
      )
    );
    Alert.alert('Joined!', 'You are now attending this meetup.');
  };

  const handleJoinEvent = (eventId: string) => {
    const event = events.find(e => e.id === eventId);
    if (!event) return;

    if (event.attendees.includes(user?.id || '')) {
      Alert.alert('Already Joined', 'You are already registered for this event.');
      return;
    }

    if (event.attendees.length >= event.maxAttendees) {
      Alert.alert('Full', 'This event is at maximum capacity.');
      return;
    }

    setEvents(prev => 
      prev.map(e => 
        e.id === eventId 
          ? { ...e, attendees: [...e.attendees, user?.id || ''] }
          : e
      )
    );
    Alert.alert('Registered!', 'You are now registered for this event.');
  };

  const handleSubmitCleanestCar = () => {
    Alert.alert(
      'Submit Cleanest Car',
      'This would open camera/gallery to submit your car photos for the competition.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Submit Photos', onPress: () => {
          Alert.alert('Submitted!', 'Your car has been submitted for the Cleanest Car competition.');
        }}
      ]
    );
  };

  const renderCarOwnerCard = ({ item }: { item: CarOwner }) => (
    <View style={styles.ownerCard}>
      <View style={styles.ownerHeader}>
        <View style={styles.ownerInfo}>
          <Text style={styles.ownerName}>{item.name}</Text>
          <Text style={styles.carInfo}>
            {item.carDetails.year} {item.carDetails.make} {item.carDetails.model}
          </Text>
          <Text style={styles.carColor}>{item.carDetails.color}</Text>
        </View>
        <View style={styles.statusContainer}>
          <View style={[
            styles.onlineIndicator,
            { backgroundColor: item.isOnline ? '#4CAF50' : '#666' }
          ]} />
          <Text style={styles.statusText}>
            {item.isOnline ? 'Online' : item.lastSeen}
          </Text>
        </View>
      </View>

      <View style={styles.modificationsContainer}>
        {item.carDetails.modifications.map((mod, index) => (
          <View key={index} style={styles.modificationTag}>
            <Text style={styles.modificationText}>{mod}</Text>
          </View>
        ))}
      </View>

      <View style={styles.interestsContainer}>
        {item.interests.map((interest, index) => (
          <View key={index} style={styles.interestTag}>
            <Text style={styles.interestText}>{interest}</Text>
          </View>
        ))}
      </View>

      <View style={styles.statsContainer}>
        <Text style={styles.statsText}>📍 {item.location}</Text>
        <Text style={styles.statsText}>🧽 {item.totalWashes} washes</Text>
        <Text style={styles.statsText}>👤 Member since {item.memberSince}</Text>
      </View>

      <View style={styles.actionButtons}>
        {item.isConnected ? (
          <>
            <TouchableOpacity
              style={[styles.actionButton, styles.messageButton]}
              onPress={() => Alert.alert('Message', `This would open chat with ${item.name}`)}
            >
              <Text style={styles.actionButtonText}>Message</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionButton, styles.disconnectButton]}
              onPress={() => handleDisconnect(item.id)}
            >
              <Text style={styles.actionButtonText}>Disconnect</Text>
            </TouchableOpacity>
          </>
        ) : (
          <TouchableOpacity
            style={[styles.actionButton, styles.connectButton]}
            onPress={() => handleConnect(item.id)}
          >
            <Text style={styles.actionButtonText}>Connect</Text>
          </TouchableOpacity>
        )}
        
        <TouchableOpacity
          style={[styles.actionButton, styles.profileButton]}
          onPress={() => Alert.alert('Profile', `This would show ${item.name}'s detailed profile`)}
        >
          <Text style={styles.actionButtonText}>View Profile</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderMeetupCard = ({ item }: { item: CarMeetup }) => (
    <View style={styles.meetupCard}>
      <View style={styles.meetupHeader}>
        <Text style={styles.meetupTitle}>{item.title}</Text>
        <View style={[
          styles.eventTypeBadge,
          { backgroundColor: item.featured ? '#FFD700' : '#87CEEB' }
        ]}>
          <Text style={styles.eventTypeText}>
            {item.featured ? '⭐ Featured' : item.eventType.toUpperCase()}
          </Text>
        </View>
      </View>
      
      <Text style={styles.meetupDescription}>{item.description}</Text>
      <Text style={styles.meetupLocation}>📍 {item.location}</Text>
      <Text style={styles.meetupDate}>
        📅 {item.date.toLocaleDateString()} at {item.date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
      </Text>
      <Text style={styles.meetupAttendees}>
        👥 {item.attendees.length}/{item.maxAttendees} attending
      </Text>
      
      <TouchableOpacity
        style={[
          styles.joinButton,
          item.attendees.includes(user?.id || '') && styles.joinedButton
        ]}
        onPress={() => handleJoinMeetup(item.id)}
      >
        <Text style={styles.joinButtonText}>
          {item.attendees.includes(user?.id || '') ? 'Joined' : 'Join Meetup'}
        </Text>
      </TouchableOpacity>
    </View>
  );

  const renderEventCard = ({ item }: { item: CarEvent }) => (
    <View style={styles.eventCard}>
      <View style={styles.eventHeader}>
        <Text style={styles.eventTitle}>{item.title}</Text>
        <View style={[
          styles.eventTypeBadge,
          { backgroundColor: item.featured ? '#FFD700' : '#4CAF50' }
        ]}>
          <Text style={styles.eventTypeText}>
            {item.featured ? '⭐ Featured' : item.eventType.toUpperCase()}
          </Text>
        </View>
      </View>
      
      <Text style={styles.eventDescription}>{item.description}</Text>
      <Text style={styles.eventLocation}>📍 {item.location}</Text>
      <Text style={styles.eventDate}>
        📅 {item.startDate.toLocaleDateString()} - {item.endDate.toLocaleDateString()}
      </Text>
      <Text style={styles.eventAttendees}>
        👥 {item.attendees.length}/{item.maxAttendees} registered
      </Text>
      <Text style={styles.eventFee}>
        💰 {item.entryFee === 0 ? 'Free' : `£${item.entryFee}`}
      </Text>
      
      <TouchableOpacity
        style={[
          styles.joinButton,
          item.attendees.includes(user?.id || '') && styles.joinedButton
        ]}
        onPress={() => handleJoinEvent(item.id)}
      >
        <Text style={styles.joinButtonText}>
          {item.attendees.includes(user?.id || '') ? 'Registered' : 'Register'}
        </Text>
      </TouchableOpacity>
    </View>
  );

  const filteredCarOwners = carOwners.filter(owner =>
    owner.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    owner.carDetails.make.toLowerCase().includes(searchQuery.toLowerCase()) ||
    owner.carDetails.model.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Car Owner Network</Text>
          <TouchableOpacity onPress={() => setShowCleanestCarModal(true)} style={styles.cleanestCarButton}>
            <Text style={styles.cleanestCarButtonText}>🏆</Text>
          </TouchableOpacity>
        </View>

        {/* Cleanest Car Competition Banner */}
        <View style={styles.competitionBanner}>
          <Text style={styles.competitionTitle}>🏆 Cleanest Car of the Month</Text>
          <Text style={styles.competitionDescription}>
            Submit your car photos for a chance to win a free premium wash!
          </Text>
          <TouchableOpacity style={styles.submitButton} onPress={handleSubmitCleanestCar}>
            <Text style={styles.submitButtonText}>Submit Your Car</Text>
          </TouchableOpacity>
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <TextInput
            style={styles.searchInput}
            placeholder="Search car owners, makes, models..."
            placeholderTextColor="#87CEEB"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {/* Tab Navigation */}
        <View style={styles.tabContainer}>
          <TouchableOpacity
            style={[styles.tabButton, selectedTab === 'owners' && styles.tabButtonActive]}
            onPress={() => setSelectedTab('owners')}
          >
            <Text style={[styles.tabButtonText, selectedTab === 'owners' && styles.tabButtonTextActive]}>
              Car Owners ({carOwners.length})
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.tabButton, selectedTab === 'meetups' && styles.tabButtonActive]}
            onPress={() => setSelectedTab('meetups')}
          >
            <Text style={[styles.tabButtonText, selectedTab === 'meetups' && styles.tabButtonTextActive]}>
              Meetups ({meetups.length})
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.tabButton, selectedTab === 'events' && styles.tabButtonActive]}
            onPress={() => setSelectedTab('events')}
          >
            <Text style={[styles.tabButtonText, selectedTab === 'events' && styles.tabButtonTextActive]}>
              Events ({events.length})
            </Text>
          </TouchableOpacity>
        </View>

        {/* Content */}
        {selectedTab === 'owners' && (
          <View style={styles.contentContainer}>
            <FlatList
              data={filteredCarOwners}
              renderItem={renderCarOwnerCard}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
            />
          </View>
        )}

        {selectedTab === 'meetups' && (
          <View style={styles.contentContainer}>
            <FlatList
              data={meetups}
              renderItem={renderMeetupCard}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
            />
          </View>
        )}

        {selectedTab === 'events' && (
          <View style={styles.contentContainer}>
            <FlatList
              data={events}
              renderItem={renderEventCard}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
            />
          </View>
        )}

        {/* Social Features */}
        <View style={styles.socialFeaturesContainer}>
          <Text style={styles.socialFeaturesTitle}>🔗 Connect Your Social Media</Text>
          <View style={styles.socialButtons}>
            <TouchableOpacity style={styles.socialButton}>
              <Text style={styles.socialButtonText}>📸 Instagram</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.socialButton}>
              <Text style={styles.socialButtonText}>📘 Facebook</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.socialButton}>
              <Text style={styles.socialButtonText}>🐦 Twitter</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  cleanestCarButton: {
    padding: 8,
  },
  cleanestCarButtonText: {
    fontSize: 24,
  },
  competitionBanner: {
    backgroundColor: 'rgba(255, 215, 0, 0.2)',
    margin: 20,
    padding: 20,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#FFD700',
  },
  competitionTitle: {
    color: '#FFD700',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  competitionDescription: {
    color: '#E5E7EB',
    fontSize: 14,
    marginBottom: 16,
  },
  submitButton: {
    backgroundColor: '#FFD700',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  submitButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: 'bold',
  },
  searchContainer: {
    padding: 20,
  },
  searchInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    color: '#F9FAFB',
    fontSize: 16,
  },
  tabContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 8,
    marginHorizontal: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    alignItems: 'center',
  },
  tabButtonActive: {
    backgroundColor: '#87CEEB',
  },
  tabButtonText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  tabButtonTextActive: {
    color: '#0A1929',
  },
  contentContainer: {
    padding: 20,
  },
  ownerCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  ownerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  ownerInfo: {
    flex: 1,
  },
  ownerName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  carInfo: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 2,
  },
  carColor: {
    color: '#E5E7EB',
    fontSize: 12,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  onlineIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  statusText: {
    color: '#87CEEB',
    fontSize: 12,
  },
  modificationsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 12,
  },
  modificationTag: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginRight: 8,
    marginBottom: 4,
  },
  modificationText: {
    color: '#87CEEB',
    fontSize: 12,
  },
  interestsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 12,
  },
  interestTag: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginRight: 8,
    marginBottom: 4,
  },
  interestText: {
    color: '#4CAF50',
    fontSize: 12,
  },
  statsContainer: {
    marginBottom: 12,
  },
  statsText: {
    color: '#E5E7EB',
    fontSize: 12,
    marginBottom: 2,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  connectButton: {
    backgroundColor: '#4CAF50',
  },
  disconnectButton: {
    backgroundColor: '#EF4444',
  },
  messageButton: {
    backgroundColor: '#2196F3',
  },
  profileButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  meetupCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  meetupHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  meetupTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    flex: 1,
  },
  eventTypeBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  eventTypeText: {
    color: '#0A1929',
    fontSize: 10,
    fontWeight: 'bold',
  },
  meetupDescription: {
    color: '#E5E7EB',
    fontSize: 14,
    marginBottom: 8,
  },
  meetupLocation: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 4,
  },
  meetupDate: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 4,
  },
  meetupAttendees: {
    color: '#E5E7EB',
    fontSize: 12,
    marginBottom: 12,
  },
  eventCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  eventHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  eventTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    flex: 1,
  },
  eventDescription: {
    color: '#E5E7EB',
    fontSize: 14,
    marginBottom: 8,
  },
  eventLocation: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 4,
  },
  eventDate: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 4,
  },
  eventAttendees: {
    color: '#E5E7EB',
    fontSize: 12,
    marginBottom: 4,
  },
  eventFee: {
    color: '#E5E7EB',
    fontSize: 12,
    marginBottom: 12,
  },
  joinButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  joinedButton: {
    backgroundColor: '#666',
  },
  joinButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  socialFeaturesContainer: {
    padding: 20,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    margin: 20,
    borderRadius: 12,
  },
  socialFeaturesTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  socialButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  socialButton: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  socialButtonText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
});
