import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  ScrollView,
  StatusBar,
} from 'react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width, height: _height } = Dimensions.get('window');

interface OnboardingSlide {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  icon: string;
  color: string;
}

const slides: OnboardingSlide[] = [
  {
    id: 1,
    title: 'Wish a Wash',
    subtitle: 'The First AI-Powered Car Care Platform',
    description: 'Revolutionizing the industry by seamlessly connecting professional valeters with customers through intelligent matching, real-time tracking, and premium service delivery.',
    icon: '🧽',
    color: '#87CEEB',
  },
  {
    id: 2,
    title: 'Smart Booking System',
    subtitle: 'AI-Powered Scheduling',
    description: 'Our intelligent platform matches you with the perfect valeter, suggests optimal times, and handles all the logistics. Book in seconds, not minutes.',
    icon: '🧠',
    color: '#4CAF50',
  },
  {
    id: 3,
    title: 'Fair Pricing',
    subtitle: 'Win-Win for Everyone',
    description: 'Transparent pricing that ensures fair compensation for valeters while keeping costs reasonable for customers. Everyone wins with our balanced approach.',
    icon: '⚖️',
    color: '#9C27B0',
  },
  {
    id: 4,
    title: 'Live Tracking',
    subtitle: 'Real-Time Updates',
    description: 'Track your valeter\'s location in real-time and receive instant updates on arrival time. Know exactly when your professional valeter will arrive.',
    icon: '📍',
    color: '#2196F3',
  },
  {
    id: 5,
    title: 'Premium Quality',
    subtitle: 'Excellence Guaranteed',
    description: 'Expert valeters with professional-grade equipment and eco-friendly products. Your vehicle receives the highest standard of care and attention to detail.',
    icon: '🌱',
    color: '#4CAF50',
  },
];

export default function OnboardingScreen() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const scrollViewRef = useRef<ScrollView>(null);
  
  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const iconAnim = useRef(new Animated.Value(0)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Initial animations
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(iconAnim, {
        toValue: 1,
        duration: 1200,
        useNativeDriver: true,
      }),
    ]).start();

    // Progress animation
    Animated.timing(progressAnim, {
      toValue: (currentSlide + 1) / slides.length,
      duration: 500,
      useNativeDriver: false,
    }).start();
  }, [currentSlide]);

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      const nextSlide = currentSlide + 1;
      setCurrentSlide(nextSlide);
      scrollViewRef.current?.scrollTo({
        x: nextSlide * width,
        animated: true,
      });
    } else {
      handleGetStarted();
    }
  };

  const handleSkip = () => {
    handleGetStarted();
  };

  const handleGetStarted = async () => {
    try {
      // Mark onboarding as seen
      await AsyncStorage.setItem('onboarding_seen', 'true');
      router.replace('/login');
    } catch (error) {
      console.error('Error saving onboarding status:', error);
      router.replace('/login');
    }
  };

  const handleScroll = (event: any) => {
    const offsetX = event.nativeEvent.contentOffset.x;
    const slideIndex = Math.round(offsetX / width);
    if (slideIndex !== currentSlide) {
      setCurrentSlide(slideIndex);
    }
  };

  const renderSlide = (slide: OnboardingSlide, _index: number) => {
    // const isActive = index === currentSlide;
    
    return (
      <View key={slide.id} style={[styles.slide, { width }]}>
        <Animated.View
          style={[
            styles.iconContainer,
            {
              backgroundColor: slide.color + '20',
              transform: [
                {
                  scale: iconAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.5, 1],
                  }),
                },
              ],
            },
          ]}
        >
          <Text style={styles.icon}>{slide.icon}</Text>
        </Animated.View>

        <Animated.View
          style={[
            styles.content,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <Text style={styles.title}>{slide.title}</Text>
          <Text style={styles.subtitle}>{slide.subtitle}</Text>
          <Text style={styles.description}>{slide.description}</Text>
        </Animated.View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      
      {/* Progress Bar */}
      <View style={styles.progressContainer}>
        <View style={styles.progressBar}>
          <Animated.View
            style={[
              styles.progressFill,
              {
                width: progressAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: ['0%', '100%'],
                }),
              },
            ]}
          />
        </View>
        <TouchableOpacity style={styles.skipButton} onPress={handleSkip}>
          <Text style={styles.skipText}>Skip</Text>
        </TouchableOpacity>
      </View>

      {/* Slides */}
      <ScrollView
        ref={scrollViewRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        style={styles.scrollView}
      >
        {slides.map((slide, index) => renderSlide(slide, index))}
      </ScrollView>

      {/* Enhanced Navigation */}
      <View style={styles.navigation}>
        <View style={styles.navigationLeft}>
          <View style={styles.dots}>
            {slides.map((_, index) => (
              <Animated.View
                key={index}
                style={[
                  styles.dot,
                  index === currentSlide && styles.activeDot,
                  {
                    transform: [
                      {
                        scale: index === currentSlide ? 1.2 : 1,
                      },
                    ],
                  },
                ]}
              />
            ))}
          </View>
        </View>

        <View style={styles.navigationRight}>
          <TouchableOpacity style={styles.nextButton} onPress={handleNext}>
            <Text style={styles.nextButtonText}>
              {currentSlide === slides.length - 1 ? 'Get Started' : 'Next'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  progressContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
  },
  progressBar: {
    flex: 1,
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 2,
    marginRight: 20,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#87CEEB',
    borderRadius: 2,
  },
  skipButton: {
    paddingHorizontal: 15,
    paddingVertical: 8,
  },
  skipText: {
    color: '#B0E0E6',
    fontSize: 16,
    fontWeight: '600',
  },
  scrollView: {
    flex: 1,
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
    paddingVertical: 60,
  },
  iconContainer: {
    width: 140,
    height: 140,
    borderRadius: 70,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 50,
    borderWidth: 4,
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.15)',
    shadowColor: '#87CEEB',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 12,
  },
  icon: {
    fontSize: 70,
  },
  content: {
    alignItems: 'center',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 20,
    color: '#87CEEB',
    textAlign: 'center',
    marginBottom: 20,
    fontWeight: '600',
  },
  description: {
    fontSize: 16,
    color: '#B0E0E6',
    textAlign: 'center',
    lineHeight: 24,
    paddingHorizontal: 20,
  },
  navigation: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 50,
  },
  navigationLeft: {
    flex: 1,
    alignItems: 'flex-start',
  },
  navigationRight: {
    flex: 1,
    alignItems: 'flex-end',
  },
  dots: {
    flexDirection: 'row',
    gap: 8,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  activeDot: {
    backgroundColor: '#87CEEB',
    width: 24,
  },
  nextButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 25,
    paddingHorizontal: 30,
    paddingVertical: 15,
    minWidth: 120,
    alignItems: 'center',
  },
  nextButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
