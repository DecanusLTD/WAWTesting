import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import * as Location from 'expo-location';
import { useAuth } from './auth-context';
import { supabase } from '../src/lib/api/real/supabaseClient';
import { pricingEngine } from '../src/utils/pricing-engine';

type ServiceId = 'wash' | 'valet' | 'priority_wash';
type KnownArea =
  | 'Current Location'
  | 'Central London'
  | 'West London'
  | 'East London'
  | 'North London'
  | 'South London';

const SERVICES: { id: ServiceId; name: string; price: number; duration: string; icon: string }[] = [
  { id: 'wash',          name: 'Quick Wash',   price: 15, duration: '15 min', icon: '🚿' },
  { id: 'valet',         name: 'Full Valet',   price: 25, duration: '30 min', icon: '✨' },
  { id: 'priority_wash', name: 'Express Wash', price: 35, duration: '10 min', icon: '⚡' },
];

// Approximate centroids for quick presets
const AREA_COORDS: Record<Exclude<KnownArea, 'Current Location'>, { lat: number; lng: number; address: string }> = {
  'Central London': { lat: 51.5074, lng: -0.1278, address: 'Central London' },
  'West London':    { lat: 51.5136, lng: -0.3043, address: 'West London' },
  'East London':    { lat: 51.5310, lng: -0.0550, address: 'East London' },
  'North London':   { lat: 51.5667, lng: -0.1333, address: 'North London' },
  'South London':   { lat: 51.4450, lng: -0.1600, address: 'South London' },
};

export default function EnhancedBooking() {
  console.log('📍 Rendering EnhancedBooking');

  const router = useRouter();
  const { user } = useAuth();

  const [selectedService, setSelectedService] = useState<ServiceId>('wash');
  const [selectedLocation, setSelectedLocation] = useState<KnownArea>('Central London');
  const [isBooking, setIsBooking] = useState(false);

  const LOCATIONS: KnownArea[] = [
    'Current Location',
    'Central London',
    'West London',
    'East London',
    'North London',
    'South London',
  ];

  /** Resolve lat/lng/address based on user choice */
  const resolveLocation = async (): Promise<{ address: string; lat: number; lng: number } | null> => {
    if (selectedLocation !== 'Current Location') {
      const preset = AREA_COORDS[selectedLocation];
      return { address: preset.address, lat: preset.lat, lng: preset.lng };
    }

    // Current Location flow
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert(
        'Permission Needed',
        'Location permission is required to use your current location. Please choose a preset area or enable location access in Settings.'
      );
      return null;
    }

    try {
      const pos = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
        mayShowUserSettingsDialog: true,
      });

      // Try to reverse-geocode into a readable address (best effort; safe to skip if it fails)
      let address = 'Current Location';
      try {
        const geocode = await Location.reverseGeocodeAsync({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
        });
        if (geocode?.[0]) {
          const g = geocode[0];
          address =
            [g.name, g.street, g.city, g.region, g.postalCode, g.country]
              .filter(Boolean)
              .join(', ') || 'Current Location';
        }
      } catch {
        // ignore reverse geocode errors
      }

      return {
        address,
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
      };
    } catch (e: any) {
      console.log('[EnhancedBooking] getCurrentPosition error:', e?.message || e);
      Alert.alert('Location Error', 'Unable to get your current location. Pick a preset area instead.');
      return null;
    }
  };

  const handleBookService = async () => {
    if (!user) {
      Alert.alert('Error', 'Please login to book a service');
      return;
    }
    if (isBooking) return;

    setIsBooking(true);

    try {
      // 1) Resolve location
      const loc = await resolveLocation();
      if (!loc) {
        setIsBooking(false);
        return;
      }

      // 2) Price calculation via your pricing engine
      const timeOfDay = pricingEngine.getTimeOfDay();
      const dayOfWeek = pricingEngine.getDayOfWeek();
      const demand = pricingEngine.getDemandLevel(loc.address, timeOfDay, dayOfWeek);
      const priceBreakdown = pricingEngine.calculatePrice({
        serviceType: selectedService,
        location: loc.address,
        timeOfDay,
        dayOfWeek,
        demand,
        weather: 'sunny',
        vehicleSize: 'medium',
      });
      const finalPrice = Math.round(priceBreakdown.totalPrice);

      // 3) Build payload for Supabase `bookings`
      const payload = {
        user_id: user.id,                    // RLS must allow: user_id = auth.uid()
        service_type: selectedService,       // 'wash' | 'valet' | 'priority_wash'
        scheduled_at: new Date().toISOString(),
        status: 'scheduled',                 // must exist in your enum
        price: finalPrice,
        valeter_id: null,

        // Location fields (ensure these columns exist in DB)
        location_address: loc.address,
        location_lat: loc.lat,
        location_lng: loc.lng,
      };

      // 4) Insert (no returning to avoid RLS select issues)
      const { error } = await supabase
        .from('bookings')
        .insert([payload], { returning: 'minimal' });

      if (error) {
        console.error('[EnhancedBooking] Insert error:', {
          message: error.message,
          details: (error as any)?.details,
          code: (error as any)?.code,
          hint: (error as any)?.hint,
        });
        Alert.alert('Booking Failed', error.message || 'Please try again.');
        return;
      }

      // 5) Success UI
      const serviceName = SERVICES.find(s => s.id === selectedService)?.name || 'Service';
      Alert.alert(
        'Booking Successful! 🎉',
        `Your ${serviceName} has been booked for £${finalPrice} at ${loc.address}. We’re finding you a valeter…`,
        [
          { text: 'Track Booking', onPress: () => router.push('/tracking') },
          { text: 'Back to Dashboard', onPress: () => router.push('/owner-dashboard') },
        ]
      );
    } catch (err: any) {
      console.error('[EnhancedBooking] Unexpected error:', err);
      Alert.alert('Error', err?.message || 'Something went wrong.');
    } finally {
      setIsBooking(false);
    }
  };

  const handleCancelBooking = () => {
    Alert.alert(
      'Cancel Booking',
      'Are you sure you want to cancel this booking?',
      [
        { text: 'Keep Booking', style: 'cancel' },
        {
          text: 'Cancel Booking',
          style: 'destructive',
          onPress: () => {
            Alert.alert('Booking Cancelled', 'Your booking has been cancelled.');
            router.push('/owner-dashboard');
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Book Service</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Service Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Choose Service</Text>
          {SERVICES.map((service) => (
            <TouchableOpacity
              key={service.id}
              style={[
                styles.serviceCard,
                selectedService === service.id && styles.selectedServiceCard,
              ]}
              onPress={() => setSelectedService(service.id)}
              disabled={isBooking}
            >
              <Text style={styles.serviceIcon}>{service.icon}</Text>
              <View style={styles.serviceInfo}>
                <Text style={styles.serviceName}>{service.name}</Text>
                <Text style={styles.serviceDetails}>
                  {service.duration} • £{service.price}
                </Text>
              </View>
              {selectedService === service.id && <Text style={styles.selectedIcon}>✓</Text>}
            </TouchableOpacity>
          ))}
        </View>

        {/* Location Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Select Location</Text>
          {LOCATIONS.map((location) => (
            <TouchableOpacity
              key={location}
              style={[
                styles.locationCard,
                selectedLocation === location && styles.selectedLocationCard,
              ]}
              onPress={() => setSelectedLocation(location)}
              disabled={isBooking}
            >
              <Text style={styles.locationText}>{location}</Text>
              {selectedLocation === location && <Text style={styles.selectedIcon}>✓</Text>}
            </TouchableOpacity>
          ))}
        </View>

        {/* Booking Actions */}
        <View style={styles.bookingSection}>
          <TouchableOpacity
            style={[styles.bookButton, isBooking && styles.bookButtonDisabled]}
            onPress={handleBookService}
            disabled={isBooking}
          >
            {isBooking ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <Text style={styles.bookButtonText}>Book Now</Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.cancelButton}
            onPress={handleCancelBooking}
            disabled={isBooking}
          >
            <Text style={styles.cancelButtonText}>Cancel</Text>
          </TouchableOpacity>
        </View>

        {/* Security / info */}
        <View style={styles.securityNotice}>
          <Text style={styles.securityIcon}>🔒</Text>
          <Text style={styles.securityText}>
            Payments are coming soon. For now, bookings are created without charging your card.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

/* ===== Styles ===== */
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  scrollView: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 20, borderBottomWidth: 1, borderBottomColor: '#1E3A8A',
  },
  backButton: { padding: 8 },
  backButtonText: { color: '#87CEEB', fontSize: 16 },
  headerTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: 'bold' },
  placeholder: { width: 60 },
  section: { padding: 20, borderBottomWidth: 1, borderBottomColor: '#1E3A8A' },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: 'bold', marginBottom: 8 },

  serviceCard: {
    flexDirection: 'row', alignItems: 'center', padding: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.05)', borderRadius: 12, marginBottom: 12,
  },
  selectedServiceCard: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)', borderColor: '#87CEEB', borderWidth: 2,
  },
  serviceIcon: { fontSize: 24, marginRight: 16 },
  serviceInfo: { flex: 1 },
  serviceName: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
  serviceDetails: { color: '#87CEEB', fontSize: 14, marginTop: 4 },

  locationCard: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 16, backgroundColor: 'rgba(255, 255, 255, 0.05)', borderRadius: 12, marginBottom: 12,
  },
  selectedLocationCard: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)', borderColor: '#87CEEB', borderWidth: 2,
  },
  locationText: { color: '#F9FAFB', fontSize: 16 },

  bookingSection: { padding: 20 },
  bookButton: {
    backgroundColor: '#4CAF50', paddingVertical: 16, paddingHorizontal: 24,
    borderRadius: 12, alignItems: 'center', marginBottom: 12,
  },
  bookButtonDisabled: { backgroundColor: '#666' },
  bookButtonText: { color: '#FFFFFF', fontSize: 18, fontWeight: 'bold' },
  cancelButton: {
    backgroundColor: 'transparent', paddingVertical: 16, paddingHorizontal: 24,
    borderRadius: 12, borderWidth: 2, borderColor: '#EF4444', alignItems: 'center',
  },
  cancelButtonText: { color: '#EF4444', fontSize: 16, fontWeight: 'bold' },

  securityNotice: {
    flexDirection: 'row', alignItems: 'center', padding: 20,
    backgroundColor: 'rgba(76, 175, 80, 0.1)', margin: 20, borderRadius: 12,
  },
  securityIcon: { fontSize: 20, marginRight: 12, color: '#4CAF50' },
  securityText: { color: '#4CAF50', fontSize: 14, flex: 1 },
});