import React, { useMemo, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { WebView } from 'react-native-webview';
import { GOOGLE_MAPS_API_KEY } from '../../src/config/google-maps';

type Loc = { latitude: number; longitude: number; address?: string };
type Pin = { latitude: number; longitude: number; title?: string; description?: string };

interface ExpoMapProps {
  /** Valeter pin (optional) */
  valeterLocation?: Loc | null;
  /** User pin (optional) */
  userLocation?: Loc | null;
  /** Extra pins (e.g. all open jobs for valeter) */
  markers?: Pin[];
  /** Show/hide map */
  showMap: boolean;
  /** Only affects titles/labels */
  isCustomerView?: boolean;
}

const DEFAULT_CENTER: Loc = { latitude: 51.5074, longitude: -0.1278, address: 'London' };

export default function ExpoMap({
  valeterLocation = null,
  userLocation = null,
  markers = [],
  showMap,
  isCustomerView = true,
}: ExpoMapProps) {
  const [mapError, setMapError] = useState<string | null>(null);
  const [mapLoaded, setMapLoaded] = useState<boolean>(false);

  if (!showMap) return null;

  // Pick a safe center
  const center = useMemo<Loc>(() => {
    if (userLocation?.latitude != null && userLocation?.longitude != null) return userLocation;
    if (valeterLocation?.latitude != null && valeterLocation?.longitude != null) return valeterLocation;
    const first = markers?.[0];
    if (first?.latitude != null && first?.longitude != null)
      return { latitude: first.latitude, longitude: first.longitude, address: first.title };
    return DEFAULT_CENTER;
  }, [userLocation, valeterLocation, markers]);

  const createMapHTML = () => {
    // Build JS arrays for pins (guarding undefineds)
    const valeterJs =
      valeterLocation?.latitude != null && valeterLocation?.longitude != null
        ? `{ lat: ${valeterLocation.latitude}, lng: ${valeterLocation.longitude}, title: "${isCustomerView ? 'Valeter' : 'You'}", desc: "${valeterLocation.address || ''}" }`
        : 'null';

    const userJs =
      userLocation?.latitude != null && userLocation?.longitude != null
        ? `{ lat: ${userLocation.latitude}, lng: ${userLocation.longitude}, title: "${isCustomerView ? 'Your Location' : 'Job Area'}", desc: "${userLocation.address || ''}" }`
        : 'null';

    const extraMarkersJs = (markers || [])
      .filter(m => m?.latitude != null && m?.longitude != null)
      .map(
        m =>
          `{ lat: ${m.latitude}, lng: ${m.longitude}, title: ${JSON.stringify(m.title || 'Job')}, desc: ${JSON.stringify(
            m.description || ''
          )} }`
      )
      .join(',');

    const valeterSvg = encodeURIComponent(
      `<svg width="50" height="50" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg"><circle cx="25" cy="25" r="22" fill="#87CEEB" stroke="#1E3A8A" stroke-width="3"/><text x="25" y="32" text-anchor="middle" font-size="24" font-weight="bold">🧽</text></svg>`
    );
    const userSvg = encodeURIComponent(
      `<svg width="50" height="50" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg"><circle cx="25" cy="25" r="22" fill="#10B981" stroke="#1E3A8A" stroke-width="3"/><text x="25" y="32" text-anchor="middle" font-size="24" font-weight="bold">📍</text></svg>`
    );

    return `<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    html,body,#map{height:100%;margin:0;padding:0}
  </style>
</head>
<body>
  <div id="map"></div>
  <script>
    let map, valeterMarker, userMarker;

    const center = { lat: ${center.latitude}, lng: ${center.longitude} };
    const valeter = ${valeterJs};
    const user = ${userJs};
    const extraPins = [${extraMarkersJs}];

    function addMarker(pos, title, desc, iconUrl) {
      return new google.maps.Marker({
        position: pos,
        map: map,
        title: title || '',
        icon: iconUrl ? { url: iconUrl, scaledSize: new google.maps.Size(50, 50), anchor: new google.maps.Point(25, 25) } : undefined
      });
    }

    function initMap() {
      map = new google.maps.Map(document.getElementById('map'), {
        center: center,
        zoom: 14,
        disableDefaultUI: true,
        zoomControl: true,
        streetViewControl: false,
        mapTypeControl: false,
        fullscreenControl: false,
      });

      const bounds = new google.maps.LatLngBounds();
      let anyBounds = false;

      if (valeter) {
        valeterMarker = addMarker({lat: valeter.lat, lng: valeter.lng}, valeter.title, valeter.desc, 'data:image/svg+xml;charset=UTF-8,${valeterSvg}');
        bounds.extend(valeterMarker.getPosition()); anyBounds = true;
      }
      if (user) {
        userMarker = addMarker({lat: user.lat, lng: user.lng}, user.title, user.desc, 'data:image/svg+xml;charset=UTF-8,${userSvg}');
        bounds.extend(userMarker.getPosition()); anyBounds = true;
      }

      if (extraPins && extraPins.length) {
        extraPins.forEach((p) => {
          const mk = addMarker({lat: p.lat, lng: p.lng}, p.title, p.desc, null);
          bounds.extend(mk.getPosition()); anyBounds = true;
        });
      }

      if (anyBounds) {
        map.fitBounds(bounds);
        const ls = google.maps.event.addListenerOnce(map, 'bounds_changed', () => {
          if (map.getZoom() > 16) map.setZoom(16);
          google.maps.event.removeListener(ls);
        });
      } else {
        map.setCenter(center);
        map.setZoom(14);
      }
    }
  </script>
  <script async defer src="https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&callback=initMap"></script>
</body>
</html>`;
  };

  return (
    <View style={styles.mapContainer}>
      <View style={styles.mapHeader}>
        <Text style={styles.mapTitle}>🗺️ Live Map</Text>
        <Text style={styles.mapSubtitle}>
          {isCustomerView ? 'Follow your valeter' : 'Jobs around you'}
        </Text>
      </View>

      <View style={styles.mapContent}>
        {mapError ? (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>Map error: {mapError}</Text>
            <TouchableOpacity style={styles.retryButton} onPress={() => { setMapError(null); setMapLoaded(false); }}>
              <Text style={styles.retryButtonText}>Retry</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <WebView
            source={{ html: createMapHTML() }}
            style={styles.map}
            onLoad={() => setMapLoaded(true)}
            onError={(err) => setMapError(err?.nativeEvent?.description || 'Unknown map error')}
            javaScriptEnabled
            domStorageEnabled
            startInLoadingState
            bounces={false}
            scrollEnabled={false}
          />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  mapContainer: { flex: 1, backgroundColor: '#0A1929' },
  mapHeader: {
    padding: 20,
    backgroundColor: '#1E3A8A',
    borderBottomWidth: 1,
    borderBottomColor: '#87CEEB',
  },
  mapTitle: { fontSize: 22, fontWeight: 'bold', color: '#87CEEB', marginBottom: 5 },
  mapSubtitle: { fontSize: 16, color: '#B0E0E6' },
  mapContent: { flex: 1, position: 'relative' },
  map: { flex: 1, width: '100%', height: '100%' },
  errorContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#1E3A8A' },
  errorText: { color: '#ff6b6b', fontSize: 16, textAlign: 'center', marginBottom: 20 },
  retryButton: { backgroundColor: '#87CEEB', paddingHorizontal: 20, paddingVertical: 10, borderRadius: 20 },
  retryButtonText: { color: '#0A1929', fontSize: 14, fontWeight: 'bold' },
});