import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  Modal,
  TextInput,
  FlatList,
} from 'react-native';
import { useRouter } from 'expo-router';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

export default function HelpSupport() {
  const router = useRouter();
  const [expandedFAQ, setExpandedFAQ] = useState<string | null>(null);
  const [showWebChat, setShowWebChat] = useState(false);
  const [showAIChat, setShowAIChat] = useState(false);
  const [chatMessage, setChatMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{id: string, message: string, isUser: boolean, timestamp: Date}>>([]);
  const [isTyping, setIsTyping] = useState(false);

  const faqs = [
    {
      id: '1',
      question: 'How do I book a car wash service?',
      answer: 'Simply tap "Book Service" on your dashboard, select your preferred service type (Standard Wash, Full Valet, or Priority Wash), choose your location, select a payment method, and confirm your booking. A valeter will be notified and can accept your job.',
    },
    {
      id: '2',
      question: 'What is the cancellation policy?',
      answer: 'For instant bookings: Cancel within 5 minutes for full refund, within 15 minutes for 90% refund, within 30 minutes for 75% refund, within 1 hour for 50% refund, within 2 hours for 25% refund. After 2 hours, no refund is available. Refunds are processed within 24 hours.',
    },
    {
      id: '3',
      question: 'How do I track my valeter?',
      answer: 'Once a valeter accepts your job, you can track them in real-time through the tracking screen. You\'ll see their location, estimated arrival time, and can communicate directly through the app.',
    },
    {
      id: '4',
      question: 'What payment methods are accepted?',
      answer: 'We accept all major credit/debit cards, PayPal, Apple Pay, and Google Pay. All payments are processed securely and your card details are never stored on our servers.',
    },
    {
      id: '5',
      question: 'How do I become a valeter?',
      answer: 'To become a valeter, you must complete our verification process including document upload, background checks, insurance verification, and license verification. This ensures the highest quality service for our customers.',
    },
    {
      id: '6',
      question: 'What if I\'m not satisfied with the service?',
      answer: 'If you\'re not satisfied, please contact us within 24 hours of service completion. We\'ll investigate and may offer a refund or re-service. Your satisfaction is our priority.',
    },
    {
      id: '7',
      question: 'How do rewards and points work?',
      answer: 'Earn points for every booking, rating, and referral. Points can be redeemed for discounts, free services, and exclusive rewards. Higher levels unlock better benefits.',
    },
    {
      id: '8',
      question: 'Is my data secure?',
      answer: 'Yes, we use industry-standard encryption and security measures to protect your personal and payment information. We never share your data with third parties without consent.',
    },
  ];

  const contactOptions = [
    {
      id: '1',
      title: 'Customer Support',
      subtitle: 'General inquiries and account help',
      icon: '📞',
      action: () => Alert.alert('Contact Support', 'Call us at +44 20 1234 5678\nAvailable 24/7'),
    },
    {
      id: '2',
      title: 'Technical Support',
      subtitle: 'App issues and technical problems',
      icon: '🔧',
      action: () => Alert.alert('Technical Support', 'Email: tech@wishawash.com\nResponse within 2 hours'),
    },
    {
      id: '3',
      title: 'Emergency Contact',
      subtitle: 'Urgent issues during service',
      icon: '🚨',
      action: () => Alert.alert('Emergency Contact', 'Call: +44 20 1234 5679\nAvailable during active bookings'),
    },
    {
      id: '4',
      title: 'Feedback & Suggestions',
      subtitle: 'Help us improve our service',
      icon: '💬',
      action: () => Alert.alert('Feedback', 'Email: feedback@wishawash.com\nWe value your input!'),
    },
  ];

  const quickActions = [
    {
      id: '1',
      title: 'Report an Issue',
      subtitle: 'Report service problems',
      icon: '⚠️',
      action: () => router.push('/report-issue'),
    },
    {
      id: '2',
      title: 'Request Refund',
      subtitle: 'Cancel and get refund',
      icon: '💰',
      action: () => router.push('/request-refund'),
    },
    {
      id: '3',
      title: 'Update Profile',
      subtitle: 'Change account details',
      icon: '👤',
      action: () => router.push('/owner-profile'),
    },
    {
      id: '4',
      title: 'Privacy Settings',
      subtitle: 'Manage data preferences',
      icon: '🔒',
      action: () => router.push('/privacy-settings'),
    },
  ];

  const toggleFAQ = async (id: string) => {
    await hapticFeedback.selection();
    setExpandedFAQ(expandedFAQ === id ? null : id);
  };

  const handleWebChat = async () => {
    await hapticFeedback.impact('medium');
    setShowWebChat(true);
    const welcomeMessage = isValeter
      ? 'Hello! Welcome to Wish a Wash valeter support. A human agent will be with you shortly to assist with your valeter-specific needs.'
      : 'Hello! Welcome to Wish a Wash support. How can I help you today?';
    
    setChatHistory([{
      id: '1',
      message: welcomeMessage,
      isUser: false,
      timestamp: new Date()
    }]);
  };

  const handleAIChat = async () => {
    await hapticFeedback.impact('medium');
    setShowAIChat(true);
    const welcomeMessage = isValeter 
      ? 'Hi! I\'m Wish a Wash AI Assistant for valeters. I can help you with document uploads, payments, job assignments, and more. What would you like to know?'
      : 'Hi! I\'m Wish a Wash AI Assistant. I can help you with booking services, payments, tracking, and more. What would you like to know?';
    
    setChatHistory([{
      id: '1',
      message: welcomeMessage,
      isUser: false,
      timestamp: new Date()
    }]);
  };

  const sendMessage = async () => {
    if (!chatMessage.trim()) return;

    const userMessage = {
      id: Date.now().toString(),
      message: chatMessage,
      isUser: true,
      timestamp: new Date()
    };

    setChatHistory(prev => [...prev, userMessage]);
    setChatMessage('');
    setIsTyping(true);

    // AI response logic with intelligent escalation
    setTimeout(() => {
      const userMessageLower = chatMessage.toLowerCase();
      let aiResponse = '';
      let shouldEscalate = false;

      // Check if AI can handle the issue based on user type
      if (isValeter) {
        // Valeter-specific responses
        if (userMessageLower.includes('online') || userMessageLower.includes('go online')) {
          aiResponse = 'To go online, make sure all your documents are uploaded and verified. Check your Documents section in the app. If you\'re still having issues, I can help you check your verification status.';
        } else if (userMessageLower.includes('payment') || userMessageLower.includes('not received') || userMessageLower.includes('earnings')) {
          aiResponse = 'Payments are processed weekly on Fridays. If you haven\'t received your payment, please check your bank details in your profile. Payments can take 2-3 business days to appear.';
        } else if (userMessageLower.includes('document') || userMessageLower.includes('upload')) {
          aiResponse = 'You can upload documents in the Documents section of your profile. Make sure files are clear and readable. Verification typically takes 24-48 hours.';
        } else if (userMessageLower.includes('insurance') || userMessageLower.includes('verification')) {
          aiResponse = 'Insurance verification is required for all valeters. Please upload your current insurance certificate. If you need help, I can guide you through the process.';
        } else if (userMessageLower.includes('background') || userMessageLower.includes('check')) {
          aiResponse = 'Background checks are processed within 5-7 business days. You\'ll receive a notification when it\'s complete. If it\'s been longer, let me connect you with our verification team.';
        } else if (userMessageLower.includes('job') || userMessageLower.includes('assignment')) {
          aiResponse = 'Jobs are assigned based on your location and availability. Make sure your location services are enabled and you\'re in an active service area.';
        } else if (userMessageLower.includes('customer') || userMessageLower.includes('complaint')) {
          aiResponse = 'Customer complaints are taken seriously. Please provide details about the situation, and I\'ll connect you with our support team for immediate assistance.';
          shouldEscalate = true;
        } else if (userMessageLower.includes('app') && (userMessageLower.includes('crash') || userMessageLower.includes('not working'))) {
          aiResponse = 'I\'m sorry to hear the app isn\'t working properly. Let me connect you with our technical support team who can help resolve this issue quickly.';
          shouldEscalate = true;
        } else {
          // AI doesn't understand - escalate to human
          aiResponse = 'I want to make sure you get the best possible help with this. Let me connect you with one of our human agents who can assist you more effectively. They\'ll be with you shortly!';
          shouldEscalate = true;
        }
      } else {
        // Customer-specific responses
        if (userMessageLower.includes('refund') || userMessageLower.includes('money back')) {
          aiResponse = 'I can help you with refund requests! For instant bookings, you can cancel within 5 minutes for a full refund, within 15 minutes for 90% refund, and so on. Would you like me to guide you through the refund process?';
        } else if (userMessageLower.includes('book') || userMessageLower.includes('service')) {
          aiResponse = 'Booking a service is easy! Simply tap "Book Service" on your dashboard, select your preferred service type, choose your location, and confirm. Would you like me to walk you through the process?';
        } else if (userMessageLower.includes('payment') || userMessageLower.includes('card')) {
          aiResponse = 'We accept all major credit/debit cards, PayPal, Apple Pay, and Google Pay. All payments are processed securely. Is there a specific payment issue you\'re experiencing?';
        } else if (userMessageLower.includes('track') || userMessageLower.includes('valeter')) {
          aiResponse = 'You can track your valeter in real-time through the tracking screen once they accept your job. You\'ll see their location and estimated arrival time. Is the tracking not working for you?';
        } else if (userMessageLower.includes('app') && (userMessageLower.includes('crash') || userMessageLower.includes('not working'))) {
          aiResponse = 'I\'m sorry to hear the app isn\'t working properly. Let me connect you with our technical support team who can help resolve this issue quickly.';
          shouldEscalate = true;
        } else if (userMessageLower.includes('complaint') || userMessageLower.includes('bad service') || userMessageLower.includes('unhappy')) {
          aiResponse = 'I\'m sorry to hear about your experience. This requires immediate attention from our customer service team. Let me connect you with a specialist who can address your concerns properly.';
          shouldEscalate = true;
        } else if (userMessageLower.includes('legal') || userMessageLower.includes('sue') || userMessageLower.includes('lawyer')) {
          aiResponse = 'I understand this is a serious matter. Let me connect you with our legal team who can address your concerns appropriately.';
          shouldEscalate = true;
        } else {
          // AI doesn't understand - escalate to human
          aiResponse = 'I want to make sure you get the best possible help with this. Let me connect you with one of our human agents who can assist you more effectively. They\'ll be with you shortly!';
          shouldEscalate = true;
        }
      }

      const aiMessage = {
        id: (Date.now() + 1).toString(),
        message: aiResponse,
        isUser: false,
        timestamp: new Date()
      };

      setChatHistory(prev => [...prev, aiMessage]);

      // If escalation is needed, add human agent message
      if (shouldEscalate) {
        setTimeout(() => {
          const escalationMessage = {
            id: (Date.now() + 2).toString(),
            message: '🤝 A human agent will contact you within the next 5 minutes. Thank you for your patience, and we appreciate you reaching out to us!',
            isUser: false,
            timestamp: new Date()
          };
          setChatHistory(prev => [...prev, escalationMessage]);
          
          // Show notification
          Alert.alert(
            'Agent Assigned',
            'A human agent has been assigned to your case and will contact you shortly. Thank you for your patience!',
            [{ text: 'OK' }]
          );
        }, 2000);
      }

      setIsTyping(false);
    }, 1500);
  };

  // Get user type from auth context or route params
  const getUserType = () => {
    // This would normally come from auth context
    // For now, we'll check if we're in a valeter route
    const currentRoute = router.canGoBack() ? 'customer' : 'customer'; // Default to customer
    return currentRoute;
  };

  const isValeter = getUserType() === 'valeter';

  const customerQuickReplies = [
    'I can\'t book a service',
    'Payment issue',
    'Valeter not responding',
    'App not working',
    'Need a refund',
    'Account problem'
  ];

  const valeterQuickReplies = [
    'I can\'t go online',
    'Payment not received',
    'Customer complaint',
    'App not working',
    'Document upload issue',
    'Job assignment problem',
    'Insurance verification',
    'Background check status'
  ];

  const quickReplies = isValeter ? valeterQuickReplies : customerQuickReplies;

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Help & Support</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Live Chat Options */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>💬 Live Support</Text>
          <View style={styles.chatOptionsGrid}>
            <TouchableOpacity
              style={styles.chatOptionCard}
              onPress={handleAIChat}
            >
              <Text style={styles.chatOptionIcon}>🤖</Text>
              <Text style={styles.chatOptionTitle}>
                {isValeter ? 'Valeter AI Assistant' : 'AI Assistant'}
              </Text>
              <Text style={styles.chatOptionSubtitle}>
                {isValeter ? 'Instant help with valeter issues' : 'Instant help with common issues'}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.chatOptionCard}
              onPress={handleWebChat}
            >
              <Text style={styles.chatOptionIcon}>👨‍💼</Text>
              <Text style={styles.chatOptionTitle}>
                {isValeter ? 'Valeter Support Agent' : 'Human Agent'}
              </Text>
              <Text style={styles.chatOptionSubtitle}>
                {isValeter ? 'Connect with valeter support team' : 'Connect with support team'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.quickActionsGrid}>
            {quickActions.map((action) => (
              <TouchableOpacity
                key={action.id}
                style={styles.quickActionCard}
                onPress={action.action}
              >
                <Text style={styles.quickActionIcon}>{action.icon}</Text>
                <Text style={styles.quickActionTitle}>{action.title}</Text>
                <Text style={styles.quickActionSubtitle}>{action.subtitle}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Contact Options */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Contact Us</Text>
          <View style={styles.contactGrid}>
            {contactOptions.map((contact) => (
              <TouchableOpacity
                key={contact.id}
                style={styles.contactCard}
                onPress={contact.action}
              >
                <Text style={styles.contactIcon}>{contact.icon}</Text>
                <View style={styles.contactInfo}>
                  <Text style={styles.contactTitle}>{contact.title}</Text>
                  <Text style={styles.contactSubtitle}>{contact.subtitle}</Text>
                </View>
                <Text style={styles.contactArrow}>→</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* FAQs */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Frequently Asked Questions</Text>
          <View style={styles.faqContainer}>
            {faqs.map((faq) => (
              <TouchableOpacity
                key={faq.id}
                style={styles.faqCard}
                onPress={() => toggleFAQ(faq.id)}
              >
                <View style={styles.faqHeader}>
                  <Text style={styles.faqQuestion}>{faq.question}</Text>
                  <Text style={styles.faqToggle}>
                    {expandedFAQ === faq.id ? '−' : '+'}
                  </Text>
                </View>
                {expandedFAQ === faq.id && (
                  <Text style={styles.faqAnswer}>{faq.answer}</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Troubleshooting */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Troubleshooting</Text>
          <View style={styles.troubleshootingCard}>
            <Text style={styles.troubleshootingTitle}>Common Issues</Text>
            
            <View style={styles.issueItem}>
              <Text style={styles.issueIcon}>📱</Text>
              <View style={styles.issueInfo}>
                <Text style={styles.issueTitle}>App not loading</Text>
                <Text style={styles.issueSolution}>Try restarting the app or checking your internet connection</Text>
              </View>
            </View>
            
            <View style={styles.issueItem}>
              <Text style={styles.issueIcon}>📍</Text>
              <View style={styles.issueInfo}>
                <Text style={styles.issueTitle}>Location not working</Text>
                <Text style={styles.issueSolution}>Enable location services in your device settings</Text>
              </View>
            </View>
            
            <View style={styles.issueItem}>
              <Text style={styles.issueIcon}>💳</Text>
              <View style={styles.issueInfo}>
                <Text style={styles.issueTitle}>Payment failed</Text>
                <Text style={styles.issueSolution}>Check your card details or try a different payment method</Text>
              </View>
            </View>
            
            <View style={styles.issueItem}>
              <Text style={styles.issueIcon}>🔔</Text>
              <View style={styles.issueInfo}>
                <Text style={styles.issueTitle}>No notifications</Text>
                <Text style={styles.issueSolution}>Enable push notifications in app settings</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Legal Links */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Legal & Privacy</Text>
          <View style={styles.legalGrid}>
            <TouchableOpacity
              style={styles.legalCard}
              onPress={() => router.push('/terms-of-service')}
            >
              <Text style={styles.legalIcon}>📋</Text>
              <Text style={styles.legalTitle}>Terms of Service</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.legalCard}
              onPress={() => router.push('/privacy-policy')}
            >
              <Text style={styles.legalIcon}>🔒</Text>
              <Text style={styles.legalTitle}>Privacy Policy</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.legalCard}
              onPress={() => Alert.alert('Cookie Policy', 'Our cookie policy is available on our website.')}
            >
              <Text style={styles.legalIcon}>🍪</Text>
              <Text style={styles.legalTitle}>Cookie Policy</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.legalCard}
              onPress={() => Alert.alert('GDPR', 'Learn about your data rights under GDPR.')}
            >
              <Text style={styles.legalIcon}>🇪🇺</Text>
              <Text style={styles.legalTitle}>GDPR Rights</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* App Info */}
        <View style={styles.section}>
          <View style={styles.appInfoCard}>
            <Text style={styles.appInfoTitle}>Wish a Wash</Text>
            <Text style={styles.appInfoVersion}>Version 1.0.0</Text>
            <Text style={styles.appInfoCopyright}>© 2024 Wish a Wash Ltd. All rights reserved.</Text>
          </View>
        </View>
      </ScrollView>

      {/* AI Chat Modal */}
      <Modal
        visible={showAIChat}
        animationType="slide"
        transparent={false}
      >
        <SafeAreaView style={styles.chatContainer}>
          <View style={styles.chatHeader}>
            <TouchableOpacity onPress={() => setShowAIChat(false)} style={styles.chatBackButton}>
              <Text style={styles.chatBackText}>← Back</Text>
            </TouchableOpacity>
            <Text style={styles.chatTitle}>
              {isValeter ? '🤖 Valeter AI Assistant' : '🤖 AI Assistant'}
            </Text>
            <View style={styles.placeholder} />
          </View>

          <FlatList
            data={chatHistory}
            keyExtractor={(item) => item.id}
            style={styles.chatMessages}
            renderItem={({ item }) => (
              <View style={[
                styles.messageContainer,
                item.isUser ? styles.userMessage : styles.aiMessage
              ]}>
                <Text style={[
                  styles.messageText,
                  item.isUser ? styles.userMessageText : styles.aiMessageText
                ]}>
                  {item.message}
                </Text>
                <Text style={styles.messageTime}>
                  {item.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </Text>
              </View>
            )}
          />

          {isTyping && (
            <View style={styles.typingIndicator}>
              <Text style={styles.typingText}>AI is typing...</Text>
            </View>
          )}

          <View style={styles.chatInputContainer}>
            <TextInput
              style={styles.chatInput}
              placeholder="Type your message..."
              placeholderTextColor="#9CA3AF"
              value={chatMessage}
              onChangeText={setChatMessage}
              multiline
            />
            <TouchableOpacity
              style={[styles.sendButton, !chatMessage.trim() && styles.sendButtonDisabled]}
              onPress={sendMessage}
              disabled={!chatMessage.trim()}
            >
              <Text style={styles.sendButtonText}>Send</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.quickRepliesContainer}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {quickReplies.map((reply, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.quickReplyButton}
                  onPress={() => {
                    setChatMessage(reply);
                    sendMessage();
                  }}
                >
                  <Text style={styles.quickReplyText}>{reply}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </SafeAreaView>
      </Modal>

      {/* Web Chat Modal */}
      <Modal
        visible={showWebChat}
        animationType="slide"
        transparent={false}
      >
        <SafeAreaView style={styles.chatContainer}>
          <View style={styles.chatHeader}>
            <TouchableOpacity onPress={() => setShowWebChat(false)} style={styles.chatBackButton}>
              <Text style={styles.chatBackText}>← Back</Text>
            </TouchableOpacity>
            <Text style={styles.chatTitle}>
              {isValeter ? '👨‍💼 Valeter Support Agent' : '👨‍💼 Human Agent'}
            </Text>
            <View style={styles.placeholder} />
          </View>

          <FlatList
            data={chatHistory}
            keyExtractor={(item) => item.id}
            style={styles.chatMessages}
            renderItem={({ item }) => (
              <View style={[
                styles.messageContainer,
                item.isUser ? styles.userMessage : styles.agentMessage
              ]}>
                <Text style={[
                  styles.messageText,
                  item.isUser ? styles.userMessageText : styles.agentMessageText
                ]}>
                  {item.message}
                </Text>
                <Text style={styles.messageTime}>
                  {item.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </Text>
              </View>
            )}
          />

          <View style={styles.chatInputContainer}>
            <TextInput
              style={styles.chatInput}
              placeholder="Type your message..."
              placeholderTextColor="#9CA3AF"
              value={chatMessage}
              onChangeText={setChatMessage}
              multiline
            />
            <TouchableOpacity
              style={[styles.sendButton, !chatMessage.trim() && styles.sendButtonDisabled]}
              onPress={sendMessage}
              disabled={!chatMessage.trim()}
            >
              <Text style={styles.sendButtonText}>Send</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 60,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  quickActionCard: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  quickActionIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  quickActionTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 4,
  },
  quickActionSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  contactGrid: {
    gap: 12,
  },
  contactCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  contactIcon: {
    fontSize: 24,
    marginRight: 16,
  },
  contactInfo: {
    flex: 1,
  },
  contactTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
  contactSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
  },
  contactArrow: {
    color: '#87CEEB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  faqContainer: {
    gap: 12,
  },
  faqCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  faqHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  faqQuestion: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    flex: 1,
    marginRight: 16,
  },
  faqToggle: {
    color: '#87CEEB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  faqAnswer: {
    color: '#E5E7EB',
    fontSize: 14,
    lineHeight: 20,
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
  troubleshootingCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  troubleshootingTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  issueItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  issueIcon: {
    fontSize: 20,
    marginRight: 12,
    marginTop: 2,
  },
  issueInfo: {
    flex: 1,
  },
  issueTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  issueSolution: {
    color: '#87CEEB',
    fontSize: 12,
    lineHeight: 16,
  },
  legalGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  legalCard: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  legalIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  legalTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  appInfoCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  appInfoTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  appInfoVersion: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 4,
  },
  appInfoCopyright: {
    color: '#E5E7EB',
    fontSize: 12,
    textAlign: 'center',
  },
  // Chat styles
  chatOptionsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  chatOptionCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  chatOptionIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  chatOptionTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 4,
  },
  chatOptionSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  chatContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
    backgroundColor: '#1E3A8A',
  },
  chatBackButton: {
    padding: 8,
  },
  chatBackText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  chatTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  chatMessages: {
    flex: 1,
    padding: 16,
  },
  messageContainer: {
    marginBottom: 16,
    maxWidth: '80%',
  },
  userMessage: {
    alignSelf: 'flex-end',
    backgroundColor: '#3B82F6',
    borderRadius: 18,
    padding: 12,
    marginLeft: '20%',
  },
  aiMessage: {
    alignSelf: 'flex-start',
    backgroundColor: '#1E3A8A',
    borderRadius: 18,
    padding: 12,
    marginRight: '20%',
  },
  agentMessage: {
    alignSelf: 'flex-start',
    backgroundColor: '#059669',
    borderRadius: 18,
    padding: 12,
    marginRight: '20%',
  },
  messageText: {
    fontSize: 16,
    lineHeight: 20,
  },
  userMessageText: {
    color: '#FFFFFF',
  },
  aiMessageText: {
    color: '#F9FAFB',
  },
  agentMessageText: {
    color: '#FFFFFF',
  },
  messageTime: {
    fontSize: 12,
    color: '#9CA3AF',
    marginTop: 4,
    textAlign: 'right',
  },
  typingIndicator: {
    padding: 16,
    alignItems: 'center',
  },
  typingText: {
    color: '#87CEEB',
    fontSize: 14,
    fontStyle: 'italic',
  },
  chatInputContainer: {
    flexDirection: 'row',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#1E3A8A',
    backgroundColor: '#1E3A8A',
  },
  chatInput: {
    flex: 1,
    backgroundColor: '#0A1929',
    borderRadius: 20,
    padding: 12,
    marginRight: 8,
    color: '#F9FAFB',
    fontSize: 16,
    maxHeight: 100,
  },
  sendButton: {
    backgroundColor: '#10B981',
    borderRadius: 20,
    padding: 12,
    justifyContent: 'center',
    alignItems: 'center',
    minWidth: 60,
  },
  sendButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  sendButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  quickRepliesContainer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#1E3A8A',
    backgroundColor: '#1E3A8A',
  },
  quickReplyButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 8,
    marginRight: 8,
  },
  quickReplyText: {
    color: '#F9FAFB',
    fontSize: 14,
  },
});
