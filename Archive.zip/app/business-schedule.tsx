import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import { useAuth } from './auth-context';

const { width, height } = Dimensions.get('window');

interface ScheduleJob {
  id: string;
  customerName: string;
  serviceType: string;
  date: string;
  time: string;
  duration: number;
  assignedTo: string;
  status: 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
  location: string;
  price: number;
}

interface TeamMember {
  id: string;
  name: string;
  status: 'available' | 'busy' | 'offline';
  currentJob?: string;
  jobsToday: number;
  totalHours: number;
}

export default function BusinessSchedule() {
  const { user } = useAuth();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [scheduleJobs, setScheduleJobs] = useState<ScheduleJob[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [viewMode, setViewMode] = useState<'day' | 'week' | 'month'>('day');

  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    // Load mock schedule data
    const mockScheduleJobs: ScheduleJob[] = [
      {
        id: '1',
        customerName: 'John Smith',
        serviceType: 'Premium Wash',
        date: '2024-01-20',
        time: '09:00',
        duration: 45,
        assignedTo: 'Mike Johnson',
        status: 'scheduled',
        location: 'London, SW1A 1AA',
        price: 45.00,
      },
      {
        id: '2',
        customerName: 'Emma Wilson',
        serviceType: 'Luxury Wash',
        date: '2024-01-20',
        time: '10:30',
        duration: 60,
        assignedTo: 'Sarah Williams',
        status: 'in_progress',
        location: 'Manchester, M1 1AA',
        price: 89.00,
      },
      {
        id: '3',
        customerName: 'David Brown',
        serviceType: 'Standard Wash',
        date: '2024-01-20',
        time: '14:00',
        duration: 30,
        assignedTo: 'David Brown',
        status: 'scheduled',
        location: 'Birmingham, B1 1AA',
        price: 29.00,
      },
      {
        id: '4',
        customerName: 'Lisa Anderson',
        serviceType: 'Premium Wash',
        date: '2024-01-20',
        time: '16:00',
        duration: 45,
        assignedTo: 'Emma Davis',
        status: 'scheduled',
        location: 'Leeds, LS1 1AA',
        price: 45.00,
      },
    ];

    const mockTeamMembers: TeamMember[] = [
      {
        id: '1',
        name: 'Mike Johnson',
        status: 'available',
        jobsToday: 3,
        totalHours: 6,
      },
      {
        id: '2',
        name: 'Sarah Williams',
        status: 'busy',
        currentJob: 'Emma Wilson - Luxury Wash',
        jobsToday: 2,
        totalHours: 4,
      },
      {
        id: '3',
        name: 'David Brown',
        status: 'available',
        jobsToday: 2,
        totalHours: 3,
      },
      {
        id: '4',
        name: 'Emma Davis',
        status: 'available',
        jobsToday: 1,
        totalHours: 2,
      },
    ];

    setScheduleJobs(mockScheduleJobs);
    setTeamMembers(mockTeamMembers);

    // Start animations
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handleViewModeChange = async (mode: 'day' | 'week' | 'month') => {
    await hapticFeedback.selection();
    setViewMode(mode);
  };

  const handleAssignJob = async (jobId: string, memberName: string) => {
    await hapticFeedback.impact('medium');
    Alert.alert(
      'Assign Job',
      `Assign this job to ${memberName}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Assign',
          onPress: () => {
            setScheduleJobs(prev => prev.map(job => 
              job.id === jobId ? { ...job, assignedTo: memberName } : job
            ));
            Alert.alert('Success', `Job assigned to ${memberName}`);
          }
        }
      ]
    );
  };

  const handleRescheduleJob = async (jobId: string) => {
    await hapticFeedback.impact('medium');
    Alert.alert('Reschedule Job', 'This would open a date/time picker to reschedule the job.');
  };

  const handleCancelJob = async (jobId: string) => {
    await hapticFeedback.impact('medium');
    Alert.alert(
      'Cancel Job',
      'Are you sure you want to cancel this job?',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes',
          style: 'destructive',
          onPress: () => {
            setScheduleJobs(prev => prev.map(job => 
              job.id === jobId ? { ...job, status: 'cancelled' } : job
            ));
            Alert.alert('Job Cancelled', 'The job has been cancelled successfully.');
          }
        }
      ]
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return '#87CEEB';
      case 'in_progress': return '#F59E0B';
      case 'completed': return '#10B981';
      case 'cancelled': return '#EF4444';
      default: return '#6B7280';
    }
  };

  const getStatusText = (status: string) => {
    return status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  const formatTime = (time: string) => {
    return time;
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Schedule Management</Text>
        <TouchableOpacity style={styles.addButton} onPress={() => Alert.alert('Add Job', 'This would open job creation form.')}>
          <Text style={styles.addButtonText}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* View Mode Selector */}
          <View style={styles.viewModeSelector}>
            <TouchableOpacity
              style={[styles.viewModeButton, viewMode === 'day' && styles.activeViewModeButton]}
              onPress={() => handleViewModeChange('day')}
            >
              <Text style={[styles.viewModeButtonText, viewMode === 'day' && styles.activeViewModeButtonText]}>
                Day
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.viewModeButton, viewMode === 'week' && styles.activeViewModeButton]}
              onPress={() => handleViewModeChange('week')}
            >
              <Text style={[styles.viewModeButtonText, viewMode === 'week' && styles.activeViewModeButtonText]}>
                Week
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.viewModeButton, viewMode === 'month' && styles.activeViewModeButton]}
              onPress={() => handleViewModeChange('month')}
            >
              <Text style={[styles.viewModeButtonText, viewMode === 'month' && styles.activeViewModeButtonText]}>
                Month
              </Text>
            </TouchableOpacity>
          </View>

          {/* Date Display */}
          <View style={styles.dateSection}>
            <Text style={styles.dateText}>
              {selectedDate.toLocaleDateString('en-GB', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </Text>
            <Text style={styles.scheduleSummary}>
              {scheduleJobs.length} jobs scheduled • {teamMembers.filter(m => m.status === 'available').length} team members available
            </Text>
          </View>

          {/* Team Overview */}
          <View style={styles.teamSection}>
            <Text style={styles.sectionTitle}>Team Overview</Text>
            <View style={styles.teamGrid}>
              {teamMembers.map((member) => (
                <View key={member.id} style={styles.teamMemberCard}>
                  <View style={styles.memberHeader}>
                    <Text style={styles.memberName}>{member.name}</Text>
                    <View style={[
                      styles.statusIndicator,
                      { backgroundColor: member.status === 'available' ? '#10B981' : member.status === 'busy' ? '#F59E0B' : '#6B7280' }
                    ]} />
                  </View>
                  <Text style={styles.memberStatus}>
                    {member.status === 'busy' && member.currentJob ? member.currentJob : member.status}
                  </Text>
                  <View style={styles.memberStats}>
                    <Text style={styles.memberStat}>{member.jobsToday} jobs today</Text>
                    <Text style={styles.memberStat}>{member.totalHours}h total</Text>
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Schedule Jobs */}
          <View style={styles.scheduleSection}>
            <Text style={styles.sectionTitle}>Today's Schedule</Text>
            <View style={styles.scheduleList}>
              {scheduleJobs.map((job) => (
                <View key={job.id} style={styles.scheduleCard}>
                  <View style={styles.jobHeader}>
                    <View style={styles.jobTime}>
                      <Text style={styles.jobTimeText}>{formatTime(job.time)}</Text>
                      <Text style={styles.jobDuration}>{formatDuration(job.duration)}</Text>
                    </View>
                    <View style={[
                      styles.jobStatus,
                      { backgroundColor: getStatusColor(job.status) }
                    ]}>
                      <Text style={styles.jobStatusText}>{getStatusText(job.status)}</Text>
                    </View>
                  </View>

                  <View style={styles.jobDetails}>
                    <Text style={styles.customerName}>{job.customerName}</Text>
                    <Text style={styles.serviceType}>{job.serviceType}</Text>
                    <Text style={styles.jobLocation}>📍 {job.location}</Text>
                    <Text style={styles.jobPrice}>£{job.price.toFixed(2)}</Text>
                  </View>

                  <View style={styles.jobAssignment}>
                    <Text style={styles.assignedTo}>Assigned to: {job.assignedTo}</Text>
                  </View>

                  <View style={styles.jobActions}>
                    <TouchableOpacity
                      style={styles.actionButton}
                      onPress={() => Alert.alert('Reassign', 'Select team member to reassign this job.')}
                    >
                      <Text style={styles.actionButtonText}>Reassign</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.actionButton}
                      onPress={() => handleRescheduleJob(job.id)}
                    >
                      <Text style={styles.actionButtonText}>Reschedule</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.actionButton, styles.cancelButton]}
                      onPress={() => handleCancelJob(job.id)}
                    >
                      <Text style={[styles.actionButtonText, styles.cancelButtonText]}>Cancel</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Quick Actions */}
          <View style={styles.quickActionsSection}>
            <Text style={styles.sectionTitle}>Quick Actions</Text>
            <View style={styles.quickActionsGrid}>
              <TouchableOpacity
                style={styles.quickActionCard}
                onPress={() => Alert.alert('Add Job', 'Create a new job in the schedule.')}
              >
                <LinearGradient
                  colors={['#10B981', '#059669']}
                  style={styles.quickActionGradient}
                >
                  <Text style={styles.quickActionIcon}>➕</Text>
                  <Text style={styles.quickActionTitle}>Add Job</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.quickActionCard}
                onPress={() => Alert.alert('Bulk Assign', 'Assign multiple jobs to team members.')}
              >
                <LinearGradient
                  colors={['#8B5CF6', '#7C3AED']}
                  style={styles.quickActionGradient}
                >
                  <Text style={styles.quickActionIcon}>👥</Text>
                  <Text style={styles.quickActionTitle}>Bulk Assign</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.quickActionCard}
                onPress={() => Alert.alert('Export Schedule', 'Export schedule to calendar or PDF.')}
              >
                <LinearGradient
                  colors={['#F59E0B', '#D97706']}
                  style={styles.quickActionGradient}
                >
                  <Text style={styles.quickActionIcon}>📅</Text>
                  <Text style={styles.quickActionTitle}>Export</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.quickActionCard}
                onPress={() => Alert.alert('Team Availability', 'View and manage team availability.')}
              >
                <LinearGradient
                  colors={['#06B6D4', '#0891B2']}
                  style={styles.quickActionGradient}
                >
                  <Text style={styles.quickActionIcon}>📊</Text>
                  <Text style={styles.quickActionTitle}>Availability</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  addButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#10B981',
    justifyContent: 'center',
    alignItems: 'center',
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
  },
  viewModeSelector: {
    flexDirection: 'row',
    padding: 20,
    gap: 8,
  },
  viewModeButton: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 8,
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  activeViewModeButton: {
    backgroundColor: '#87CEEB',
  },
  viewModeButtonText: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
  },
  activeViewModeButtonText: {
    color: '#0A1929',
  },
  dateSection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  dateText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  scheduleSummary: {
    color: '#87CEEB',
    fontSize: 14,
  },
  teamSection: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  teamGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  teamMemberCard: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  memberHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  memberName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  statusIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  memberStatus: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 8,
  },
  memberStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  memberStat: {
    color: '#B0E0E6',
    fontSize: 12,
  },
  scheduleSection: {
    padding: 20,
  },
  scheduleList: {
    gap: 12,
  },
  scheduleCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  jobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  jobTime: {
    alignItems: 'flex-start',
  },
  jobTimeText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  jobDuration: {
    color: '#87CEEB',
    fontSize: 12,
  },
  jobStatus: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  jobStatusText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  jobDetails: {
    marginBottom: 12,
  },
  customerName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  serviceType: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 4,
  },
  jobLocation: {
    color: '#B0E0E6',
    fontSize: 14,
    marginBottom: 4,
  },
  jobPrice: {
    color: '#F59E0B',
    fontSize: 16,
    fontWeight: 'bold',
  },
  jobAssignment: {
    marginBottom: 12,
  },
  assignedTo: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
  },
  jobActions: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  cancelButton: {
    backgroundColor: 'rgba(239, 68, 68, 0.2)',
  },
  cancelButtonText: {
    color: '#EF4444',
  },
  quickActionsSection: {
    padding: 20,
    paddingBottom: 40,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  quickActionCard: {
    width: '48%',
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 8,
  },
  quickActionGradient: {
    padding: 16,
    alignItems: 'center',
  },
  quickActionIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  quickActionTitle: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
