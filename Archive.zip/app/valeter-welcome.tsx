import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ScrollView,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import { useAuth } from './auth-context';

const { width, height } = Dimensions.get('window');

interface WelcomeFeature {
  id: string;
  icon: string;
  title: string;
  description: string;
  color: string;
}

interface EarningPotential {
  level: string;
  jobs: number;
  earnings: number;
  color: string;
}

export default function ValeterWelcome() {
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(0);
  const [showFeatures, setShowFeatures] = useState(false);
  const [showEarnings, setShowEarnings] = useState(false);
  
  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;
  const bubbleAnim = useRef(new Animated.Value(0)).current;
  const featureAnim = useRef(new Animated.Value(0)).current;
  const earningAnim = useRef(new Animated.Value(0)).current;

  const welcomeSteps = [
    {
      title: `Welcome to the Team, ${user?.name?.split(' ')[0] || 'Professional'}! 🧽✨`,
      subtitle: 'Your journey to success starts here',
      description: 'Join our elite network of professional valeters and start earning while delivering exceptional service.',
      icon: '👨‍🔧',
      color: '#10B981',
    },
    {
      title: 'Flexible Work, Maximum Earnings 💰',
      subtitle: 'Work when you want, earn what you deserve',
      description: 'Set your own schedule, choose your jobs, and keep up to 85% of every booking. No more fixed hours or low wages.',
      icon: '💳',
      color: '#F59E0B',
    },
    {
      title: 'Professional Support & Growth 📈',
      subtitle: 'We invest in your success',
      description: 'Get training, equipment support, insurance coverage, and continuous professional development opportunities.',
      icon: '🎯',
      color: '#8B5CF6',
    },
  ];

  const features: WelcomeFeature[] = [
    {
      id: '1',
      icon: '⚡',
      title: 'Flexible Schedule',
      description: 'Work when you want - mornings, evenings, weekends',
      color: '#10B981',
    },
    {
      id: '2',
      icon: '💰',
      title: 'High Earnings',
      description: 'Keep up to 85% of every booking with transparent pricing',
      color: '#F59E0B',
    },
    {
      id: '3',
      icon: '🎯',
      title: 'Job Selection',
      description: 'Choose jobs that fit your skills and preferences',
      color: '#8B5CF6',
    },
    {
      id: '4',
      icon: '🛡️',
      title: 'Full Insurance',
      description: 'Complete coverage for you and your customers',
      color: '#EF4444',
    },
    {
      id: '5',
      icon: '📱',
      title: 'Smart App',
      description: 'Easy job management and customer communication',
      color: '#06B6D4',
    },
    {
      id: '6',
      icon: '🏆',
      title: 'Rewards System',
      description: 'Earn bonuses and recognition for great service',
      color: '#84CC16',
    },
  ];

  const earningPotentials: EarningPotential[] = [
    {
      level: 'Starter',
      jobs: 10,
      earnings: 250,
      color: '#10B981',
    },
    {
      level: 'Professional',
      jobs: 25,
      earnings: 650,
      color: '#F59E0B',
    },
    {
      level: 'Expert',
      jobs: 50,
      earnings: 1400,
      color: '#8B5CF6',
    },
    {
      level: 'Elite',
      jobs: 100,
      earnings: 3200,
      color: '#EF4444',
    },
  ];

  useEffect(() => {
    // Initial animation
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
    ]).start();

    // Bubble animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(bubbleAnim, {
          toValue: 1,
          duration: 3000,
          useNativeDriver: true,
        }),
        Animated.timing(bubbleAnim, {
          toValue: 0,
          duration: 3000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Show features after initial animation
    setTimeout(() => {
      setShowFeatures(true);
      Animated.timing(featureAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }).start();
    }, 2000);

    // Show earnings after features
    setTimeout(() => {
      setShowEarnings(true);
      Animated.timing(earningAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }).start();
    }, 3500);
  }, []);

  const handleGetStarted = async () => {
    await hapticFeedback.impact('medium');
    router.replace('/driver-dashboard');
  };

  const handleSkip = async () => {
    await hapticFeedback.impact('light');
    router.replace('/driver-dashboard');
  };

  const renderWelcomeStep = (step: any, index: number) => (
    <Animated.View
      key={index}
      style={[
        styles.welcomeStep,
        {
          opacity: fadeAnim,
          transform: [
            { translateY: slideAnim },
            { scale: scaleAnim },
          ],
        },
      ]}
    >
      <View style={[styles.stepIcon, { backgroundColor: step.color }]}>
        <Text style={styles.stepIconText}>{step.icon}</Text>
      </View>
      <Text style={styles.stepTitle}>{step.title}</Text>
      <Text style={styles.stepSubtitle}>{step.subtitle}</Text>
      <Text style={styles.stepDescription}>{step.description}</Text>
    </Animated.View>
  );

  const renderFeature = (feature: WelcomeFeature, index: number) => (
    <Animated.View
      key={feature.id}
      style={[
        styles.featureCard,
        {
          opacity: featureAnim,
          transform: [
            {
              translateY: featureAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [50, 0],
              }),
            },
          ],
        },
      ]}
    >
      <View style={[styles.featureIcon, { backgroundColor: feature.color }]}>
        <Text style={styles.featureIconText}>{feature.icon}</Text>
      </View>
      <View style={styles.featureContent}>
        <Text style={styles.featureTitle}>{feature.title}</Text>
        <Text style={styles.featureDescription}>{feature.description}</Text>
      </View>
    </Animated.View>
  );

  const renderEarningPotential = (earning: EarningPotential, index: number) => (
    <Animated.View
      key={earning.level}
      style={[
        styles.earningCard,
        {
          opacity: earningAnim,
          transform: [
            {
              translateY: earningAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [30, 0],
              }),
            },
          ],
        },
      ]}
    >
      <View style={[styles.earningHeader, { backgroundColor: earning.color }]}>
        <Text style={styles.earningLevel}>{earning.level}</Text>
      </View>
      <View style={styles.earningContent}>
        <View style={styles.earningStat}>
          <Text style={styles.earningLabel}>Jobs per week</Text>
          <Text style={styles.earningValue}>{earning.jobs}</Text>
        </View>
        <View style={styles.earningStat}>
          <Text style={styles.earningLabel}>Weekly earnings</Text>
          <Text style={styles.earningValue}>£{earning.earnings}</Text>
        </View>
      </View>
    </Animated.View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Background with animated bubbles */}
      <View style={styles.background}>
        <LinearGradient
          colors={['#0A1929', '#1E3A8A', '#0A1929']}
          style={styles.gradient}
        />
        
        {/* Animated bubbles */}
        <Animated.View
          style={[
            styles.bubble,
            styles.bubble1,
            {
              opacity: bubbleAnim,
              transform: [
                {
                  translateY: bubbleAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-30, 30],
                  }),
                },
                {
                  scale: bubbleAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.8, 1.2],
                  }),
                },
              ],
            },
          ]}
        />
        <Animated.View
          style={[
            styles.bubble,
            styles.bubble2,
            {
              opacity: bubbleAnim.interpolate({
                inputRange: [0, 0.5, 1],
                outputRange: [0, 1, 0],
              }),
              transform: [
                {
                  translateY: bubbleAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-40, 40],
                  }),
                },
                {
                  scale: bubbleAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.6, 1.4],
                  }),
                },
              ],
            },
          ]}
        />
        <Animated.View
          style={[
            styles.bubble,
            styles.bubble3,
            {
              opacity: bubbleAnim.interpolate({
                inputRange: [0, 0.5, 1],
                outputRange: [0, 1, 0],
              }),
              transform: [
                {
                  translateY: bubbleAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-35, 35],
                  }),
                },
                {
                  scale: bubbleAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.7, 1.3],
                  }),
                },
              ],
            },
          ]}
        />
      </View>

      {/* Content */}
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Logo and Brand */}
        <View style={styles.logoSection}>
          <Animated.View
            style={[
              styles.logoContainer,
              {
                opacity: fadeAnim,
                transform: [
                  { scale: scaleAnim },
                ],
              },
            ]}
          >
            <Text style={styles.logo}>🧽</Text>
            <Text style={styles.brandName}>Wish a Wash</Text>
            <Text style={styles.tagline}>Professional Valeter Network</Text>
          </Animated.View>
        </View>

        {/* Welcome Steps */}
        <View style={styles.welcomeSection}>
          {welcomeSteps.map((step, index) => renderWelcomeStep(step, index))}
        </View>

        {/* Features Grid */}
        {showFeatures && (
          <View style={styles.featuresSection}>
            <Text style={styles.featuresTitle}>Why Choose Wish a Wash?</Text>
            <View style={styles.featuresGrid}>
              {features.map((feature, index) => renderFeature(feature, index))}
            </View>
          </View>
        )}

        {/* Earning Potential */}
        {showEarnings && (
          <View style={styles.earningsSection}>
            <Text style={styles.earningsTitle}>Your Earning Potential</Text>
            <Text style={styles.earningsSubtitle}>
              Based on weekly performance levels
            </Text>
            <View style={styles.earningsGrid}>
              {earningPotentials.map((earning, index) => renderEarningPotential(earning, index))}
            </View>
          </View>
        )}

        {/* Action Buttons */}
        <View style={styles.actionSection}>
          <TouchableOpacity
            style={styles.getStartedButton}
            onPress={handleGetStarted}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={['#10B981', '#059669']}
              style={styles.getStartedGradient}
            >
              <Text style={styles.getStartedText}>Start Earning</Text>
              <Text style={styles.getStartedSubtext}>Begin Your Journey</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.skipButton}
            onPress={handleSkip}
            activeOpacity={0.7}
          >
            <Text style={styles.skipButtonText}>Skip for now</Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Join hundreds of successful valeters who have transformed their careers with Wish a Wash
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  background: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  gradient: {
    flex: 1,
  },
  bubble: {
    position: 'absolute',
    borderRadius: 50,
    backgroundColor: 'rgba(135, 206, 235, 0.3)',
    shadowColor: '#87CEEB',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 6,
  },
  bubble1: {
    width: 60,
    height: 60,
    left: '15%',
    top: '20%',
  },
  bubble2: {
    width: 40,
    height: 40,
    left: '75%',
    top: '30%',
  },
  bubble3: {
    width: 50,
    height: 50,
    left: '60%',
    top: '15%',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  logoSection: {
    alignItems: 'center',
    marginTop: 40,
    marginBottom: 40,
  },
  logoContainer: {
    alignItems: 'center',
  },
  logo: {
    fontSize: 80,
    marginBottom: 16,
  },
  brandName: {
    color: '#F9FAFB',
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  tagline: {
    color: '#87CEEB',
    fontSize: 18,
    fontWeight: '600',
  },
  welcomeSection: {
    marginBottom: 40,
  },
  welcomeStep: {
    alignItems: 'center',
    marginBottom: 30,
    paddingHorizontal: 20,
  },
  stepIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  stepIconText: {
    fontSize: 36,
  },
  stepTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
    lineHeight: 30,
  },
  stepSubtitle: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 12,
  },
  stepDescription: {
    color: '#B0E0E6',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  featuresSection: {
    marginBottom: 40,
  },
  featuresTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 24,
  },
  featuresGrid: {
    gap: 16,
  },
  featureCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  featureIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  featureIconText: {
    fontSize: 24,
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  featureDescription: {
    color: '#B0E0E6',
    fontSize: 14,
    lineHeight: 18,
  },
  earningsSection: {
    marginBottom: 40,
  },
  earningsTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  earningsSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
  },
  earningsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  earningCard: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  earningHeader: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  earningLevel: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  earningContent: {
    padding: 16,
  },
  earningStat: {
    alignItems: 'center',
    marginBottom: 8,
  },
  earningLabel: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 4,
  },
  earningValue: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  actionSection: {
    marginBottom: 40,
  },
  getStartedButton: {
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  getStartedGradient: {
    paddingVertical: 20,
    paddingHorizontal: 32,
    alignItems: 'center',
  },
  getStartedText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  getStartedSubtext: {
    color: '#FFFFFF',
    fontSize: 14,
    opacity: 0.9,
  },
  skipButton: {
    alignItems: 'center',
    paddingVertical: 12,
  },
  skipButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    textDecorationLine: 'underline',
  },
  footer: {
    alignItems: 'center',
    paddingBottom: 40,
  },
  footerText: {
    color: '#B0E0E6',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    fontStyle: 'italic',
  },
});
