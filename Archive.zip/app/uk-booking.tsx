import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from './auth-context';
import { dynamicPricingService, PricingFactors } from '../src/services/DynamicPricingService';
import { vehiclePricingService, VehicleCategory, WashMethod } from '../src/services/VehiclePricingService';
import { stripePaymentService } from '../src/services/StripePaymentService';
import { simulationService } from '../src/services/SimulationService';

const { width } = Dimensions.get('window');

export default function UKBooking() {
    console.log('📍 Rendering UK BookingScreen.tsx');
  const router = useRouter();
  const { user } = useAuth();
  const [selectedVehicleCategory, setSelectedVehicleCategory] = useState<string>('medium');
  const [selectedWashMethod, setSelectedWashMethod] = useState<string>('standard_wash');
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedArea, setSelectedArea] = useState('');
  const [selectedAddons, setSelectedAddons] = useState<string[]>([]);
  const [isBooking, setIsBooking] = useState(false);
  const [priceEstimate, setPriceEstimate] = useState<number>(0);

  const cities = dynamicPricingService.getAvailableCities();
  const areas = selectedCity ? dynamicPricingService.getAreasForCity(selectedCity) : [];
  const vehicleCategories = vehiclePricingService.getVehicleCategories();
  const washMethods = vehiclePricingService.getWashMethodsForVehicle(selectedVehicleCategory);
  const addons = selectedCity && selectedArea ? 
    dynamicPricingService.getAddonsForService(selectedCity, selectedArea, 'quickWash') : [];

  useEffect(() => {
    if (selectedCity && selectedArea) {
      calculatePrice();
    }
  }, [selectedVehicleCategory, selectedWashMethod, selectedCity, selectedArea, selectedAddons]);

  const calculatePrice = () => {
    if (!selectedCity || !selectedArea) return;

    // Get location multiplier from dynamic pricing service
    const location = dynamicPricingService.getLocationPricing(selectedCity, selectedArea);
    const locationMultiplier = location?.baseMultiplier || 1.0;

    // Calculate time and demand multipliers
    const timeOfDay = new Date().getHours();
    const dayOfWeek = new Date().getDay();
    const isWeekday = dayOfWeek >= 1 && dayOfWeek <= 5;
    const isPeakHour = (timeOfDay >= 7 && timeOfDay <= 9) || (timeOfDay >= 17 && timeOfDay <= 19);
    const timeMultiplier = isWeekday && isPeakHour ? 1.2 : isWeekday ? 1.1 : isPeakHour ? 1.15 : 1.0;
    const demandMultiplier = 1.0; // Would come from real-time demand data
    const weatherMultiplier = 1.0; // Would come from weather API

    try {
      const pricing = vehiclePricingService.calculatePrice(
        selectedVehicleCategory,
        selectedWashMethod,
        locationMultiplier,
        timeMultiplier,
        demandMultiplier,
        weatherMultiplier
      );
      
      if (pricing) {
        setPriceEstimate(pricing.finalPrice);
      }
    } catch (error) {
      console.error('Error calculating price:', error);
    }
  };

  const handleAddonToggle = (addonId: string) => {
    setSelectedAddons(prev => 
      prev.includes(addonId) 
        ? prev.filter(id => id !== addonId)
        : [...prev, addonId]
    );
  };

  const handleBookService = async () => {
    if (!user || !selectedCity || !selectedArea) {
      Alert.alert('Error', 'Please select a location');
      return;
    }

    setIsBooking(true);
    
    try {
      // Create payment intent with Stripe
      const paymentIntent = await stripePaymentService.createPaymentIntent(
        priceEstimate,
        'gbp',
        {
          serviceType: selectedService,
          location: `${selectedCity}, ${selectedArea}`,
          vehicleSize,
          addons: selectedAddons.join(','),
          userId: user.id
        }
      );

      // Create job in simulation
      const jobId = simulationService.createJob(
        user.id,
        selectedWashMethod,
        { lat: 51.5074, lng: -0.1278, address: `${selectedCity}, ${selectedArea}` },
        priceEstimate
      );

      const vehicleCategory = vehiclePricingService.getVehicleCategory(selectedVehicleCategory);
      const washMethod = vehiclePricingService.getWashMethodsForVehicle(selectedVehicleCategory)
        .find(m => m.id === selectedWashMethod);

      Alert.alert(
        'Booking Successful! 🎉',
        `Your ${vehicleCategory?.name} ${washMethod?.name} has been booked for £${priceEstimate}. A valeter will be with you shortly!`,
        [
          { text: 'Track Service', onPress: () => router.push('/tracking') },
          { text: 'Back to Dashboard', onPress: () => router.push('/owner-dashboard') }
        ]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to book service. Please try again.');
    } finally {
      setIsBooking(false);
    }
  };

  const getPriceRange = () => {
    if (!selectedCity || !selectedArea) return null;
    return dynamicPricingService.getPriceRange(selectedCity, selectedArea, selectedService);
  };

  const priceRange = getPriceRange();

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Book Car Wash</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Service Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Choose Service</Text>
          <View style={styles.serviceGrid}>
            {services.map((service) => (
              <TouchableOpacity
                key={service.id}
                style={[
                  styles.serviceCard,
                  selectedService === service.id && styles.selectedServiceCard
                ]}
                onPress={() => setSelectedService(service.id as any)}
              >
                <Text style={styles.serviceIcon}>{service.icon}</Text>
                <Text style={styles.serviceName}>{service.name}</Text>
                <Text style={styles.serviceDescription}>{service.description}</Text>
                {selectedService === service.id && (
                  <View style={styles.selectedIndicator}>
                    <Text style={styles.selectedIcon}>✓</Text>
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Vehicle Size Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Vehicle Size</Text>
          <View style={styles.vehicleGrid}>
            {vehicleSizes.map((vehicle) => (
              <TouchableOpacity
                key={vehicle.id}
                style={[
                  styles.vehicleCard,
                  vehicleSize === vehicle.id && styles.selectedVehicleCard
                ]}
                onPress={() => setVehicleSize(vehicle.id as any)}
              >
                <Text style={styles.vehicleIcon}>{vehicle.icon}</Text>
                <Text style={styles.vehicleName}>{vehicle.name}</Text>
                {vehicleSize === vehicle.id && (
                  <View style={styles.selectedIndicator}>
                    <Text style={styles.selectedIcon}>✓</Text>
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Location Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Location</Text>
          
          {/* City Selection */}
          <Text style={styles.subsectionTitle}>Select City</Text>
          <View style={styles.locationGrid}>
            {cities.map((city) => (
              <TouchableOpacity
                key={city}
                style={[
                  styles.locationCard,
                  selectedCity === city && styles.selectedLocationCard
                ]}
                onPress={() => {
                  setSelectedCity(city);
                  setSelectedArea('');
                }}
              >
                <Text style={styles.locationText}>{city}</Text>
                {selectedCity === city && (
                  <Text style={styles.selectedIcon}>✓</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>

          {/* Area Selection */}
          {selectedCity && (
            <>
              <Text style={styles.subsectionTitle}>Select Area</Text>
              <View style={styles.locationGrid}>
                {areas.map((area) => (
                  <TouchableOpacity
                    key={area}
                    style={[
                      styles.locationCard,
                      selectedArea === area && styles.selectedLocationCard
                    ]}
                    onPress={() => setSelectedArea(area)}
                  >
                    <Text style={styles.locationText}>{area}</Text>
                    {selectedArea === area && (
                      <Text style={styles.selectedIcon}>✓</Text>
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </>
          )}
        </View>

        {/* Addons Selection */}
        {selectedCity && selectedArea && addons.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Add-ons (Optional)</Text>
            <View style={styles.addonsGrid}>
              {addons.map((addon) => (
                <TouchableOpacity
                  key={addon.id}
                  style={[
                    styles.addonCard,
                    selectedAddons.includes(addon.id) && styles.selectedAddonCard
                  ]}
                  onPress={() => handleAddonToggle(addon.id)}
                >
                  <View style={styles.addonInfo}>
                    <Text style={styles.addonName}>{addon.name}</Text>
                    <Text style={styles.addonDescription}>{addon.description}</Text>
                    <Text style={styles.addonPrice}>+£{addon.basePrice}</Text>
                  </View>
                  {selectedAddons.includes(addon.id) && (
                    <View style={styles.selectedIndicator}>
                      <Text style={styles.selectedIcon}>✓</Text>
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        {/* Price Estimate */}
        {selectedCity && selectedArea && (
          <View style={styles.section}>
            <View style={styles.priceCard}>
              <Text style={styles.priceTitle}>Price Estimate</Text>
              <Text style={styles.priceAmount}>£{priceEstimate}</Text>
              {priceRange && (
                <Text style={styles.priceRange}>
                  Range: £{priceRange.min} - £{priceRange.max}
                </Text>
              )}
              <Text style={styles.priceNote}>
                *Final price may vary based on demand and conditions
              </Text>
            </View>
          </View>
        )}

        {/* Booking Button */}
        <View style={styles.bookingSection}>
          <TouchableOpacity
            style={[
              styles.bookButton,
              (!selectedCity || !selectedArea || isBooking) && styles.bookButtonDisabled
            ]}
            onPress={handleBookService}
            disabled={!selectedCity || !selectedArea || isBooking}
          >
            {isBooking ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <Text style={styles.bookButtonText}>
                Book Now - £{priceEstimate}
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 60,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  subsectionTitle: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
    marginTop: 16,
  },
  serviceGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  serviceCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    position: 'relative',
  },
  selectedServiceCard: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    borderColor: '#87CEEB',
    borderWidth: 2,
  },
  serviceIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 4,
  },
  serviceDescription: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  vehicleGrid: {
    flexDirection: 'row',
    gap: 8,
  },
  vehicleCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    position: 'relative',
  },
  selectedVehicleCard: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    borderColor: '#87CEEB',
    borderWidth: 2,
  },
  vehicleIcon: {
    fontSize: 24,
    marginBottom: 4,
  },
  vehicleName: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  locationGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  locationCard: {
    flex: 1,
    minWidth: (width - 60) / 2,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    position: 'relative',
  },
  selectedLocationCard: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    borderColor: '#87CEEB',
    borderWidth: 2,
  },
  locationText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  addonsGrid: {
    gap: 12,
  },
  addonCard: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    position: 'relative',
  },
  selectedAddonCard: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    borderColor: '#87CEEB',
    borderWidth: 2,
  },
  addonInfo: {
    flex: 1,
  },
  addonName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  addonDescription: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 4,
  },
  addonPrice: {
    color: '#4CAF50',
    fontSize: 14,
    fontWeight: 'bold',
  },
  selectedIndicator: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedIcon: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  priceCard: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    borderLeftWidth: 4,
    borderLeftColor: '#87CEEB',
  },
  priceTitle: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  priceAmount: {
    color: '#F9FAFB',
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  priceRange: {
    color: '#E5E7EB',
    fontSize: 14,
    marginBottom: 8,
  },
  priceNote: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  bookingSection: {
    padding: 20,
  },
  bookButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: 'center',
  },
  bookButtonDisabled: {
    backgroundColor: '#666',
  },
  bookButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
