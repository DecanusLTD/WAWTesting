import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Animated,
  Dimensions,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
// import { useAnimations } from '../../hooks/useAnimations';
// import { Card } from '../ui/Card';
// import { Button } from '../ui/Button';
import { useAuth } from '../../../app/auth-context';
import { simulationService, SimulationUser } from '../../services/SimulationService';
import { valeterVerificationService } from '../../services/ValeterVerificationService';

const { width } = Dimensions.get('window');

interface QuickActionProps {
  title: string;
  subtitle: string;
  icon: string;
  color: string;
  onPress: () => void;
  delay?: number;
}

const QuickAction: React.FC<QuickActionProps> = ({
  title,
  subtitle,
  icon,
  color,
  onPress,
  delay = 0,
}) => {
  // Simple animation replacement
  const fadeValue = useRef(new Animated.Value(0)).current;
  const scaleValue = useRef(new Animated.Value(1)).current;
  
  const fadeIn = () => {
    Animated.timing(fadeValue, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  };
  
  const pulse = () => {
    Animated.sequence([
      Animated.timing(scaleValue, {
        toValue: 1.1,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleValue, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
  };

  useEffect(() => {
    setTimeout(() => {
      fadeIn();
    }, delay);
  }, [fadeIn, delay]);

  const handlePress = () => {
    pulse();
    setTimeout(onPress, 150);
  };

  return (
    <Animated.View
      style={[
        styles.quickActionContainer,
        {
          opacity: fadeValue,
          transform: [{ scale: scaleValue }],
        },
      ]}
    >
      <TouchableOpacity onPress={handlePress} activeOpacity={0.9}>
        <LinearGradient
          colors={[color, `${color}CC`]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[styles.quickAction, {
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.3,
            shadowRadius: 8,
            elevation: 8,
          }]}
        >
          <Text style={styles.quickActionIcon}>{icon}</Text>
          <Text 
            style={[styles.quickActionTitle, { color: '#F9FAFB' }]}
            numberOfLines={1}
            ellipsizeMode="tail"
          >
            {title}
          </Text>
          <Text 
            style={[styles.quickActionSubtitle, { color: '#D1D5DB' }]}
            numberOfLines={1}
            ellipsizeMode="tail"
          >
            {subtitle}
          </Text>
        </LinearGradient>
      </TouchableOpacity>
    </Animated.View>
  );
};

interface StatCardProps {
  title: string;
  value: string;
  change: string;
  isPositive: boolean;
  icon: string;
  delay?: number;
  onPress?: () => void;
}

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  change,
  isPositive,
  icon,
  delay = 0,
  onPress,
}) => {
  // Simple animation replacement
  const fadeValue = useRef(new Animated.Value(0)).current;
  const slideValue = useRef(new Animated.Value(50)).current;
  const scaleValue = useRef(new Animated.Value(1)).current;
  
  const fadeIn = () => {
    Animated.timing(fadeValue, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  };
  
  const slideIn = () => {
    Animated.timing(slideValue, {
      toValue: 0,
      duration: 500,
      useNativeDriver: true,
    }).start();
  };
  
  const pulse = () => {
    Animated.sequence([
      Animated.timing(scaleValue, {
        toValue: 1.1,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleValue, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
  };

  useEffect(() => {
    setTimeout(() => {
      fadeIn();
      slideIn();
    }, delay);
  }, [fadeIn, slideIn, delay]);

  const handlePress = () => {
    if (onPress) {
      pulse();
      setTimeout(onPress, 150);
    }
  };

  const CardContent = (
    <View style={{
      backgroundColor: 'rgba(255, 255, 255, 0.1)',
      borderRadius: 12,
      padding: 16,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 3,
    }}>
      <View style={styles.statCardContent}>
        <View style={styles.statCardHeader}>
          <Text style={styles.statIcon}>{icon}</Text>
          <View style={[
            styles.changeIndicator,
            { backgroundColor: isPositive ? '#10B981' : '#EF4444' }
          ]}>
            <Text style={styles.changeText}>
              {isPositive ? '↗' : '↘'} {change}
            </Text>
          </View>
        </View>
        <Text 
          style={[styles.statValue, { color: '#F9FAFB' }]}
          numberOfLines={1}
          ellipsizeMode="tail"
        >
          {value}
        </Text>
        <Text 
          style={[styles.statTitle, { color: '#D1D5DB' }]}
          numberOfLines={1}
          ellipsizeMode="tail"
        >
          {title}
        </Text>
      </View>
    </View>
  );

  return (
    <Animated.View
      style={[
        {
          opacity: fadeValue,
          transform: [{ translateY: slideValue }, { scale: scaleValue }],
        },
      ]}
    >
      {onPress ? (
        <TouchableOpacity onPress={handlePress} activeOpacity={0.9}>
          {CardContent}
        </TouchableOpacity>
      ) : (
        CardContent
      )}
    </Animated.View>
  );
};

export const PowerfulDriverDashboard: React.FC = () => {
  const { user, logout } = useAuth();
  // Simple animation replacement
  const fadeValue = useRef(new Animated.Value(0)).current;
  
  const fadeIn = () => {
    Animated.timing(fadeValue, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  };
  
  // Online/Offline state
  const [isOnline, setIsOnline] = useState(false);
  const [workingRadius, setWorkingRadius] = useState(10); // Default 10km radius
  const [canGoOnline, setCanGoOnline] = useState(false);
  const [onlineStatusMessage, setOnlineStatusMessage] = useState('');
  const [availableJobs, setAvailableJobs] = useState<any[]>([]);
  const [incomingJob, setIncomingJob] = useState<any>(null);
  const [showJobRequest, setShowJobRequest] = useState(false);
  const [currentJob, setCurrentJob] = useState<any>(null);
  const [jobStatus, setJobStatus] = useState<'idle' | 'en_route' | 'in_progress' | 'completing'>('idle');
  const [recentJobs, setRecentJobs] = useState<any[]>([]);
  
  // Valeter following system
  const [showReferralModal, setShowReferralModal] = useState(false);
  
  // Organization system
  const [showOrganizationModal, setShowOrganizationModal] = useState(false);
  const [selectedOrganization, setSelectedOrganization] = useState<string | null>(null);
  const [organizationType, setOrganizationType] = useState<'independent' | 'business'>('independent');
  
  const scrollY = useRef(new Animated.Value(0)).current;
  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [200, 120],
    extrapolate: 'clamp',
  });

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 50, 100],
    outputRange: [1, 0.8, 0.6],
    extrapolate: 'clamp',
  });

  useEffect(() => {
    fadeIn();
  }, [fadeIn]);

  useEffect(() => {
    if (!user) return;

    console.log('🔍 Valeter Dashboard - User:', user);
    
    // Check if valeter can go online
    const checkOnlineStatus = () => {
      const { canGo, reason } = valeterVerificationService.canGoOnline(user.id);
      setCanGoOnline(canGo);
      setOnlineStatusMessage(reason || '');
    };
    
    checkOnlineStatus();
    
    // Check if this is first time login (show onboarding)
    const checkOnboarding = async () => {
      try {
        const hasSeenOnboarding = await AsyncStorage.getItem('valeter_onboarding_completed');
        if (!hasSeenOnboarding) {
          router.push('/valeter-onboarding');
          return;
        }
      } catch (error) {
        console.log('Error checking onboarding status:', error);
      }
    };
    
    checkOnboarding();
    
    // Add valeter to simulation service
    const valeterProfile: SimulationUser = {
      id: user.id,
      name: user.name,
      email: user.email,
      userType: 'valeter',
      location: { lat: 51.5074, lng: -0.1278 },
      isOnline: false,
      rating: 4.8,
      jobsCompleted: 127,
      phone: user.phone || '+44 7700 900123',
      isVerified: user.isVerified || false,
      documentsUploaded: user.documentsUploaded || false,
      insuranceVerified: user.insuranceVerified || false,
      licenseVerified: user.licenseVerified || false,
      backgroundCheckPassed: user.backgroundCheckPassed || false
    };
    
    simulationService.addUser(valeterProfile);

    // Subscribe to updates
    const unsubscribe = simulationService.subscribeToUpdates(user.id, (data) => {
      console.log('🔍 Valeter received update:', data);
      
      if (data.type === 'job_created' && isOnline) {
        // Show incoming job request
        setIncomingJob({
          id: data.job.id,
          customer: 'New Customer',
          customerPhone: '+44 7700 900000',
          vehicle: 'Customer Vehicle',
          location: data.job.location.address,
          distance: '2.3km',
          service: data.job.serviceType.replace('_', ' '),
          estimatedDuration: `${data.job.estimatedTime} min`,
          price: `£${data.job.price}`,
          specialInstructions: ''
        });
        setShowJobRequest(true);
      }
      
      if (data.type === 'job_accepted') {
        setCurrentJob({
          id: data.job.id,
          customer: 'Customer',
          vehicle: 'Customer Vehicle',
          service: data.job.serviceType.replace('_', ' '),
          price: `£${data.job.price}`,
          location: data.job.location.address
        });
        setJobStatus('en_route');
        setShowJobRequest(false);
      }
      
      if (data.type === 'job_started') {
        setJobStatus('in_progress');
      }
      
      if (data.type === 'job_completed') {
        setJobStatus('idle');
        setCurrentJob(null);
        // Update valeter stats
        const updatedUser = simulationService.getUser(user.id);
        if (updatedUser) {
          updatedUser.jobsCompleted += 1;
          simulationService.addUser(updatedUser);
        }
        // Add to recent jobs
        setRecentJobs(prev => [{
          id: data.job.id,
          customer: 'Customer',
          vehicle: 'Customer Vehicle',
          service: data.job.serviceType.replace('_', ' '),
          price: `£${data.job.price}`,
          status: 'completed',
          completedAt: new Date().toLocaleTimeString()
        }, ...prev.slice(0, 4)]);
      }
    });

    // Load initial data
    loadDashboardData();

    return () => unsubscribe();
  }, [user, isOnline]);

  const loadDashboardData = () => {
    if (!user) return;

    // Get available jobs
    const available = simulationService.getAvailableJobs();
    setAvailableJobs(available.map(job => ({
      id: job.id,
      customer: 'Customer',
      vehicle: 'Customer Vehicle',
      location: job.location.address,
      distance: '2.3km',
      price: `£${job.price}`,
      service: job.serviceType.replace('_', ' '),
      estimatedDuration: `${job.estimatedTime} min`
    })));

    // Get valeter's jobs
    const valeterJobs = simulationService.getJobsForUser(user.id, 'valeter');
    const activeJob = valeterJobs.find(job => job.status === 'accepted' || job.status === 'in_progress');
    if (activeJob) {
      setCurrentJob({
        id: activeJob.id,
        customer: 'Customer',
        vehicle: 'Customer Vehicle',
        service: activeJob.serviceType.replace('_', ' '),
        price: `£${activeJob.price}`,
        location: activeJob.location.address
      });
      setJobStatus(activeJob.status === 'accepted' ? 'en_route' : 'in_progress');
    }

    // Get recent completed jobs
    const completedJobs = valeterJobs.filter(job => job.status === 'completed');
    setRecentJobs(completedJobs.slice(0, 5).map(job => ({
      id: job.id,
      customer: 'Customer',
      vehicle: 'Customer Vehicle',
      service: job.serviceType.replace('_', ' '),
      price: `£${job.price}`,
      status: 'completed',
      completedAt: new Date(job.createdAt).toLocaleTimeString()
    })));
  };

  const handleOnlineToggle = () => {
    if (isOnline) {
      // Going offline
      setIsOnline(false);
      setAvailableJobs([]);
      simulationService.setUserOnlineStatus(user?.id || '', false);
      Alert.alert('Offline', 'You are now offline and not receiving new jobs.');
    } else {
      // Check if valeter can go online
      if (!canGoOnline) {
        Alert.alert(
          'Cannot Go Online',
          `You cannot go online at this time:\n\n${onlineStatusMessage}\n\nPlease complete your verification requirements in your profile.`,
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'View Profile', onPress: () => router.push('/valeter-profile') }
          ]
        );
        return;
      }
      
      // Going online - show radius selection first
      Alert.alert(
        'Set Working Radius',
        `Select your working radius (currently ${workingRadius}km):`,
        [
          { text: '5km', onPress: () => goOnline(5) },
          { text: '10km', onPress: () => goOnline(10) },
          { text: '15km', onPress: () => goOnline(15) },
          { text: 'Cancel', style: 'cancel' }
        ]
      );
    }
  };

  const goOnline = (radius: number) => {
    setWorkingRadius(radius);
    setIsOnline(true);
    simulationService.setUserOnlineStatus(user?.id || '', true);
    
    // Load available jobs
    loadDashboardData();
    
    Alert.alert('Online', `You are now online and receiving jobs within ${radius}km radius.`);
  };

  const handleAcceptJob = () => {
    if (!incomingJob || !user) return;
    
    if (simulationService.acceptJob(incomingJob.id, user.id)) {
      setShowJobRequest(false);
      setIncomingJob(null);
      Alert.alert('Job Accepted', 'You have accepted the job. Head to the customer location!');
      router.push('/tracking');
    } else {
      Alert.alert('Error', 'Failed to accept job. It may have been taken by another valeter.');
    }
  };

  const handleDeclineJob = () => {
    setShowJobRequest(false);
    setIncomingJob(null);
    Alert.alert('Job Declined', 'Job has been declined.');
  };

  const handleReferToValeter = () => {
    setShowJobRequest(false);
    setIncomingJob(null);
    Alert.alert('Job Referred', 'Job has been referred to another valeter.');
  };

  const handleStartJob = () => {
    if (!currentJob || !user) return;
    
    if (simulationService.startJob(currentJob.id)) {
      setJobStatus('in_progress');
      Alert.alert('Job Started', 'Service has begun!');
    } else {
      Alert.alert('Error', 'Failed to start job.');
    }
  };

  const handleCompleteJob = () => {
    if (!currentJob || !user) return;
    
    if (simulationService.completeJob(currentJob.id)) {
      setJobStatus('idle');
      setCurrentJob(null);
      Alert.alert('Job Completed', 'Service finished. Earnings updated!');
      
      // Update valeter stats
      const updatedUser = simulationService.getUser(user.id);
      if (updatedUser) {
        updatedUser.jobsCompleted += 1;
        simulationService.addUser(updatedUser);
      }
    } else {
      Alert.alert('Error', 'Failed to complete job.');
    }
  };

  const handleLogout = async () => {
    // Simple logout without confirmation for better UX
    try {
      await logout();
      router.replace('/');
    } catch (error) {
      console.log('Logout error:', error);
    }
  };

  // Mock data for rewards - will be replaced by detailed version below

  if (!user) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  const quickActions = [
    {
      title: isOnline ? 'Go Offline' : 'Go Online',
      subtitle: isOnline ? 'Stop accepting jobs' : canGoOnline ? 'Start accepting jobs' : onlineStatusMessage,
      icon: isOnline ? '🔴' : canGoOnline ? '🟢' : '⚠️',
      color: isOnline ? '#EF4444' : canGoOnline ? '#4CAF50' : '#FF9800',
      onPress: handleOnlineToggle,
    },
    {
      title: 'Current Trip',
      subtitle: 'View active job',
      icon: '📍',
      color: '#2196F3',
      onPress: () => router.push('/live-tracking'),
    },
    {
      title: 'Track Vehicle',
      subtitle: `Adjust radius (${workingRadius}km)`,
      icon: '🚗',
      color: '#87CEEB',
      onPress: () => {
        Alert.alert(
          'Set Working Radius',
          `Select your working radius (currently ${workingRadius}km):`,
          [
            { text: '5km', onPress: () => setWorkingRadius(5) },
            { text: '10km', onPress: () => setWorkingRadius(10) },
            { text: '15km', onPress: () => setWorkingRadius(15) },
            { text: '20km', onPress: () => setWorkingRadius(20) },
            { text: 'Cancel', style: 'cancel' }
          ]
        );
      },
    },
    {
      title: 'My Profile',
      subtitle: 'View & edit profile',
      icon: '👤',
      color: '#FF9800',
      onPress: () => router.push('/valeter-profile'),
    },
    {
      title: 'Valeter Network',
      subtitle: 'Manage connections',
      icon: '👥',
      color: '#9C27B0',
      onPress: () => router.push('/valeter-network'),
    },
    {
      title: 'Organization',
      subtitle: organizationType === 'independent' ? 'Independent Valeter' : `Working for ${selectedOrganization || 'Business'}`,
      icon: organizationType === 'independent' ? '🏢' : '🏢',
      color: organizationType === 'independent' ? '#6B7280' : '#10B981',
      onPress: () => setShowOrganizationModal(true),
    },
  ];

  // Driver Rewards System Data
  const driverRewards = {
    points: 850,
    level: 'Silver',
    nextLevel: 'Gold',
    pointsToNextLevel: 150,
    totalPoints: 850,
    recentEarnings: [
      { id: '1', amount: 25, reason: 'Completed valet', date: '1 hour ago' },
      { id: '2', amount: 50, reason: '5-star customer rating', date: '3 hours ago' },
      { id: '3', amount: 100, reason: 'Weekly performance bonus', date: '1 day ago' },
      { id: '4', amount: 30, reason: 'On-time arrival bonus', date: '2 days ago' },
    ]
  };

  const handleStatPress = () => {
    // Navigate to detailed stats page
    router.push('/detailed-stats');
  };

  const stats = [
    {
      title: 'Today\'s Earnings',
      value: '£45',
      change: '+£12',
      isPositive: true,
      icon: '💷',
      onPress: () => handleStatPress(),
    },
    {
      title: 'Jobs Completed',
      value: '3',
      change: '+1',
      isPositive: true,
      icon: '✅',
      onPress: () => handleStatPress(),
    },
    {
      title: 'Rewards Points',
      value: driverRewards.points.toString(),
      change: '+125',
      isPositive: true,
      icon: '🎁',
      onPress: () => router.push('/detailed-stats'),
    },
    {
      title: 'Online Hours',
      value: '6h',
      change: '+2h',
      isPositive: true,
      icon: '⏰',
      onPress: () => handleStatPress(),
    },
  ];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: '#0A1929' }]}>
      {/* Animated Header */}
      <Animated.View
        style={[
          styles.header,
          {
            height: headerHeight,
            opacity: headerOpacity,
          },
        ]}
      >
        <LinearGradient
          colors={['#0A1929', '#1E3A8A']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
        
        <View style={styles.headerContent}>
          <View style={styles.headerTop}>
            <View style={styles.headerLeft}>
              <Text style={[styles.greeting, { color: '#F9FAFB' }]}>
                {new Date().getHours() < 12 ? 'Good morning! 👋' : 
                 new Date().getHours() < 17 ? 'Good afternoon! 🌟' : 'Good evening! 🌙'}
              </Text>
              <Text style={[styles.userName, { color: '#F9FAFB' }]}>{user?.name || 'Valeter'}</Text>
              <Text style={[styles.subtitle, { color: '#87CEEB' }]}>Professional Valeting Dashboard</Text>
              
              <View style={styles.onlineStatus}>
                <View style={[
                  styles.onlineIndicator,
                  { backgroundColor: isOnline ? '#4CAF50' : '#EF4444' }
                ]} />
                <Text style={[
                  styles.onlineText,
                  { color: isOnline ? '#4CAF50' : '#EF4444' }
                ]}>
                  {isOnline ? 'Online' : 'Offline'}
                </Text>
              </View>
            </View>
            
            <View style={styles.headerActions}>
              <TouchableOpacity
                style={[styles.profileButton, {
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.3,
                  shadowRadius: 2,
                  elevation: 1,
                }]}
                onPress={() => router.push('/valeter-profile')}
              >
                <Text style={styles.profileIcon}>👤</Text>
              </TouchableOpacity>
            </View>
          </View>
          
          <View style={styles.poweredByContainer}>
            <Text style={styles.poweredByText}>Powered by Wish a Wash ⚡</Text>
          </View>
        </View>
      </Animated.View>

      {/* Scrollable Content */}
      <Animated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
      >
        {/* Quick Actions */}
        <Animated.View style={[styles.section, { opacity: fadeValue }]}>
          <Text style={[styles.sectionTitle, { color: '#F9FAFB' }]}>
            Quick Actions
          </Text>
          <View style={styles.quickActionsGrid}>
            {quickActions.map((action, index) => (
              <QuickAction
                key={action.title}
                {...action}
                delay={index * 100}
              />
            ))}
          </View>
        </Animated.View>

        {/* Statistics */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: '#F9FAFB' }]}>
            Today's Stats
          </Text>
          <View style={styles.statsGrid}>
            {stats.map((stat, index) => (
              <StatCard
                key={stat.title}
                {...stat}
                delay={index * 150}
              />
            ))}
          </View>
        </View>

        {/* Current Job Status */}
        {currentJob && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: '#F9FAFB' }]}>
              Current Job
            </Text>
            <View style={styles.cardContainer}>
              <View style={styles.currentJobHeader}>
                <Text style={styles.currentJobCustomer}>{currentJob.customer}</Text>
                <View style={[
                  styles.jobStatusBadge,
                  { backgroundColor: jobStatus === 'en_route' ? '#FF9800' : jobStatus === 'in_progress' ? '#2196F3' : '#4CAF50' }
                ]}>
                  <Text style={styles.jobStatusText}>
                    {jobStatus === 'en_route' ? 'En Route' : jobStatus === 'in_progress' ? 'In Progress' : 'Completing'}
                  </Text>
                </View>
              </View>
              <Text style={styles.currentJobVehicle}>{currentJob.vehicle}</Text>
              <Text style={styles.currentJobService}>{currentJob.service} • {currentJob.price}</Text>
              <Text style={styles.currentJobLocation}>📍 {currentJob.location}</Text>
            </View>
          </View>
        )}

        {/* Available Jobs Section - Only show when online */}
        {isOnline && availableJobs.length > 0 && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: '#F9FAFB' }]}>
              Available Jobs ({availableJobs.length})
            </Text>
            <View style={styles.cardContainer}>
              {availableJobs.map((job, index) => (
                <TouchableOpacity
                  key={job.id}
                  style={[
                    styles.jobCard,
                    index < availableJobs.length - 1 && styles.jobCardBorder
                  ]}
                  onPress={() => router.push('/live-tracking')}
                >
                  <View style={styles.jobHeader}>
                    <Text style={styles.jobCustomer}>{job.customer}</Text>
                    <Text style={styles.jobPrice}>{job.price}</Text>
                  </View>
                  <Text style={styles.jobVehicle}>{job.vehicle}</Text>
                  <View style={styles.jobDetails}>
                    <Text style={styles.jobLocation}>📍 {job.location} ({job.distance})</Text>
                    <Text style={styles.jobService}>🧽 {job.service}</Text>
                    <Text style={styles.jobDuration}>⏰ {job.estimatedDuration}</Text>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        {/* Rewards Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: '#F9FAFB' }]}>
            Rewards & Bonuses
          </Text>
          <View style={styles.cardContainer}>
            <View style={styles.rewardsHeader}>
              <View style={styles.rewardsInfo}>
                <Text style={styles.rewardsPoints}>{driverRewards.points} Points</Text>
                <Text style={styles.rewardsLevel}>{driverRewards.level} Level</Text>
                <Text style={styles.rewardsProgress}>
                  {driverRewards.pointsToNextLevel} points to {driverRewards.nextLevel}
                </Text>
              </View>
              <View style={styles.rewardsIcon}>
                <Text style={styles.rewardsIconText}>🎁</Text>
              </View>
            </View>
            
            <View style={styles.rewardsProgressBar}>
              <View style={styles.rewardsProgressFill} />
            </View>
            
            <View style={styles.rewardsActions}>
              <TouchableOpacity 
                style={styles.rewardsButton}
                onPress={() => router.push('/detailed-stats')}
              >
                <Text style={styles.rewardsButtonText}>View Rewards</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.rewardsButton}
                onPress={() => router.push('/detailed-stats')}
              >
                <Text style={styles.rewardsButtonText}>Earn More</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Recent Jobs */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: '#F9FAFB' }]}>
            Recent Jobs
          </Text>
          <View style={styles.cardContainer}>
            {recentJobs.map((job, index) => (
              <View key={job.id} style={styles.activityItem}>
                <Text style={styles.activityIcon}>
                  {job.status === 'completed' ? '✅' : '🚗'}
                </Text>
                <View style={styles.activityContent}>
                  <Text style={[styles.activityTitle, { color: '#F9FAFB' }]}>
                    {job.vehicle} - {job.status}
                  </Text>
                  <Text style={[styles.activitySubtitle, { color: '#E5E7EB' }]}>
                    {job.location} • {job.completedAt}
                  </Text>
                </View>
                <Text style={[styles.activityValue, { color: job.status === 'completed' ? '#10B981' : '#F59E0B' }]}>
                  £{job.price}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.section}>
          <TouchableOpacity
            style={styles.actionButtonPrimary}
            onPress={() => router.push('/detailed-stats')}
          >
            <Text style={styles.actionButtonText}>💰 View Earnings History</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.actionButtonSecondary}
            onPress={() => router.push('/valeter-profile')}
          >
            <Text style={styles.actionButtonSecondaryText}>👤 Manage Profile</Text>
          </TouchableOpacity>
        </View>

        {/* Quick Navigation */}
        <View style={styles.quickNav}>
          <TouchableOpacity style={styles.navButton} onPress={() => router.push('/detailed-stats')}>
            <Text style={styles.navButtonIcon}>📊</Text>
            <Text style={styles.navButtonText}>Stats</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.navButton} onPress={() => router.push('/help-support')}>
            <Text style={styles.navButtonIcon}>❓</Text>
            <Text style={styles.navButtonText}>Help</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.navButton} onPress={() => router.push('/live-chat')}>
            <Text style={styles.navButtonIcon}>💬</Text>
            <Text style={styles.navButtonText}>Chat</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.navButton} onPress={() => router.push('/valeter-documents')}>
            <Text style={styles.navButtonIcon}>📄</Text>
            <Text style={styles.navButtonText}>Docs</Text>
          </TouchableOpacity>
        </View>

      </Animated.ScrollView>

      {/* Incoming Job Request Popup */}
      {showJobRequest && incomingJob && (
        <View style={styles.jobRequestOverlay}>
          <Animated.View style={styles.jobRequestCard}>
            {/* Phone Call Header */}
            <View style={styles.callHeader}>
              <View style={styles.callIndicator}>
                <Text style={styles.callIcon}>📞</Text>
                <Text style={styles.callText}>Incoming Job Request</Text>
              </View>
              <Text style={styles.callTime}>Now</Text>
            </View>

            {/* Customer Info */}
            <View style={styles.customerInfo}>
              <Text style={styles.customerName}>{incomingJob.customer}</Text>
              <Text style={styles.customerPhone}>{incomingJob.customerPhone}</Text>
            </View>

            {/* Job Details */}
            <View style={styles.jobDetailsCard}>
              <View style={styles.jobDetailRow}>
                <Text style={styles.jobDetailLabel}>🚗 Vehicle:</Text>
                <Text style={styles.jobDetailValue}>{incomingJob.vehicle}</Text>
              </View>
              <View style={styles.jobDetailRow}>
                <Text style={styles.jobDetailLabel}>📍 Location:</Text>
                <Text style={styles.jobDetailValue}>{incomingJob.location}</Text>
              </View>
              <View style={styles.jobDetailRow}>
                <Text style={styles.jobDetailLabel}>📏 Distance:</Text>
                <Text style={styles.jobDetailValue}>{incomingJob.distance}</Text>
              </View>
              <View style={styles.jobDetailRow}>
                <Text style={styles.jobDetailLabel}>🧽 Service:</Text>
                <Text style={styles.jobDetailValue}>{incomingJob.service}</Text>
              </View>
              <View style={styles.jobDetailRow}>
                <Text style={styles.jobDetailLabel}>⏰ Duration:</Text>
                <Text style={styles.jobDetailValue}>{incomingJob.estimatedDuration}</Text>
              </View>
              <View style={styles.jobDetailRow}>
                <Text style={styles.jobDetailLabel}>💰 Price:</Text>
                <Text style={[styles.jobDetailValue, styles.priceText]}>{incomingJob.price}</Text>
              </View>
              {incomingJob.specialInstructions && (
                <View style={styles.specialInstructions}>
                  <Text style={styles.specialLabel}>📝 Special Instructions:</Text>
                  <Text style={styles.specialText}>{incomingJob.specialInstructions}</Text>
                </View>
              )}
            </View>

            {/* Action Buttons */}
            <View style={styles.jobActions}>
              <TouchableOpacity
                style={[styles.actionButton, styles.declineButton]}
                onPress={handleDeclineJob}
              >
                <Text style={styles.declineButtonText}>❌ Decline</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.actionButton, styles.referButton]}
                onPress={handleReferToValeter}
              >
                <Text style={styles.referButtonText}>👥 Refer</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.actionButton, styles.acceptButton]}
                onPress={handleAcceptJob}
              >
                <Text style={styles.acceptButtonText}>✅ Accept</Text>
              </TouchableOpacity>
            </View>
          </Animated.View>
        </View>
      )}

      {/* Referral Modal */}
      {showReferralModal && (
        <View style={styles.jobRequestOverlay}>
          <Animated.View style={styles.jobRequestCard}>
            <View style={styles.callHeader}>
              <View style={styles.callIndicator}>
                <Text style={styles.callIcon}>👥</Text>
                <Text style={styles.callText}>Refer to Valeter</Text>
              </View>
              <TouchableOpacity onPress={() => setShowReferralModal(false)}>
                <Text style={styles.callTime}>✕</Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.customerName}>Select a Valeter to Refer</Text>
            <Text style={styles.customerPhone}>Available valeters in your network</Text>

            <View style={styles.valeterList}>
              {/* This section is not directly tied to incomingJob, so it's not shown here */}
              {/* It would require a separate state for available valeters */}
            </View>

            <TouchableOpacity
              style={[styles.actionButton, styles.acceptButton]}
              onPress={() => setShowReferralModal(false)}
            >
              <Text style={styles.acceptButtonText}>Close</Text>
            </TouchableOpacity>
          </Animated.View>
        </View>
      )}

      {/* Organization Modal */}
      {showOrganizationModal && (
        <View style={styles.jobRequestOverlay}>
          <Animated.View style={styles.jobRequestCard}>
            <View style={styles.callHeader}>
              <View style={styles.callIndicator}>
                <Text style={styles.callIcon}>🏢</Text>
                <Text style={styles.callText}>Organization Settings</Text>
              </View>
              <TouchableOpacity onPress={() => setShowOrganizationModal(false)}>
                <Text style={styles.callTime}>✕</Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.customerName}>Choose Your Organization Type</Text>
            <Text style={styles.customerPhone}>Select how you want to operate</Text>

            <View style={styles.organizationOptions}>
              <TouchableOpacity
                style={[
                  styles.organizationOption,
                  organizationType === 'independent' && styles.selectedOrganizationOption
                ]}
                onPress={() => {
                  setOrganizationType('independent');
                  setSelectedOrganization(null);
                  hapticFeedback.selection();
                }}
              >
                <Text style={styles.organizationIcon}>👤</Text>
                <Text style={styles.organizationTitle}>Independent Valeter</Text>
                <Text style={styles.organizationSubtitle}>
                  Work independently with your own insurance and licensing
                </Text>
                <Text style={styles.organizationBenefits}>
                  • Full control over your business{'\n'}
                  • Keep 100% of earnings{'\n'}
                  • Manage your own schedule{'\n'}
                  • Need your own insurance & licensing
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.organizationOption,
                  organizationType === 'business' && styles.selectedOrganizationOption
                ]}
                onPress={() => {
                  setOrganizationType('business');
                  hapticFeedback.selection();
                }}
              >
                <Text style={styles.organizationIcon}>🏢</Text>
                <Text style={styles.organizationTitle}>Business Employee</Text>
                <Text style={styles.organizationSubtitle}>
                  Work under a business with their insurance and licensing
                </Text>
                <Text style={styles.organizationBenefits}>
                  • Business covers insurance & licensing{'\n'}
                  • Simplified onboarding process{'\n'}
                  • Team support and resources{'\n'}
                  • Shared business benefits
                </Text>
              </TouchableOpacity>
            </View>

            {organizationType === 'business' && (
              <View style={styles.businessSelection}>
                <Text style={styles.businessSelectionTitle}>Select Your Business</Text>
                <TouchableOpacity
                  style={styles.businessOption}
                  onPress={() => {
                    setSelectedOrganization('Elite Valet Services Ltd');
                    hapticFeedback.selection();
                  }}
                >
                  <Text style={styles.businessName}>Elite Valet Services Ltd</Text>
                  <Text style={styles.businessDetails}>
                    12 employees • London area • 4.8⭐ rating
                  </Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={styles.businessOption}
                  onPress={() => {
                    setSelectedOrganization('Premium Car Care Group');
                    hapticFeedback.selection();
                  }}
                >
                  <Text style={styles.businessName}>Premium Car Care Group</Text>
                  <Text style={styles.businessDetails}>
                    8 employees • Manchester area • 4.6⭐ rating
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.businessOption}
                  onPress={() => {
                    setSelectedOrganization('Custom Business');
                    hapticFeedback.selection();
                  }}
                >
                  <Text style={styles.businessName}>Add Custom Business</Text>
                  <Text style={styles.businessDetails}>
                    Contact support to add your business
                  </Text>
                </TouchableOpacity>
              </View>
            )}

            <View style={styles.organizationActions}>
              <TouchableOpacity
                style={[styles.actionButton, styles.declineButton]}
                onPress={() => setShowOrganizationModal(false)}
              >
                <Text style={styles.declineButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.actionButton, styles.acceptButton]}
                onPress={() => {
                  hapticFeedback.impact('medium');
                  Alert.alert(
                    'Organization Updated',
                    `You are now set as ${organizationType === 'independent' ? 'an independent valeter' : `working for ${selectedOrganization}`}. This affects your insurance and licensing requirements.`,
                    [{ text: 'OK', onPress: () => setShowOrganizationModal(false) }]
                  );
                }}
              >
                <Text style={styles.acceptButtonText}>Confirm</Text>
              </TouchableOpacity>
            </View>
          </Animated.View>
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 60,
    justifyContent: 'space-between',
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  headerLeft: {
    flex: 1,
  },
  headerCenter: {
    flex: 2,
    alignItems: 'center',
  },
  headerActions: {
    flex: 1,
    alignItems: 'flex-end',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    fontSize: 20,
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  greeting: {
    fontSize: 16,
    opacity: 0.9,
  },
  userName: {
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 4,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 12,
  },
  profileButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileIcon: {
    fontSize: 20,
  },
  poweredByContainer: {
    alignItems: 'flex-end',
    marginTop: 8,
  },
  poweredByText: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 10,
    fontWeight: '400',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingTop: 220,
    paddingHorizontal: 20,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  quickActionContainer: {
    width: (width - 56) / 2,
  },
  quickAction: {
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
    minHeight: 120,
    justifyContent: 'center',
  },
  quickActionIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  quickActionTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  quickActionSubtitle: {
    fontSize: 12,
    opacity: 0.8,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCardContent: {
    alignItems: 'center',
  },
  statCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 12,
  },
  statIcon: {
    fontSize: 24,
  },
  changeIndicator: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  changeText: {
    fontSize: 12,
    fontWeight: '600',
    color: 'white',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statTitle: {
    fontSize: 14,
    textAlign: 'center',
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  activityIcon: {
    fontSize: 24,
    marginRight: 16,
  },
  activityContent: {
    flex: 1,
  },
  activityTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 2,
  },
  activitySubtitle: {
    fontSize: 14,
    opacity: 0.7,
  },
  activityValue: {
    fontSize: 16,
    fontWeight: '600',
  },
  // Rewards Styles
  rewardsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  rewardsInfo: {
    flex: 1,
  },
  rewardsPoints: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  rewardsLevel: {
    fontSize: 16,
    color: '#87CEEB',
    fontWeight: '600',
    marginBottom: 4,
  },
  rewardsProgress: {
    fontSize: 14,
    color: '#D1D5DB',
  },
  rewardsIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  rewardsIconText: {
    fontSize: 24,
  },
  rewardsProgressBar: {
    height: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 3,
    marginBottom: 16,
  },
  rewardsProgressFill: {
    height: '100%',
    backgroundColor: '#87CEEB',
    borderRadius: 3,
    width: '70%',
  },
  rewardsActions: {
    flexDirection: 'row',
    gap: 12,
  },
  rewardsButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  rewardsButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  // Online Status Styles
  onlineStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  onlineIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#4CAF50',
    marginRight: 6,
  },
  onlineText: {
    fontSize: 12,
    color: '#4CAF50',
    fontWeight: '600',
  },
  // Job Card Styles
  jobCard: {
    paddingVertical: 16,
    paddingHorizontal: 0,
  },
  jobCardBorder: {
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  jobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  jobCustomer: {
    fontSize: 16,
    fontWeight: '600',
    color: '#F9FAFB',
  },
  jobPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  jobVehicle: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 8,
  },
  jobDetails: {
    gap: 4,
  },
  jobLocation: {
    fontSize: 12,
    color: '#D1D5DB',
  },
  jobService: {
    fontSize: 12,
    color: '#D1D5DB',
  },
  jobDuration: {
    fontSize: 12,
    color: '#D1D5DB',
  },
  // Job Request Popup Styles
  jobRequestOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  jobRequestCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 24,
    margin: 20,
    width: '90%',
    maxWidth: 400,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 15,
  },
  callHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.2)',
  },
  callIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  callIcon: {
    fontSize: 24,
    marginRight: 8,
  },
  callText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#F9FAFB',
  },
  callTime: {
    fontSize: 14,
    color: '#87CEEB',
  },
  customerInfo: {
    marginBottom: 20,
  },
  customerName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  customerPhone: {
    fontSize: 14,
    color: '#87CEEB',
  },
  jobDetailsCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  jobDetailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  jobDetailLabel: {
    fontSize: 14,
    color: '#D1D5DB',
    flex: 1,
  },
  jobDetailValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#F9FAFB',
    textAlign: 'right',
    flex: 1,
  },
  priceText: {
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  specialInstructions: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.2)',
  },
  specialLabel: {
    fontSize: 14,
    color: '#D1D5DB',
    marginBottom: 4,
  },
  specialText: {
    fontSize: 14,
    color: '#F9FAFB',
    fontStyle: 'italic',
  },
  jobActions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  declineButton: {
    backgroundColor: '#EF4444',
  },
  referButton: {
    backgroundColor: '#FF9800',
  },
  acceptButton: {
    backgroundColor: '#4CAF50',
  },
  declineButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  referButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  acceptButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  // Valeter List Styles
  valeterList: {
    marginVertical: 16,
  },
  valeterItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
    marginBottom: 8,
  },
  valeterInfo: {
    flex: 1,
  },
  valeterName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  valeterDetails: {
    fontSize: 12,
    color: '#D1D5DB',
  },
  referArrow: {
    fontSize: 18,
    color: '#87CEEB',
    fontWeight: 'bold',
  },
  // Organization Modal Styles
  organizationOptions: {
    marginVertical: 16,
    gap: 12,
  },
  organizationOption: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedOrganizationOption: {
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  organizationIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  organizationTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  organizationSubtitle: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 8,
  },
  organizationBenefits: {
    fontSize: 12,
    color: '#D1D5DB',
    lineHeight: 16,
  },
  businessSelection: {
    marginTop: 16,
    marginBottom: 16,
  },
  businessSelectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 12,
  },
  businessOption: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
  },
  businessName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  businessDetails: {
    fontSize: 12,
    color: '#87CEEB',
  },
  organizationActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  // Current Job Styles
  currentJobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  currentJobCustomer: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#F9FAFB',
  },
  jobStatusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  jobStatusText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  currentJobVehicle: {
    fontSize: 16,
    color: '#87CEEB',
    marginBottom: 8,
  },
  currentJobService: {
    fontSize: 14,
    color: '#D1D5DB',
    marginBottom: 8,
  },
  currentJobLocation: {
    fontSize: 14,
    color: '#D1D5DB',
  },
  cardContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  actionButtonPrimary: {
    backgroundColor: '#87CEEB',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    marginBottom: 12,
    alignItems: 'center',
  },
  actionButtonOutline: {
    backgroundColor: 'transparent',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#EF4444',
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
  actionButtonSecondary: {
    backgroundColor: 'transparent',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#87CEEB',
    alignItems: 'center',
    marginBottom: 12,
  },
  actionButtonSecondaryText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0A1929',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  logoutSection: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  logoutButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#EF4444',
    borderWidth: 3,
    borderColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  logoutIcon: {
    fontSize: 24,
  },
  quickNav: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    marginHorizontal: 20,
    marginTop: 20,
    borderRadius: 16,
  },
  navButton: {
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  navButtonIcon: {
    fontSize: 24,
    marginBottom: 4,
  },
  navButtonText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '500',
  },
});

export default PowerfulDriverDashboard;
