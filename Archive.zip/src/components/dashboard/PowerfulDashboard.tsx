import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  SafeAreaView,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../../app/auth-context';
import ExpoMap from '../../../app/components/ExpoMap';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { supabase } from '../../../src/lib/api/real/supabaseClient';

const { width } = Dimensions.get('window');

type DbBooking = {
  id: string;
  user_id: string;
  valeter_id: string | null;
  service_type: 'wash' | 'valet' | 'priority_wash' | string;
  scheduled_at: string;   // ISO timestamptz
  status: 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
  price: number | null;
  valeter_name: string | null;
  valeter_rating: number | null;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  created_at: string;
  updated_at: string;
};

interface Booking {
  id: string;
  serviceType: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  status: DbBooking['status'];
  price: number;
  valeterName?: string;
  valeterRating?: number;
  // NEW: coords for map usage
  locationAddress?: string | null;
  locationLat?: number | null;
  locationLng?: number | null;
}

interface CustomerStats {
  totalBookings: number;
  totalSpent: number;
  averageRating: number;
  completedServices: number;
}

interface ValeterStats {
  assignedCount: number;
  openJobs: number;
  completedServices: number;
  totalEarnings: number;
  averageRating: number;
}

function formatDateTime(iso: string) {
  const d = new Date(iso);
  const date = d.toISOString().slice(0, 10);
  const time = d.toTimeString().slice(0, 5);
  return { date, time };
}

export default function PowerfulDashboard() {
  const { user, logout } = useAuth();
  const isValeter = (user?.userType === 'valeter');

  // Shared state
  const [loading, setLoading] = useState(true);

  // Customer view
  const [custBookings, setCustBookings] = useState<Booking[]>([]);
  const [custStats, setCustStats] = useState<CustomerStats>({
    totalBookings: 0,
    totalSpent: 0,
    averageRating: 0,
    completedServices: 0,
  });

  // Valeter view
  const [valeterAssigned, setValeterAssigned] = useState<Booking[]>([]);
  const [valeterOpen, setValeterOpen] = useState<Booking[]>([]);
  const [valStats, setValStats] = useState<ValeterStats>({
    assignedCount: 0,
    openJobs: 0,
    completedServices: 0,
    totalEarnings: 0,
    averageRating: 0,
  });

  // Header animations
  const scrollY = useRef(new Animated.Value(0)).current;
  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [200, 120],
    extrapolate: 'clamp',
  });
  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 50, 100],
    outputRange: [1, 0.8, 0.6],
    extrapolate: 'clamp',
  });

  // ===== Helpers to map rows =====
  const toBooking = useCallback((row: DbBooking): Booking => {
    const { date, time } = formatDateTime(row.scheduled_at);
    return {
      id: row.id,
      serviceType: row.service_type,
      date,
      time,
      status: row.status,
      price: Number(row.price || 0),
      valeterName: row.valeter_name ?? undefined,
      valeterRating: row.valeter_rating != null ? Number(row.valeter_rating) : undefined,
      locationAddress: row.location_address ?? null,
      locationLat: row.location_lat ?? null,
      locationLng: row.location_lng ?? null,
    };
  }, []);

  // ===== Stats calculators =====
  const computeCustomerStats = useCallback((rows: DbBooking[]): CustomerStats => {
    const totalBookings = rows.length;
    let totalSpent = 0;
    let completedServices = 0;
    const ratings: number[] = [];

    for (const r of rows) {
      if (r.status === 'completed') {
        completedServices += 1;
        totalSpent += Number(r.price || 0);
      }
      if (r.valeter_rating != null) ratings.push(Number(r.valeter_rating));
    }
    const averageRating = ratings.length
      ? Math.round((ratings.reduce((a, b) => a + b, 0) / ratings.length) * 10) / 10
      : 0;

    return {
      totalBookings,
      totalSpent: Math.round(totalSpent * 100) / 100,
      averageRating,
      completedServices,
    };
  }, []);

  const computeValeterStats = useCallback((assigned: DbBooking[], open: DbBooking[]): ValeterStats => {
    const assignedCount = assigned.length;
    const openJobs = open.length;

    let completedServices = 0;
    let totalEarnings = 0;
    const ratings: number[] = [];

    for (const r of assigned) {
      if (r.status === 'completed') {
        completedServices += 1;
        totalEarnings += Number(r.price || 0);
      }
      if (r.valeter_rating != null) ratings.push(Number(r.valeter_rating));
    }
    const averageRating = ratings.length
      ? Math.round((ratings.reduce((a, b) => a + b, 0) / ratings.length) * 10) / 10
      : 0;

    return {
      assignedCount,
      openJobs,
      completedServices,
      totalEarnings: Math.round(totalEarnings * 100) / 100,
      averageRating,
    };
  }, []);

  // ===== Loaders =====
  const loadCustomer = useCallback(async () => {
    if (!user?.id) return;
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .eq('user_id', user.id)
      .order('scheduled_at', { ascending: false })
      .limit(50);

    if (error) throw error;
    const rows = (data || []) as DbBooking[];
    setCustBookings(rows.map(toBooking));
    setCustStats(computeCustomerStats(rows));
  }, [user?.id, toBooking, computeCustomerStats]);

  const loadValeter = useCallback(async () => {
    if (!user?.id) return;

    const assignedPromise = supabase
      .from('bookings')
      .select('*')
      .eq('valeter_id', user.id)
      .order('scheduled_at', { ascending: false })
      .limit(50);

    const openPromise = supabase
      .from('bookings')
      .select('*')
      .is('valeter_id', null)
      .eq('status', 'scheduled')
      .order('scheduled_at', { ascending: false })
      .limit(50);

    const [{ data: aData, error: aErr }, { data: oData, error: oErr }] = await Promise.all([assignedPromise, openPromise]);
    if (aErr) throw aErr;
    if (oErr) throw oErr;

    const assignedRows = (aData || []) as DbBooking[];
    const openRows = (oData || []) as DbBooking[];

    setValeterAssigned(assignedRows.map(toBooking));
    setValeterOpen(openRows.map(toBooking));
    setValStats(computeValeterStats(assignedRows, openRows));
  }, [user?.id, toBooking, computeValeterStats]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      if (isValeter) {
        await loadValeter();
      } else {
        await loadCustomer();
      }
    } catch (e: any) {
      console.log('dashboard load error:', e?.message || e);
      Alert.alert('Error', 'Could not load dashboard data.');
    } finally {
      setLoading(false);
    }
  }, [isValeter, loadCustomer, loadValeter]);

  useEffect(() => { load(); }, [load]);

  // Realtime
  useEffect(() => {
    if (!user?.id) return;

    if (isValeter) {
      const chAssigned = supabase
        .channel(`bookings-valeter-assigned-${user.id}`)
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'bookings', filter: `valeter_id=eq.${user.id}` },
          () => loadValeter()
        )
        .subscribe();

      const chOpen = supabase
        .channel(`bookings-open`)
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'bookings' },
          () => loadValeter()
        )
        .subscribe();

      return () => {
        supabase.removeChannel(chAssigned);
        supabase.removeChannel(chOpen);
      };
    } else {
      const chCustomer = supabase
        .channel(`bookings-user-${user.id}`)
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
          () => loadCustomer()
        )
        .subscribe();

      return () => {
        supabase.removeChannel(chCustomer);
      };
    }
  }, [user?.id, isValeter, loadCustomer, loadValeter]);

  // ===== Derived data for the map =====

  // Customer: show map only for latest in-progress booking with coords
  const latestInProgressBooking = useMemo(() => {
    if (isValeter) return null;
    const candidates = custBookings
      .filter(b => b.status === 'in_progress' && b.locationLat != null && b.locationLng != null)
      .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : a.time < b.time ? 1 : -1));
    return candidates[0] || null;
  }, [isValeter, custBookings]);

  // Valeter: markers for all open jobs with coords
  const openJobMarkers = useMemo(() => {
    if (!isValeter) return [];
    return valeterOpen
      .filter(b => b.locationLat != null && b.locationLng != null)
      .map(b => ({
        latitude: Number(b.locationLat),
        longitude: Number(b.locationLng),
        title: b.serviceType,
        description: b.locationAddress || `${b.date} ${b.time}`,
      }));
  }, [isValeter, valeterOpen]);

  // ===== Actions & nav =====
  const handleQuickBook = async () => { await hapticFeedback.impact('medium'); router.push('/enhanced-booking'); };
  const handleInstantWash = async () => { await hapticFeedback.impact('medium'); router.push('/instant-wash'); };
  const handlePriorityWash = async () => { await hapticFeedback.impact('medium'); router.push('/priority-wash'); };
  const handleViewProfile = () => router.push(isValeter ? '/driver-profile' : '/owner-profile');
  const handleViewAnalytics = () => router.push('/detailed-stats');
  const handleViewNetwork = () => router.push('/car-owner-network');
  const handleSystemMonitor = () => router.push('/system-monitor');
  const handleLogout = async () => { try { await logout(); router.replace('/'); } catch (e) { console.log('Logout error:', e); } };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Loading dashboard...</Text>
      </View>
    );
  }

  // Status color helper
  const statusBg = (s: DbBooking['status']) =>
    s === 'completed' ? '#10B981' :
    s === 'in_progress' ? '#F59E0B' :
    s === 'scheduled' ? '#6B7280' : '#EF4444';

  const goToTracking = async (bookingId: string) => {
    try { await hapticFeedback.impact('light'); } catch {}
    router.push({ pathname: '/tracking', params: { bookingId } as any });
  };

  const BookingRow = ({ b }: { b: Booking }) => (
    <TouchableOpacity style={styles.bookingCard} activeOpacity={0.8} onPress={() => goToTracking(b.id)}>
      <View style={styles.bookingHeader}>
        <Text style={styles.bookingService}>{b.serviceType}</Text>
        <View style={[styles.bookingStatus, { backgroundColor: statusBg(b.status) }]}>
          <Text style={styles.bookingStatusText}>{b.status}</Text>
        </View>
      </View>
      <Text style={styles.bookingDetails}>
        {b.date} at {b.time} • £{b.price.toFixed(2)}
      </Text>
      {b.valeterName && (
        <Text style={styles.valeterInfo}>
          Valeter: {b.valeterName} {b.valeterRating ? `${b.valeterRating}⭐` : ''}
        </Text>
      )}
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Animated Header */}
      <Animated.View style={[styles.header, { height: headerHeight, opacity: headerOpacity }]}>
        <LinearGradient colors={['#1E3A8A', '#87CEEB']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
        <View style={styles.headerContent}>
          <View style={styles.headerTop}>
            <View style={styles.headerLeft}>
              <Text style={styles.greeting}>
                {new Date().getHours() < 12 ? 'Good morning! 👋'
                 : new Date().getHours() < 17 ? 'Good afternoon! 🌟'
                 : 'Good evening! 🌙'}
              </Text>
              <Text style={styles.userName}>{user?.name || (isValeter ? 'Valeter' : 'Customer')}</Text>
              <Text style={styles.subtitle}>
                {isValeter ? 'Your jobs and earnings at a glance' : 'Welcome to Wish a Wash'}
              </Text>
            </View>
            <View style={styles.headerActions}>
              <TouchableOpacity style={styles.profileButton} onPress={handleViewProfile}>
                <Text style={styles.profileIcon}>👤</Text>
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.poweredByContainer}>
            <Text style={styles.poweredByText}>Powered by Wish a Wash ⚡</Text>
          </View>
        </View>
      </Animated.View>

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
      >
        {/* Quick Actions */}
        <View style={styles.quickActions}>
          {!isValeter && (
            <TouchableOpacity style={styles.quickActionCard} onPress={handleQuickBook}>
              <LinearGradient colors={['#6B7280', '#4B5563']} style={styles.quickActionGradient}>
                <Text style={styles.quickActionIcon}>📅</Text>
                <Text style={styles.quickActionTitle}>Book Service</Text>
                <Text style={styles.quickActionSubtitle}>Schedule a valet</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}

          {isValeter ? (
            <>
              <TouchableOpacity style={styles.quickActionCard} onPress={() => router.push('/ValeterJobsScreen')}>
                <LinearGradient colors={['#0ea5e9', '#0369a1']} style={styles.quickActionGradient}>
                  <Text style={styles.quickActionIcon}>🧽</Text>
                  <Text style={styles.quickActionTitle}>Open Jobs</Text>
                  <Text style={styles.quickActionSubtitle}>Claim available work</Text>
                </LinearGradient>
              </TouchableOpacity>
              <TouchableOpacity style={styles.quickActionCard} onPress={() => router.push('/ValeterJobsScreen')}>
                <LinearGradient colors={['#22c55e', '#15803d']} style={styles.quickActionGradient}>
                  <Text style={styles.quickActionIcon}>📋</Text>
                  <Text style={styles.quickActionTitle}>My Assignments</Text>
                  <Text style={styles.quickActionSubtitle}>Today’s workload</Text>
                </LinearGradient>
              </TouchableOpacity>
            </>
          ) : (
            <>
              <TouchableOpacity style={styles.quickActionCard} onPress={handleInstantWash}>
                <LinearGradient colors={['#10B981', '#059669']} style={styles.quickActionGradient}>
                  <Text style={styles.quickActionIcon}>⚡</Text>
                  <Text style={styles.quickActionTitle}>Instant Wash</Text>
                  <Text style={styles.quickActionSubtitle}>15 min service</Text>
                </LinearGradient>
              </TouchableOpacity>
              <TouchableOpacity style={styles.quickActionCard} onPress={handlePriorityWash}>
                <LinearGradient colors={['#000000', '#FFD700']} style={styles.quickActionGradient}>
                  <Text style={styles.quickActionIcon}>🏆</Text>
                  <Text style={styles.quickActionTitle}>Priority Wash</Text>
                  <Text style={styles.quickActionSubtitle}>Skip the queue</Text>
                </LinearGradient>
              </TouchableOpacity>
            </>
          )}
        </View>

        {/* Stats */}
        <View style={styles.statsSection}>
          <Text style={styles.sectionTitle}>📊 Overview</Text>
          {isValeter ? (
            <View className="valeter-stats" style={styles.statsGrid}>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{valStats.assignedCount}</Text>
                <Text style={styles.statLabel}>Assigned Jobs</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{valStats.openJobs}</Text>
                <Text style={styles.statLabel}>Open Jobs</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>£{valStats.totalEarnings.toFixed(2)}</Text>
                <Text style={styles.statLabel}>Earnings (Completed)</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>
                  {valStats.averageRating ? `${valStats.averageRating}⭐` : '—'}
                </Text>
                <Text style={styles.statLabel}>Avg Rating</Text>
              </View>
            </View>
          ) : (
            <View className="customer-stats" style={styles.statsGrid}>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{custStats.totalBookings}</Text>
                <Text style={styles.statLabel}>Total Bookings</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>£{custStats.totalSpent.toFixed(2)}</Text>
                <Text style={styles.statLabel}>Total Spent</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>
                  {custStats.averageRating ? `${custStats.averageRating}⭐` : '—'}
                </Text>
                <Text style={styles.statLabel}>Avg Rating</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{custStats.completedServices}</Text>
                <Text style={styles.statLabel}>Completed</Text>
              </View>
            </View>
          )}
        </View>

        {/* Map Section — conditional */}
        <View style={styles.mapSection}>
          <Text style={styles.sectionTitle}>
            {isValeter ? '📍 Open Jobs Near You' : '📍 Follow Your Valeter'}
          </Text>

          {/* CUSTOMER: show only if latest in-progress booking with coords exists */}
          {!isValeter && latestInProgressBooking && latestInProgressBooking.locationLat != null && latestInProgressBooking.locationLng != null ? (
            <TouchableOpacity
              style={styles.mapContainer}
              onPress={() => router.push({ pathname: '/tracking', params: { bookingId: latestInProgressBooking.id } as any })}
              activeOpacity={0.9}
            >
              <ExpoMap
                userLocation={{
                  latitude: Number(latestInProgressBooking.locationLat),
                  longitude: Number(latestInProgressBooking.locationLng),
                  address: latestInProgressBooking.locationAddress || 'Service location',
                }}
                valeterLocation={{
                  // If you later store live valeter coords, pass them here; for now mirror user location
                  latitude: Number(latestInProgressBooking.locationLat),
                  longitude: Number(latestInProgressBooking.locationLng),
                  address: 'Awaiting valeter GPS',
                }}
                showMap
                isCustomerView
              />
            </TouchableOpacity>
          ) : null}

          {/* VALETER: show map of all open jobs (markers) */}
          {isValeter && openJobMarkers.length > 0 ? (
            <TouchableOpacity style={styles.mapContainer} onPress={() => router.push('/ValeterJobsScreen')} activeOpacity={0.9}>
              <ExpoMap
                // Optional markers prop — add support in ExpoMap to render multiple pins
                // Each marker: { latitude, longitude, title?, description? }
                // Fallback: if your ExpoMap doesn't support markers, pick the first marker to center the map.
                markers={openJobMarkers}
                showMap
                isCustomerView={false}
              />
            </TouchableOpacity>
          ) : null}
        </View>

        {/* Lists */}
        {isValeter ? (
          <>
            <View style={styles.bookingsSection}>
              <Text style={styles.sectionTitle}>📋 Assigned to You</Text>
              {valeterAssigned.map((b) => (
                <BookingRow key={b.id} b={b} />
              ))}
            </View>

            <View style={styles.bookingsSection}>
              <Text style={styles.sectionTitle}>🆓 Open Jobs</Text>
              {valeterOpen.map((b) => (
                <BookingRow key={b.id} b={b} />
              ))}
            </View>
          </>
        ) : (
          <View style={styles.bookingsSection}>
            <Text style={styles.sectionTitle}>📋 Recent Bookings</Text>
            {custBookings.map((b) => (
              <BookingRow key={b.id} b={b} />
            ))}
          </View>
        )}

        {/* Quick Navigation */}
        <View style={styles.quickNav}>
          <TouchableOpacity style={styles.navButton} onPress={handleViewProfile}>
            <Text style={styles.navButtonIcon}>👤</Text>
            <Text style={styles.navButtonText}>Profile</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.navButton} onPress={handleViewAnalytics}>
            <Text style={styles.navButtonIcon}>📊</Text>
            <Text style={styles.navButtonText}>Analytics</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.navButton} onPress={handleViewNetwork}>
            <Text style={styles.navButtonIcon}>🌐</Text>
            <Text style={styles.navButtonText}>Network</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.navButton} onPress={handleSystemMonitor}>
            <Text style={styles.navButtonIcon}>🛡️</Text>
            <Text style={styles.navButtonText}>System</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.navButton} onPress={() => router.push('/admin-dashboard')}>
            <Text style={styles.navButtonIcon}>👑</Text>
            <Text style={styles.navButtonText}>Admin</Text>
          </TouchableOpacity>
        </View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#0A1929' },
  loadingText: { color: '#F9FAFB', fontSize: 16 },
  header: { position: 'absolute', top: 0, left: 0, right: 0, zIndex: 1000 },
  headerContent: { flex: 1, justifyContent: 'flex-end', padding: 20 },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  headerLeft: { flex: 1 },
  headerActions: { flexDirection: 'row', gap: 12 },
  profileButton: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center' },
  profileIcon: { fontSize: 20 },
  greeting: { color: '#F9FAFB', fontSize: 18, marginBottom: 4 },
  userName: { color: '#F9FAFB', fontSize: 28, fontWeight: 'bold', marginBottom: 4 },
  subtitle: { color: '#87CEEB', fontSize: 16 },
  poweredByContainer: { alignItems: 'flex-end', marginTop: 8 },
  poweredByText: { color: 'rgba(255, 255, 255, 0.6)', fontSize: 10, fontWeight: '400' },
  scrollView: { flex: 1, paddingTop: 200 },
  quickActions: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 20, gap: 12, marginBottom: 24 },
  quickActionCard: { flex: 1, borderRadius: 16, overflow: 'hidden', elevation: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8 },
  quickActionGradient: { padding: 20, alignItems: 'center' },
  quickActionIcon: { fontSize: 32, marginBottom: 8 },
  quickActionTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold', marginBottom: 4 },
  quickActionSubtitle: { color: '#FFFFFF', fontSize: 12, opacity: 0.9 },

  statsSection: { paddingHorizontal: 20, marginBottom: 24 },
  sectionTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: 'bold', marginBottom: 16 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  statCard: { flex: 1, minWidth: (width - 52) / 2, backgroundColor: '#1E3A8A', padding: 16, borderRadius: 12, alignItems: 'center' },
  statNumber: { fontSize: 24, fontWeight: 'bold', color: '#F9FAFB', marginBottom: 4 },
  statLabel: { fontSize: 12, color: '#87CEEB', textAlign: 'center' },

  mapSection: { paddingHorizontal: 20, marginBottom: 24 },
  mapContainer: { backgroundColor: '#1E3A8A', borderRadius: 20, marginBottom: 20, overflow: 'hidden', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.25, shadowRadius: 3.84, elevation: 5, height: 300, position: 'relative' },

  bookingsSection: { paddingHorizontal: 20, marginBottom: 24 },
  bookingCard: { backgroundColor: '#1E3A8A', padding: 16, borderRadius: 12, marginBottom: 12 },
  bookingHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  bookingService: { fontSize: 16, fontWeight: '600', color: '#F9FAFB' },
  bookingStatus: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  bookingStatusText: { fontSize: 12, color: '#FFFFFF', fontWeight: '600' },
  bookingDetails: { fontSize: 14, color: '#87CEEB', marginBottom: 4 },
  valeterInfo: { fontSize: 12, color: '#9CA3AF' },

  quickNav: { flexDirection: 'row', justifyContent: 'space-around', paddingHorizontal: 20, paddingVertical: 16, backgroundColor: '#1E3A8A', marginHorizontal: 20, marginTop: 20, borderRadius: 16 },
  navButton: { alignItems: 'center', paddingVertical: 8, paddingHorizontal: 12 },
  navButtonIcon: { fontSize: 24, marginBottom: 4 },
  navButtonText: { color: '#F9FAFB', fontSize: 12, fontWeight: '500' },
});