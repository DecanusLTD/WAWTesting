// Test script to verify migration setup
import * as api from '../api';

export async function testMigrationSetup() {
  console.log('🧪 Testing Migration Setup...');
  
  try {
    // Test auth
    console.log('Testing auth...');
    const session = await api.auth.login('test@example.com', 'password');
    console.log('✅ Auth test passed:', session.role);
    
    // Test services
    console.log('Testing services...');
    const services = await api.jobs.listServices();
    console.log('✅ Services test passed:', services.length, 'services');
    
    // Test payment intent
    console.log('Testing payments...');
    const paymentIntent = await api.payments.createPaymentIntent({
      serviceId: 1,
      lat: 51.5074,
      lng: -0.1278
    });
    console.log('✅ Payments test passed:', paymentIntent.status);
    
    // Test locations
    console.log('Testing locations...');
    const valeters = await api.locations.getNearbyValeters(51.5074, -0.1278);
    console.log('✅ Locations test passed:', valeters.length, 'valeters');
    
    console.log('🎉 All migration tests passed!');
    return true;
    
  } catch (error) {
    console.error('❌ Migration test failed:', error);
    return false;
  }
}

// Test both mock and real modes
export async function testBothModes() {
  console.log('🔄 Testing Mock Mode...');
  process.env.EXPO_PUBLIC_USE_REAL = 'false';
  await testMigrationSetup();
  
  console.log('\n🔄 Testing Real Mode...');
  process.env.EXPO_PUBLIC_USE_REAL = 'true';
  await testMigrationSetup();
}
