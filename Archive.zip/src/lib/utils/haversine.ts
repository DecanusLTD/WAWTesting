// Haversine distance calculation
export function distanceKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const R = 6371; // Earth's radius in km
  
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  
  const s1 = Math.sin(dLat / 2);
  const s2 = Math.sin(dLng / 2);
  
  const c = 2 * Math.asin(Math.sqrt(s1 * s1 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * s2 * s2));
  return R * c;
}

export function etaMinutesKm(distanceKm: number, avgKmh = 25, min = 2, max = 120) {
  const mins = (distanceKm / avgKmh) * 60;
  return Math.max(min, Math.min(max, Math.round(mins)));
}
