// Real payments implementation using Stripe
export async function createPaymentIntent(args: { serviceId: number; lat: number; lng: number }) {
  const functionsBase = process.env.EXPO_PUBLIC_FUNCTIONS_BASE;
  if (!functionsBase) throw new Error('Functions base URL not configured');
  
  const response = await fetch(`${functionsBase}/confirm-payment`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(args)
  });
  
  if (!response.ok) throw new Error(await response.text());
  return response.json();
}
