// Real tracking implementation using Supabase
import { supabase } from "./supabaseClient";

export function subscribePings(jobId: number, cb: (p: { lat: number; lng: number; atIso: string }) => void) {
  const channel = supabase
    .channel(`pings-${jobId}`)
    .on("postgres_changes",
      { event: "INSERT", schema: "public", table: "locations", filter: `job_id=eq.${jobId}` },
      (payload) => cb({
        lat: payload.new.lat,
        lng: payload.new.lng,
        atIso: payload.new.at
      })
    )
    .subscribe();
  
  return () => supabase.removeChannel(channel);
}

export async function sendPing(jobId: number, lat: number, lng: number) {
  const { error } = await supabase
    .from("locations")
    .insert({ job_id: jobId, lat, lng });
  
  if (error) throw error;
}
