// Real auth implementation using Supabase
import { supabase } from "./supabaseClient";

export type Role = "customer" | "valeter" | "admin";
export type Session = { userId: string; role: Role; emailVerified: boolean; phoneVerified: boolean };

export async function login(email: string, password: string): Promise<Session> {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  
  const user = data.user!;
  
  // Fetch role from profiles table
  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .maybeSingle();
  
  const role = (profile?.role ?? "customer") as Role;
  
  return {
    userId: user.id,
    role,
    emailVerified: !!user.email_confirmed_at,
    phoneVerified: true // Assuming phone verification is handled separately
  };
}

export async function logout(): Promise<void> {
  await supabase.auth.signOut();
}

export async function getCurrentSession(): Promise<Session | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  
  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .maybeSingle();
  
  const role = (profile?.role ?? "customer") as Role;
  
  return {
    userId: user.id,
    role,
    emailVerified: !!user.email_confirmed_at,
    phoneVerified: true
  };
}
