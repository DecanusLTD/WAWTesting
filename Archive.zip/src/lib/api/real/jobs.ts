// Real jobs implementation using Supabase
import { supabase } from "./supabaseClient";

export type JobStatus = 'REQUESTED' | 'ACCEPTED' | 'EN_ROUTE' | 'ARRIVED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED' | 'EXPIRED';

export async function listServices() {
  const { data, error } = await supabase
    .from("services")
    .select("*")
    .order("price");
  
  if (error) throw error;
  return data!;
}

export async function createPendingJob(args: { serviceId: number; pickup: { lat: number; lng: number } }) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Not authenticated");
  
  const { data, error } = await supabase
    .from("jobs")
    .insert({
      customer_id: user.id,
      service_id: args.serviceId,
      pickup_lat: args.pickup.lat,
      pickup_lng: args.pickup.lng,
      status: 'REQUESTED'
    })
    .select("id")
    .single();
  
  if (error) throw error;
  return { jobId: data!.id as number };
}

export async function acceptJob(jobId: number) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Not authenticated");
  
  const { error } = await supabase
    .from("jobs")
    .update({ status: 'ACCEPTED', valeter_id: user.id })
    .eq("id", jobId)
    .is("valeter_id", null)
    .eq("status", 'REQUESTED');
  
  if (error) throw error;
}

export function subscribeJob(jobId: number, cb: (j: any) => void) {
  const channel = supabase
    .channel(`job-${jobId}`)
    .on("postgres_changes",
      { event: "UPDATE", schema: "public", table: "jobs", filter: `id=eq.${jobId}` },
      (payload) => cb(payload.new)
    )
    .subscribe();
  
  return () => supabase.removeChannel(channel);
}

export async function advance(jobId: number, next: JobStatus) {
  const { error } = await supabase
    .from("jobs")
    .update({ status: next })
    .eq("id", jobId);
  
  if (error) throw error;
}
