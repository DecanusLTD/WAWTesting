// Mock Payments API - Wraps existing PaymentSystem functionality
import { 
  PaymentsAPI, 
  RefundRequest, 
  ApiException, 
  ErrorCodes 
} from '../types';

// Import existing payment system
import { PaymentSystem } from '../../../services/PaymentSystem';

// Mock payment data
const mockRefundRequests: RefundRequest[] = [
  {
    id: 1,
    jobId: 1,
    customerId: 'customer_1',
    valeterId: 'valeter_1',
    amount: 2500, // £25.00
    reason: 'Service not completed as expected',
    status: 'pending',
    priority: 2,
    createdAtIso: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 2,
    jobId: 2,
    customerId: 'customer_1',
    valeterId: 'valeter_1',
    amount: 3500, // £35.00
    reason: 'Valeter did not arrive',
    status: 'approved',
    priority: 1,
    processedBy: 'reece_admin',
    processedAtIso: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    createdAtIso: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
  },
];

// Mock implementation that wraps PaymentSystem
export const payments: PaymentsAPI = {
  // Payment processing
  async createPaymentIntent(jobId: number, amount: number): Promise<{ clientSecret: string }> {
    console.log('💳 Mock Payments: Create payment intent', { jobId, amount });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock validation
    if (!jobId || amount <= 0) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Invalid job ID or amount');
    }
    
    // Mock payment intent creation
    const clientSecret = `pi_mock_${jobId}_${Date.now()}_secret_${Math.random().toString(36).substr(2, 9)}`;
    
    console.log('💳 Mock Payments: Payment intent created', { clientSecret });
    
    return { clientSecret };
  },

  async confirmPayment(paymentIntentId: string): Promise<void> {
    console.log('💳 Mock Payments: Confirm payment', { paymentIntentId });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock validation
    if (!paymentIntentId || !paymentIntentId.startsWith('pi_mock_')) {
      throw new ApiException(ErrorCodes.PAYMENT_FAILED, 'Invalid payment intent ID');
    }
    
    // Mock payment confirmation
    console.log('💳 Mock Payments: Payment confirmed successfully');
  },

  // Refunds
  async requestRefund(jobId: number, amount: number, reason: string): Promise<RefundRequest> {
    console.log('💳 Mock Payments: Request refund', { jobId, amount, reason });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Mock validation
    if (!jobId || amount <= 0 || !reason) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Invalid refund request data');
    }
    
    // Create refund request
    const refundRequest: RefundRequest = {
      id: mockRefundRequests.length + 1,
      jobId,
      customerId: 'customer_1', // Mock customer ID
      valeterId: 'valeter_1', // Mock valeter ID
      amount,
      reason,
      status: 'pending',
      priority: 2, // Default priority
      createdAtIso: new Date().toISOString(),
    };
    
    // Add to mock data
    mockRefundRequests.push(refundRequest);
    
    console.log('💳 Mock Payments: Refund request created', { refundId: refundRequest.id });
    
    return refundRequest;
  },

  async getRefundRequests(userId: string): Promise<RefundRequest[]> {
    console.log('💳 Mock Payments: Get refund requests', { userId });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Return refund requests for the user
    const userRefunds = mockRefundRequests.filter(refund => 
      refund.customerId === userId || refund.valeterId === userId
    );
    
    return userRefunds;
  },

  // Admin functions
  async processRefund(refundId: number, action: "approve" | "reject", notes?: string): Promise<RefundRequest> {
    console.log('💳 Mock Payments: Process refund', { refundId, action, notes });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Find refund request
    const refundRequest = mockRefundRequests.find(refund => refund.id === refundId);
    if (!refundRequest) {
      throw new ApiException(ErrorCodes.NOT_FOUND, 'Refund request not found');
    }
    
    // Update refund request
    refundRequest.status = action === 'approve' ? 'approved' : 'rejected';
    refundRequest.processedBy = 'reece_admin'; // Mock admin user
    refundRequest.processedAtIso = new Date().toISOString();
    if (notes) {
      refundRequest.adminNotes = notes;
    }
    
    console.log('💳 Mock Payments: Refund processed', { 
      refundId, 
      action, 
      status: refundRequest.status 
    });
    
    return refundRequest;
  },

  async getRefundRequestsForAdmin(): Promise<RefundRequest[]> {
    console.log('💳 Mock Payments: Get refund requests for admin');
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Return all refund requests for admin
    return mockRefundRequests;
  },
};
