// Mock Auth API - Wraps existing AuthContext functionality
import { 
  AuthAPI, 
  User, 
  RegisterData, 
  ApiException, 
  ErrorCodes 
} from '../types';

// Import existing auth context types
import { useAuth } from '../../../app/auth-context';

// Mock implementation that uses existing AuthContext
export const auth: AuthAPI = {
  // Authentication
  async login(email: string, password: string): Promise<{ user: User; session: any }> {
    console.log('🔐 Mock Auth: Login attempt', { email });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Mock validation
    if (!email || !password) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Email and password are required');
    }
    
    // Mock user lookup (this would normally come from AuthContext)
    const mockUsers = [
      {
        id: 'customer_1',
        email: 'customer@test.com',
        name: 'John Customer',
        phone: '+44 7700 900001',
        role: 'customer' as const,
        userType: 'customer' as const,
        isEmailVerified: true,
        rating: 4.8,
        jobsCompleted: 0,
        yearsExperience: 0,
        badges: [],
        createdAtIso: new Date().toISOString(),
        updatedAtIso: new Date().toISOString(),
      },
      {
        id: 'valeter_1',
        email: 'valeter@test.com',
        name: 'Mike Valeter',
        phone: '+44 7700 900123',
        role: 'valeter' as const,
        userType: 'valeter' as const,
        isEmailVerified: true,
        rating: 4.9,
        jobsCompleted: 127,
        yearsExperience: 3,
        badges: ['Pro', 'Verified'],
        createdAtIso: new Date().toISOString(),
        updatedAtIso: new Date().toISOString(),
      },
      {
        id: 'reece_admin',
        email: 'reece@wishawash.com',
        name: 'Reece Dixon',
        phone: '+44 7700 900000',
        role: 'admin' as const,
        userType: 'customer' as const,
        isEmailVerified: true,
        rating: 5.0,
        jobsCompleted: 0,
        yearsExperience: 0,
        badges: ['Founder'],
        createdAtIso: new Date().toISOString(),
        updatedAtIso: new Date().toISOString(),
      },
      {
        id: 'charlie_admin',
        email: 'charlie@wishawash.com',
        name: 'Charlie Blunden',
        phone: '+44 7700 900002',
        role: 'admin' as const,
        userType: 'customer' as const,
        isEmailVerified: true,
        rating: 5.0,
        jobsCompleted: 0,
        yearsExperience: 0,
        badges: ['Founder'],
        createdAtIso: new Date().toISOString(),
        updatedAtIso: new Date().toISOString(),
      }
    ];
    
    const user = mockUsers.find(u => u.email === email);
    
    if (!user) {
      throw new ApiException(ErrorCodes.UNAUTHORIZED, 'Invalid email or password');
    }
    
    // Mock password validation
    if (password !== 'password123' && password !== 'admin123') {
      throw new ApiException(ErrorCodes.UNAUTHORIZED, 'Invalid email or password');
    }
    
    console.log('🔐 Mock Auth: Login successful', { userId: user.id, role: user.role });
    
    return {
      user,
      session: {
        userId: user.id,
        role: user.role,
        emailVerified: user.isEmailVerified,
        phoneVerified: true,
      }
    };
  },

  async register(userData: RegisterData): Promise<{ user: User; session: any }> {
    console.log('🔐 Mock Auth: Registration attempt', { email: userData.email });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock validation
    if (!userData.email || !userData.password || !userData.name) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Email, password, and name are required');
    }
    
    // Mock email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(userData.email)) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Invalid email format');
    }
    
    // Mock password strength validation
    if (userData.password.length < 6) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Password must be at least 6 characters');
    }
    
    // Check if user already exists
    const existingUsers = ['customer@test.com', 'valeter@test.com', 'reece@wishawash.com', 'charlie@wishawash.com'];
    if (existingUsers.includes(userData.email)) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'User with this email already exists');
    }
    
    // Create new user
    const newUser: User = {
      id: `${userData.userType}_${Date.now()}`,
      email: userData.email,
      name: userData.name,
      phone: userData.phone,
      role: userData.userType === 'valeter' ? 'valeter' : 'customer',
      userType: userData.userType,
      isEmailVerified: false,
      rating: 0,
      jobsCompleted: 0,
      yearsExperience: 0,
      badges: [],
      createdAtIso: new Date().toISOString(),
      updatedAtIso: new Date().toISOString(),
    };
    
    console.log('🔐 Mock Auth: Registration successful', { userId: newUser.id });
    
    return {
      user: newUser,
      session: {
        userId: newUser.id,
        role: newUser.role,
        emailVerified: newUser.isEmailVerified,
        phoneVerified: false,
      }
    };
  },

  async logout(): Promise<void> {
    console.log('🔐 Mock Auth: Logout');
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Mock logout - in real implementation this would clear session
    console.log('🔐 Mock Auth: Logout successful');
  },

  async getCurrentUser(): Promise<User | null> {
    console.log('🔐 Mock Auth: Get current user');
    
    // Mock - return null for now, would normally get from session
    return null;
  },

  // Profile management
  async updateProfile(updates: Partial<User>): Promise<User> {
    console.log('🔐 Mock Auth: Update profile', updates);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock validation
    if (updates.email && !updates.email.includes('@')) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Invalid email format');
    }
    
    // Mock user update
    const mockUser: User = {
      id: 'customer_1',
      email: 'customer@test.com',
      name: 'John Customer',
      phone: '+44 7700 900001',
      role: 'customer',
      userType: 'customer',
      isEmailVerified: true,
      rating: 4.8,
      jobsCompleted: 0,
      yearsExperience: 0,
      badges: [],
      createdAtIso: new Date().toISOString(),
      updatedAtIso: new Date().toISOString(),
      ...updates,
    };
    
    console.log('🔐 Mock Auth: Profile updated successfully');
    
    return mockUser;
  },

  async updatePassword(currentPassword: string, newPassword: string): Promise<void> {
    console.log('🔐 Mock Auth: Update password');
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock validation
    if (currentPassword !== 'password123') {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Current password is incorrect');
    }
    
    if (newPassword.length < 6) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'New password must be at least 6 characters');
    }
    
    console.log('🔐 Mock Auth: Password updated successfully');
  },

  async resetPassword(email: string): Promise<void> {
    console.log('🔐 Mock Auth: Reset password', { email });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock validation
    if (!email || !email.includes('@')) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Invalid email format');
    }
    
    // Mock password reset email
    console.log('🔐 Mock Auth: Password reset email sent to', email);
  },

  // Admin functions
  async hasAdminAccess(): Promise<boolean> {
    console.log('🔐 Mock Auth: Check admin access');
    
    // Mock admin check - would normally check current user's role
    const adminEmails = ['reece@wishawash.com', 'charlie@wishawash.com'];
    const currentUserEmail = 'reece@wishawash.com'; // Mock current user
    
    const hasAccess = adminEmails.includes(currentUserEmail);
    console.log('🔐 Mock Auth: Admin access', { hasAccess, email: currentUserEmail });
    
    return hasAccess;
  },

  async isBusinessOwner(): Promise<boolean> {
    console.log('🔐 Mock Auth: Check business owner access');
    
    // Mock business owner check
    const businessOwnerEmails = ['business@elitevalet.com'];
    const currentUserEmail = 'business@elitevalet.com'; // Mock current user
    
    const isOwner = businessOwnerEmails.includes(currentUserEmail);
    console.log('🔐 Mock Auth: Business owner access', { isOwner, email: currentUserEmail });
    
    return isOwner;
  },
};
