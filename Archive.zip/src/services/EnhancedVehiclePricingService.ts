export interface VehicleCategory {
  id: string;
  name: string;
  icon: string;
  description: string;
  basePrice: number;
  sizeMultiplier: number;
  specialRequirements: string[];
  valeterQualifications: string[];
  examples: string[];
  maxDimensions: {
    length: number; // meters
    width: number; // meters
    height: number; // meters
  };
}

export interface WashMethod {
  id: string;
  name: string;
  description: string;
  duration: string;
  priceMultiplier: number;
  requirements: string[];
  tools: string[];
  isLuxuryOnly: boolean;
}

export interface VehiclePricing {
  categoryId: string;
  washMethodId: string;
  basePrice: number;
  finalPrice: number;
  duration: string;
  requirements: string[];
  tools: string[];
}

export class EnhancedVehiclePricingService {
  private static instance: EnhancedVehiclePricingService;
  
  private vehicleCategories: VehicleCategory[] = [
    {
      id: 'bike',
      name: 'Motorcycle',
      icon: '🏍️',
      description: 'Motorcycles, scooters, and mopeds',
      basePrice: 12,
      sizeMultiplier: 0.6,
      specialRequirements: ['Handlebar cleaning', 'Chain lubrication'],
      valeterQualifications: ['Basic motorcycle cleaning'],
      examples: ['Honda CBR', 'Yamaha R1', 'Vespa', 'Harley Davidson'],
      maxDimensions: { length: 2.5, width: 1.0, height: 1.5 }
    },
    {
      id: 'small_car',
      name: 'Small Car',
      icon: '🚗',
      description: 'Hatchbacks, small sedans, and city cars',
      basePrice: 20,
      sizeMultiplier: 1.0,
      specialRequirements: ['Compact space handling'],
      valeterQualifications: ['Standard car cleaning'],
      examples: ['Ford Fiesta', 'Vauxhall Corsa', 'Mini Cooper', 'Toyota Yaris'],
      maxDimensions: { length: 4.2, width: 1.8, height: 1.5 }
    },
    {
      id: 'large_car',
      name: 'Large Car',
      icon: '🚙',
      description: 'Saloon cars, estates, and executive vehicles',
      basePrice: 25,
      sizeMultiplier: 1.3,
      specialRequirements: ['Premium interior cleaning', 'Leather care'],
      valeterQualifications: ['Premium car cleaning', 'Leather treatment'],
      examples: ['BMW 5 Series', 'Mercedes E-Class', 'Audi A6', 'Volvo S90'],
      maxDimensions: { length: 5.0, width: 2.0, height: 1.6 }
    },
    {
      id: 'suv',
      name: 'SUV',
      icon: '🚙',
      description: 'Sports Utility Vehicles and crossovers',
      basePrice: 30,
      sizeMultiplier: 1.5,
      specialRequirements: ['Higher reach cleaning', 'All-terrain cleaning'],
      valeterQualifications: ['SUV cleaning', 'High reach equipment'],
      examples: ['Range Rover', 'BMW X5', 'Audi Q7', 'Mercedes GLE'],
      maxDimensions: { length: 5.2, width: 2.1, height: 1.8 }
    },
    {
      id: 'van',
      name: 'Van',
      icon: '🚐',
      description: 'Commercial vans and minibuses',
      basePrice: 35,
      sizeMultiplier: 1.8,
      specialRequirements: ['Commercial vehicle cleaning', 'Cargo area cleaning'],
      valeterQualifications: ['Commercial vehicle cleaning', 'Cargo area access'],
      examples: ['Ford Transit', 'Mercedes Sprinter', 'Vauxhall Vivaro', 'Peugeot Partner'],
      maxDimensions: { length: 6.0, width: 2.2, height: 2.5 }
    },
    {
      id: 'coach',
      name: 'Coach',
      icon: '🚌',
      description: 'Large coaches and buses',
      basePrice: 80,
      sizeMultiplier: 3.0,
      specialRequirements: ['Specialized equipment', 'Multiple valeters required'],
      valeterQualifications: ['Commercial vehicle cleaning', 'Team coordination'],
      examples: ['National Express', 'Megabus', 'School buses', 'Tour coaches'],
      maxDimensions: { length: 12.0, width: 2.6, height: 3.5 }
    },
    {
      id: 'luxury',
      name: 'Luxury Vehicle',
      icon: '🏎️',
      description: 'High-end sports cars and luxury vehicles',
      basePrice: 50,
      sizeMultiplier: 2.0,
      specialRequirements: ['Premium materials care', 'Specialized products'],
      valeterQualifications: ['Luxury vehicle certification', 'Premium materials'],
      examples: ['Ferrari', 'Lamborghini', 'Porsche', 'Bentley', 'Rolls Royce'],
      maxDimensions: { length: 5.5, width: 2.2, height: 1.4 }
    },
    {
      id: 'classic',
      name: 'Classic Car',
      icon: '🚗',
      description: 'Vintage and classic vehicles',
      basePrice: 45,
      sizeMultiplier: 1.8,
      specialRequirements: ['Gentle cleaning methods', 'Vintage care'],
      valeterQualifications: ['Classic car certification', 'Vintage materials'],
      examples: ['Jaguar E-Type', 'Aston Martin DB5', 'Mini Classic', 'MG B'],
      maxDimensions: { length: 5.0, width: 2.0, height: 1.5 }
    },
    {
      id: 'electric',
      name: 'Electric Vehicle',
      icon: '⚡',
      description: 'Electric and hybrid vehicles',
      basePrice: 28,
      sizeMultiplier: 1.2,
      specialRequirements: ['Battery safety', 'Electric system care'],
      valeterQualifications: ['EV safety training', 'Electric system awareness'],
      examples: ['Tesla Model 3', 'Nissan Leaf', 'BMW i3', 'Audi e-tron'],
      maxDimensions: { length: 5.0, width: 2.0, height: 1.6 }
    }
  ];

  private washMethods: WashMethod[] = [
    {
      id: 'exterior_only',
      name: 'Exterior Only',
      description: 'Wash exterior body, windows, and wheels',
      duration: '15-20 min',
      priceMultiplier: 0.7,
      requirements: ['Basic cleaning equipment'],
      tools: ['Pressure washer', 'Microfiber cloths', 'Car shampoo', 'Wheel cleaner'],
      isLuxuryOnly: false
    },
    {
      id: 'standard',
      name: 'Standard Wash',
      description: 'Exterior wash plus interior vacuum and wipe down',
      duration: '30-45 min',
      priceMultiplier: 1.0,
      requirements: ['Standard cleaning equipment'],
      tools: ['Pressure washer', 'Vacuum cleaner', 'Microfiber cloths', 'Interior cleaner'],
      isLuxuryOnly: false
    },
    {
      id: 'premium',
      name: 'Premium Wash',
      description: 'Deep clean with wax, tire dressing, and interior detail',
      duration: '60-90 min',
      priceMultiplier: 1.4,
      requirements: ['Premium cleaning equipment'],
      tools: ['Pressure washer', 'Wax applicator', 'Tire dressing', 'Interior detail kit'],
      isLuxuryOnly: false
    },
    {
      id: 'luxury_exterior',
      name: 'Luxury Exterior',
      description: 'Premium exterior with ceramic coating preparation',
      duration: '90-120 min',
      priceMultiplier: 1.8,
      requirements: ['Luxury vehicle certification'],
      tools: ['Clay bar', 'Paint correction kit', 'Ceramic coating', 'Premium wax'],
      isLuxuryOnly: true
    },
    {
      id: 'luxury_full',
      name: 'Luxury Full Detail',
      description: 'Complete luxury detail with paint correction and protection',
      duration: '180-240 min',
      priceMultiplier: 2.5,
      requirements: ['Luxury vehicle certification', 'Paint correction training'],
      tools: ['Paint correction kit', 'Ceramic coating', 'Leather care kit', 'Premium products'],
      isLuxuryOnly: true
    },
    {
      id: 'commercial',
      name: 'Commercial Clean',
      description: 'Commercial vehicle cleaning with cargo area',
      duration: '45-60 min',
      priceMultiplier: 1.2,
      requirements: ['Commercial vehicle training'],
      tools: ['Heavy-duty cleaner', 'Cargo area equipment', 'Commercial vacuum'],
      isLuxuryOnly: false
    },
    {
      id: 'classic',
      name: 'Classic Car Detail',
      description: 'Specialized cleaning for vintage vehicles',
      duration: '120-180 min',
      priceMultiplier: 2.0,
      requirements: ['Classic car certification'],
      tools: ['Gentle cleaners', 'Vintage-safe products', 'Specialized equipment'],
      isLuxuryOnly: false
    }
  ];

  static getInstance(): EnhancedVehiclePricingService {
    if (!EnhancedVehiclePricingService.instance) {
      EnhancedVehiclePricingService.instance = new EnhancedVehiclePricingService();
    }
    return EnhancedVehiclePricingService.instance;
  }

  getVehicleCategories(): VehicleCategory[] {
    return this.vehicleCategories;
  }

  getVehicleCategory(categoryId: string): VehicleCategory | undefined {
    return this.vehicleCategories.find(category => category.id === categoryId);
  }

  getWashMethods(): WashMethod[] {
    return this.washMethods;
  }

  getWashMethodsForVehicle(categoryId: string): WashMethod[] {
    const category = this.getVehicleCategory(categoryId);
    if (!category) return [];

    return this.washMethods.filter(method => {
      // Luxury methods only for luxury vehicles
      if (method.isLuxuryOnly && category.id !== 'luxury') {
        return false;
      }
      
      // Classic methods only for classic cars
      if (method.id === 'classic' && category.id !== 'classic') {
        return false;
      }

      // Commercial methods for vans and coaches
      if (method.id === 'commercial' && !['van', 'coach'].includes(category.id)) {
        return false;
      }

      return true;
    });
  }

  calculatePrice(
    categoryId: string,
    washMethodId: string,
    locationMultiplier: number = 1.0,
    timeMultiplier: number = 1.0,
    demandMultiplier: number = 1.0,
    weatherMultiplier: number = 1.0
  ): VehiclePricing | null {
    const category = this.getVehicleCategory(categoryId);
    const method = this.washMethods.find(m => m.id === washMethodId);

    if (!category || !method) {
      return null;
    }

    // Check if valeter is qualified
    const canWash = this.canValeterWashVehicle([], categoryId, washMethodId);
    if (!canWash.canWash) {
      return null;
    }

    const basePrice = category.basePrice * method.priceMultiplier;
    const finalPrice = Math.round(
      basePrice * 
      locationMultiplier * 
      timeMultiplier * 
      demandMultiplier * 
      weatherMultiplier
    );

    return {
      categoryId,
      washMethodId,
      basePrice: Math.round(basePrice),
      finalPrice,
      duration: method.duration,
      requirements: [...category.specialRequirements, ...method.requirements],
      tools: method.tools
    };
  }

  canValeterWashVehicle(
    valeterCertifications: string[],
    vehicleCategoryId: string,
    washMethodId: string
  ): { canWash: boolean; reason?: string } {
    const category = this.getVehicleCategory(vehicleCategoryId);
    const method = this.washMethods.find(m => m.id === washMethodId);

    if (!category || !method) {
      return { canWash: false, reason: 'Invalid vehicle category or wash method' };
    }

    // Check basic qualifications
    const requiredQualifications = [...category.valeterQualifications, ...method.requirements];
    
    for (const qualification of requiredQualifications) {
      if (!valeterCertifications.includes(qualification)) {
        return { 
          canWash: false, 
          reason: `Missing qualification: ${qualification}` 
        };
      }
    }

    return { canWash: true };
  }

  getPriceRange(
    categoryId: string,
    locationMultiplier: number = 1.0
  ): { min: number; max: number; typical: number } | null {
    const category = this.getVehicleCategory(categoryId);
    if (!category) return null;

    const methods = this.getWashMethodsForVehicle(categoryId);
    if (methods.length === 0) return null;

    const prices = methods.map(method => 
      this.calculatePrice(categoryId, method.id, locationMultiplier)?.finalPrice || 0
    ).filter(price => price > 0);

    if (prices.length === 0) return null;

    return {
      min: Math.min(...prices),
      max: Math.max(...prices),
      typical: Math.round(prices.reduce((a, b) => a + b, 0) / prices.length)
    };
  }

  getVehicleExamples(categoryId: string): string[] {
    const category = this.getVehicleCategory(categoryId);
    return category?.examples || [];
  }

  getSpecialRequirements(categoryId: string): string[] {
    const category = this.getVehicleCategory(categoryId);
    return category?.specialRequirements || [];
  }

  getRequiredTools(washMethodId: string): string[] {
    const method = this.washMethods.find(m => m.id === washMethodId);
    return method?.tools || [];
  }

  isLuxuryOnlyWash(washMethodId: string): boolean {
    const method = this.washMethods.find(m => m.id === washMethodId);
    return method?.isLuxuryOnly || false;
  }

  getVehicleByDimensions(length: number, width: number, height: number): VehicleCategory | null {
    for (const category of this.vehicleCategories) {
      const max = category.maxDimensions;
      if (length <= max.length && width <= max.width && height <= max.height) {
        return category;
      }
    }
    return null;
  }

  getUKRegionalPricing(region: string): { baseMultiplier: number; description: string } {
    const regionalPricing: { [key: string]: { baseMultiplier: number; description: string } } = {
      'london': { baseMultiplier: 1.4, description: 'London premium pricing' },
      'manchester': { baseMultiplier: 1.2, description: 'Manchester standard pricing' },
      'birmingham': { baseMultiplier: 1.1, description: 'Birmingham standard pricing' },
      'leeds': { baseMultiplier: 1.1, description: 'Leeds standard pricing' },
      'liverpool': { baseMultiplier: 1.0, description: 'Liverpool standard pricing' },
      'newcastle': { baseMultiplier: 1.0, description: 'Newcastle standard pricing' },
      'sheffield': { baseMultiplier: 1.0, description: 'Sheffield standard pricing' },
      'bristol': { baseMultiplier: 1.1, description: 'Bristol standard pricing' },
      'glasgow': { baseMultiplier: 1.0, description: 'Glasgow standard pricing' },
      'edinburgh': { baseMultiplier: 1.1, description: 'Edinburgh standard pricing' },
      'cardiff': { baseMultiplier: 1.0, description: 'Cardiff standard pricing' },
      'belfast': { baseMultiplier: 1.0, description: 'Belfast standard pricing' }
    };

    return regionalPricing[region.toLowerCase()] || { baseMultiplier: 1.0, description: 'Standard UK pricing' };
  }

  getTimeBasedPricing(hour: number, dayOfWeek: number): { multiplier: number; description: string } {
    // Peak hours (7-9 AM, 5-7 PM) on weekdays
    const isPeakHour = (hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19);
    const isWeekday = dayOfWeek >= 1 && dayOfWeek <= 5;
    
    if (isPeakHour && isWeekday) {
      return { multiplier: 1.3, description: 'Peak hour pricing' };
    }
    
    // Weekend pricing
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      return { multiplier: 1.2, description: 'Weekend pricing' };
    }
    
    return { multiplier: 1.0, description: 'Standard pricing' };
  }

  getWeatherBasedPricing(weather: string): { multiplier: number; description: string } {
    const weatherPricing: { [key: string]: { multiplier: number; description: string } } = {
      'rain': { multiplier: 1.2, description: 'Rain surcharge' },
      'snow': { multiplier: 1.4, description: 'Snow surcharge' },
      'mud': { multiplier: 1.3, description: 'Mud surcharge' },
      'sunny': { multiplier: 1.0, description: 'Standard pricing' },
      'cloudy': { multiplier: 1.0, description: 'Standard pricing' }
    };

    return weatherPricing[weather.toLowerCase()] || { multiplier: 1.0, description: 'Standard pricing' };
  }
}

export const enhancedVehiclePricingService = EnhancedVehiclePricingService.getInstance();
