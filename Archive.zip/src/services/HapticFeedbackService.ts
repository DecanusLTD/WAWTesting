import * as Haptics from 'expo-haptics';

export class HapticFeedbackService {
  private static instance: HapticFeedbackService;
  private isEnabled: boolean = true;

  static getInstance(): HapticFeedbackService {
    if (!HapticFeedbackService.instance) {
      HapticFeedbackService.instance = new HapticFeedbackService();
    }
    return HapticFeedbackService.instance;
  }

  private async safeHapticCall(hapticFunction: () => Promise<void>) {
    if (!this.isEnabled) return;
    
    try {
      await hapticFunction();
    } catch (error) {
      console.log('Haptic feedback not available:', error);
      // Silently fail - don't break the app
    }
  }

  // Light feedback for selections
  async selection() {
    await this.safeHapticCall(() => Haptics.selectionAsync());
  }

  // Medium feedback for button presses
  async impact(style: 'light' | 'medium' | 'heavy' = 'medium') {
    await this.safeHapticCall(() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle[style.toUpperCase() as keyof typeof Haptics.ImpactFeedbackStyle]));
  }

  // Heavy feedback for important actions
  async notification(type: 'success' | 'warning' | 'error' = 'success') {
    const notificationType = {
      success: Haptics.NotificationFeedbackType.Success,
      warning: Haptics.NotificationFeedbackType.Warning,
      error: Haptics.NotificationFeedbackType.Error
    };
    
    await this.safeHapticCall(() => Haptics.notificationAsync(notificationType[type]));
  }

  // Toggle haptic feedback on/off
  toggle() {
    this.isEnabled = !this.isEnabled;
    console.log('Haptic feedback:', this.isEnabled ? 'enabled' : 'disabled');
  }

  // Check if haptics are enabled
  isHapticEnabled(): boolean {
    return this.isEnabled;
  }
}

export const hapticFeedback = HapticFeedbackService.getInstance();
