export interface VehicleCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  sizeMultiplier: number;
  basePriceMultiplier: number;
  specialRequirements: string[];
  examples: string[];
  washMethods: WashMethod[];
}

export interface WashMethod {
  id: string;
  name: string;
  description: string;
  basePrice: number;
  duration: string;
  includes: string[];
  specialTools: string[];
  isLuxuryOnly: boolean;
}

export interface VehiclePricing {
  vehicleCategory: VehicleCategory;
  washMethod: WashMethod;
  locationMultiplier: number;
  timeMultiplier: number;
  demandMultiplier: number;
  weatherMultiplier: number;
  finalPrice: number;
}

export class VehiclePricingService {
  private static instance: VehiclePricingService;

  // Vehicle categories based on UK car valeting market research
  private vehicleCategories: VehicleCategory[] = [
    {
      id: 'small',
      name: 'Small Car',
      description: 'Hatchbacks, small sedans',
      icon: '🚗',
      sizeMultiplier: 0.85,
      basePriceMultiplier: 0.9,
      specialRequirements: [],
      examples: ['VW Golf', 'Ford Fiesta', 'Toyota Yaris', 'Mini Cooper'],
      washMethods: [
        {
          id: 'exterior_only',
          name: 'Exterior Only',
          description: 'Wash, dry, and basic exterior care',
          basePrice: 12,
          duration: '15 min',
          includes: ['Hand wash', 'Dry with microfiber', 'Tire dressing', 'Window clean'],
          specialTools: ['Microfiber cloths', 'pH-neutral soap'],
          isLuxuryOnly: false
        },
        {
          id: 'standard_wash',
          name: 'Standard Wash',
          description: 'Exterior wash with interior vacuum',
          basePrice: 18,
          duration: '25 min',
          includes: ['Hand wash', 'Dry with microfiber', 'Interior vacuum', 'Dashboard wipe', 'Tire dressing', 'Window clean'],
          specialTools: ['Microfiber cloths', 'pH-neutral soap', 'Vacuum cleaner'],
          isLuxuryOnly: false
        }
      ]
    },
    {
      id: 'medium',
      name: 'Medium Car',
      description: 'Family cars, SUVs, estates',
      icon: '🚙',
      sizeMultiplier: 1.0,
      basePriceMultiplier: 1.0,
      specialRequirements: [],
      examples: ['BMW 3 Series', 'Audi A4', 'VW Passat', 'Ford Mondeo'],
      washMethods: [
        {
          id: 'exterior_only',
          name: 'Exterior Only',
          description: 'Wash, dry, and basic exterior care',
          basePrice: 15,
          duration: '20 min',
          includes: ['Hand wash', 'Dry with microfiber', 'Tire dressing', 'Window clean'],
          specialTools: ['Microfiber cloths', 'pH-neutral soap'],
          isLuxuryOnly: false
        },
        {
          id: 'standard_wash',
          name: 'Standard Wash',
          description: 'Exterior wash with interior vacuum',
          basePrice: 22,
          duration: '30 min',
          includes: ['Hand wash', 'Dry with microfiber', 'Interior vacuum', 'Dashboard wipe', 'Tire dressing', 'Window clean'],
          specialTools: ['Microfiber cloths', 'pH-neutral soap', 'Vacuum cleaner'],
          isLuxuryOnly: false
        }
      ]
    },
    {
      id: 'large',
      name: 'Large Car',
      description: 'Large SUVs, vans, people carriers',
      icon: '🚐',
      sizeMultiplier: 1.3,
      basePriceMultiplier: 1.25,
      specialRequirements: ['Requires more water', 'Longer drying time'],
      examples: ['Range Rover', 'BMW X5', 'Mercedes V-Class', 'Ford Transit'],
      washMethods: [
        {
          id: 'exterior_only',
          name: 'Exterior Only',
          description: 'Wash, dry, and basic exterior care',
          basePrice: 20,
          duration: '25 min',
          includes: ['Hand wash', 'Dry with microfiber', 'Tire dressing', 'Window clean'],
          specialTools: ['Microfiber cloths', 'pH-neutral soap'],
          isLuxuryOnly: false
        },
        {
          id: 'standard_wash',
          name: 'Standard Wash',
          description: 'Exterior wash with interior vacuum',
          basePrice: 28,
          duration: '40 min',
          includes: ['Hand wash', 'Dry with microfiber', 'Interior vacuum', 'Dashboard wipe', 'Tire dressing', 'Window clean'],
          specialTools: ['Microfiber cloths', 'pH-neutral soap', 'Vacuum cleaner'],
          isLuxuryOnly: false
        }
      ]
    },
    {
      id: 'luxury',
      name: 'Luxury Car',
      description: 'High-end sports cars, luxury vehicles',
      icon: '🏎️',
      sizeMultiplier: 1.2,
      basePriceMultiplier: 2.0,
      specialRequirements: [
        'Certified luxury car valeter required',
        'Special paint-safe products only',
        'Two-bucket wash method mandatory',
        'No automatic car washes allowed',
        'Paint protection film awareness'
      ],
      examples: ['Ferrari', 'Lamborghini', 'Porsche 911', 'Bentley', 'Rolls-Royce'],
      washMethods: [
        {
          id: 'luxury_exterior',
          name: 'Luxury Exterior',
          description: 'Premium exterior wash for luxury vehicles',
          basePrice: 45,
          duration: '45 min',
          includes: [
            'Two-bucket wash method',
            'Paint-safe products only',
            'Clay bar treatment',
            'Premium wax application',
            'Tire and wheel detailing',
            'Glass treatment'
          ],
          specialTools: [
            'Two-bucket system',
            'Clay bar kit',
            'Premium wax',
            'Paint-safe soap',
            'Microfiber towels'
          ],
          isLuxuryOnly: true
        },
        {
          id: 'luxury_full',
          name: 'Luxury Full Service',
          description: 'Complete luxury car detailing',
          basePrice: 85,
          duration: '90 min',
          includes: [
            'Two-bucket wash method',
            'Paint-safe products only',
            'Clay bar treatment',
            'Premium wax application',
            'Interior leather treatment',
            'Dashboard conditioning',
            'Tire and wheel detailing',
            'Glass treatment',
            'Air freshener'
          ],
          specialTools: [
            'Two-bucket system',
            'Clay bar kit',
            'Premium wax',
            'Leather conditioner',
            'Paint-safe soap',
            'Microfiber towels'
          ],
          isLuxuryOnly: true
        },
        {
          id: 'exterior_only',
          name: 'Exterior Only',
          description: 'Wash, dry, and basic exterior care',
          basePrice: 25,
          duration: '25 min',
          includes: ['Hand wash', 'Dry with microfiber', 'Tire dressing', 'Window clean'],
          specialTools: ['Microfiber cloths', 'pH-neutral soap'],
          isLuxuryOnly: false
        },
        {
          id: 'standard_wash',
          name: 'Standard Wash',
          description: 'Exterior wash with interior vacuum',
          basePrice: 35,
          duration: '40 min',
          includes: ['Hand wash', 'Dry with microfiber', 'Interior vacuum', 'Dashboard wipe', 'Tire dressing', 'Window clean'],
          specialTools: ['Microfiber cloths', 'pH-neutral soap', 'Vacuum cleaner'],
          isLuxuryOnly: false
        }
      ]
    }
  ];

  static getInstance(): VehiclePricingService {
    if (!VehiclePricingService.instance) {
      VehiclePricingService.instance = new VehiclePricingService();
    }
    return VehiclePricingService.instance;
  }

  getVehicleCategories(): VehicleCategory[] {
    return this.vehicleCategories;
  }

  getVehicleCategory(categoryId: string): VehicleCategory | undefined {
    return this.vehicleCategories.find(cat => cat.id === categoryId);
  }

  getWashMethodsForVehicle(categoryId: string): WashMethod[] {
    const category = this.getVehicleCategory(categoryId);
    return category ? category.washMethods : [];
  }

  calculatePrice(
    categoryId: string,
    washMethodId: string,
    locationMultiplier: number = 1.0,
    timeMultiplier: number = 1.0,
    demandMultiplier: number = 1.0,
    weatherMultiplier: number = 1.0
  ): VehiclePricing | null {
    const category = this.getVehicleCategory(categoryId);
    if (!category) return null;

    const washMethod = category.washMethods.find(method => method.id === washMethodId);
    if (!washMethod) return null;

    // Base calculation
    let basePrice = washMethod.basePrice;
    
    // Apply vehicle size multiplier
    basePrice *= category.sizeMultiplier;
    
    // Apply vehicle category multiplier (luxury cars cost more)
    basePrice *= category.basePriceMultiplier;
    
    // Apply location and demand multipliers
    const finalPrice = basePrice * locationMultiplier * timeMultiplier * demandMultiplier * weatherMultiplier;

    return {
      vehicleCategory: category,
      washMethod,
      locationMultiplier,
      timeMultiplier,
      demandMultiplier,
      weatherMultiplier,
      finalPrice: Math.round(finalPrice)
    };
  }

  // Get price range for a vehicle category and wash method
  getPriceRange(
    categoryId: string,
    washMethodId: string,
    locationMultiplier: number = 1.0
  ): { min: number; max: number; typical: number } | null {
    const category = this.getVehicleCategory(categoryId);
    if (!category) return null;

    const washMethod = category.washMethods.find(method => method.id === washMethodId);
    if (!washMethod) return null;

    const basePrice = washMethod.basePrice * category.sizeMultiplier * category.basePriceMultiplier;
    
    return {
      min: Math.round(basePrice * locationMultiplier * 0.8), // Low demand
      max: Math.round(basePrice * locationMultiplier * 1.5), // High demand
      typical: Math.round(basePrice * locationMultiplier * 1.1) // Average
    };
  }

  // Check if valeter is qualified for luxury cars
  isValeterQualifiedForLuxury(valeterCertifications: string[]): boolean {
    const requiredCertifications = [
      'luxury_car_certification',
      'paint_protection_training',
      'two_bucket_method_certified'
    ];
    
    return requiredCertifications.every(cert => valeterCertifications.includes(cert));
  }

  // Get special requirements for a vehicle category
  getSpecialRequirements(categoryId: string): string[] {
    const category = this.getVehicleCategory(categoryId);
    return category ? category.specialRequirements : [];
  }

  // Get recommended tools for a wash method
  getRequiredTools(washMethodId: string): string[] {
    for (const category of this.vehicleCategories) {
      const method = category.washMethods.find(m => m.id === washMethodId);
      if (method) {
        return method.specialTools;
      }
    }
    return [];
  }

  // Check if wash method is luxury-only
  isLuxuryOnlyWash(washMethodId: string): boolean {
    for (const category of this.vehicleCategories) {
      const method = category.washMethods.find(m => m.id === washMethodId);
      if (method) {
        return method.isLuxuryOnly;
      }
    }
    return false;
  }

  // Get vehicle examples for a category
  getVehicleExamples(categoryId: string): string[] {
    const category = this.getVehicleCategory(categoryId);
    return category ? category.examples : [];
  }

  // Validate if a valeter can wash a specific vehicle type
  canValeterWashVehicle(
    valeterCertifications: string[],
    vehicleCategoryId: string,
    washMethodId: string
  ): { canWash: boolean; reason?: string } {
    const category = this.getVehicleCategory(vehicleCategoryId);
    if (!category) {
      return { canWash: false, reason: 'Invalid vehicle category' };
    }

    const washMethod = category.washMethods.find(m => m.id === washMethodId);
    if (!washMethod) {
      return { canWash: false, reason: 'Invalid wash method' };
    }

    // Check if it's a luxury wash method
    if (washMethod.isLuxuryOnly) {
      if (!this.isValeterQualifiedForLuxury(valeterCertifications)) {
        return { 
          canWash: false, 
          reason: 'Luxury car certification required for this service' 
        };
      }
    }

    return { canWash: true };
  }
}

export const vehiclePricingService = VehiclePricingService.getInstance();
