export interface ValeterDocument {
  id: string;
  type: 'profile_photo' | 'driving_license' | 'insurance_certificate' | 'dbs_check' | 'public_liability_insurance' | 'vehicle_registration' | 'vehicle_insurance' | 'business_license' | 'id_proof';
  name: string;
  description: string;
  required: boolean;
  status: 'pending' | 'approved' | 'rejected' | 'not_uploaded';
  uploadedAt?: Date;
  approvedAt?: Date;
  rejectionReason?: string;
  fileUrl?: string;
}

export interface ValeterProfileData {
  id: string;
  name: string;
  email: string;
  phone: string;
  profilePhoto?: string;
  bio: string;
  experience: string;
  specializations: string[];
  vehicleDetails: {
    make: string;
    model: string;
    year: string;
    registration: string;
    color: string;
    insuranceProvider: string;
    insurancePolicyNumber: string;
  };
  documents: ValeterDocument[];
  verificationStatus: 'pending' | 'verified' | 'rejected';
  verifiedAt?: Date;
  verificationBadge: boolean;
  rating: number;
  jobsCompleted: number;
  isOnline: boolean;
  workingRadius: number;
  hourlyRate: number;
  availability: {
    monday: { start: string; end: string; available: boolean };
    tuesday: { start: string; end: string; available: boolean };
    wednesday: { start: string; end: string; available: boolean };
    thursday: { start: string; end: string; available: boolean };
    friday: { start: string; end: string; available: boolean };
    saturday: { start: string; end: string; available: boolean };
    sunday: { start: string; end: string; available: boolean };
  };
}

export class ValeterVerificationService {
  private static instance: ValeterVerificationService;
  private valeterProfiles: Map<string, ValeterProfileData> = new Map();

  static getInstance(): ValeterVerificationService {
    if (!ValeterVerificationService.instance) {
      ValeterVerificationService.instance = new ValeterVerificationService();
    }
    return ValeterVerificationService.instance;
  }

  // Required documents based on UK legal requirements for mobile valeting
  getRequiredDocuments(): ValeterDocument[] {
    return [
      {
        id: 'profile_photo',
        type: 'profile_photo',
        name: 'Profile Photo',
        description: 'Clear headshot against plain background (required for customer trust)',
        required: true,
        status: 'not_uploaded'
      },
      {
        id: 'driving_license',
        type: 'driving_license',
        name: 'Driving License',
        description: 'Valid UK driving license (front and back)',
        required: true,
        status: 'not_uploaded'
      },
      {
        id: 'dbs_check',
        type: 'dbs_check',
        name: 'DBS Background Check',
        description: 'Disclosure and Barring Service check (Enhanced)',
        required: true,
        status: 'not_uploaded'
      },
      {
        id: 'public_liability_insurance',
        type: 'public_liability_insurance',
        name: 'Public Liability Insurance',
        description: 'Minimum £2 million coverage for mobile valeting',
        required: true,
        status: 'not_uploaded'
      },
      {
        id: 'vehicle_insurance',
        type: 'vehicle_insurance',
        name: 'Vehicle Insurance',
        description: 'Business use insurance for work vehicle',
        required: true,
        status: 'not_uploaded'
      },
      {
        id: 'vehicle_registration',
        type: 'vehicle_registration',
        name: 'Vehicle Registration',
        description: 'V5C registration document for work vehicle',
        required: true,
        status: 'not_uploaded'
      },
      {
        id: 'business_license',
        type: 'business_license',
        name: 'Business License',
        description: 'Local authority business license (if required)',
        required: false,
        status: 'not_uploaded'
      },
      {
        id: 'id_proof',
        type: 'id_proof',
        name: 'Proof of Identity',
        description: 'Passport or national ID card',
        required: true,
        status: 'not_uploaded'
      }
    ];
  }

  getValeterProfile(valeterId: string): ValeterProfileData | undefined {
    if (!this.valeterProfiles.has(valeterId)) {
      // Create default profile
      const defaultProfile: ValeterProfile = {
        id: valeterId,
        name: 'New Valeter',
        email: '',
        phone: '',
        bio: 'Professional mobile valeter with years of experience in car care and detailing.',
        experience: '3+ years',
        specializations: ['Exterior Wash', 'Interior Cleaning', 'Wax & Polish'],
        vehicleDetails: {
          make: '',
          model: '',
          year: '',
          registration: '',
          color: '',
          insuranceProvider: '',
          insurancePolicyNumber: ''
        },
        documents: this.getRequiredDocuments(),
        verificationStatus: 'pending',
        verificationBadge: false,
        rating: 0,
        jobsCompleted: 0,
        isOnline: false,
        workingRadius: 10,
        hourlyRate: 25,
        availability: {
          monday: { start: '09:00', end: '17:00', available: true },
          tuesday: { start: '09:00', end: '17:00', available: true },
          wednesday: { start: '09:00', end: '17:00', available: true },
          thursday: { start: '09:00', end: '17:00', available: true },
          friday: { start: '09:00', end: '17:00', available: true },
          saturday: { start: '09:00', end: '17:00', available: true },
          sunday: { start: '10:00', end: '16:00', available: false }
        }
      };
      this.valeterProfiles.set(valeterId, defaultProfile);
    }
    return this.valeterProfiles.get(valeterId);
  }

  updateValeterProfile(valeterId: string, updates: Partial<ValeterProfileData>): boolean {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return false;

    Object.assign(profile, updates);
    return true;
  }

  uploadDocument(valeterId: string, documentType: ValeterDocument['type'], fileUrl: string): boolean {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return false;

    const document = profile.documents.find(d => d.type === documentType);
    if (!document) return false;

    document.status = 'pending';
    document.uploadedAt = new Date();
    document.fileUrl = fileUrl;

    // Auto-approve for demo (in real app, this would go through admin review)
    setTimeout(() => {
      this.approveDocument(valeterId, documentType);
    }, 2000);

    return true;
  }

  approveDocument(valeterId: string, documentType: ValeterDocument['type']): boolean {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return false;

    const document = profile.documents.find(d => d.type === documentType);
    if (!document) return false;

    document.status = 'approved';
    document.approvedAt = new Date();

    // Check if all required documents are approved
    this.checkVerificationStatus(valeterId);

    return true;
  }

  rejectDocument(valeterId: string, documentType: ValeterDocument['type'], reason: string): boolean {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return false;

    const document = profile.documents.find(d => d.type === documentType);
    if (!document) return false;

    document.status = 'rejected';
    document.rejectionReason = reason;

    return true;
  }

  private checkVerificationStatus(valeterId: string): void {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return;

    const requiredDocuments = profile.documents.filter(d => d.required);
    const approvedDocuments = requiredDocuments.filter(d => d.status === 'approved');

    if (approvedDocuments.length === requiredDocuments.length && profile.profilePhoto) {
      profile.verificationStatus = 'verified';
      profile.verificationBadge = true;
      profile.verifiedAt = new Date();
    }
  }

  getVerificationProgress(valeterId: string): {
    total: number;
    completed: number;
    percentage: number;
    missing: string[];
  } {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return { total: 0, completed: 0, percentage: 0, missing: [] };

    const requiredDocuments = profile.documents.filter(d => d.required);
    const completed = requiredDocuments.filter(d => d.status === 'approved').length;
    const missing = requiredDocuments
      .filter(d => d.status !== 'approved')
      .map(d => d.name);

    // Add profile photo requirement
    const total = requiredDocuments.length + (profile.profilePhoto ? 1 : 0);
    const actualCompleted = completed + (profile.profilePhoto ? 1 : 0);

    return {
      total,
      completed: actualCompleted,
      percentage: Math.round((actualCompleted / total) * 100),
      missing
    };
  }

  // Legal compliance check
  isLegallyCompliant(valeterId: string): {
    compliant: boolean;
    issues: string[];
    recommendations: string[];
  } {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) {
      return {
        compliant: false,
        issues: ['Profile not found'],
        recommendations: ['Contact support']
      };
    }

    const issues: string[] = [];
    const recommendations: string[] = [];

    // Check required documents
    const requiredDocs = profile.documents.filter(d => d.required);
    const missingDocs = requiredDocs.filter(d => d.status !== 'approved');

    if (missingDocs.length > 0) {
      issues.push(`Missing required documents: ${missingDocs.map(d => d.name).join(', ')}`);
      recommendations.push('Upload all required documents for verification');
    }

    // Check profile photo
    if (!profile.profilePhoto) {
      issues.push('Profile photo required');
      recommendations.push('Upload a clear headshot against plain background');
    }

    // Check vehicle details
    if (!profile.vehicleDetails.registration || !profile.vehicleDetails.insuranceProvider) {
      issues.push('Vehicle details incomplete');
      recommendations.push('Complete vehicle registration and insurance information');
    }

    // Check public liability insurance
    const liabilityInsurance = profile.documents.find(d => d.type === 'public_liability_insurance');
    if (!liabilityInsurance || liabilityInsurance.status !== 'approved') {
      issues.push('Public liability insurance required (£2M minimum)');
      recommendations.push('Obtain public liability insurance for mobile valeting');
    }

    // Check DBS check
    const dbsCheck = profile.documents.find(d => d.type === 'dbs_check');
    if (!dbsCheck || dbsCheck.status !== 'approved') {
      issues.push('DBS background check required');
      recommendations.push('Complete enhanced DBS check for customer safety');
    }

    return {
      compliant: issues.length === 0,
      issues,
      recommendations
    };
  }

  // Check if valeter can go online (requires all documents verified)
  canGoOnline(valeterId: string): { canGo: boolean; reason?: string } {
    const profile = this.valeterProfiles.get(valeterId);
    if (!profile) {
      return { canGo: false, reason: 'Profile not found' };
    }

    // Check if all required documents are approved
    const requiredDocuments = this.getRequiredDocuments();
    const approvedDocuments = profile.documents.filter(doc => doc.status === 'approved');
    const pendingDocuments = profile.documents.filter(doc => doc.status === 'pending');
    const rejectedDocuments = profile.documents.filter(doc => doc.status === 'rejected');

    if (approvedDocuments.length < requiredDocuments.length) {
      return { 
        canGo: false, 
        reason: `Missing ${requiredDocuments.length - approvedDocuments.length} verified documents` 
      };
    }

    if (rejectedDocuments.length > 0) {
      return { 
        canGo: false, 
        reason: `${rejectedDocuments.length} documents rejected - please resubmit` 
      };
    }

    if (pendingDocuments.length > 0) {
      return { 
        canGo: false, 
        reason: `${pendingDocuments.length} documents pending verification` 
      };
    }

    return { canGo: true };
  }
}

export const valeterVerificationService = ValeterVerificationService.getInstance();
