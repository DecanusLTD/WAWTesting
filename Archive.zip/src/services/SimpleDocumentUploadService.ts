export interface UploadedDocument {
  id: string;
  name: string;
  type: 'photo' | 'document' | 'pdf';
  uri: string;
  size: number;
  mimeType: string;
  uploadDate: Date;
  status: 'pending' | 'uploading' | 'completed' | 'failed';
  progress: number;
  verificationStatus: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
}

export interface UploadProgress {
  documentId: string;
  progress: number;
  status: 'uploading' | 'completed' | 'failed';
  error?: string;
}

export class SimpleDocumentUploadService {
  private static instance: SimpleDocumentUploadService;
  private documents: Map<string, UploadedDocument> = new Map();
  private progressListeners: Map<string, (progress: UploadProgress) => void> = new Map();

  static getInstance(): SimpleDocumentUploadService {
    if (!SimpleDocumentUploadService.instance) {
      SimpleDocumentUploadService.instance = new SimpleDocumentUploadService();
    }
    return SimpleDocumentUploadService.instance;
  }

  // Simulate taking a photo
  async takePhoto(documentType: string): Promise<UploadedDocument | null> {
    try {
      // Simulate camera delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const documentId = `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const document: UploadedDocument = {
        id: documentId,
        name: `${documentType}_photo_${Date.now()}.jpg`,
        type: 'photo',
        uri: `file://simulated/photo/${documentId}.jpg`,
        size: Math.floor(Math.random() * 2000000) + 500000, // 500KB - 2.5MB
        mimeType: 'image/jpeg',
        uploadDate: new Date(),
        status: 'pending',
        progress: 0,
        verificationStatus: 'pending'
      };

      this.documents.set(documentId, document);
      return document;
    } catch (error) {
      console.error('Error taking photo:', error);
      throw error;
    }
  }

  // Simulate picking a document
  async pickDocument(documentType: string): Promise<UploadedDocument | null> {
    try {
      // Simulate file picker delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const documentId = `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const document: UploadedDocument = {
        id: documentId,
        name: `${documentType}_document_${Date.now()}.pdf`,
        type: 'document',
        uri: `file://simulated/document/${documentId}.pdf`,
        size: Math.floor(Math.random() * 5000000) + 1000000, // 1MB - 6MB
        mimeType: 'application/pdf',
        uploadDate: new Date(),
        status: 'pending',
        progress: 0,
        verificationStatus: 'pending'
      };

      this.documents.set(documentId, document);
      return document;
    } catch (error) {
      console.error('Error picking document:', error);
      throw error;
    }
  }

  // Upload document with simulated progress
  async uploadDocument(documentId: string): Promise<boolean> {
    const document = this.documents.get(documentId);
    if (!document) {
      throw new Error('Document not found');
    }

    try {
      // Update status to uploading
      document.status = 'uploading';
      document.progress = 0;
      this.documents.set(documentId, document);

      // Simulate upload progress
      const uploadSteps = 10;
      for (let i = 0; i <= uploadSteps; i++) {
        await new Promise(resolve => setTimeout(resolve, 200)); // Simulate network delay
        
        document.progress = (i / uploadSteps) * 100;
        this.documents.set(documentId, document);
        
        // Notify progress listeners
        this.notifyProgressListeners(documentId, {
          documentId,
          progress: document.progress,
          status: 'uploading'
        });
      }

      // Upload completed
      document.status = 'completed';
      document.progress = 100;
      document.verificationStatus = 'pending';
      this.documents.set(documentId, document);

      // Notify completion
      this.notifyProgressListeners(documentId, {
        documentId,
        progress: 100,
        status: 'completed'
      });

      return true;
    } catch (error) {
      document.status = 'failed';
      document.progress = 0;
      this.documents.set(documentId, document);

      this.notifyProgressListeners(documentId, {
        documentId,
        progress: 0,
        status: 'failed',
        error: error instanceof Error ? error.message : 'Upload failed'
      });

      throw error;
    }
  }

  // Get user's documents
  getUserDocuments(userId: string): UploadedDocument[] {
    return Array.from(this.documents.values())
      .filter(doc => doc.id.startsWith(userId))
      .sort((a, b) => b.uploadDate.getTime() - a.uploadDate.getTime());
  }

  // Get specific document
  getDocument(documentId: string): UploadedDocument | undefined {
    return this.documents.get(documentId);
  }

  // Get upload progress
  getUploadProgress(documentId: string): number {
    const document = this.documents.get(documentId);
    return document?.progress ?? 0;
  }

  // Delete document
  async deleteDocument(documentId: string): Promise<boolean> {
    const document = this.documents.get(documentId);
    if (!document) {
      return false;
    }

    try {
      // Remove from documents map
      this.documents.delete(documentId);
      return true;
    } catch (error) {
      console.error('Error deleting document:', error);
      return false;
    }
  }

  // Update document status
  updateDocumentStatus(documentId: string, status: 'pending' | 'approved' | 'rejected', rejectionReason?: string): boolean {
    const document = this.documents.get(documentId);
    if (!document) {
      return false;
    }

    document.verificationStatus = status;
    if (rejectionReason) {
      document.rejectionReason = rejectionReason;
    }

    this.documents.set(documentId, document);
    return true;
  }

  // Add progress listener
  addProgressListener(documentId: string, listener: (progress: UploadProgress) => void): void {
    this.progressListeners.set(documentId, listener);
  }

  // Remove progress listener
  removeProgressListener(documentId: string): void {
    this.progressListeners.delete(documentId);
  }

  // Format file size
  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  // Clear all documents (for testing)
  clearAll(): void {
    this.documents.clear();
    this.progressListeners.clear();
  }

  // Private helper methods
  private notifyProgressListeners(documentId: string, progress: UploadProgress): void {
    const listener = this.progressListeners.get(documentId);
    if (listener) {
      listener(progress);
    }
  }
}

export const simpleDocumentUploadService = SimpleDocumentUploadService.getInstance();
