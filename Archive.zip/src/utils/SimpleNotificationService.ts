import { Alert } from 'react-native';

export interface NotificationData {
  title: string;
  message: string;
  type?: 'info' | 'success' | 'warning' | 'error';
}

export class SimpleNotificationService {
  private static instance: SimpleNotificationService;

  private constructor() {}

  public static getInstance(): SimpleNotificationService {
    if (!SimpleNotificationService.instance) {
      SimpleNotificationService.instance = new SimpleNotificationService();
    }
    return SimpleNotificationService.instance;
  }

  // Show a simple alert notification
  showNotification(data: NotificationData): void {
    Alert.alert(data.title, data.message, [
      { text: 'OK', style: 'default' }
    ]);
  }

  // Job-specific notification methods
  showJobAlert(jobData: any): void {
    this.showNotification({
      title: '🚗 New Valet Available!',
      message: `£${jobData.price} - ${jobData.vehicleType} valet in ${jobData.distance}`,
      type: 'info'
    });
  }

  showJobAccepted(jobData: any): void {
    this.showNotification({
      title: '✅ Valet Accepted!',
      message: `You're on your way to ${jobData.customerName}`,
      type: 'success'
    });
  }

  showJobCompleted(jobData: any): void {
    this.showNotification({
      title: '🎉 Job Completed!',
      message: `You earned £${jobData.earnings} for this service`,
      type: 'success'
    });
  }

  showPaymentConfirmation(paymentData: any): void {
    this.showNotification({
      title: '💳 Payment Successful!',
      message: `£${paymentData.amount} charged for ${paymentData.service}`,
      type: 'success'
    });
  }

  showDriverArrival(customerData: any): void {
    this.showNotification({
      title: '🚗 Driver Arrived!',
      message: `${customerData.driverName} has arrived for your service`,
      type: 'info'
    });
  }

  showServiceStarted(): void {
    this.showNotification({
      title: '🧽 Service Started!',
      message: 'Your vehicle wash is now in progress',
      type: 'info'
    });
  }

  showServiceCompleted(): void {
    this.showNotification({
      title: '✨ Service Completed!',
      message: 'Your vehicle wash is finished. Please rate your experience!',
      type: 'success'
    });
  }

  showEarningsUpdate(earningsData: any): void {
    this.showNotification({
      title: '💰 Earnings Updated!',
      message: `You've earned £${earningsData.amount} this week`,
      type: 'success'
    });
  }

  showPromotionalOffer(promoData: any): void {
    this.showNotification({
      title: '🎁 Special Offer!',
      message: promoData.message,
      type: 'info'
    });
  }
}

// Export singleton instance
export const simpleNotificationService = SimpleNotificationService.getInstance();

export default simpleNotificationService;
