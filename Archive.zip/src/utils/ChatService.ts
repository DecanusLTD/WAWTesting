import { notificationService, ChatMessage } from './NotificationService';

export interface ChatConversation {
  id: string;
  customerId: string;
  valeterId: string;
  customerName: string;
  valeterName: string;
  lastMessage: string;
  lastMessageTime: Date;
  unreadCount: number;
  isActive: boolean;
}

export interface ChatMessageExtended extends ChatMessage {
  conversationId: string;
  messageType: 'text' | 'image' | 'location' | 'status';
  status?: 'sent' | 'delivered' | 'read';
}

class ChatService {
  private conversations: ChatConversation[] = [];
  private messages: Map<string, ChatMessageExtended[]> = new Map();
  private messageListeners: ((message: ChatMessageExtended) => void)[] = [];
  private conversationListeners: ((conversation: ChatConversation) => void)[] = [];

  // Initialize chat service
  initialize() {
    // Load mock conversations
    this.loadMockConversations();
    console.log('Chat service initialized');
  }

  // Load mock conversations
  private loadMockConversations() {
    this.conversations = [
      {
        id: 'conv_001',
        customerId: 'a7b9c2d4e6f8g0h2',
        valeterId: '126546fghfdsvvfg',
        customerName: 'Sarah Wilson',
        valeterName: 'John Driver',
        lastMessage: 'I\'ll be there in 10 minutes',
        lastMessageTime: new Date(Date.now() - 5 * 60 * 1000), // 5 minutes ago
        unreadCount: 0,
        isActive: true,
      },
      {
        id: 'conv_002',
        customerId: 'k3m5n7p9q1r3s5t7',
        valeterId: '126546fghfdsvvfg',
        customerName: 'Mike Chen',
        valeterName: 'John Driver',
        lastMessage: 'Wash completed successfully!',
        lastMessageTime: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
        unreadCount: 1,
        isActive: false,
      },
    ];

    // Load mock messages
    this.loadMockMessages();
  }

  // Load mock messages
  private loadMockMessages() {
    // Conversation 1 messages
    this.messages.set('conv_001', [
      {
        id: 'msg_001',
        conversationId: 'conv_001',
        senderId: 'a7b9c2d4e6f8g0h2',
        senderName: 'Sarah Wilson',
        message: 'Hi, I\'ve booked a deep clean for my BMW X5',
        timestamp: new Date(Date.now() - 30 * 60 * 1000),
        isRead: true,
        messageType: 'text',
        status: 'read',
      },
      {
        id: 'msg_002',
        conversationId: 'conv_001',
        senderId: '126546fghfdsvvfg',
        senderName: 'John Driver',
        message: 'Hello Sarah! I\'ve accepted your booking. I\'ll be there in 10 minutes',
        timestamp: new Date(Date.now() - 5 * 60 * 1000),
        isRead: true,
        messageType: 'text',
        status: 'read',
      },
    ]);

    // Conversation 2 messages
    this.messages.set('conv_002', [
      {
        id: 'msg_003',
        conversationId: 'conv_002',
        senderId: 'k3m5n7p9q1r3s5t7',
        senderName: 'Mike Chen',
        message: 'Can you do an interior clean for my Audi A3?',
        timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
        isRead: true,
        messageType: 'text',
        status: 'read',
      },
      {
        id: 'msg_004',
        conversationId: 'conv_002',
        senderId: '126546fghfdsvvfg',
        senderName: 'John Driver',
        message: 'Absolutely! I\'ll start with the interior clean',
        timestamp: new Date(Date.now() - 2.5 * 60 * 60 * 1000),
        isRead: true,
        messageType: 'text',
        status: 'read',
      },
      {
        id: 'msg_005',
        conversationId: 'conv_002',
        senderId: '126546fghfdsvvfg',
        senderName: 'John Driver',
        message: 'Wash completed successfully! Your Audi looks great',
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
        isRead: false,
        messageType: 'text',
        status: 'delivered',
      },
    ]);
  }

  // Get conversations for a user
  getConversations(userId: string): ChatConversation[] {
    return this.conversations.filter(conv => 
      conv.customerId === userId || conv.valeterId === userId
    );
  }

  // Get messages for a conversation
  getMessages(conversationId: string): ChatMessageExtended[] {
    return this.messages.get(conversationId) || [];
  }

  // Send a message
  async sendMessage(
    conversationId: string,
    senderId: string,
    senderName: string,
    message: string,
    messageType: 'text' | 'image' | 'location' | 'status' = 'text'
  ): Promise<ChatMessageExtended> {
    const newMessage: ChatMessageExtended = {
      id: `msg_${Date.now()}`,
      conversationId,
      senderId,
      senderName,
      message,
      timestamp: new Date(),
      isRead: false,
      messageType,
      status: 'sent',
    };

    // Add message to conversation
    const conversationMessages = this.messages.get(conversationId) || [];
    conversationMessages.push(newMessage);
    this.messages.set(conversationId, conversationMessages);

    // Update conversation
    const conversation = this.conversations.find(c => c.id === conversationId);
    if (conversation) {
      conversation.lastMessage = message;
      conversation.lastMessageTime = new Date();
      conversation.unreadCount += 1;
    }

    // Notify listeners
    this.messageListeners.forEach(listener => listener(newMessage));
    this.conversationListeners.forEach(listener => {
      if (conversation) listener(conversation);
    });

    // Send push notification to recipient
    const recipientId = conversation?.customerId === senderId 
      ? conversation.valeterId 
      : conversation?.customerId;
    
    if (recipientId) {
      try {
        await notificationService.sendChatNotification({
          id: newMessage.id,
          senderId: newMessage.senderId,
          senderName: newMessage.senderName,
          message: newMessage.message,
          timestamp: newMessage.timestamp,
          isRead: newMessage.isRead,
        });
      } catch (error) {
        // Log notification errors but don't fail the message sending
        console.log('Notification error (non-critical):', error);
      }
    }

    return newMessage;
  }

  // Mark messages as read
  markMessagesAsRead(conversationId: string, userId: string) {
    const messages = this.messages.get(conversationId);
    if (messages) {
      messages.forEach(msg => {
        if (msg.senderId !== userId) {
          msg.isRead = true;
          msg.status = 'read';
        }
      });
    }

    // Reset unread count
    const conversation = this.conversations.find(c => c.id === conversationId);
    if (conversation) {
      conversation.unreadCount = 0;
    }
  }

  // Create a new conversation
  createConversation(
    customerId: string,
    valeterId: string,
    customerName: string,
    valeterName: string
  ): ChatConversation {
    const conversation: ChatConversation = {
      id: `conv_${Date.now()}`,
      customerId,
      valeterId,
      customerName,
      valeterName,
      lastMessage: '',
      lastMessageTime: new Date(),
      unreadCount: 0,
      isActive: true,
    };

    this.conversations.push(conversation);
    this.messages.set(conversation.id, []);

    return conversation;
  }

  // Get unread count for a user
  getUnreadCount(userId: string): number {
    return this.conversations
      .filter(conv => conv.customerId === userId || conv.valeterId === userId)
      .reduce((total, conv) => total + conv.unreadCount, 0);
  }

  // Add message listener
  addMessageListener(listener: (message: ChatMessageExtended) => void) {
    this.messageListeners.push(listener);
  }

  // Add conversation listener
  addConversationListener(listener: (conversation: ChatConversation) => void) {
    this.conversationListeners.push(listener);
  }

  // Remove listeners
  removeListeners() {
    this.messageListeners = [];
    this.conversationListeners = [];
  }

  // Simulate typing indicator
  simulateTyping(conversationId: string, senderId: string, isTyping: boolean) {
    // In a real app, this would send a typing indicator to the other user
    console.log(`${senderId} is ${isTyping ? 'typing' : 'not typing'} in ${conversationId}`);
  }

  // Get conversation by participants
  getConversationByParticipants(userId1: string, userId2: string): ChatConversation | null {
    return this.conversations.find(conv => 
      (conv.customerId === userId1 && conv.valeterId === userId2) ||
      (conv.customerId === userId2 && conv.valeterId === userId1)
    ) || null;
  }
}

// Export singleton instance
export const chatService = new ChatService();

export default chatService;
