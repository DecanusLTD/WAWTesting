# Backend Contracts & Interfaces

## Core Types

```typescript
export type Role = "customer" | "valeter" | "admin";
export type JobStatus = "REQUESTED" | "ACCEPTED" | "EN_ROUTE" | "ARRIVED" | "IN_PROGRESS" | "COMPLETED" | "CANCELLED" | "EXPIRED";
export type UserType = "customer" | "valeter";

export interface Service {
  id: number;
  name: string;
  description: string;
  price: number; // pence
  duration_min: number;
  is_active: boolean;
}

export interface Valeter {
  id: string;
  name: string;
  email: string;
  phone: string;
  rating: number;
  jobsCompleted: number;
  level: "New" | "Pro" | "Elite";
  badges: string[];
  yearsExperience?: number;
  phoneMasked?: string;
  isVerified: boolean;
  documentsUploaded: boolean;
  insuranceVerified: boolean;
  licenseVerified: boolean;
  backgroundCheckPassed: boolean;
}

export interface Job {
  id: number;
  customerId: string;
  valeterId?: string;
  serviceId: number;
  serviceName: string;
  price: number; // pence
  pickupLat: number;
  pickupLng: number;
  pickupAddress: string;
  status: JobStatus;
  valeter?: Valeter;
  etaMinutes?: number;
  createdAtIso: string;
  updatedAtIso: string;
}

export interface ChatMessage {
  id: string;
  jobId: number;
  senderId: string;
  receiverId: string;
  content: string;
  isRead: boolean;
  createdAtIso: string;
}

export interface Ping {
  id: number;
  userId: string;
  jobId?: number;
  lat: number;
  lng: number;
  heading?: number;
  speed?: number;
  timestampIso: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  role: Role;
  userType: UserType;
  isEmailVerified: boolean;
  rating: number;
  jobsCompleted: number;
  yearsExperience: number;
  badges: string[];
  createdAtIso: string;
  updatedAtIso: string;
}

export interface RefundRequest {
  id: number;
  jobId: number;
  customerId: string;
  valeterId: string;
  amount: number; // pence
  reason: string;
  status: "pending" | "approved" | "rejected";
  priority: 1 | 2 | 3;
  adminNotes?: string;
  processedBy?: string;
  processedAtIso?: string;
  createdAtIso: string;
}

export interface SystemReport {
  id: number;
  title: string;
  description: string;
  category: "fraud" | "service_quality" | "payment_issue" | "safety" | "technical" | "other";
  priority: 1 | 2 | 3;
  status: "open" | "investigating" | "resolved" | "closed";
  reportedBy: string;
  assignedTo?: string;
  resolution?: string;
  createdAtIso: string;
  updatedAtIso: string;
}
```

## API Facade Interface

```typescript
// src/lib/api/index.ts
export interface ApiFacade {
  auth: AuthAPI;
  jobs: JobsAPI;
  payments: PaymentsAPI;
  tracking: TrackingAPI;
  messaging: MessagingAPI;
  locations: LocationsAPI;
}

export interface AuthAPI {
  // Authentication
  login(email: string, password: string): Promise<{ user: User; session: any }>;
  register(userData: RegisterData): Promise<{ user: User; session: any }>;
  logout(): Promise<void>;
  getCurrentUser(): Promise<User | null>;
  
  // Profile management
  updateProfile(updates: Partial<User>): Promise<User>;
  updatePassword(currentPassword: string, newPassword: string): Promise<void>;
  resetPassword(email: string): Promise<void>;
  
  // Admin functions
  hasAdminAccess(): Promise<boolean>;
  isBusinessOwner(): Promise<boolean>;
}

export interface JobsAPI {
  // Job management
  createJob(jobData: CreateJobData): Promise<Job>;
  getJob(jobId: number): Promise<Job>;
  getJobsForUser(userId: string, userType: UserType): Promise<Job[]>;
  getAvailableJobs(): Promise<Job[]>;
  
  // Job actions
  acceptJob(jobId: number, valeterId: string): Promise<Job>;
  startJob(jobId: number): Promise<Job>;
  completeJob(jobId: number): Promise<Job>;
  cancelJob(jobId: number, reason: string): Promise<Job>;
  
  // Real-time subscriptions
  subscribeToJob(jobId: number, callback: (job: Job) => void): () => void;
  subscribeToUserJobs(userId: string, callback: (jobs: Job[]) => void): () => void;
  
  // Services
  getServices(): Promise<Service[]>;
  getService(serviceId: number): Promise<Service>;
}

export interface PaymentsAPI {
  // Payment processing
  createPaymentIntent(jobId: number, amount: number): Promise<{ clientSecret: string }>;
  confirmPayment(paymentIntentId: string): Promise<void>;
  
  // Refunds
  requestRefund(jobId: number, amount: number, reason: string): Promise<RefundRequest>;
  getRefundRequests(userId: string): Promise<RefundRequest[]>;
  
  // Admin functions
  processRefund(refundId: number, action: "approve" | "reject", notes?: string): Promise<RefundRequest>;
  getRefundRequestsForAdmin(): Promise<RefundRequest[]>;
}

export interface TrackingAPI {
  // Location tracking
  sendPing(userId: string, lat: number, lng: number, jobId?: number): Promise<void>;
  getPingsForJob(jobId: number): Promise<Ping[]>;
  
  // Real-time subscriptions
  subscribeToPings(jobId: number, callback: (ping: Ping) => void): () => void;
  
  // ETA calculation
  calculateETA(fromLat: number, fromLng: number, toLat: number, toLng: number): Promise<number>;
}

export interface MessagingAPI {
  // Chat management
  sendMessage(jobId: number, senderId: string, receiverId: string, content: string): Promise<ChatMessage>;
  getMessagesForJob(jobId: number): Promise<ChatMessage[]>;
  
  // Real-time subscriptions
  subscribeToMessages(jobId: number, callback: (message: ChatMessage) => void): () => void;
  
  // Message status
  markMessageAsRead(messageId: string): Promise<void>;
  getUnreadCount(userId: string): Promise<number>;
}

export interface LocationsAPI {
  // Static locations
  getStaticLocations(): Promise<StaticLocation[]>;
  getAvailableSlots(locationId: string, date: string): Promise<TimeSlot[]>;
  
  // Location management
  createStaticLocation(locationData: CreateLocationData): Promise<StaticLocation>;
  updateStaticLocation(locationId: string, updates: Partial<StaticLocation>): Promise<StaticLocation>;
}

// Additional types
export interface RegisterData {
  email: string;
  password: string;
  name: string;
  phone: string;
  userType: UserType;
}

export interface CreateJobData {
  customerId: string;
  serviceId: number;
  pickupLat: number;
  pickupLng: number;
  pickupAddress: string;
  price: number;
}

export interface StaticLocation {
  id: string;
  name: string;
  description: string;
  lat: number;
  lng: number;
  address: string;
  isActive: boolean;
  services: Service[];
}

export interface TimeSlot {
  id: string;
  locationId: string;
  startTime: string;
  endTime: string;
  isAvailable: boolean;
  price: number;
}

export interface CreateLocationData {
  name: string;
  description: string;
  lat: number;
  lng: number;
  address: string;
  services: number[];
}
```

## Edge Functions Contracts

### create-job
```typescript
// Request
interface CreateJobRequest {
  customerId: string;
  serviceId: number;
  pickupLat: number;
  pickupLng: number;
  pickupAddress: string;
  price: number;
}

// Response
interface CreateJobResponse {
  success: boolean;
  job: Job;
  error?: string;
}
```

### accept-job
```typescript
// Request
interface AcceptJobRequest {
  jobId: number;
  valeterId: string;
}

// Response
interface AcceptJobResponse {
  success: boolean;
  job: Job;
  error?: string;
}
```

### advance-status
```typescript
// Request
interface AdvanceStatusRequest {
  jobId: number;
  newStatus: JobStatus;
  userId: string;
}

// Response
interface AdvanceStatusResponse {
  success: boolean;
  job: Job;
  error?: string;
}
```

### cancel-job
```typescript
// Request
interface CancelJobRequest {
  jobId: number;
  reason: string;
  userId: string;
}

// Response
interface CancelJobResponse {
  success: boolean;
  job: Job;
  refundProcessed: boolean;
  error?: string;
}
```

### confirm-payment
```typescript
// Request
interface ConfirmPaymentRequest {
  paymentIntentId: string;
  jobId: number;
}

// Response
interface ConfirmPaymentResponse {
  success: boolean;
  paymentConfirmed: boolean;
  error?: string;
}
```

### ping
```typescript
// Request
interface PingRequest {
  userId: string;
  lat: number;
  lng: number;
  jobId?: number;
  heading?: number;
  speed?: number;
}

// Response
interface PingResponse {
  success: boolean;
  pingId: number;
  error?: string;
}
```

### send-message
```typescript
// Request
interface SendMessageRequest {
  jobId: number;
  senderId: string;
  receiverId: string;
  content: string;
}

// Response
interface SendMessageResponse {
  success: boolean;
  message: ChatMessage;
  error?: string;
}
```

### save-device-token
```typescript
// Request
interface SaveDeviceTokenRequest {
  userId: string;
  platform: "ios" | "android";
  token: string;
}

// Response
interface SaveDeviceTokenResponse {
  success: boolean;
  error?: string;
}
```

### send-push
```typescript
// Request
interface SendPushRequest {
  userId: string;
  title: string;
  body: string;
  data?: Record<string, any>;
}

// Response
interface SendPushResponse {
  success: boolean;
  messageId: string;
  error?: string;
}
```

## Database Schema Contracts

### Profiles Table
```sql
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  phone TEXT,
  role user_role NOT NULL DEFAULT 'customer',
  user_type TEXT NOT NULL CHECK (user_type IN ('customer', 'valeter')),
  is_email_verified BOOLEAN DEFAULT FALSE,
  rating NUMERIC DEFAULT 0,
  jobs_completed INTEGER DEFAULT 0,
  years_experience INTEGER DEFAULT 0,
  badges TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### Jobs Table
```sql
CREATE TABLE jobs (
  id BIGSERIAL PRIMARY KEY,
  customer_id UUID REFERENCES profiles(id) NOT NULL,
  valeter_id UUID REFERENCES profiles(id),
  service_id BIGINT REFERENCES services(id) NOT NULL,
  status job_status NOT NULL DEFAULT 'REQUESTED',
  pickup_lat DOUBLE PRECISION NOT NULL,
  pickup_lng DOUBLE PRECISION NOT NULL,
  pickup_address TEXT,
  eta_minutes INTEGER,
  total_amount INTEGER NOT NULL,
  commission_amount INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### Messages Table
```sql
CREATE TABLE messages (
  id BIGSERIAL PRIMARY KEY,
  job_id BIGINT REFERENCES jobs(id) NOT NULL,
  sender_id UUID REFERENCES profiles(id) NOT NULL,
  receiver_id UUID REFERENCES profiles(id) NOT NULL,
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### Locations Table
```sql
CREATE TABLE locations (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) NOT NULL,
  job_id BIGINT REFERENCES jobs(id),
  lat DOUBLE PRECISION NOT NULL,
  lng DOUBLE PRECISION NOT NULL,
  heading DOUBLE PRECISION,
  speed DOUBLE PRECISION,
  timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

## Error Handling

```typescript
export interface ApiError {
  code: string;
  message: string;
  details?: any;
}

export class ApiException extends Error {
  constructor(
    public code: string,
    message: string,
    public details?: any
  ) {
    super(message);
    this.name = 'ApiException';
  }
}

// Common error codes
export const ErrorCodes = {
  UNAUTHORIZED: 'UNAUTHORIZED',
  FORBIDDEN: 'FORBIDDEN',
  NOT_FOUND: 'NOT_FOUND',
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  PAYMENT_FAILED: 'PAYMENT_FAILED',
  JOB_NOT_FOUND: 'JOB_NOT_FOUND',
  JOB_ALREADY_ACCEPTED: 'JOB_ALREADY_ACCEPTED',
  INVALID_STATUS_TRANSITION: 'INVALID_STATUS_TRANSITION',
  LOCATION_SERVICE_UNAVAILABLE: 'LOCATION_SERVICE_UNAVAILABLE',
  NETWORK_ERROR: 'NETWORK_ERROR',
  SERVER_ERROR: 'SERVER_ERROR',
} as const;
```

## Real-time Events

```typescript
export interface RealtimeEvent {
  type: string;
  payload: any;
  timestamp: string;
}

export const EventTypes = {
  JOB_CREATED: 'job_created',
  JOB_UPDATED: 'job_updated',
  JOB_ACCEPTED: 'job_accepted',
  JOB_STARTED: 'job_started',
  JOB_COMPLETED: 'job_completed',
  JOB_CANCELLED: 'job_cancelled',
  LOCATION_UPDATED: 'location_updated',
  MESSAGE_SENT: 'message_sent',
  MESSAGE_READ: 'message_read',
  PAYMENT_CONFIRMED: 'payment_confirmed',
  REFUND_PROCESSED: 'refund_processed',
} as const;
```
