# Screens & Features Matrix

## Customer Portal Screens

| Screen | Role | Purpose | Reads From | Writes To | Realtime? | Validators/Guards | Navigates To |
|--------|------|---------|------------|-----------|-----------|------------------|--------------|
| `app/index.tsx` | All | Entry point routing | `useAuth()` | - | No | `hasSeenOnboarding` | Role-based routing |
| `app/login.tsx` | Customer | Customer login | `useAuth()` | `AuthContext` | No | Email/password validation | `/owner-dashboard` |
| `app/owner-dashboard.tsx` | Customer | Main dashboard | `PowerfulDashboard` | - | Yes | `useAuth()` | `/booking`, `/tracking`, `/profile` |
| `app/booking.tsx` | Customer | Service booking | `SimulationService`, `PricingEngine` | `SimulationService` | No | Service/location selection | `/tracking` |
| `app/tracking.tsx` | Customer | Live service tracking | `SimulationService`, `LiveTrackingService` | - | Yes | Job status validation | `/owner-dashboard` |
| `app/owner-profile.tsx` | Customer | Profile management | `useAuth()`, `FileUploadService` | `AuthContext` | No | Profile validation | `/privacy-settings`, `/help-support` |
| `app/customer-welcome.tsx` | Customer | Onboarding | `useAuth()` | `AsyncStorage` | No | Welcome completion | `/owner-dashboard` |
| `app/unified-booking.tsx` | Customer | Enhanced booking | `SimulationService`, `PricingEngine` | `SimulationService` | No | Vehicle selection | `/tracking` |
| `app/priority-wash.tsx` | Customer | Priority service | `SimulationService`, `PricingEngine` | `SimulationService` | No | Location validation | `/tracking` |
| `app/instant-wash.tsx` | Customer | Instant booking | `SimulationService`, `PricingEngine` | `SimulationService` | No | Service validation | `/tracking` |
| `app/customer-network.tsx` | Customer | Social features | `ChatService` | `ChatService` | Yes | User validation | `/live-chat` |
| `app/live-chat.tsx` | Customer | Support chat | `ChatService` | `ChatService` | Yes | Chat validation | - |
| `app/help-support.tsx` | Customer | Help & support | - | - | No | - | `/live-chat` |
| `app/privacy-settings.tsx` | Customer | Privacy management | `useAuth()` | `AuthContext` | No | Password validation | - |
| `app/terms-of-service.tsx` | Customer | Legal terms | - | - | No | - | - |
| `app/privacy-policy.tsx` | Customer | Privacy policy | - | - | No | - | - |

## Valeter Portal Screens

| Screen | Role | Purpose | Reads From | Writes To | Realtime? | Validators/Guards | Navigates To |
|--------|------|---------|------------|-----------|-----------|------------------|--------------|
| `app/organization-login.tsx` | Valeter | Valeter login | `useAuth()` | `AuthContext` | No | Email/password validation | `/driver-dashboard` |
| `app/driver-dashboard.tsx` | Valeter | Valeter dashboard | `SimulationService`, `LiveTrackingService` | `SimulationService` | Yes | `useAuth()`, verification status | `/tracking`, `/profile` |
| `app/valeter-profile.tsx` | Valeter | Valeter profile | `useAuth()`, `FileUploadService` | `AuthContext` | No | Document validation | `/driver-dashboard` |
| `app/valeter-welcome.tsx` | Valeter | Valeter onboarding | `useAuth()` | `AsyncStorage` | No | Welcome completion | `/driver-dashboard` |
| `app/track-vehicle.tsx` | Valeter | Vehicle tracking | `LiveTrackingService` | `LiveTrackingService` | Yes | GPS permissions | `/driver-dashboard` |
| `app/follow-valeter.tsx` | Customer | Valeter tracking | `LiveTrackingService` | - | Yes | Job validation | `/tracking` |

## Admin Portal Screens

| Screen | Role | Purpose | Reads From | Writes To | Realtime? | Validators/Guards | Navigates To |
|--------|------|---------|------------|-----------|-----------|------------------|--------------|
| `app/admin-dashboard.tsx` | Admin | Admin dashboard | `SimulationService`, `PaymentSystem` | `SimulationService` | Yes | `hasAdminAccess()` | Various admin screens |
| `app/admin/_layout.tsx` | Admin | Admin layout guard | `useAuth()` | - | No | `hasAdminAccess()` | Redirects non-admins |

## Shared Screens

| Screen | Role | Purpose | Reads From | Writes To | Realtime? | Validators/Guards | Navigates To |
|--------|------|---------|------------|-----------|-----------|------------------|--------------|
| `app/onboarding.tsx` | All | App onboarding | - | `AsyncStorage` | No | Onboarding completion | Role-based routing |
| `app/service-tracker.tsx` | All | Service tracking | `SimulationService`, `LiveTrackingService` | - | Yes | Job validation | `/tracking` |

## Data Flow Patterns

### Customer Booking Flow
1. **Login** (`app/login.tsx`) → **Dashboard** (`app/owner-dashboard.tsx`)
2. **Dashboard** → **Booking** (`app/booking.tsx`) → **Tracking** (`app/tracking.tsx`)
3. **Tracking** → **Dashboard** (completion)

### Valeter Job Flow
1. **Login** (`app/organization-login.tsx`) → **Dashboard** (`app/driver-dashboard.tsx`)
2. **Dashboard** → **Job Acceptance** → **Tracking** (`app/tracking.tsx`)
3. **Tracking** → **Dashboard** (completion)

### Admin Management Flow
1. **Profile** → **Admin Toggle** → **Admin Dashboard** (`app/admin-dashboard.tsx`)
2. **Admin Dashboard** → Various management screens

## Real-time Features

### Live Tracking
- **Customer**: Real-time valeter location updates
- **Valeter**: GPS sharing and route optimization
- **Admin**: Live system monitoring

### Chat & Messaging
- **Customer-Valeter**: Job-scoped chat
- **Support**: Live chat with AI/human agents
- **Admin**: System-wide messaging

### Notifications
- **Push Notifications**: Job updates, new bookings
- **In-app Alerts**: Status changes, errors
- **Email/SMS**: Important updates

## Data Validation & Guards

### Authentication Guards
- **Login Required**: All dashboard screens
- **Role Validation**: Admin screens
- **Session Management**: Auto-logout on expiry

### Business Logic Guards
- **Job Status**: Valid transitions only
- **Payment Validation**: Stripe integration
- **Location Services**: GPS permissions
- **Document Upload**: File validation

### UI Guards
- **Loading States**: Data fetching indicators
- **Error Boundaries**: Graceful error handling
- **Empty States**: No data scenarios
- **Permission Checks**: Feature access control

## Navigation Patterns

### Stack Navigation
- **Customer**: Login → Dashboard → Booking → Tracking
- **Valeter**: Login → Dashboard → Job Management
- **Admin**: Profile → Admin Dashboard → Management

### Tab Navigation
- **Customer Dashboard**: Home, Book, Track, Profile
- **Valeter Dashboard**: Jobs, Track, Profile
- **Admin Dashboard**: Analytics, Users, Reports

### Modal Navigation
- **Booking Flow**: Service selection, payment
- **Profile Updates**: Settings, preferences
- **Admin Actions**: User management, refunds

## Performance Considerations

### Data Loading
- **Lazy Loading**: Screen-specific data
- **Caching**: User preferences, service data
- **Optimistic Updates**: UI responsiveness

### Real-time Optimization
- **WebSocket Management**: Connection handling
- **GPS Throttling**: Battery optimization
- **Update Batching**: Reduce API calls

### Memory Management
- **Component Cleanup**: Unsubscribe from updates
- **Image Optimization**: Profile pictures, maps
- **State Cleanup**: Clear unused data
