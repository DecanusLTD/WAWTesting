# Manual Test Plan

## Overview
This document outlines the manual testing procedures for the Wish a Wash app, covering all major user flows and edge cases.

## Test Environment Setup

### Prerequisites
- Expo Go app installed on test device
- Test device with GPS capabilities
- Stable internet connection
- Test accounts ready (see below)

### Test Accounts
```bash
# Customer Accounts
Email: customer@test.com
Password: password123

# Valeter Accounts  
Email: valeter@test.com
Password: password123

# Admin Accounts
Email: reece@wishawash.com
Password: admin123
Email: charlie@wishawash.com
Password: admin123

# Business Owner Account
Email: business@elitevalet.com
Password: password123
```

## Test Scenarios

### 1. Customer Flow: Login → Book → Track → Complete

#### 1.1 Customer Login
**Steps:**
1. Open app
2. Select "Customer Login"
3. Enter email: `customer@test.com`
4. Enter password: `password123`
5. Tap "Login"

**Expected Results:**
- [ ] Login successful
- [ ] Redirected to customer dashboard
- [ ] Dashboard shows customer name and stats
- [ ] No admin options visible

**Test Data:**
- Valid credentials: Should login successfully
- Invalid email: Should show error message
- Invalid password: Should show error message
- Empty fields: Should show validation error

#### 1.2 Service Booking
**Steps:**
1. From dashboard, tap "Book Service"
2. Select service type (Basic Wash, Premium Wash, etc.)
3. Enter pickup location
4. Review pricing
5. Tap "Book Now"

**Expected Results:**
- [ ] Service selection works
- [ ] Location input accepts valid addresses
- [ ] Pricing calculation shows correct amounts
- [ ] Booking confirmation appears
- [ ] Redirected to tracking screen

**Test Data:**
- Valid service selection: Should proceed to location
- Invalid location: Should show error
- Different service types: Should show different pricing

#### 1.3 Live Tracking
**Steps:**
1. After booking, observe tracking screen
2. Wait for valeter assignment
3. Monitor live location updates
4. Check ETA updates

**Expected Results:**
- [ ] Tracking screen loads
- [ ] Shows "Searching for valeter" initially
- [ ] Updates to show valeter details when assigned
- [ ] Live location updates every 10-15 seconds
- [ ] ETA updates in real-time

**Test Data:**
- No valeters online: Should show "No valeters available"
- Valeter assigned: Should show valeter profile and location
- Service completed: Should show completion screen

#### 1.4 Service Completion
**Steps:**
1. Wait for service to complete
2. Rate the service (1-5 stars)
3. Add optional tip
4. Submit rating

**Expected Results:**
- [ ] Rating screen appears after completion
- [ ] Star rating works (1-5 stars)
- [ ] Tip selection works
- [ ] Rating submission successful
- [ ] Redirected to dashboard

**Test Data:**
- Different ratings: Should all be accepted
- No tip: Should proceed without tip
- With tip: Should add tip to total

### 2. Valeter Flow: Login → Accept → Navigate → Complete

#### 2.1 Valeter Login
**Steps:**
1. Open app
2. Select "Valeter Login"
3. Enter email: `valeter@test.com`
4. Enter password: `password123`
5. Tap "Login"

**Expected Results:**
- [ ] Login successful
- [ ] Redirected to valeter dashboard
- [ ] Dashboard shows valeter stats and available jobs
- [ ] No admin options visible

#### 2.2 Job Acceptance
**Steps:**
1. From dashboard, view available jobs
2. Select a job
3. Review job details
4. Tap "Accept Job"

**Expected Results:**
- [ ] Available jobs list loads
- [ ] Job details show correctly
- [ ] Job acceptance successful
- [ ] Job status updates to "Accepted"
- [ ] Customer notified of acceptance

#### 2.3 GPS Sharing
**Steps:**
1. After accepting job, tap "Start Navigation"
2. Allow location permissions
3. Observe GPS sharing status

**Expected Results:**
- [ ] Location permission request appears
- [ ] GPS sharing starts
- [ ] Location updates sent every 10-15 seconds
- [ ] Customer can see valeter location

#### 2.4 Service Completion
**Steps:**
1. Navigate to customer location
2. Tap "Arrive at Location"
3. Tap "Start Service"
4. Complete service
5. Tap "Complete Service"

**Expected Results:**
- [ ] Status updates correctly through each stage
- [ ] Customer notified of each status change
- [ ] Service completion successful
- [ ] Payment processing initiated

### 3. Admin Flow: Login → Dashboard → Management

#### 3.1 Admin Login
**Steps:**
1. Open app
2. Login as admin: `reece@wishawash.com` / `admin123`
3. Go to profile settings
4. Enable admin dashboard mode

**Expected Results:**
- [ ] Login successful
- [ ] Admin dashboard mode toggle visible
- [ ] Toggle works correctly
- [ ] Admin dashboard accessible

#### 3.2 Admin Dashboard
**Steps:**
1. Access admin dashboard
2. View analytics tabs
3. Check user management
4. Review financial data

**Expected Results:**
- [ ] Dashboard loads with real data
- [ ] Analytics show correct metrics
- [ ] User list displays correctly
- [ ] Financial data accurate

#### 3.3 Admin Actions
**Steps:**
1. View user profiles
2. Process refund requests
3. View system reports
4. Export data

**Expected Results:**
- [ ] User profile viewing works
- [ ] Refund processing functional
- [ ] Reports display correctly
- [ ] Data export works

### 4. Error Scenarios

#### 4.1 Network Errors
**Steps:**
1. Disconnect internet
2. Try to perform actions (login, booking, etc.)
3. Reconnect internet
4. Retry actions

**Expected Results:**
- [ ] Graceful error handling
- [ ] User-friendly error messages
- [ ] Retry functionality works
- [ ] No app crashes

#### 4.2 Invalid Data
**Steps:**
1. Enter invalid email formats
2. Enter invalid phone numbers
3. Enter invalid locations
4. Submit forms with missing data

**Expected Results:**
- [ ] Input validation works
- [ ] Error messages clear and helpful
- [ ] Forms don't submit with invalid data
- [ ] No app crashes

#### 4.3 GPS Issues
**Steps:**
1. Disable GPS permissions
2. Try to use location features
3. Re-enable GPS
4. Test location features

**Expected Results:**
- [ ] Graceful handling of GPS unavailability
- [ ] Clear permission requests
- [ ] Location features work when GPS enabled
- [ ] No app crashes

### 5. Edge Cases

#### 5.1 Job Cancellation
**Steps:**
1. Book a service as customer
2. Cancel before valeter accepts
3. Check refund processing

**Expected Results:**
- [ ] Cancellation successful
- [ ] Refund processed correctly
- [ ] Valeter notified of cancellation
- [ ] No duplicate charges

#### 5.2 Job Expiry
**Steps:**
1. Book a service
2. Wait for 15-minute timeout
3. Check automatic expiry

**Expected Results:**
- [ ] Job expires after 15 minutes
- [ ] Customer notified of expiry
- [ ] Refund processed automatically
- [ ] Job removed from available jobs

#### 5.3 Multiple Users
**Steps:**
1. Login as customer on device 1
2. Login as valeter on device 2
3. Book service from device 1
4. Accept job on device 2

**Expected Results:**
- [ ] Real-time updates work across devices
- [ ] Job assignment successful
- [ ] Live tracking works
- [ ] Chat functionality works

### 6. Performance Testing

#### 6.1 App Performance
**Steps:**
1. Monitor app startup time
2. Test navigation between screens
3. Monitor memory usage
4. Test battery consumption

**Expected Results:**
- [ ] App starts within 3 seconds
- [ ] Screen transitions smooth
- [ ] Memory usage stable
- [ ] Battery usage reasonable

#### 6.2 Real-time Updates
**Steps:**
1. Monitor GPS update frequency
2. Test chat message delivery
3. Check job status updates
4. Monitor notification delivery

**Expected Results:**
- [ ] GPS updates every 10-15 seconds
- [ ] Chat messages delivered instantly
- [ ] Job status updates real-time
- [ ] Notifications received promptly

## Test Checklist

### Customer Features
- [ ] Login/logout works
- [ ] Service booking functional
- [ ] Live tracking works
- [ ] Payment processing works
- [ ] Rating system works
- [ ] Chat functionality works
- [ ] Profile management works

### Valeter Features
- [ ] Login/logout works
- [ ] Job acceptance works
- [ ] GPS sharing works
- [ ] Service completion works
- [ ] Earnings tracking works
- [ ] Profile management works

### Admin Features
- [ ] Admin access restricted
- [ ] Dashboard loads correctly
- [ ] User management works
- [ ] Financial data accurate
- [ ] Refund processing works
- [ ] Analytics display correctly

### General Features
- [ ] Error handling works
- [ ] Loading states display
- [ ] Offline handling works
- [ ] Push notifications work
- [ ] App performance good
- [ ] No crashes or freezes

## Bug Reporting

### Bug Report Template
```
**Bug Title:** [Brief description]

**Steps to Reproduce:**
1. [Step 1]
2. [Step 2]
3. [Step 3]

**Expected Result:** [What should happen]

**Actual Result:** [What actually happened]

**Device Info:**
- Device: [iPhone/Android model]
- OS Version: [iOS/Android version]
- App Version: [App version]

**Screenshots:** [If applicable]

**Additional Notes:** [Any other relevant information]
```

### Priority Levels
- **Critical:** App crashes, data loss, security issues
- **High:** Core functionality broken, user cannot complete main tasks
- **Medium:** Minor functionality issues, UI problems
- **Low:** Cosmetic issues, minor improvements

## Test Completion Criteria

### Success Criteria
- [ ] All critical paths work correctly
- [ ] No app crashes during testing
- [ ] All user roles function properly
- [ ] Real-time features work reliably
- [ ] Error handling is graceful
- [ ] Performance meets requirements

### Sign-off Requirements
- [ ] All test scenarios completed
- [ ] All bugs documented and prioritized
- [ ] Performance metrics recorded
- [ ] Test results reviewed by team
- [ ] Approval from product owner
