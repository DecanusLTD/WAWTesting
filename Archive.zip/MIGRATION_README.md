# Wish-A-Wash Mock → Real Migration Guide

## Overview
This migration allows you to gradually replace simulated systems with real adapters (Supabase + Edge Functions + Stripe) while maintaining the existing app functionality.

## Quick Start

### 1. Environment Setup
Copy `env.example` to `.env` and configure:

```bash
# For mock mode (default)
EXPO_PUBLIC_USE_REAL=false

# For real mode
EXPO_PUBLIC_USE_REAL=true
EXPO_PUBLIC_SUPABASE_URL=your_supabase_url
EXPO_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
EXPO_PUBLIC_FUNCTIONS_BASE=https://your-edge-functions-host
EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_...
```

### 2. Supabase Setup
1. Create a new Supabase project
2. Run the SQL from `supabase-schema.sql` in the SQL editor
3. Copy your project URL and anon key to `.env`

### 3. Dependencies
Install required packages:

```bash
npm install @supabase/supabase-js @casl/ability
```

## Architecture

### API Facade
All I/O goes through `src/lib/api/index.ts`:

```typescript
import * as api from '@/lib/api';

// Use the same interface for both mock and real
const session = await api.auth.login(email, password);
const services = await api.jobs.listServices();
```

### Mock vs Real
- **Mock**: Uses existing `SimulationService` and other mock services
- **Real**: Uses Supabase client and Stripe integration

### Migration Steps

#### Phase 1: Facade Implementation ✅
- [x] Create API facade structure
- [x] Implement mock adapters
- [x] Implement real adapters
- [x] Add environment toggle

#### Phase 2: Auth Migration
- [ ] Wire login/logout to facade
- [ ] Test with `EXPO_PUBLIC_USE_REAL=true`
- [ ] Verify role-based access

#### Phase 3: Jobs Migration
- [ ] Replace `SimulationService` calls with `api.jobs.*`
- [ ] Test job creation and acceptance
- [ ] Verify real-time updates

#### Phase 4: Tracking Migration
- [ ] Implement real GPS pinging
- [ ] Test location updates
- [ ] Verify map integration

#### Phase 5: Payments Migration
- [ ] Integrate Stripe payment intents
- [ ] Test payment flow
- [ ] Verify refund handling

#### Phase 6: Messaging Migration
- [ ] Implement real-time chat
- [ ] Test message delivery
- [ ] Verify chat history

## Testing

### Mock Mode
```bash
EXPO_PUBLIC_USE_REAL=false npm start
```
- All functionality works with simulated data
- No external dependencies required

### Real Mode
```bash
EXPO_PUBLIC_USE_REAL=true npm start
```
- Requires Supabase and Stripe setup
- Real data persistence and payments

### Manual Test Checklist
- [ ] Customer login → Service selection → Booking → Tracking
- [ ] Valeter login → Job acceptance → Location sharing → Completion
- [ ] Chat functionality between customer and valeter
- [ ] Payment processing and refunds
- [ ] Admin dashboard access

## Troubleshooting

### Common Issues
1. **Supabase connection failed**: Check URL and anon key
2. **Stripe payment failed**: Verify publishable key and function URL
3. **Real-time updates not working**: Check Supabase real-time settings

### Rollback
To rollback to mock mode:
```bash
EXPO_PUBLIC_USE_REAL=false
```

## Security Notes
- RLS (Row Level Security) is disabled initially for easier development
- Enable RLS and add policies before production deployment
- CASL abilities provide client-side authorization
- Server-side validation required in edge functions

## Next Steps
1. Implement edge functions for payment processing
2. Add RLS policies for data security
3. Implement background location tracking
4. Add push notifications
5. Performance monitoring and analytics
