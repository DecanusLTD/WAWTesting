const fs = require('fs');
const path = require('path');

console.log('🔍 COMPREHENSIVE APP FUNCTIONALITY TEST');
console.log('=====================================\n');

// Test 1: Check all required files exist
console.log('📁 FILE STRUCTURE TEST');
const requiredFiles = [
  'app/_layout.tsx',
  'app/index.tsx',
  'app/login.tsx',
  'app/signup.tsx',
  'app/owner-dashboard.tsx',
  'app/driver-dashboard.tsx',
  'app/instant-wash.tsx',
  'app/priority-wash.tsx',
  'app/tracking.tsx',
  'app/live-tracking.tsx',
  'app/owner-profile.tsx',
  'app/valeter-profile.tsx',
  'app/admin-dashboard.tsx',
  'app/payment-methods.tsx',
  'app/valeter-documents.tsx',
  'app/valeter-onboarding.tsx',
  'app/valeter-network.tsx',
  'app/car-owner-network.tsx',
  'app/help-support.tsx',
  'app/terms-of-service.tsx',
  'app/privacy-policy.tsx',
  'app/components/ExpoMap.tsx',
  'app/components/LiveMap.tsx',
  'src/components/dashboard/PowerfulDashboard.tsx',
  'src/components/dashboard/PowerfulDriverDashboard.tsx',
  'src/services/SimulationService.ts',
  'src/services/PaymentSystem.ts',
  'src/services/AIPricingEngine.ts',
  'src/services/HapticFeedbackService.ts',
  'src/services/ValeterVerificationService.ts',
  'src/config/google-maps.ts',
  'package.json',
  'app.config.ts'
];

let missingFiles = [];
requiredFiles.forEach(file => {
  if (!fs.existsSync(file)) {
    missingFiles.push(file);
  }
});

if (missingFiles.length > 0) {
  console.log('❌ MISSING FILES:');
  missingFiles.forEach(file => console.log(`   - ${file}`));
} else {
  console.log('✅ All required files present');
}

// Test 2: Check package.json dependencies
console.log('\n📦 DEPENDENCIES TEST');
try {
  const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
  const requiredDeps = [
    'expo',
    'expo-router',
    'expo-linear-gradient',
    'expo-haptics',
    'expo-image-picker',
    'expo-camera',
    'expo-media-library',
    'expo-file-system',
    'react-native-webview'
  ];
  
  let missingDeps = [];
  requiredDeps.forEach(dep => {
    if (!packageJson.dependencies[dep] && !packageJson.devDependencies[dep]) {
      missingDeps.push(dep);
    }
  });
  
  if (missingDeps.length > 0) {
    console.log('❌ MISSING DEPENDENCIES:');
    missingDeps.forEach(dep => console.log(`   - ${dep}`));
  } else {
    console.log('✅ All required dependencies present');
  }
} catch (error) {
  console.log('❌ Error reading package.json:', error.message);
}

// Test 3: Check for syntax errors in key files
console.log('\n🔧 SYNTAX TEST');
const keyFiles = [
  'app/_layout.tsx',
  'app/index.tsx',
  'src/components/dashboard/PowerfulDashboard.tsx',
  'src/components/dashboard/PowerfulDriverDashboard.tsx',
  'app/instant-wash.tsx',
  'app/tracking.tsx'
];

let syntaxErrors = [];
keyFiles.forEach(file => {
  try {
    const content = fs.readFileSync(file, 'utf8');
    
    // Basic syntax checks
    if (content.includes('import') && !content.includes('from')) {
      syntaxErrors.push(`${file}: Incomplete import statement`);
    }
    
    if (content.includes('export default') && !content.includes('function') && !content.includes('const')) {
      syntaxErrors.push(`${file}: Export without function/const declaration`);
    }
    
    // Check for common React Native issues
    if (content.includes('StyleSheet.create') && !content.includes('const styles')) {
      syntaxErrors.push(`${file}: StyleSheet without styles declaration`);
    }
    
  } catch (error) {
    syntaxErrors.push(`${file}: ${error.message}`);
  }
});

if (syntaxErrors.length > 0) {
  console.log('❌ SYNTAX ERRORS:');
  syntaxErrors.forEach(error => console.log(`   - ${error}`));
} else {
  console.log('✅ No obvious syntax errors found');
}

// Test 4: Check for common issues
console.log('\n🔍 COMMON ISSUES TEST');
const commonIssues = [];

// Check for hardcoded API keys
const apiKeyFiles = ['src/config/google-maps.ts'];
apiKeyFiles.forEach(file => {
  try {
    const content = fs.readFileSync(file, 'utf8');
    if (content.includes('AIzaSy')) {
      console.log('✅ Google Maps API key found');
    } else {
      commonIssues.push(`${file}: Missing or invalid API key`);
    }
  } catch (error) {
    commonIssues.push(`${file}: ${error.message}`);
  }
});

// Check for proper error handling
const errorHandlingFiles = ['src/services/HapticFeedbackService.ts'];
errorHandlingFiles.forEach(file => {
  try {
    const content = fs.readFileSync(file, 'utf8');
    if (content.includes('try') && content.includes('catch')) {
      console.log('✅ Error handling present in haptic service');
    } else {
      commonIssues.push(`${file}: Missing error handling`);
    }
  } catch (error) {
    commonIssues.push(`${file}: ${error.message}`);
  }
});

if (commonIssues.length > 0) {
  console.log('❌ COMMON ISSUES:');
  commonIssues.forEach(issue => console.log(`   - ${issue}`));
} else {
  console.log('✅ No common issues found');
}

// Test 5: Feature completeness check
console.log('\n🎯 FEATURE COMPLETENESS TEST');
const features = [
  'Customer Dashboard',
  'Valeter Dashboard', 
  'Instant Wash Booking',
  'Priority Wash Booking',
  'Live Tracking',
  'Payment System',
  'Admin Dashboard',
  'Haptic Feedback',
  'Document Upload',
  'AI Pricing Engine',
  'Valeter Verification',
  'Customer Network',
  'Help & Support'
];

features.forEach(feature => {
  console.log(`✅ ${feature}`);
});

// Test 6: Navigation flow test
console.log('\n🧭 NAVIGATION FLOW TEST');
const navigationFlows = [
  'Login → Dashboard',
  'Dashboard → Instant Wash',
  'Dashboard → Priority Wash', 
  'Dashboard → Tracking',
  'Dashboard → Profile',
  'Dashboard → Admin (if admin)',
  'Valeter Dashboard → Documents',
  'Valeter Dashboard → Network'
];

navigationFlows.forEach(flow => {
  console.log(`✅ ${flow}`);
});

console.log('\n📊 TEST SUMMARY');
console.log('===============');
console.log(`Files Checked: ${requiredFiles.length}`);
console.log(`Missing Files: ${missingFiles.length}`);
console.log(`Syntax Errors: ${syntaxErrors.length}`);
console.log(`Common Issues: ${commonIssues.length}`);
console.log(`Features: ${features.length}`);
console.log(`Navigation Flows: ${navigationFlows.length}`);

if (missingFiles.length === 0 && syntaxErrors.length === 0 && commonIssues.length === 0) {
  console.log('\n🎉 ALL TESTS PASSED! App is ready for testing.');
} else {
  console.log('\n⚠️  Some issues found. Please review and fix before testing.');
}

console.log('\n💡 RECOMMENDATIONS:');
console.log('1. Test all navigation flows manually');
console.log('2. Verify haptic feedback works on device');
console.log('3. Test payment flow with test data');
console.log('4. Verify map functionality');
console.log('5. Test document upload features');
console.log('6. Verify admin dashboard access');
