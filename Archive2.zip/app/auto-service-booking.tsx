import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { LinearGradient } from 'expo-linear-gradient';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import BookingService from '../src/services/BookingService';
import { pricingEngine } from '../src/utils/pricing-engine';
import * as Location from 'expo-location';
import { supabase } from '../src/lib/supabase'; // NEW: query vehicles from DB

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

/** ---------------- DEBUG UTIL ---------------- */
const DEBUG_TAG = '[AutoServiceBooking]';
const DEBUG = true; // flip to false to silence logs
const safeJson = (obj: any) => { try { return JSON.stringify(obj, null, 2); } catch { return String(obj); } };
const dbg = (...args: any[]) => { if (!DEBUG) return; const ts = new Date().toISOString(); console.log(`${DEBUG_TAG} ${ts}`, ...args); };
/** ------------------------------------------- */

type LegacyServiceId = 'wash' | 'valet' | 'priority_wash';

interface ServiceOption {
  id: 'basic-wash' | 'premium-wash' | 'full-valet' | 'exterior-detail' | 'interior-detail' | 'premium-valet';
  name: string;
  description: string;
  duration: string;
  features: string[];
  colors: string[];
  details?: string;
}

interface VehicleType {
  id: 'small' | 'medium' | 'large' | 'suv' | 'luxury';
  name: string;
  description: string;
  icon: string;
  basePrice: number;
  colors: string[];
}

interface LocationOption {
  id: 'current' | 'home' | 'work' | 'gym' | 'shopping' | 'airport' | 'hotel';
  name: string;
  icon: string;
  description?: string;
  colors: string[];
}

interface TimeSlot {
  id: 'on-demand' | 'morning' | 'afternoon' | 'evening' | 'weekend';
  name: string;
  icon: string;
  colors: string[];
}

interface Vehicle {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  isDefault: boolean;
  photo?: string | null;
}

/** Component */
export default function AutoServiceBooking() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  dbg('Component mount. User:', user ? { id: user.id, name: user.name, email: user.email } : 'NO USER');

  /* ---------------- Active booking guard ---------------- */
  const [activeBooking, setActiveBooking] = useState<any | null>(null);
  const [loadingActive, setLoadingActive] = useState<boolean>(true);

  useEffect(() => {
    const checkActive = async () => {
      try {
        if (!user) {
          setActiveBooking(null);
          return;
        }
        const existing = await BookingService.getActiveBookingForUser(user.id);
        dbg('Active booking check ->', existing ? { id: existing.id, status: existing.status } : 'none');
        setActiveBooking(existing || null);
      } catch (e: any) {
        console.error('[AutoServiceBooking] getActiveBookingForUser error:', e?.message || e);
        setActiveBooking(null);
      } finally {
        setLoadingActive(false);
      }
    };
    checkActive();
  }, [user]);
  /* ------------------------------------------------------ */

  // selections
  const [selectedService, setSelectedService] = useState<ServiceOption | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleType | null>(null);
  const [selectedStoredVehicle, setSelectedStoredVehicle] = useState<Vehicle | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<LocationOption | null>(null);
  const [selectedTimeId, setSelectedTimeId] = useState<TimeSlot['id']>('on-demand');
  const [selectedAddons] = useState<string[]>([]); // reserved for future

  // data + ui
  const [userVehicles, setUserVehicles] = useState<Vehicle[]>([]);
  const [vehiclesLoading, setVehiclesLoading] = useState<boolean>(false);
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4>(1);
  const [isProcessing, setIsProcessing] = useState(false);

  // location state
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [gps, setGps] = useState<{ lat: number; lng: number } | null>(null);
  const [gpsAddress, setGpsAddress] = useState<string | null>(null);

  // ---- static options ----
  const serviceOptions: ServiceOption[] = [
    { id: 'basic-wash', name: 'Basic Wash', description: 'Exterior wash & dry',
      details: '• Hand wash exterior\n• Dry with microfiber\n• Tire dressing\n• Basic interior wipe',
      duration: '15-20 min', features: ['Hand wash', 'Dry', 'Tire dressing', 'Basic interior'],
      colors: ['#10B981', '#059669'] },
    { id: 'premium-wash', name: 'Premium Wash', description: 'Exterior + Interior clean',
      details: '• Hand wash exterior\n• Interior vacuum & wipe\n• Glass cleaning\n• Tire & wheel cleaning',
      duration: '25-30 min', features: ['Hand wash', 'Interior clean', 'Glass clean', 'Wheel clean'],
      colors: ['#3B82F6', '#1D4ED8'] },
    { id: 'full-valet', name: 'Full Valet', description: 'Complete interior & exterior',
      details: '• Deep interior cleaning\n• Exterior wash & wax\n• Engine bay clean\n• Full detailing',
      duration: '45-60 min', features: ['Deep clean', 'Wax', 'Engine bay', 'Full detail'],
      colors: ['#8B5CF6', '#7C3AED'] },
    { id: 'exterior-detail', name: 'Exterior Detail', description: 'Professional exterior detailing',
      details: '• Clay bar treatment\n• Paint correction\n• Ceramic coating\n• Wheel restoration',
      duration: '2-3 hours', features: ['Clay bar', 'Paint correction', 'Ceramic coat', 'Wheel restore'],
      colors: ['#F59E0B', '#D97706'] },
    { id: 'interior-detail', name: 'Interior Detail', description: 'Deep interior restoration',
      details: '• Steam cleaning\n• Leather treatment\n• Odor removal\n• Fabric protection',
      duration: '1-2 hours', features: ['Steam clean', 'Leather care', 'Odor removal', 'Fabric protect'],
      colors: ['#EF4444', '#DC2626'] },
    { id: 'premium-valet', name: 'Premium Valet', description: 'Luxury car specialist service',
      details: '• Premium products only\n• Multi-stage paint care\n• Interior sanitization\n• Paint protection',
      duration: '3-4 hours', features: ['Premium products', 'Multi-stage', 'Sanitization', 'Paint protection'],
      colors: ['#FFD700', '#FFA500'] },
  ];

  const vehicleTypes: VehicleType[] = [
    { id: 'small', name: 'Small Car', description: 'Fiesta, Corsa, 208, Aygo, Up!', icon: '🚗', basePrice: 1.0, colors: ['#10B981', '#059669'] },
    { id: 'medium', name: 'Medium Car', description: 'Focus, Golf, Astra, Civic, Corolla', icon: '🚙', basePrice: 1.25, colors: ['#3B82F6', '#1D4ED8'] },
    { id: 'large', name: 'Large Car', description: 'Mondeo, Passat, Insignia, Accord', icon: '🏎️', basePrice: 1.5, colors: ['#EC4899', '#DB2777'] },
    { id: 'suv', name: 'SUV/4x4', description: 'Qashqai, Kuga, CR-V, RAV4, X3', icon: '🚐', basePrice: 1.75, colors: ['#8B5CF6', '#7C3AED'] },
    { id: 'luxury', name: 'Luxury Vehicle', description: 'BMW, Mercedes, Audi, Range Rover', icon: '🏁', basePrice: 2.0, colors: ['#FCD34D', '#F59E0B'] },
  ];

  const locations: LocationOption[] = [
    { id: 'current', name: 'Use Current Location', icon: '📍', description: 'GPS location for instant wash', colors: ['#10B981', '#059669'] },
    { id: 'home', name: 'Home Address', icon: '🏠', colors: ['#3B82F6', '#1D4ED8'] },
    { id: 'work', name: 'Work/Office', icon: '🏢', colors: ['#8B5CF6', '#7C3AED'] },
    { id: 'gym', name: 'Gym/Leisure', icon: '💪', colors: ['#F59E0B', '#D97706'] },
    { id: 'shopping', name: 'Shopping Centre', icon: '🛍️', colors: ['#EC4899', '#DB2777'] },
    { id: 'airport', name: 'Airport', icon: '✈️', colors: ['#FCD34D', '#F59E0B'] },
    { id: 'hotel', name: 'Hotel', icon: '🏨', colors: ['#06B6D4', '#0891B2'] },
  ];

  const timeSlots: TimeSlot[] = [
    { id: 'on-demand', name: 'On-Demand (Instant)', icon: '⚡', colors: ['#10B981', '#059669'] },
    { id: 'morning', name: 'Morning (8AM-12PM)', icon: '🌅', colors: ['#F59E0B', '#D97706'] },
    { id: 'afternoon', name: 'Afternoon (12PM-5PM)', icon: '☀️', colors: ['#FCD34D', '#F59E0B'] },
    { id: 'evening', name: 'Evening (5PM-9PM)', icon: '🌆', colors: ['#8B5CF6', '#7C3AED'] },
    { id: 'weekend', name: 'Weekend', icon: '🎉', colors: ['#EC4899', '#DB2777'] },
  ];

  /** ---------- Load vehicles from DB (Supabase) ---------- */
  const loadVehicles = async () => {
    if (!user?.id) {
      setUserVehicles([]);
      setSelectedStoredVehicle(null);
      return;
    }
    try {
      setVehiclesLoading(true);
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('id, user_id, type, make, model, color, registration, is_default, photo, created_at, updated_at')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false })
        .order('created_at', { ascending: true });

      if (error) throw error;

      const mapped: Vehicle[] = (data ?? []).map((row: any) => ({
        id: String(row.id),
        type: String(row.type ?? 'Car'),
        make: String(row.make ?? ''),
        model: String(row.model ?? ''),
        color: String(row.color ?? ''),
        registration: String(row.registration ?? ''),
        isDefault: !!row.is_default,
        photo: row.photo ?? null,
      }));

      setUserVehicles(mapped);
      const def = mapped.find(v => v.isDefault);
      setSelectedStoredVehicle(def ?? null);
      dbg('Vehicles loaded:', mapped.length);
    } catch (e: any) {
      console.error('[AutoServiceBooking] loadVehicles error:', e?.message || e);
      Alert.alert('Vehicles', 'Could not load your vehicles.');
      setUserVehicles([]);
      setSelectedStoredVehicle(null);
    } finally {
      setVehiclesLoading(false);
    }
  };

  useEffect(() => { loadVehicles(); }, [user?.id]);
  /** ------------------------------------------------------ */

  // ----- helpers -----
  const mapServiceToLegacy = (svc: ServiceOption, timeId: TimeSlot['id']): LegacyServiceId => {
    const mapped =
      timeId === 'on-demand' && (svc.id === 'basic-wash' || svc.id === 'premium-wash')
        ? 'priority_wash'
        : (svc.id === 'basic-wash' || svc.id === 'premium-wash')
        ? 'wash'
        : 'valet';
    dbg('mapServiceToLegacy ->', { uiServiceId: svc.id, timeId, legacy: mapped });
    return mapped;
  };

  const computeLegacyPrice = (legacyService: LegacyServiceId) => {
    const timeOfDay = pricingEngine.getTimeOfDay();
    const dayOfWeek = pricingEngine.getDayOfWeek();
    const demand = pricingEngine.getDemandLevel('London', timeOfDay, dayOfWeek);

    const priceBreakdown = pricingEngine.calculatePrice({
      location: 'London',
      timeOfDay,
      dayOfWeek,
      demand,
      weather: 'sunny',
      vehicleSize: (selectedVehicle?.id ?? 'medium') as 'small' | 'medium' | 'large' | 'suv' | 'luxury',
      serviceType: legacyService,
    });

    const total = Math.round(priceBreakdown.totalPrice);
    dbg('computeLegacyPrice ->', { legacyService, timeOfDay, dayOfWeek, demand, vehicleSize: selectedVehicle?.id ?? 'medium', total, priceBreakdown });
    return total;
  };

  const coordsForChoice = useMemo(() => {
    const map = {
      home: { lat: 51.5074, lng: -0.1278 },
      work: { lat: 51.5074, lng: -0.1278 },
      gym: { lat: 51.5074, lng: -0.1278 },
      shopping: { lat: 51.5074, lng: -0.1278 },
      airport: { lat: 51.4700, lng: -0.4543 },
      hotel: { lat: 51.5074, lng: -0.1278 },
    } as Record<Exclude<LocationOption['id'], 'current'>, { lat: number; lng: number }>;
    dbg('coordsForChoice memoized map:', map);
    return map;
  }, []);

  // ---- step guards (enables "Next") ----
  const step1Ready = !!(selectedVehicle || selectedStoredVehicle);
  const step2Ready = !!selectedService;
  const step3Ready = !!selectedLocation && (selectedLocation.id !== 'current' || !!gps || gpsLoading === false);

  useEffect(() => { dbg('state:step readiness ->', { step1Ready, step2Ready, step3Ready }); }, [step1Ready, step2Ready, step3Ready]);
  useEffect(() => { dbg('state:selections ->', {
    currentStep, selectedVehicle, selectedStoredVehicle, selectedService, selectedLocation, selectedTimeId, gps, gpsError, gpsLoading, gpsAddress
  }); }, [currentStep, selectedVehicle, selectedStoredVehicle, selectedService, selectedLocation, selectedTimeId, gps, gpsError, gpsLoading, gpsAddress]);

  // ---- actions ----
  const handleBack = async () => {
    await hapticFeedback('light');
    dbg('handleBack pressed. Current step:', currentStep);
    if (currentStep > 1) {
      setCurrentStep((s) => {
        const next = ((s - 1) as 1 | 2 | 3 | 4);
        dbg('Navigating back to step:', next);
        return next;
      });
    } else {
      dbg('Back -> router.back()');
      router.back();
    }
  };

  const handleNext = async () => {
    await hapticFeedback('light');
    dbg('handleNext pressed. Current step:', currentStep);

    if (currentStep === 1 && !step1Ready) { dbg('Next blocked: step1 not ready'); return; }
    if (currentStep === 2 && !step2Ready) { dbg('Next blocked: step2 not ready'); return; }

    if (currentStep === 3) {
      if (!selectedLocation) { dbg('Next blocked: no location selected'); return; }
      if (selectedLocation.id === 'current') {
        if (!gps) {
          dbg('No GPS yet, requesting…');
          await requestAndFetchGps();
          if (!gps) { dbg('Next blocked: still no GPS (denied/error)'); return; }
        }
      }
    }

    if (currentStep < 4) {
      setCurrentStep((s) => {
        const next = ((s + 1) as 1 | 2 | 3 | 4);
        dbg('Advancing to step:', next);
        return next;
      });
    } else {
      dbg('Confirm booking from step 4');
      await handleConfirmBooking();
    }
  };

  const formatAddress = (geo: Location.LocationGeocodedAddress) => {
    const parts = [
      geo.name || geo.street || '',
      geo.postalCode || '',
      geo.city || geo.subregion || '',
      geo.region || '',
      geo.country || '',
    ].filter(Boolean);
    return parts.join(', ').replace(/\s+,/g, ',').replace(/,+\s*$/,'');
  };

  const requestAndFetchGps = async () => {
    try {
      dbg('requestAndFetchGps:start');
      setGpsError(null);
      setGpsLoading(true);
      const { status } = await Location.requestForegroundPermissionsAsync();
      dbg('Location permission status:', status);
      if (status !== 'granted') {
        setGpsError('Location permission denied');
        Alert.alert('Location Permission', 'We could not access your location. You can choose another location option, or enable permissions in settings.');
        return;
      }
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      dbg('Location fetched:', pos?.coords ? { lat: pos.coords.latitude, lng: pos.coords.longitude, accuracy: pos.coords.accuracy } : 'no coords');
      const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      setGps(coords);

      try {
        const r = await Location.reverseGeocodeAsync({ latitude: coords.lat, longitude: coords.lng });
        const addr = r?.[0] ? formatAddress(r[0]) : null;
        setGpsAddress(addr);
        dbg('reverseGeocode ->', addr || 'NO ADDRESS');
      } catch (rgErr: any) {
        dbg('reverseGeocode ERROR ->', rgErr?.message ?? rgErr);
        setGpsAddress(null);
      }
    } catch (e: any) {
      console.warn(`${DEBUG_TAG} GPS error`, e?.message ?? e);
      setGpsError('Failed to get current location');
      Alert.alert('Location Error', 'We could not fetch your current location.');
    } finally {
      setGpsLoading(false);
      dbg('requestAndFetchGps:end');
    }
  };

  const handleSelectLocation = async (location: LocationOption) => {
    dbg('handleSelectLocation:', location);
    setSelectedLocation(location);
    if (location.id === 'current') {
      await requestAndFetchGps();
    } else {
      setGpsError(null);
      setGps(null);
      setGpsAddress(null);
    }
  };

  const handleConfirmBooking = async () => {
    dbg('handleConfirmBooking:start', {
      user: user ? { id: user.id, email: user.email } : 'NO USER',
      selectedService, selectedVehicle, selectedStoredVehicle, selectedLocation, selectedTimeId, gps, gpsAddress
    });

    if (!user) {
      await hapticFeedback('medium');
      Alert.alert('Error', 'Please login to book a service');
      dbg('Confirm blocked: no user');
      return;
    }
    if (!selectedService || (!selectedVehicle && !selectedStoredVehicle) || !selectedLocation) {
      await hapticFeedback('medium');
      Alert.alert('Error', 'Please complete all selections');
      dbg('Confirm blocked: incomplete selections');
      return;
    }

    try {
      const existing = await BookingService.getActiveBookingForUser(user.id);
      if (existing) {
        await hapticFeedback('medium');
        Alert.alert(
          'Existing Booking',
          'You already have a booking in progress.',
          [
            { text: 'Go to Current Booking', onPress: () => router.push({ pathname: '/current-trip', params: { bookingId: existing.id } }) },
            { text: 'OK', style: 'cancel' }
          ]
        );
        dbg('Confirm blocked: active booking exists ->', { id: existing.id, status: existing.status });
        return;
      }
    } catch (e) {
      console.warn('[AutoServiceBooking] Active re-check failed, proceeding to create:', (e as any)?.message || e);
    }

    setIsProcessing(true);
    await hapticFeedback('medium');

    const legacyType: LegacyServiceId = mapServiceToLegacy(selectedService, selectedTimeId);
    const finalPrice = computeLegacyPrice(legacyType);

    const { id: locId, name: locName } = selectedLocation;

    const latlng = (() => {
      if (locId === 'current' && gps) return gps;
      if (locId !== 'current') return coordsForChoice[locId];
      return { lat: 51.5074, lng: -0.1278 };
    })();

    const address = locId === 'current' ? (gpsAddress || 'Current Location') : locName;

    const payload = {
      customerId: user.id,
      serviceType: legacyType,
      serviceName: selectedService.name,
      price: finalPrice,
      location: {
        address,
        latitude: latlng.lat,
        longitude: latlng.lng,
      },
      status: 'pending',
      paymentStatus: 'unpaid',
      uiServiceId: selectedService.id,
      locationChoice: locId,
      timeSlot: selectedTimeId,
      addons: selectedAddons,
      vehicleType:
        (selectedVehicle?.id ??
          ((selectedStoredVehicle?.type?.toLowerCase?.() as VehicleType['id']) || 'medium')) as VehicleType['id'],
      vehicleInfo: selectedStoredVehicle
        ? `${selectedStoredVehicle.make} ${selectedStoredVehicle.model} (${selectedStoredVehicle.registration})`
        : selectedVehicle
        ? selectedVehicle.name
        : 'Medium',
      priceSource: 'pricing_engine_v1',
    };

    dbg('BookingService.createBooking payload ->\n', safeJson(payload));

    try {
      const booking = await BookingService.createBooking(payload as any);
      dbg('BookingService.createBooking result ->', booking);

      const bookingId = (booking && (booking.id || (booking as any).bookingId)) ?? 'UNKNOWN_ID';
      console.log('✅ Booking created:', bookingId);

      Alert.alert(
        'Booking Created! 🎉',
        `Your ${selectedService.name} is booked.\n\nPrice: £${finalPrice}\nLocation: ${address}\n\nWe’re finding you a valeter...`,
        [{
          text: 'Continue',
          onPress: () => {
            dbg('Navigating to valeter-search with bookingId:', bookingId);
            router.push({ pathname: 'valeter/valeter-search', params: { bookingId } });
          }
        }]
      );
    } catch (e: any) {
      console.error(`${DEBUG_TAG} Booking error:`, e?.message ?? e);
      dbg('Booking error (full):', e);
      Alert.alert('Booking Error', 'Failed to create booking. Please try again.');
    } finally {
      setIsProcessing(false);
      dbg('handleConfirmBooking:end');
    }
  };

  // ---- UI sections ----
  const renderStepIndicator = () => (
    <View style={styles.stepIndicator}>
      {[
        { n: 1, label: 'Vehicle' },
        { n: 2, label: 'Service' },
        { n: 3, label: 'Location' },
        { n: 4, label: 'Confirm' },
      ].map((s, i) => (
        <View key={s.n} style={styles.stepContainer}>
          <View style={[styles.stepCircle, currentStep >= (s.n as 1|2|3|4) ? styles.stepActive : styles.stepInactive]}>
            <Text style={[styles.stepNumber, currentStep >= (s.n as 1|2|3|4) ? styles.stepNumberActive : styles.stepNumberInactive]}>
              {s.n}
            </Text>
          </View>
          <Text style={styles.stepLabel}>{s.label}</Text>
          {i < 3 && (
            <View style={[styles.stepLine, currentStep > (s.n as 1|2|3|4) ? styles.stepLineActive : styles.stepLineInactive]} />
          )}
        </View>
      ))}
    </View>
  );

  const renderVehicleSelection = () => (
    <View style={styles.stepContent}>
      <Text style={styles.stepTitle}>Vehicle Type</Text>
      <Text style={styles.stepSubtitle}>What type of vehicle do you have?</Text>

      {/* Stored vehicles from DB */}
      <View style={{ minHeight: 20 }}>
        {vehiclesLoading && (
          <View style={{ paddingVertical: 8, alignItems: 'center' }}>
            <ActivityIndicator />
            <Text style={{ color: '#B0E0E6', marginTop: 6 }}>Loading your vehicles…</Text>
          </View>
        )}
      </View>

      {userVehicles.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>Your Vehicles</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.rowScroll}
            contentContainerStyle={{ paddingHorizontal: 10 }}
          >
            {userVehicles.map((v) => {
              const selected = selectedStoredVehicle?.id === v.id;
              return (
                <TouchableOpacity
                  key={v.id}
                  style={[styles.cardSmall, selected && styles.cardSelected]}
                  onPress={() => {
                    dbg('Select stored vehicle:', v);
                    setSelectedStoredVehicle(v);
                    setSelectedVehicle(null);
                  }}
                  activeOpacity={0.9}
                >
                  <LinearGradient colors={selected ? ['#10B981', '#059669'] : ['#1E3A8A', '#87CEEB']} style={styles.cardGrad}>
                    <Text style={styles.vehicleEmoji}>🚗</Text>
                    <Text style={styles.cardTitleSm}>{v.make} {v.model}</Text>
                    <Text style={styles.cardSubSm}>{v.registration}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              );
            })}
          </ScrollView>

          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>OR</Text>
            <View style={styles.dividerLine} />
          </View>
        </>
      )}

      {(!vehiclesLoading && userVehicles.length === 0) && (
        <View style={{ alignItems: 'center', marginBottom: 16 }}>
          <Text style={{ color: '#B0E0E6', marginBottom: 10 }}>No vehicles saved yet.</Text>
          <TouchableOpacity
            onPress={() => router.push('/vehicles/add')}
            style={{ borderRadius: 12, overflow: 'hidden' }}
            activeOpacity={0.9}
          >
            <LinearGradient colors={['#3B82F6', '#1D4ED8']} style={{ paddingHorizontal: 16, paddingVertical: 10 }}>
              <Text style={{ color: '#fff', fontWeight: 'bold' }}>Add a Vehicle</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}

      {/* Vehicle types */}
      <Text style={styles.sectionTitle}>Select Vehicle Type</Text>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.rowScroll}
        contentContainerStyle={{ paddingHorizontal: 10 }}
      >
        {vehicleTypes.map((vehicle) => {
          const selected = selectedVehicle?.id === vehicle.id;
          return (
            <TouchableOpacity
              key={vehicle.id}
              style={[styles.cardMedium, selected && styles.cardSelected]}
              onPress={() => {
                dbg('Select vehicle type:', vehicle);
                setSelectedVehicle(vehicle);
                setSelectedStoredVehicle(null);
              }}
              activeOpacity={0.9}
            >
              <LinearGradient colors={selected ? vehicle.colors : ['#1E3A8A', '#87CEEB']} style={styles.cardGrad}>
                <Text style={styles.vehicleEmoji}>{vehicle.icon}</Text>
                <Text style={styles.cardTitle}>{vehicle.name}</Text>
                <Text style={styles.cardSub}>{vehicle.description}</Text>
              </LinearGradient>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );

  const renderServiceSelection = () => (
    <View style={styles.stepContent}>
      <Text style={styles.stepTitle}>Choose Your Service</Text>
      <Text style={styles.stepSubtitle}>Select the perfect wash for your vehicle</Text>
      <View style={{ gap: 16 }}>
        {serviceOptions.map((service) => {
          const selected = selectedService?.id === service.id;
          return (
            <TouchableOpacity
              key={service.id}
              style={[styles.cardLarge, selected && styles.cardSelected]}
              onPress={() => {
                dbg('Select service:', service);
                setSelectedService(service);
              }}
              activeOpacity={0.9}
            >
              <LinearGradient colors={selected ? service.colors : ['#1E3A8A', '#87CEEB']} style={styles.cardGradBig}>
                <View style={styles.serviceHeader}>
                  <Text style={styles.serviceName}>{service.name}</Text>
                </View>
                <Text style={styles.serviceDescription}>{service.description}</Text>
                {service.details ? <Text style={styles.serviceDetails}>{service.details}</Text> : null}
                <View style={styles.serviceFooter}>
                  <Text style={styles.serviceDuration}>⏱️ {service.duration}</Text>
                  <View style={{ gap: 2 }}>
                    {service.features.slice(0, 2).map((f, i) => (
                      <Text key={i} style={styles.serviceFeature}>• {f}</Text>
                    ))}
                  </View>
                </View>
              </LinearGradient>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );

  const renderLocationSelection = () => (
    <View style={styles.stepContent}>
      <Text style={styles.stepTitle}>Service Location</Text>
      <Text style={styles.stepSubtitle}>Where should we come to you?</Text>
      <Text style={styles.pricingNote}>💡 Prices vary by location based on demand & accessibility</Text>

      <View style={{ gap: 16 }}>
        {locations.map((location) => {
          const selected = selectedLocation?.id === location.id;
          return (
            <TouchableOpacity
              key={location.id}
              style={[styles.cardLarge, selected && styles.cardSelected]}
              onPress={() => handleSelectLocation(location)}
              activeOpacity={0.9}
            >
              <LinearGradient colors={selected ? location.colors : ['#1E3A8A', '#87CEEB']} style={styles.cardGradBigCenter}>
                <Text style={styles.locationIcon}>{location.icon}</Text>
                <Text style={styles.locationName}>{location.name}</Text>
                {location.id === 'current' && (
                  <View style={styles.instantBadge}>
                    <Text style={styles.instantBadgeText}>⚡ INSTANT</Text>
                  </View>
                )}
                {location.description ? <Text style={styles.locationDescription}>{location.description}</Text> : null}
                {location.id === 'current' && (
                  <View style={{ marginTop: 8, alignItems: 'center' }}>
                    {gpsLoading ? <ActivityIndicator /> : null}
                    {gpsError ? <Text style={styles.gpsError}>{gpsError}</Text> : null}
                    {gps && !gpsError ? (
                      <>
                        <Text style={styles.gpsOkay}>Using your current GPS</Text>
                        {gpsAddress ? <Text style={styles.gpsAddress}>📍 {gpsAddress}</Text> : null}
                      </>
                    ) : null}
                  </View>
                )}
                <Text style={styles.locationPricing}>
                  {location.id === 'current' && '5% discount for convenience'}
                  {location.id === 'home' && 'Standard pricing'}
                  {location.id === 'work' && '+10% business premium'}
                  {location.id === 'gym' && '+5% leisure premium'}
                  {location.id === 'shopping' && '+15% high-traffic premium'}
                  {location.id === 'airport' && '+25% premium location'}
                  {location.id === 'hotel' && '+15% hospitality premium'}
                </Text>
              </LinearGradient>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );

  const renderConfirmStep = () => {
    const legacyType = selectedService ? mapServiceToLegacy(selectedService, selectedTimeId) : 'wash';
    const finalPrice = computeLegacyPrice(legacyType);
    dbg('Confirm step summary ->', {
      legacyType,
      finalPrice,
      selections: {
        service: selectedService?.id,
        vehicle: selectedVehicle?.id ?? selectedStoredVehicle?.type ?? 'n/a',
        location: selectedLocation?.id,
        time: selectedTimeId,
      }
    });
    return (
      <View style={styles.stepContent}>
        <Text style={styles.stepTitle}>Confirm Booking</Text>
        <Text style={styles.stepSubtitle}>Review details before we find your valeter</Text>

        {/* time slot quick picker */}
        <Text style={styles.sectionTitle}>Preferred Time</Text>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.rowScroll}
          contentContainerStyle={{ paddingHorizontal: 10 }}
        >
          {timeSlots.map((t) => {
            const selected = selectedTimeId === t.id;
            return (
              <TouchableOpacity
                key={t.id}
                style={[styles.cardSmall, selected && styles.cardSelected, { width: 160 }]}
                onPress={() => {
                  dbg('Select time slot:', t);
                  setSelectedTimeId(t.id);
                }}
                activeOpacity={0.9}
              >
                <LinearGradient colors={selected ? t.colors : ['#1E3A8A', '#87CEEB']} style={styles.cardGradCenter}>
                  <Text style={styles.timeIcon}>{t.icon}</Text>
                  <Text style={styles.cardTitleSm}>{t.name}</Text>
                </LinearGradient>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* summary */}
        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>Booking Summary</Text>
          <Row label="Service" value={selectedService?.name} />
          <Row
            label="Vehicle"
            value={
              selectedStoredVehicle
                ? `${selectedStoredVehicle.make} ${selectedStoredVehicle.model}`
                : selectedVehicle?.name
            }
          />
          <Row label="Location" value={selectedLocation?.id === 'current' ? (gpsAddress || 'Current Location') : selectedLocation?.name} />
          <Row label="Time" value={timeSlots.find(t => t.id === selectedTimeId)?.name} />
          <Row label="Estimated Price" value={`£${finalPrice}`} />
        </View>
      </View>
    );
  };

  const Row = ({ label, value }: { label: string; value?: string }) => (
    <View style={styles.summaryRow}>
      <Text style={styles.summaryLabel}>{label}:</Text>
      <Text style={styles.summaryValue}>{value ?? '—'}</Text>
    </View>
  );

  // footer nav bar for all steps
  const renderFooterNav = () => {
    const canNext =
      (currentStep === 1 && step1Ready) ||
      (currentStep === 2 && step2Ready) ||
      (currentStep === 3 && step3Ready) ||
      currentStep === 4;

    return (
      <View style={[styles.footer, { paddingBottom: Math.max(insets.bottom, 8) }]}>
        <TouchableOpacity style={[styles.navBtn, styles.navBtnGhost]} onPress={handleBack} activeOpacity={0.8}>
          <Text style={styles.navBtnGhostText}>Back</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.navBtn, !canNext && styles.navBtnDisabled]}
          onPress={handleNext}
          activeOpacity={canNext ? 0.9 : 1}
          disabled={!canNext || isProcessing}
        >
          <LinearGradient
            colors={canNext ? ['#10B981', '#059669'] : ['#6B7280', '#4B5563']}
            style={styles.navBtnGrad}
          >
            <Text style={styles.navBtnText}>
              {currentStep < 4 ? 'Next' : isProcessing ? 'Creating…' : 'Confirm Booking'}
            </Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>
    );
  };

  // ---- render ----
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      {loadingActive ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 }}>
          <ActivityIndicator color="#10B981" />
          <Text style={{ color: '#fff', marginTop: 12 }}>Checking your bookings...</Text>
        </View>
      ) : activeBooking ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 }}>
          <Text style={{ color: '#fff', fontSize: 20, fontWeight: 'bold', marginBottom: 8 }}>
            You already have a booking in progress
          </Text>
          <Text style={{ color: '#87CEEB', textAlign: 'center', marginBottom: 24 }}>
            Finish or cancel your current wash before booking another.
          </Text>

          <TouchableOpacity
            onPress={() => router.push({ pathname: '/current-trip', params: { bookingId: activeBooking.id } })}
            style={{ borderRadius: 12, overflow: 'hidden', width: '80%', marginBottom: 12 }}
            activeOpacity={0.9}
          >
            <LinearGradient colors={['#10B981', '#059669']} style={{ padding: 16, alignItems: 'center' }}>
              <Text style={{ color: '#fff', fontSize: 16, fontWeight: 'bold' }}>Go to Current Booking</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => router.replace('/')}
            style={{ borderRadius: 12, overflow: 'hidden', width: '80%' }}
            activeOpacity={0.9}
          >
            <LinearGradient colors={['#334155', '#1f2937']} style={{ padding: 14, alignItems: 'center' }}>
              <Text style={{ color: '#E5E7EB', fontSize: 14, fontWeight: '600' }}>Back to Home</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          {/* header */}
          <View style={styles.header}>
            <TouchableOpacity style={styles.backButton} onPress={handleBack} activeOpacity={0.8}>
              <Text style={styles.backIcon}>←</Text>
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Wish your wash? 🚿</Text>
            <View style={styles.headerSpacer} />
          </View>

          {renderStepIndicator()}

          <ScrollView
            style={styles.content}
            contentContainerStyle={{ paddingBottom: 140 }}
            showsVerticalScrollIndicator={false}
          >
            {currentStep === 1 && renderVehicleSelection()}
            {currentStep === 2 && renderServiceSelection()}
            {currentStep === 3 && renderLocationSelection()}
            {currentStep === 4 && renderConfirmStep()}
          </ScrollView>

          {renderFooterNav()}
        </>
      )}
    </SafeAreaView>
  );
}

// ---------------- styles ----------------
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: isSmallScreen ? 16 : 20, paddingVertical: 16,
    borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  backButton: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center', alignItems: 'center',
  },
  backIcon: { color: '#F9FAFB', fontSize: 20, fontWeight: 'bold' },
  headerTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: 'bold' },
  headerSpacer: { width: 40 },

  stepIndicator: { flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center', paddingVertical: 16, paddingHorizontal: 20 },
  stepContainer: { alignItems: 'center' },
  stepCircle: { width: 32, height: 32, borderRadius: 16, justifyContent: 'center', alignItems: 'center' },
  stepActive: { backgroundColor: '#10B981' },
  stepInactive: { backgroundColor: 'rgba(255,255,255,0.2)' },
  stepNumber: { fontSize: 14, fontWeight: 'bold' },
  stepNumberActive: { color: '#FFFFFF' },
  stepNumberInactive: { color: '#9CA3AF' },
  stepLine: { width: 40, height: 2, marginHorizontal: 8 },
  stepLineActive: { backgroundColor: '#10B981' },
  stepLineInactive: { backgroundColor: 'rgba(255,255,255,0.2)' },
  stepLabel: { color: '#B0E0E6', fontSize: 12, marginTop: 8 },

  content: { flex: 1 },
  stepContent: { width, paddingHorizontal: isSmallScreen ? 16 : 20, paddingBottom: 24 },

  rowScroll: { marginBottom: 24 },

  cardSmall: {
    width: 140, borderRadius: 16, overflow: 'hidden',
    elevation: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4,
    marginRight: 12,
  },
  cardMedium: {
    width: 160, borderRadius: 16, overflow: 'hidden',
    elevation: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4,
    marginRight: 12,
  },
  cardLarge: {
    borderRadius: 16, overflow: 'hidden',
    elevation: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8,
  },
  cardSelected: { borderWidth: 2, borderColor: '#10B981' },
  cardGrad: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 12 },
  cardGradCenter: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 16 },
  cardGradBig: { padding: 16 },
  cardGradBigCenter: { padding: 16, alignItems: 'center' },

  vehicleEmoji: { fontSize: 28, marginBottom: 8 },
  cardTitle: { color: '#fff', fontSize: 16, fontWeight: 'bold', textAlign: 'center', marginBottom: 6 },
  cardSub: { color: '#E5E7EB', fontSize: 12, textAlign: 'center' },
  cardTitleSm: { color: '#fff', fontSize: 14, fontWeight: 'bold', textAlign: 'center' },
  cardSubSm: { color: '#E5E7EB', fontSize: 10 },

  serviceHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  serviceName: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  serviceDescription: { color: '#fff', fontSize: 12, opacity: 0.9, textAlign: 'center', marginBottom: 8 },
  serviceDetails: { color: '#E5E7EB', fontSize: 12, textAlign: 'center', marginBottom: 8 },
  serviceFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
  serviceDuration: { color: '#fff', fontSize: 12, opacity: 0.9 },
  serviceFeature: { color: '#fff', fontSize: 10, opacity: 0.9 },

  locationIcon: { fontSize: 28, marginBottom: 8 },
  locationName: { color: '#fff', fontSize: 16, fontWeight: 'bold', marginBottom: 4, textAlign: 'center' },
  locationDescription: { color: '#E5E7EB', fontSize: 12, textAlign: 'center', marginBottom: 6 },
  locationPricing: { color: '#93C5FD', fontSize: 12, marginTop: 6, textAlign: 'center' },

  instantBadge: { backgroundColor: '#10B981', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3, marginTop: 6 },
  instantBadgeText: { color: '#FFFFFF', fontSize: 10, fontWeight: 'bold' },

  gpsError: { color: '#FCA5A5', marginTop: 6, fontSize: 12, textAlign: 'center' },
  gpsOkay: { color: '#10B981', marginTop: 6, fontSize: 12, textAlign: 'center' },
  gpsAddress: { color: '#E5E7EB', marginTop: 4, fontSize: 12, textAlign: 'center' },

  stepTitle: { color: '#F9FAFB', fontSize: isSmallScreen ? 24 : 28, fontWeight: 'bold', marginBottom: 8, textAlign: 'center' },
  stepSubtitle: { color: '#87CEEB', fontSize: isSmallScreen ? 16 : 18, textAlign: 'center', marginBottom: 32 },
  sectionTitle: { color: '#F9FAFB', fontSize: isSmallScreen ? 18 : 20, fontWeight: 'bold', marginBottom: 16, textAlign: 'left' },
  pricingNote: { color: '#87CEEB', fontSize: isSmallScreen ? 12 : 14, textAlign: 'center', marginTop: 16, marginBottom: 24 },

  summaryCard: {
    backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 16, padding: 20, marginBottom: 24,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
  },
  summaryTitle: { color: '#fff', fontSize: 18, fontWeight: 'bold', marginBottom: 16, textAlign: 'center' },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  summaryLabel: { color: '#E5E7EB', fontSize: 14 },
  summaryValue: { color: '#fff', fontSize: 14, fontWeight: 'bold' },

  footer: {
    position: 'absolute', left: 0, right: 0, bottom: 0,
    flexDirection: 'row', gap: 12,
    paddingTop: 12, paddingHorizontal: 16,
    borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.1)',
    backgroundColor: 'rgba(10,25,41,0.98)',
  },
  navBtn: { flex: 1, borderRadius: 12, overflow: 'hidden' },
  navBtnGrad: { paddingVertical: 14, alignItems: 'center' },
  navBtnText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  navBtnDisabled: { opacity: 0.6 },
  navBtnGhost: {
    backgroundColor: 'transparent', borderWidth: 1, borderColor: 'rgba(255,255,255,0.25)',
    justifyContent: 'center', alignItems: 'center', paddingVertical: 14,
  },
  navBtnGhostText: { color: '#E5E7EB', fontSize: 16, fontWeight: '600' },

  divider: { flexDirection: 'row', alignItems: 'center', marginVertical: 24, marginHorizontal: 10 },
  dividerLine: { flex: 1, height: 1, backgroundColor: 'rgba(255,255,255,0.2)' },
  dividerText: { color: '#87CEEB', fontSize: isSmallScreen ? 14 : 16, marginHorizontal: 10 },
});