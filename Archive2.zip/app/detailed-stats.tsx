import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { rewardSystem } from '../src/services/RewardSystem';

const { width } = Dimensions.get('window');

export default function DetailedStats() {
  const router = useRouter();
  const { user } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState<'week' | 'month' | 'year'>('week');

  const userRewards = rewardSystem.getUserRewards(user?.id || '', user?.userType || 'customer');

  const periods = [
    { id: 'week', label: 'This Week' },
    { id: 'month', label: 'This Month' },
    { id: 'year', label: 'This Year' },
  ];

  // Mock detailed stats data
  const detailedStats = {
    week: {
      earnings: user?.userType === 'valeter' ? 245 : 85,
      jobs: user?.userType === 'valeter' ? 12 : 3,
      rating: 4.8,
      hours: user?.userType === 'valeter' ? 28 : 0,
      points: 125,
      topServices: [
        { name: 'Full Valet', count: 8, revenue: 200 },
        { name: 'Standard Wash', count: 4, revenue: 60 },
      ],
      peakHours: [
        { hour: '9-11 AM', jobs: 4 },
        { hour: '2-4 PM', jobs: 5 },
        { hour: '6-8 PM', jobs: 3 },
      ],
      locations: [
        { name: 'Central London', jobs: 6, revenue: 150 },
        { name: 'West London', jobs: 4, revenue: 120 },
        { name: 'Canary Wharf', jobs: 2, revenue: 50 },
      ],
    },
    month: {
      earnings: user?.userType === 'valeter' ? 980 : 320,
      jobs: user?.userType === 'valeter' ? 45 : 12,
      rating: 4.7,
      hours: user?.userType === 'valeter' ? 120 : 0,
      points: 450,
      topServices: [
        { name: 'Full Valet', count: 28, revenue: 700 },
        { name: 'Standard Wash', count: 12, revenue: 180 },
        { name: 'Priority Wash', count: 5, revenue: 175 },
      ],
      peakHours: [
        { hour: '9-11 AM', jobs: 15 },
        { hour: '2-4 PM', jobs: 18 },
        { hour: '6-8 PM', jobs: 12 },
      ],
      locations: [
        { name: 'Central London', jobs: 20, revenue: 500 },
        { name: 'West London', jobs: 15, revenue: 375 },
        { name: 'Canary Wharf', jobs: 10, revenue: 250 },
      ],
    },
    year: {
      earnings: user?.userType === 'valeter' ? 11800 : 3850,
      jobs: user?.userType === 'valeter' ? 540 : 145,
      rating: 4.6,
      hours: user?.userType === 'valeter' ? 1440 : 0,
      points: 5400,
      topServices: [
        { name: 'Full Valet', count: 320, revenue: 8000 },
        { name: 'Standard Wash', count: 150, revenue: 2250 },
        { name: 'Priority Wash', count: 70, revenue: 2450 },
      ],
      peakHours: [
        { hour: '9-11 AM', jobs: 180 },
        { hour: '2-4 PM', jobs: 220 },
        { hour: '6-8 PM', jobs: 140 },
      ],
      locations: [
        { name: 'Central London', jobs: 240, revenue: 6000 },
        { name: 'West London', jobs: 180, revenue: 4500 },
        { name: 'Canary Wharf', jobs: 120, revenue: 3000 },
      ],
    },
  };

  const currentStats = detailedStats[selectedPeriod];

  const StatCard = ({ title, value, subtitle, icon, color }: any) => (
    <View style={[styles.statCard, { borderLeftColor: color }]}>
      <View style={styles.statHeader}>
        <Text style={styles.statIcon}>{icon}</Text>
        <Text style={styles.statTitle}>{title}</Text>
      </View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statSubtitle}>{subtitle}</Text>
    </View>
  );

  const ProgressBar = ({ value, max, color }: any) => (
    <View style={styles.progressContainer}>
      <View style={[styles.progressBar, { backgroundColor: 'rgba(255, 255, 255, 0.1)' }]}>
        <View 
          style={[
            styles.progressFill, 
            { 
              width: `${(value / max) * 100}%`,
              backgroundColor: color 
            }
          ]} 
        />
      </View>
      <Text style={styles.progressText}>{value}/{max}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Detailed Analytics</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Period Selector */}
        <View style={styles.periodSelector}>
          {periods.map((period) => (
            <TouchableOpacity
              key={period.id}
              style={[
                styles.periodButton,
                selectedPeriod === period.id && styles.selectedPeriodButton
              ]}
              onPress={() => setSelectedPeriod(period.id as any)}
            >
              <Text style={[
                styles.periodText,
                selectedPeriod === period.id && styles.selectedPeriodText
              ]}>
                {period.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Main Stats Grid */}
        <View style={styles.statsGrid}>
          <StatCard
            title={user?.userType === 'valeter' ? 'Total Earnings' : 'Total Spent'}
            value={`£${currentStats.earnings}`}
            subtitle={`${selectedPeriod} total`}
            icon="💰"
            color="#4CAF50"
          />
          <StatCard
            title={user?.userType === 'valeter' ? 'Jobs Completed' : 'Services Booked'}
            value={currentStats.jobs}
            subtitle="services"
            icon="✅"
            color="#2196F3"
          />
          <StatCard
            title="Average Rating"
            value={currentStats.rating}
            subtitle="out of 5 stars"
            icon="⭐"
            color="#FF9800"
          />
          {user?.userType === 'valeter' && (
            <StatCard
              title="Hours Worked"
              value={`${currentStats.hours}h`}
              subtitle="total hours"
              icon="⏰"
              color="#9C27B0"
            />
          )}
        </View>

        {/* Rewards Progress */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Rewards Progress</Text>
          <View style={styles.rewardsCard}>
            <View style={styles.rewardsHeader}>
              <Text style={styles.rewardsLevel}>{userRewards.level} Level</Text>
              <Text style={styles.rewardsPoints}>{userRewards.points} Points</Text>
            </View>
            <ProgressBar 
              value={userRewards.points} 
              max={userRewards.points + userRewards.pointsToNextLevel}
              color="#87CEEB"
            />
            <Text style={styles.rewardsNext}>
              {userRewards.pointsToNextLevel} points to {userRewards.nextLevel}
            </Text>
          </View>
        </View>

        {/* Top Services */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Top Services</Text>
          <View style={styles.servicesCard}>
            {currentStats.topServices.map((service, index) => (
              <View key={service.name} style={styles.serviceRow}>
                <View style={styles.serviceInfo}>
                  <Text style={styles.serviceName}>{service.name}</Text>
                  <Text style={styles.serviceCount}>{service.count} services</Text>
                </View>
                <Text style={styles.serviceRevenue}>£{service.revenue}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Peak Hours */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Peak Hours</Text>
          <View style={styles.peakHoursCard}>
            {currentStats.peakHours.map((peak, index) => (
              <View key={peak.hour} style={styles.peakRow}>
                <Text style={styles.peakHour}>{peak.hour}</Text>
                <View style={styles.peakBarContainer}>
                  <View 
                    style={[
                      styles.peakBar, 
                      { 
                        width: `${(peak.jobs / Math.max(...currentStats.peakHours.map(p => p.jobs))) * 100}%`,
                        backgroundColor: index === 0 ? '#4CAF50' : index === 1 ? '#2196F3' : '#FF9800'
                      }
                    ]} 
                  />
                </View>
                <Text style={styles.peakJobs}>{peak.jobs} jobs</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Top Locations */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Top Locations</Text>
          <View style={styles.locationsCard}>
            {currentStats.locations.map((location, index) => (
              <View key={location.name} style={styles.locationRow}>
                <View style={styles.locationInfo}>
                  <Text style={styles.locationName}>{location.name}</Text>
                  <Text style={styles.locationJobs}>{location.jobs} jobs</Text>
                </View>
                <Text style={styles.locationRevenue}>£{location.revenue}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Recent Activity */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Activity</Text>
          <View style={styles.activityCard}>
            {userRewards.recentEarnings.slice(0, 5).map((earning) => (
              <View key={earning.id} style={styles.activityRow}>
                <Text style={styles.activityIcon}>🎁</Text>
                <View style={styles.activityInfo}>
                  <Text style={styles.activityReason}>{earning.reason}</Text>
                  <Text style={styles.activityDate}>{earning.date}</Text>
                </View>
                <Text style={styles.activityPoints}>+{earning.amount} pts</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Export Options */}
        <View style={styles.section}>
          <TouchableOpacity style={styles.exportButton}>
            <Text style={styles.exportButtonText}>📊 Export Report</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 60,
  },
  periodSelector: {
    flexDirection: 'row',
    padding: 20,
    gap: 12,
  },
  periodButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    alignItems: 'center',
  },
  selectedPeriodButton: {
    backgroundColor: '#87CEEB',
  },
  periodText: {
    color: '#E5E7EB',
    fontSize: 14,
    fontWeight: '600',
  },
  selectedPeriodText: {
    color: '#0A1929',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 20,
    gap: 12,
  },
  statCard: {
    width: (width - 52) / 2,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    borderLeftWidth: 4,
  },
  statHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  statIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  statTitle: {
    color: '#E5E7EB',
    fontSize: 12,
    fontWeight: '600',
  },
  statValue: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  rewardsCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  rewardsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  rewardsLevel: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  rewardsPoints: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  progressBar: {
    flex: 1,
    height: 8,
    borderRadius: 4,
    marginRight: 12,
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  rewardsNext: {
    color: '#E5E7EB',
    fontSize: 12,
  },
  servicesCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  serviceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
  serviceCount: {
    color: '#87CEEB',
    fontSize: 12,
  },
  serviceRevenue: {
    color: '#4CAF50',
    fontSize: 16,
    fontWeight: 'bold',
  },
  peakHoursCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  peakRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  peakHour: {
    color: '#F9FAFB',
    fontSize: 14,
    width: 80,
  },
  peakBarContainer: {
    flex: 1,
    height: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 10,
    marginHorizontal: 12,
    overflow: 'hidden',
  },
  peakBar: {
    height: '100%',
    borderRadius: 10,
  },
  peakJobs: {
    color: '#87CEEB',
    fontSize: 12,
    width: 60,
    textAlign: 'right',
  },
  locationsCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  locationRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  locationInfo: {
    flex: 1,
  },
  locationName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
  locationJobs: {
    color: '#87CEEB',
    fontSize: 12,
  },
  locationRevenue: {
    color: '#4CAF50',
    fontSize: 16,
    fontWeight: 'bold',
  },
  activityCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  activityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  activityIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  activityInfo: {
    flex: 1,
  },
  activityReason: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  activityDate: {
    color: '#87CEEB',
    fontSize: 12,
  },
  activityPoints: {
    color: '#4CAF50',
    fontSize: 14,
    fontWeight: 'bold',
  },
  exportButton: {
    backgroundColor: '#87CEEB',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: 'center',
  },
  exportButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
