import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Dimensions,
  Image,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import * as ImagePicker from 'expo-image-picker';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;
const isLargeScreen = width >= 414;

export default function ReportIssue() {
  const { user } = useAuth();
  const [issueType, setIssueType] = useState('');
  const [issueDescription, setIssueDescription] = useState('');
  const [bookingId, setBookingId] = useState('');
  const [contactEmail, setContactEmail] = useState(user?.email || '');
  const [contactPhone, setContactPhone] = useState(user?.phone || '');
  const [attachments, setAttachments] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedPriority, setSelectedPriority] = useState('medium');

  const issueTypes = [
    {
      id: 'service-quality',
      title: 'Service Quality',
      description: 'Poor wash quality, damage, or unsatisfactory service',
      icon: '🚿',
      priority: 'high'
    },
    {
      id: 'valeter-behavior',
      title: 'Valeter Behavior',
      description: 'Rude, unprofessional, or inappropriate behavior',
      icon: '👤',
      priority: 'high'
    },
    {
      id: 'app-technical',
      title: 'App Technical Issue',
      description: 'App crashes, bugs, or technical problems',
      icon: '📱',
      priority: 'medium'
    },
    {
      id: 'payment-issue',
      title: 'Payment Problem',
      description: 'Billing errors, double charges, or refund issues',
      icon: '💳',
      priority: 'high'
    },
    {
      id: 'booking-problem',
      title: 'Booking Problem',
      description: 'Can\'t book, cancellation issues, or scheduling problems',
      icon: '📅',
      priority: 'medium'
    },
    {
      id: 'tracking-issue',
      title: 'Tracking Issue',
      description: 'GPS not working, wrong location, or tracking problems',
      icon: '📍',
      priority: 'medium'
    },
    {
      id: 'safety-concern',
      title: 'Safety Concern',
      description: 'Safety issues, accidents, or security concerns',
      icon: '⚠️',
      priority: 'critical'
    },
    {
      id: 'other',
      title: 'Other',
      description: 'Any other issue not listed above',
      icon: '❓',
      priority: 'low'
    }
  ];

  const priorityLevels = [
    { id: 'low', title: 'Low', description: 'Minor inconvenience', color: '#10B981' },
    { id: 'medium', title: 'Medium', description: 'Affects service quality', color: '#F59E0B' },
    { id: 'high', title: 'High', description: 'Significant problem', color: '#EF4444' },
    { id: 'critical', title: 'Critical', description: 'Urgent safety or security issue', color: '#DC2626' }
  ];

  const handleIssueTypeSelect = async (type: string) => {
    try {
      await hapticFeedback('light');
      setIssueType(type);
    } catch (error) {
      console.error('Error in handleIssueTypeSelect:', error);
    }
  };

  const handlePrioritySelect = async (priority: string) => {
    try {
      await hapticFeedback('light');
      setSelectedPriority(priority);
    } catch (error) {
      console.error('Error in handlePrioritySelect:', error);
    }
  };

  const handleAddPhoto = async () => {
    try {
      await hapticFeedback('light');
      
      Alert.alert(
        'Add Photo',
        'Choose how to add a photo:',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: '📷 Take Photo', 
            onPress: () => takePhoto() 
          },
          { 
            text: '🖼️ Choose from Gallery', 
            onPress: () => pickImage() 
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleAddPhoto:', error);
    }
  };

  const takePhoto = async () => {
    try {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Camera permission is required to take a photo.');
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        setAttachments(prev => [...prev, result.assets[0].uri]);
        await hapticFeedback('success');
      }
    } catch (error) {
      console.error('Error taking photo:', error);
      Alert.alert('Error', 'Failed to take photo. Please try again.');
    }
  };

  const pickImage = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Gallery permission is required to select a photo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        setAttachments(prev => [...prev, result.assets[0].uri]);
        await hapticFeedback('success');
      }
    } catch (error) {
      console.error('Error picking image:', error);
      Alert.alert('Error', 'Failed to select image. Please try again.');
    }
  };

  const handleRemovePhoto = async (index: number) => {
    try {
      await hapticFeedback('light');
      setAttachments(prev => prev.filter((_, i) => i !== index));
    } catch (error) {
      console.error('Error in handleRemovePhoto:', error);
    }
  };

  const handleSubmit = async () => {
    try {
      if (!issueType) {
        Alert.alert('Missing Information', 'Please select an issue type.');
        return;
      }

      if (!issueDescription.trim()) {
        Alert.alert('Missing Information', 'Please describe the issue.');
        return;
      }

      if (!contactEmail.trim()) {
        Alert.alert('Missing Information', 'Please provide your email address.');
        return;
      }

      setIsSubmitting(true);
      await hapticFeedback('medium');

      // Simulate API call
      setTimeout(async () => {
        try {
          // Here you would normally send the data to your backend
          const issueData = {
            issueType,
            issueDescription,
            bookingId,
            contactEmail,
            contactPhone,
            attachments: attachments.length,
            priority: selectedPriority,
            userId: user?.id,
            timestamp: new Date().toISOString(),
            status: 'submitted'
          };

          console.log('Issue submitted:', issueData);

          await hapticFeedback('success');
          Alert.alert(
            'Issue Reported Successfully! 🎉',
            'Thank you for reporting this issue. We\'ll investigate and get back to you within 24 hours. You\'ll receive updates via email.',
            [
              {
                text: 'OK',
                onPress: () => {
                  router.back();
                }
              }
            ]
          );
        } catch (error) {
          console.error('Error submitting issue:', error);
          Alert.alert('Error', 'Failed to submit issue. Please try again.');
        } finally {
          setIsSubmitting(false);
        }
      }, 2000);

    } catch (error) {
      console.error('Error in handleSubmit:', error);
      setIsSubmitting(false);
    }
  };

  const selectedIssue = issueTypes.find(type => type.id === issueType);

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity 
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }} 
            style={styles.backButton}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Report an Issue</Text>
          <View style={styles.headerSpacer} />
        </View>

        {/* Issue Type Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>What type of issue are you experiencing?</Text>
          <View style={styles.issueTypesGrid}>
            {issueTypes.map((type) => (
              <TouchableOpacity
                key={type.id}
                style={[
                  styles.issueTypeCard,
                  issueType === type.id && styles.selectedIssueType
                ]}
                onPress={() => handleIssueTypeSelect(type.id)}
              >
                <Text style={styles.issueTypeIcon}>{type.icon}</Text>
                <Text style={styles.issueTypeTitle}>{type.title}</Text>
                <Text style={styles.issueTypeDescription}>{type.description}</Text>
                {issueType === type.id && (
                  <View style={styles.selectedIndicator}>
                    <Text style={styles.selectedIndicatorText}>✓</Text>
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Priority Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>How urgent is this issue?</Text>
          <View style={styles.priorityGrid}>
            {priorityLevels.map((priority) => (
              <TouchableOpacity
                key={priority.id}
                style={[
                  styles.priorityCard,
                  selectedPriority === priority.id && styles.selectedPriority
                ]}
                onPress={() => handlePrioritySelect(priority.id)}
              >
                <View style={[styles.priorityIndicator, { backgroundColor: priority.color }]} />
                <Text style={styles.priorityTitle}>{priority.title}</Text>
                <Text style={styles.priorityDescription}>{priority.description}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Issue Details */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Describe the issue in detail</Text>
          <TextInput
            style={styles.descriptionInput}
            value={issueDescription}
            onChangeText={setIssueDescription}
            placeholder="Please provide a detailed description of what happened, when it occurred, and any relevant details..."
            placeholderTextColor="#9CA3AF"
            multiline
            numberOfLines={6}
            textAlignVertical="top"
          />
        </View>

        {/* Booking ID */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Booking ID (if applicable)</Text>
          <TextInput
            style={styles.textInput}
            value={bookingId}
            onChangeText={setBookingId}
            placeholder="Enter your booking ID if this relates to a specific booking"
            placeholderTextColor="#9CA3AF"
          />
        </View>

        {/* Contact Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Contact Information</Text>
          <TextInput
            style={styles.textInput}
            value={contactEmail}
            onChangeText={setContactEmail}
            placeholder="Email address"
            placeholderTextColor="#9CA3AF"
            keyboardType="email-address"
            autoCapitalize="none"
          />
          <TextInput
            style={styles.textInput}
            value={contactPhone}
            onChangeText={setContactPhone}
            placeholder="Phone number (optional)"
            placeholderTextColor="#9CA3AF"
            keyboardType="phone-pad"
          />
        </View>

        {/* Photo Attachments */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Add Photos (Optional)</Text>
          <Text style={styles.sectionSubtitle}>
            Photos help us understand and resolve issues faster
          </Text>
          
          <TouchableOpacity style={styles.addPhotoButton} onPress={handleAddPhoto}>
            <Text style={styles.addPhotoIcon}>📷</Text>
            <Text style={styles.addPhotoText}>Add Photo</Text>
          </TouchableOpacity>

          {attachments.length > 0 && (
            <View style={styles.attachmentsContainer}>
              <Text style={styles.attachmentsTitle}>Attached Photos ({attachments.length})</Text>
              <View style={styles.attachmentsGrid}>
                {attachments.map((uri, index) => (
                  <View key={index} style={styles.attachmentItem}>
                    <Image source={{ uri }} style={styles.attachmentImage} />
                    <TouchableOpacity
                      style={styles.removeAttachmentButton}
                      onPress={() => handleRemovePhoto(index)}
                    >
                      <Text style={styles.removeAttachmentText}>×</Text>
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            </View>
          )}
        </View>

        {/* Submit Button */}
        <View style={styles.section}>
          <TouchableOpacity
            style={[styles.submitButton, isSubmitting && styles.submitButtonDisabled]}
            onPress={handleSubmit}
            disabled={isSubmitting}
          >
            <Text style={styles.submitButtonText}>
              {isSubmitting ? 'Submitting...' : 'Submit Issue Report'}
            </Text>
          </TouchableOpacity>
          
          <Text style={styles.submitNote}>
            We typically respond to issues within 24 hours. For urgent matters, please contact our emergency line.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: 'bold',
  },
  headerSpacer: {
    width: 60,
  },
  section: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.05)',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  sectionSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 16,
    lineHeight: 20,
  },
  issueTypesGrid: {
    gap: 12,
  },
  issueTypeCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
    position: 'relative',
  },
  selectedIssueType: {
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  issueTypeIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  issueTypeTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  issueTypeDescription: {
    color: '#87CEEB',
    fontSize: 14,
    lineHeight: 20,
  },
  selectedIndicator: {
    position: 'absolute',
    top: 12,
    right: 12,
    backgroundColor: '#87CEEB',
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedIndicatorText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
  priorityGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  priorityCard: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
    alignItems: 'center',
  },
  selectedPriority: {
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  priorityIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginBottom: 8,
  },
  priorityTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  priorityDescription: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
    lineHeight: 16,
  },
  descriptionInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    color: '#F9FAFB',
    fontSize: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    minHeight: 120,
  },
  textInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    color: '#F9FAFB',
    fontSize: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    marginBottom: 12,
  },
  addPhotoButton: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
    borderStyle: 'dashed',
    alignItems: 'center',
    marginBottom: 16,
  },
  addPhotoIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  addPhotoText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  attachmentsContainer: {
    marginTop: 16,
  },
  attachmentsTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  attachmentsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  attachmentItem: {
    position: 'relative',
    width: 80,
    height: 80,
  },
  attachmentImage: {
    width: '100%',
    height: '100%',
    borderRadius: 8,
  },
  removeAttachmentButton: {
    position: 'absolute',
    top: -8,
    right: -8,
    backgroundColor: '#EF4444',
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  removeAttachmentText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  submitButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 16,
  },
  submitButtonDisabled: {
    backgroundColor: '#6B7280',
    opacity: 0.7,
  },
  submitButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
  submitNote: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
    lineHeight: 16,
  },
});
