import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Alert,
  Dimensions,
  Image,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import * as ImagePicker from 'expo-image-picker';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;
const isLargeScreen = width >= 414;

export default function OwnerProfile() {
  const { user, logout, updateProfile } = useAuth();
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleEditProfile = async () => {
    try {
      await hapticFeedback('light');
      Alert.alert(
        'Edit Profile',
        'What would you like to edit?',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Personal Info', 
            onPress: () => router.push('/edit-profile') 
          },
          { 
            text: 'Change Password', 
            onPress: () => router.push('/change-password') 
          },
          { 
            text: 'Privacy Settings', 
            onPress: () => router.push('/privacy-settings') 
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleEditProfile:', error);
    }
  };

  const handleUploadProfilePicture = async () => {
    try {
      await hapticFeedback('light');
      
      Alert.alert(
        'Upload Profile Picture',
        'Choose how you want to add a profile picture',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Take Photo', 
            onPress: () => takePhoto() 
          },
          { 
            text: 'Choose from Gallery', 
            onPress: () => pickImage() 
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleUploadProfilePicture:', error);
    }
  };

  const takePhoto = async () => {
    try {
      setIsLoading(true);
      
      // Request camera permissions
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Camera permission is required to take a photo.');
        return;
      }

      // Launch camera
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        const imageUri = result.assets[0].uri;
        setProfilePicture(imageUri);
        
        // Update user profile with new picture
        if (user) {
          await updateProfile({ profilePicture: imageUri });
        }
        
        await hapticFeedback('success');
        Alert.alert('Success', 'Profile picture updated successfully!');
      }
    } catch (error) {
      console.error('Error taking photo:', error);
      Alert.alert('Error', 'Failed to take photo. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const pickImage = async () => {
    try {
      setIsLoading(true);
      
      // Request media library permissions
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Gallery permission is required to select a photo.');
        return;
      }

      // Launch image picker
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        const imageUri = result.assets[0].uri;
        setProfilePicture(imageUri);
        
        // Update user profile with new picture
        if (user) {
          await updateProfile({ profilePicture: imageUri });
        }
        
        await hapticFeedback('success');
        Alert.alert('Success', 'Profile picture updated successfully!');
      }
    } catch (error) {
      console.error('Error picking image:', error);
      Alert.alert('Error', 'Failed to select image. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await hapticFeedback('medium');
      Alert.alert(
        'Logout',
        'Are you sure you want to logout?',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Logout', 
            style: 'destructive', 
            onPress: async () => {
              try {
                await logout();
                await hapticFeedback('success');
                router.replace('/');
              } catch (error) {
                console.error('Logout error:', error);
                Alert.alert('Error', 'Failed to logout. Please try again.');
              }
            }
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleLogout:', error);
    }
  };

  const handleVehicleManagement = async () => {
    try {
      await hapticFeedback('light');
      router.push('/vehicle-management');
    } catch (error) {
      console.error('Error navigating to vehicle management:', error);
    }
  };

  const handleRewardsSystem = async () => {
    try {
      await hapticFeedback('light');
      router.push('/rewards-system');
    } catch (error) {
      console.error('Error navigating to rewards system:', error);
    }
  };

  const handleReferralSystem = async () => {
    try {
      await hapticFeedback('light');
      router.push('/referral-system');
    } catch (error) {
      console.error('Error navigating to referral system:', error);
    }
  };

  const handleHelpSupport = async () => {
    try {
      await hapticFeedback('light');
      router.push('/help-support');
    } catch (error) {
      console.error('Error navigating to help support:', error);
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'bronze': return ['#CD7F32', '#B8860B'];
      case 'silver': return ['#C0C0C0', '#A9A9A9'];
      case 'gold': return ['#FFD700', '#FFA500'];
      case 'platinum': return ['#E5E4E2', '#BCC6CC'];
      default: return ['#CD7F32', '#B8860B'];
    }
  };

  const getTierIcon = (tier: string) => {
    switch (tier) {
      case 'bronze': return '🥉';
      case 'silver': return '🥈';
      case 'gold': return '🥇';
      case 'platinum': return '💎';
      default: return '🥉';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity 
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }} 
            style={styles.backButton}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Profile</Text>
          <TouchableOpacity onPress={handleEditProfile} style={styles.editButton}>
            <Text style={styles.editButtonText}>Edit</Text>
          </TouchableOpacity>
        </View>

        {/* Profile Hero Section */}
        <View style={styles.heroSection}>
          <View style={styles.profilePictureContainer}>
            {profilePicture ? (
              <View style={styles.profilePicture}>
                <Image source={{ uri: profilePicture }} style={styles.profileImage} />
                {user?.isVerified && (
                  <View style={styles.verificationBadge}>
                    <Text style={styles.verificationIcon}>✓</Text>
                  </View>
                )}
              </View>
            ) : (
              <View style={styles.profilePicturePlaceholder}>
                <Text style={styles.profilePictureText}>👤</Text>
                {user?.isVerified && (
                  <View style={styles.verificationBadge}>
                    <Text style={styles.verificationIcon}>✓</Text>
                  </View>
                )}
              </View>
            )}
            <TouchableOpacity 
              style={[styles.uploadButton, isLoading && styles.uploadButtonDisabled]} 
              onPress={handleUploadProfilePicture}
              disabled={isLoading}
            >
              <Text style={styles.uploadButtonText}>
                {isLoading ? '⏳' : '📷'}
              </Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.profileInfo}>
            <View style={styles.nameRow}>
              <Text style={styles.userName}>{user?.name || 'User Name'}</Text>
              {user?.isVerified && (
                <View style={styles.verificationBadgeSmall}>
                  <Text style={styles.verificationIconSmall}>✓</Text>
                </View>
              )}
            </View>
            <Text style={styles.userEmail}>{user?.email || 'user@example.com'}</Text>
            <Text style={styles.userPhone}>{user?.phone || '+44 7700 900000'}</Text>
          </View>
        </View>

        {/* Tier & Stats Section */}
        <View style={styles.tierSection}>
          <LinearGradient
            colors={getTierColor(user?.tier || 'bronze')}
            style={styles.tierCard}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.tierContent}>
              <Text style={styles.tierIcon}>{getTierIcon(user?.tier || 'bronze')}</Text>
              <View style={styles.tierInfo}>
                <Text style={styles.tierText}>{user?.tier?.charAt(0).toUpperCase() + user?.tier?.slice(1) || 'Bronze'} Member</Text>
                <Text style={styles.tierPoints}>{user?.tierPoints || 0} points</Text>
              </View>
            </View>
          </LinearGradient>
        </View>

        {/* Verification Status */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Verification Status</Text>
          
          <View style={styles.verificationCard}>
            <View style={styles.verificationHeader}>
              <Text style={styles.verificationTitle}>
                {user?.isVerified ? '✓ Verified Customer' : 'Become Verified'}
              </Text>
              {user?.isVerified && (
                <View style={styles.verifiedBadge}>
                  <Text style={styles.verifiedText}>Verified</Text>
                </View>
              )}
            </View>
            
            <Text style={styles.verificationDescription}>
              {user?.isVerified 
                ? `You're a verified customer with ${user.totalWashes} washes completed!`
                : 'Upload a profile picture or car photo to become verified after 10 washes.'
              }
            </Text>
            
            {!user?.isVerified && (
              <TouchableOpacity style={styles.verificationButton} onPress={handleUploadProfilePicture}>
                <Text style={styles.verificationButtonText}>Upload Photo</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Account Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Settings</Text>
          
          <View style={styles.settingsContainer}>
            <TouchableOpacity style={styles.settingItem} onPress={handleEditProfile}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>👤</Text>
                <Text style={styles.settingText}>Edit Profile</Text>
              </View>
              <Text style={styles.settingArrow}>›</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.settingItem} onPress={handleVehicleManagement}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🚗</Text>
                <Text style={styles.settingText}>Vehicle Management</Text>
              </View>
              <Text style={styles.settingArrow}>›</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.settingItem} onPress={handleRewardsSystem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🎁</Text>
                <Text style={styles.settingText}>Rewards & Points</Text>
              </View>
              <Text style={styles.settingArrow}>›</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.settingItem} onPress={handleReferralSystem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>👥</Text>
                <Text style={styles.settingText}>Refer Friends</Text>
              </View>
              <Text style={styles.settingArrow}>›</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.settingItem} onPress={handleHelpSupport}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>❓</Text>
                <Text style={styles.settingText}>Help & Support</Text>
              </View>
              <Text style={styles.settingArrow}>›</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Account Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Actions</Text>
          
          <TouchableOpacity style={[styles.settingItem, styles.logoutItem]} onPress={handleLogout}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🚪</Text>
              <Text style={[styles.settingText, styles.logoutText]}>Logout</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View style={styles.appInfoSection}>
          <Text style={styles.appInfoText}>Wish a Wash v1.0.0</Text>
          <Text style={styles.appInfoText}>© 2024 Wish a Wash. All rights reserved.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

    const styles = StyleSheet.create({
      container: {
        flex: 1,
        backgroundColor: '#0A1929',
      },
      scrollView: {
        flex: 1,
      },
      header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: isSmallScreen ? 16 : 20,
        paddingVertical: 16,
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(255, 255, 255, 0.1)',
      },
      backButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
        justifyContent: 'center',
        alignItems: 'center',
      },
      backButtonText: {
        color: '#F9FAFB',
        fontSize: 20,
        fontWeight: 'bold',
      },
      headerTitle: {
        color: '#F9FAFB',
        fontSize: isSmallScreen ? 20 : 22,
        fontWeight: 'bold',
      },
      editButton: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        backgroundColor: 'rgba(135, 206, 235, 0.2)',
        borderRadius: 20,
        borderWidth: 1,
        borderColor: 'rgba(135, 206, 235, 0.3)',
      },
      editButtonText: {
        color: '#87CEEB',
        fontSize: 14,
        fontWeight: '600',
      },
      heroSection: {
        padding: isSmallScreen ? 20 : 24,
        alignItems: 'center',
        marginBottom: 0,
      },
      profilePictureContainer: {
        alignItems: 'center',
        marginBottom: 20,
        position: 'relative',
      },
      profilePicture: {
        width: 120,
        height: 120,
        borderRadius: 60,
        backgroundColor: 'rgba(135, 206, 235, 0.1)',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 16,
        borderWidth: 3,
        borderColor: 'rgba(135, 206, 235, 0.3)',
      },
      profilePicturePlaceholder: {
        width: 120,
        height: 120,
        borderRadius: 60,
        backgroundColor: 'rgba(135, 206, 235, 0.1)',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 16,
        borderWidth: 3,
        borderColor: 'rgba(135, 206, 235, 0.3)',
      },
      profilePictureText: {
        fontSize: 48,
      },
      profileImage: {
        width: '100%',
        height: '100%',
        borderRadius: 60,
      },
      uploadButton: {
        position: 'absolute',
        bottom: 12,
        right: 0,
        width: 36,
        height: 36,
        borderRadius: 18,
        backgroundColor: '#87CEEB',
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 2,
        borderColor: '#0A1929',
      },
      uploadButtonDisabled: {
        opacity: 0.7,
        backgroundColor: '#6B7280',
      },
      uploadButtonText: {
        color: '#0A1929',
        fontSize: 16,
        fontWeight: 'bold',
      },
      profileInfo: {
        alignItems: 'center',
      },
      userName: {
        color: '#F9FAFB',
        fontSize: isSmallScreen ? 24 : 28,
        fontWeight: 'bold',
        marginBottom: 4,
      },
      userEmail: {
        color: '#87CEEB',
        fontSize: isSmallScreen ? 14 : 16,
        marginBottom: 4,
      },
      userPhone: {
        color: '#87CEEB',
        fontSize: isSmallScreen ? 14 : 16,
      },
      tierSection: {
        paddingHorizontal: isSmallScreen ? 16 : 20,
        paddingVertical: 0,
        marginBottom: 20,
      },
      tierCard: {
        padding: 20,
        borderRadius: 16,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
        elevation: 8,
      },
      tierContent: {
        flexDirection: 'row',
        alignItems: 'center',
      },
      tierIcon: {
        fontSize: 48,
        marginRight: 16,
      },
      tierInfo: {
        flexDirection: 'column',
      },
      tierText: {
        color: '#F9FAFB',
        fontSize: isSmallScreen ? 18 : 20,
        fontWeight: 'bold',
        marginBottom: 4,
      },
      tierPoints: {
        color: '#F9FAFB',
        fontSize: isSmallScreen ? 14 : 16,
        opacity: 0.9,
      },
      section: {
        paddingHorizontal: isSmallScreen ? 16 : 20,
        paddingVertical: 20,
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(255, 255, 255, 0.05)',
      },
      sectionTitle: {
        color: '#F9FAFB',
        fontSize: isSmallScreen ? 18 : 20,
        fontWeight: 'bold',
        marginBottom: 16,
      },
      settingsContainer: {
        backgroundColor: 'rgba(255, 255, 255, 0.03)',
        borderRadius: 12,
        overflow: 'hidden',
      },
      settingItem: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
        paddingVertical: 16,
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(255, 255, 255, 0.05)',
      },
      settingLeft: {
        flexDirection: 'row',
        alignItems: 'center',
        flex: 1,
      },
      settingIcon: {
        fontSize: 20,
        marginRight: 12,
        width: 24,
        textAlign: 'center',
      },
      settingText: {
        color: '#F9FAFB',
        fontSize: isSmallScreen ? 16 : 18,
        fontWeight: '500',
      },
      logoutItem: {
        borderBottomWidth: 0,
        backgroundColor: 'rgba(239, 68, 68, 0.1)',
      },
      logoutText: {
        color: '#EF4444',
      },
      settingArrow: {
        color: '#87CEEB',
        fontSize: 18,
        fontWeight: 'bold',
      },
      verificationCard: {
        backgroundColor: 'rgba(255, 255, 255, 0.03)',
        borderRadius: 12,
        padding: 20,
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.05)',
      },
      verificationHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 12,
      },
      verificationTitle: {
        color: '#F9FAFB',
        fontSize: isSmallScreen ? 16 : 18,
        fontWeight: 'bold',
      },
      verifiedBadge: {
        backgroundColor: '#10B981',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 20,
      },
      verifiedText: {
        color: '#FFFFFF',
        fontSize: 12,
        fontWeight: 'bold',
      },
      verificationDescription: {
        color: '#87CEEB',
        fontSize: isSmallScreen ? 14 : 16,
        lineHeight: 22,
        marginBottom: 16,
      },
      verificationButton: {
        backgroundColor: '#87CEEB',
        paddingHorizontal: 20,
        paddingVertical: 12,
        borderRadius: 8,
        alignItems: 'center',
      },
      verificationButtonText: {
        color: '#0A1929',
        fontSize: 14,
        fontWeight: '600',
      },
      appInfoSection: {
        padding: 20,
        alignItems: 'center',
        marginTop: 20,
      },
      appInfoText: {
        color: '#87CEEB',
        fontSize: 12,
        textAlign: 'center',
        marginBottom: 4,
        opacity: 0.7,
      },
      verificationBadge: {
        position: 'absolute',
        top: -5,
        right: -5,
        backgroundColor: '#10B981',
        width: 32,
        height: 32,
        borderRadius: 16,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 3,
        borderColor: '#0A1929',
      },
      verificationIcon: {
        color: '#FFFFFF',
        fontSize: 16,
        fontWeight: 'bold',
      },
      verificationBadgeSmall: {
        backgroundColor: '#10B981',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 12,
        marginLeft: 8,
      },
      verificationIconSmall: {
        color: '#FFFFFF',
        fontSize: 12,
        fontWeight: 'bold',
      },
    });

