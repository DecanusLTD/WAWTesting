import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';

export default function OwnerAnalytics() {
  const { user } = useAuth();

  const analyticsData = {
    totalSpent: 380,
    totalBookings: 12,
    averageRating: 4.7,
    completedServices: 10,
    cancelledServices: 2,
    favoriteService: 'Full Valet',
    monthlySpending: [45, 35, 28, 42, 38, 25],
    // Customer Savings Data
    totalSavings: 85,
    savingsBreakdown: {
      loyaltyRewards: 35,
      referralDiscounts: 20,
      seasonalOffers: 18,
      firstTimeDiscounts: 12,
    },
    savingsHistory: [12, 8, 15, 10, 18, 22],
    savingsPercentage: 18.3, // Percentage saved compared to regular prices
    loyaltyPoints: 450,
    nextReward: 50, // Points needed for next reward
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Analytics</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Overview Stats */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Overview</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>£{analyticsData.totalSpent}</Text>
              <Text style={styles.statLabel}>Total Spent</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{analyticsData.totalBookings}</Text>
              <Text style={styles.statLabel}>Total Bookings</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{analyticsData.averageRating}⭐</Text>
              <Text style={styles.statLabel}>Avg Rating</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{analyticsData.completedServices}</Text>
              <Text style={styles.statLabel}>Completed</Text>
            </View>
          </View>
        </View>

        {/* Customer Savings Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>💰 Customer Savings</Text>
          
          {/* Total Savings Card */}
          <View style={styles.savingsCard}>
            <View style={styles.savingsHeader}>
              <Text style={styles.savingsTitle}>Total Savings</Text>
              <Text style={styles.savingsPercentage}>{analyticsData.savingsPercentage}%</Text>
            </View>
            <Text style={styles.savingsAmount}>£{analyticsData.totalSavings}</Text>
            <Text style={styles.savingsSubtitle}>Saved compared to regular prices</Text>
          </View>

          {/* Savings Breakdown */}
          <View style={styles.savingsBreakdown}>
            <Text style={styles.breakdownTitle}>Savings Breakdown</Text>
            <View style={styles.breakdownItem}>
              <View style={styles.breakdownInfo}>
                <Text style={styles.breakdownLabel}>🎯 Loyalty Rewards</Text>
                <Text style={styles.breakdownDescription}>Points-based discounts</Text>
              </View>
              <Text style={styles.breakdownAmount}>£{analyticsData.savingsBreakdown.loyaltyRewards}</Text>
            </View>
            <View style={styles.breakdownItem}>
              <View style={styles.breakdownInfo}>
                <Text style={styles.breakdownLabel}>👥 Referral Discounts</Text>
                <Text style={styles.breakdownDescription}>Friend referral bonuses</Text>
              </View>
              <Text style={styles.breakdownAmount}>£{analyticsData.savingsBreakdown.referralDiscounts}</Text>
            </View>
            <View style={styles.breakdownItem}>
              <View style={styles.breakdownInfo}>
                <Text style={styles.breakdownLabel}>🎄 Seasonal Offers</Text>
                <Text style={styles.breakdownDescription}>Holiday and special promotions</Text>
              </View>
              <Text style={styles.breakdownAmount}>£{analyticsData.savingsBreakdown.seasonalOffers}</Text>
            </View>
            <View style={styles.breakdownItem}>
              <View style={styles.breakdownInfo}>
                <Text style={styles.breakdownLabel}>🎁 First-Time Discounts</Text>
                <Text style={styles.breakdownDescription}>Welcome offers</Text>
              </View>
              <Text style={styles.breakdownAmount}>£{analyticsData.savingsBreakdown.firstTimeDiscounts}</Text>
            </View>
          </View>

          {/* Loyalty Points */}
          <View style={styles.loyaltyCard}>
            <View style={styles.loyaltyHeader}>
              <Text style={styles.loyaltyTitle}>🎖️ Loyalty Points</Text>
              <Text style={styles.loyaltyPoints}>{analyticsData.loyaltyPoints} pts</Text>
            </View>
            <View style={styles.loyaltyProgress}>
              <View style={styles.progressBar}>
                <View 
                  style={[
                    styles.progressFill, 
                    { width: `${(analyticsData.loyaltyPoints / (analyticsData.loyaltyPoints + analyticsData.nextReward)) * 100}%` }
                  ]} 
                />
              </View>
              <Text style={styles.progressText}>
                {analyticsData.nextReward} more points for next reward
              </Text>
            </View>
          </View>
        </View>

        {/* Service Breakdown */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Service Breakdown</Text>
          <View style={styles.serviceCard}>
            <Text style={styles.serviceTitle}>Favorite Service</Text>
            <Text style={styles.serviceValue}>{analyticsData.favoriteService}</Text>
          </View>
          <View style={styles.serviceCard}>
            <Text style={styles.serviceTitle}>Cancelled Services</Text>
            <Text style={styles.serviceValue}>{analyticsData.cancelledServices}</Text>
          </View>
        </View>

        {/* Monthly Spending */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Monthly Spending</Text>
          <View style={styles.chartContainer}>
            {analyticsData.monthlySpending.map((amount, index) => (
              <View key={index} style={styles.barContainer}>
                <View style={[styles.bar, { height: (amount / 50) * 100 }]} />
                <Text style={styles.barLabel}>£{amount}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Monthly Savings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Monthly Savings</Text>
          <View style={styles.chartContainer}>
            {analyticsData.savingsHistory.map((amount, index) => (
              <View key={index} style={styles.barContainer}>
                <View style={[styles.savingsBar, { height: (amount / 25) * 100 }]} />
                <Text style={styles.barLabel}>£{amount}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => router.push('/unified-booking')}
          >
            <Text style={styles.actionButtonText}>📅 Book New Service</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => router.push('/owner-profile')}
          >
            <Text style={styles.actionButtonText}>👤 View Profile</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => router.push('/rewards-system')}
          >
            <Text style={styles.actionButtonText}>🎁 View Rewards</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 50,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 15,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statCard: {
    width: '48%',
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#87CEEB',
    textAlign: 'center',
  },
  // Savings Styles
  savingsCard: {
    backgroundColor: '#10B981',
    padding: 20,
    borderRadius: 12,
    marginBottom: 15,
    alignItems: 'center',
  },
  savingsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    marginBottom: 10,
  },
  savingsTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  savingsPercentage: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  savingsAmount: {
    color: '#FFFFFF',
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  savingsSubtitle: {
    color: '#FFFFFF',
    fontSize: 14,
    opacity: 0.9,
  },
  savingsBreakdown: {
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
  },
  breakdownTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  breakdownItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  breakdownInfo: {
    flex: 1,
  },
  breakdownLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '500',
  },
  breakdownDescription: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 2,
  },
  breakdownAmount: {
    color: '#10B981',
    fontSize: 16,
    fontWeight: 'bold',
  },
  loyaltyCard: {
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
  },
  loyaltyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  loyaltyTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
  loyaltyPoints: {
    color: '#FFD700',
    fontSize: 18,
    fontWeight: 'bold',
  },
  loyaltyProgress: {
    alignItems: 'center',
  },
  progressBar: {
    width: '100%',
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 4,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#FFD700',
    borderRadius: 4,
  },
  progressText: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  serviceCard: {
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  serviceTitle: {
    color: '#F9FAFB',
    fontSize: 16,
  },
  serviceValue: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  chartContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'flex-end',
    height: 120,
    backgroundColor: '#1E3A8A',
    padding: 20,
    borderRadius: 12,
  },
  barContainer: {
    alignItems: 'center',
  },
  bar: {
    width: 20,
    backgroundColor: '#87CEEB',
    borderRadius: 10,
    marginBottom: 8,
  },
  savingsBar: {
    width: 20,
    backgroundColor: '#10B981',
    borderRadius: 10,
    marginBottom: 8,
  },
  barLabel: {
    color: '#F9FAFB',
    fontSize: 12,
  },
  actionButton: {
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
});
