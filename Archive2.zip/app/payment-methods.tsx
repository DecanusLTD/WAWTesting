import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput,
  Modal,
  Dimensions,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';

const { width, height } = Dimensions.get('window');

interface PaymentMethod {
  id: string;
  type: 'card' | 'paypal' | 'apple_pay' | 'google_pay' | 'bank_transfer';
  name: string;
  icon: string;
  last4?: string;
  expiry?: string;
  isDefault: boolean;
  isEnabled: boolean;
}

export default function PaymentMethods() {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([
    {
      id: '1',
      type: 'card',
      name: 'Visa ending in 4242',
      icon: '💳',
      last4: '4242',
      expiry: '12/25',
      isDefault: true,
      isEnabled: true,
    },
    {
      id: '2',
      type: 'card',
      name: 'Mastercard ending in 5555',
      icon: '💳',
      last4: '5555',
      expiry: '08/26',
      isDefault: false,
      isEnabled: true,
    },
    {
      id: '3',
      type: 'paypal',
      name: 'PayPal',
      icon: '🔵',
      isDefault: false,
      isEnabled: true,
    },
    {
      id: '4',
      type: 'apple_pay',
      name: 'Apple Pay',
      icon: '🍎',
      isDefault: false,
      isEnabled: true,
    },
    {
      id: '5',
      type: 'google_pay',
      name: 'Google Pay',
      icon: '🤖',
      isDefault: false,
      isEnabled: true,
    },
    {
      id: '6',
      type: 'bank_transfer',
      name: 'Bank Transfer',
      icon: '🏦',
      isDefault: false,
      isEnabled: false,
    },
  ]);

  const [showAddCardModal, setShowAddCardModal] = useState(false);
  const [showStripeSetupModal, setShowStripeSetupModal] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [stripeApiKey, setStripeApiKey] = useState('');
  const [stripePublishableKey, setStripePublishableKey] = useState('');

  const handleAddCard = () => {
    if (!cardNumber || !cardHolder || !expiryDate || !cvv) {
      Alert.alert('Missing Information', 'Please fill in all card details.');
      return;
    }

    // Simulate card validation
    if (cardNumber.length < 16) {
      Alert.alert('Invalid Card', 'Please enter a valid card number.');
      return;
    }

    const newCard: PaymentMethod = {
      id: Date.now().toString(),
      type: 'card',
      name: `${cardHolder} ending in ${cardNumber.slice(-4)}`,
      icon: '💳',
      last4: cardNumber.slice(-4),
      expiry: expiryDate,
      isDefault: false,
      isEnabled: true,
    };

    setPaymentMethods(prev => [...prev, newCard]);
    setShowAddCardModal(false);
    setCardNumber('');
    setCardHolder('');
    setExpiryDate('');
    setCvv('');
    Alert.alert('Success', 'Card added successfully!');
  };

  const handleSetDefault = (id: string) => {
    setPaymentMethods(prev =>
      prev.map(method => ({
        ...method,
        isDefault: method.id === id,
      }))
    );
    Alert.alert('Default Updated', 'Default payment method updated!');
  };

  const handleRemoveCard = (id: string) => {
    Alert.alert(
      'Remove Payment Method',
      'Are you sure you want to remove this payment method?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: () => {
            setPaymentMethods(prev => prev.filter(method => method.id !== id));
            Alert.alert('Removed', 'Payment method removed successfully!');
          },
        },
      ]
    );
  };

  const handleSetupStripe = () => {
    if (!stripeApiKey || !stripePublishableKey) {
      Alert.alert('Missing Keys', 'Please enter both Stripe API keys.');
      return;
    }

    Alert.alert(
      'Stripe Setup',
      'Stripe integration will be configured with your API keys. This will enable secure payment processing.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Setup',
          onPress: () => {
            setShowStripeSetupModal(false);
            setStripeApiKey('');
            setStripePublishableKey('');
            Alert.alert('Success', 'Stripe integration configured successfully!');
          },
        },
      ]
    );
  };

  const formatCardNumber = (text: string) => {
    const cleaned = text.replace(/\s/g, '');
    const groups = cleaned.match(/.{1,4}/g);
    return groups ? groups.join(' ') : cleaned;
  };

  const formatExpiryDate = (text: string) => {
    const cleaned = text.replace(/\D/g, '');
    if (cleaned.length >= 2) {
      return `${cleaned.slice(0, 2)}/${cleaned.slice(2, 4)}`;
    }
    return cleaned;
  };

  const getPaymentMethodIcon = (type: string) => {
    switch (type) {
      case 'card':
        return '💳';
      case 'paypal':
        return '🔵';
      case 'apple_pay':
        return '🍎';
      case 'google_pay':
        return '🤖';
      case 'bank_transfer':
        return '🏦';
      default:
        return '💳';
    }
  };

  const getPaymentMethodColor = (type: string) => {
    switch (type) {
      case 'card':
        return '#1E3A8A';
      case 'paypal':
        return '#003087';
      case 'apple_pay':
        return '#000000';
      case 'google_pay':
        return '#4285F4';
      case 'bank_transfer':
        return '#6B7280';
      default:
        return '#1E3A8A';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <LinearGradient
          colors={['#1E3A8A', '#87CEEB']}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.headerContent}>
          <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Payment Methods</Text>
          <View style={styles.headerRight}>
            <TouchableOpacity style={styles.stripeButton} onPress={() => setShowStripeSetupModal(true)}>
              <Text style={styles.stripeButtonText}>⚡ Stripe</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Default Payment Method */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>💳 Default Payment Method</Text>
          {paymentMethods.find(method => method.isDefault) && (
            <View style={styles.defaultCard}>
              <View style={styles.cardHeader}>
                <Text style={styles.cardIcon}>
                  {getPaymentMethodIcon(paymentMethods.find(method => method.isDefault)!.type)}
                </Text>
                <View style={styles.cardInfo}>
                  <Text style={styles.cardName}>
                    {paymentMethods.find(method => method.isDefault)!.name}
                  </Text>
                  <Text style={styles.cardDetails}>
                    {paymentMethods.find(method => method.isDefault)!.type === 'card' && 
                      `Expires ${paymentMethods.find(method => method.isDefault)!.expiry}`
                    }
                  </Text>
                </View>
                <View style={styles.defaultBadge}>
                  <Text style={styles.defaultBadgeText}>DEFAULT</Text>
                </View>
              </View>
            </View>
          )}
        </View>

        {/* All Payment Methods */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>💳 All Payment Methods</Text>
            <TouchableOpacity style={styles.addButton} onPress={() => setShowAddCardModal(true)}>
              <Text style={styles.addButtonText}>+ Add</Text>
            </TouchableOpacity>
          </View>

          {paymentMethods.map((method) => (
            <View key={method.id} style={styles.paymentMethodCard}>
              <View style={styles.methodInfo}>
                <Text style={styles.methodIcon}>{method.icon}</Text>
                <View style={styles.methodDetails}>
                  <Text style={styles.methodName}>{method.name}</Text>
                  {method.type === 'card' && (
                    <Text style={styles.methodDetails}>
                      Expires {method.expiry}
                    </Text>
                  )}
                </View>
                {method.isDefault && (
                  <View style={styles.defaultIndicator}>
                    <Text style={styles.defaultIndicatorText}>Default</Text>
                  </View>
                )}
              </View>

              <View style={styles.methodActions}>
                {!method.isDefault && (
                  <TouchableOpacity 
                    style={styles.actionButton} 
                    onPress={() => handleSetDefault(method.id)}
                  >
                    <Text style={styles.actionButtonText}>Set Default</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity 
                  style={styles.removeButton} 
                  onPress={() => handleRemoveCard(method.id)}
                >
                  <Text style={styles.removeButtonText}>Remove</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>

        {/* Payment Security */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🔒 Payment Security</Text>
          <View style={styles.securityCard}>
            <View style={styles.securityItem}>
              <Text style={styles.securityIcon}>🔐</Text>
              <View style={styles.securityInfo}>
                <Text style={styles.securityTitle}>PCI DSS Compliant</Text>
                <Text style={styles.securityDescription}>
                  All payment data is encrypted and secure
                </Text>
              </View>
            </View>
            <View style={styles.securityItem}>
              <Text style={styles.securityIcon}>🛡️</Text>
              <View style={styles.securityInfo}>
                <Text style={styles.securityTitle}>Fraud Protection</Text>
                <Text style={styles.securityDescription}>
                  Advanced fraud detection and prevention
                </Text>
              </View>
            </View>
            <View style={styles.securityItem}>
              <Text style={styles.securityIcon}>🔒</Text>
              <View style={styles.securityInfo}>
                <Text style={styles.securityTitle}>Secure Processing</Text>
                <Text style={styles.securityDescription}>
                  Bank-level security for all transactions
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Supported Payment Methods */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>💳 Supported Payment Methods</Text>
          <View style={styles.supportedMethods}>
            <View style={styles.methodGrid}>
              <View style={styles.methodItem}>
                <Text style={styles.methodItemIcon}>💳</Text>
                <Text style={styles.methodItemText}>Credit Cards</Text>
              </View>
              <View style={styles.methodItem}>
                <Text style={styles.methodItemIcon}>🔵</Text>
                <Text style={styles.methodItemText}>PayPal</Text>
              </View>
              <View style={styles.methodItem}>
                <Text style={styles.methodItemIcon}>🍎</Text>
                <Text style={styles.methodItemText}>Apple Pay</Text>
              </View>
              <View style={styles.methodItem}>
                <Text style={styles.methodItemIcon}>🤖</Text>
                <Text style={styles.methodItemText}>Google Pay</Text>
              </View>
              <View style={styles.methodItem}>
                <Text style={styles.methodItemIcon}>🏦</Text>
                <Text style={styles.methodItemText}>Bank Transfer</Text>
              </View>
              <View style={styles.methodItem}>
                <Text style={styles.methodItemIcon}>📱</Text>
                <Text style={styles.methodItemText}>Mobile Wallets</Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* Add Card Modal */}
      <Modal
        visible={showAddCardModal}
        animationType="slide"
        transparent={true}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Payment Method</Text>
              <TouchableOpacity onPress={() => setShowAddCardModal(false)}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>
            
            <View style={styles.modalBody}>
              <Text style={styles.inputLabel}>Card Number</Text>
              <TextInput
                style={styles.input}
                value={cardNumber}
                onChangeText={(text) => setCardNumber(formatCardNumber(text))}
                placeholder="1234 5678 9012 3456"
                keyboardType="numeric"
                maxLength={19}
                placeholderTextColor="#666"
              />
              
              <Text style={styles.inputLabel}>Cardholder Name</Text>
              <TextInput
                style={styles.input}
                value={cardHolder}
                onChangeText={setCardHolder}
                placeholder="John Doe"
                placeholderTextColor="#666"
              />
              
              <View style={styles.row}>
                <View style={styles.halfWidth}>
                  <Text style={styles.inputLabel}>Expiry Date</Text>
                  <TextInput
                    style={styles.input}
                    value={expiryDate}
                    onChangeText={(text) => setExpiryDate(formatExpiryDate(text))}
                    placeholder="MM/YY"
                    keyboardType="numeric"
                    maxLength={5}
                    placeholderTextColor="#666"
                  />
                </View>
                <View style={styles.halfWidth}>
                  <Text style={styles.inputLabel}>CVV</Text>
                  <TextInput
                    style={styles.input}
                    value={cvv}
                    onChangeText={setCvv}
                    placeholder="123"
                    keyboardType="numeric"
                    maxLength={4}
                    placeholderTextColor="#666"
                  />
                </View>
              </View>
            </View>
            
            <View style={styles.modalActions}>
              <TouchableOpacity 
                style={styles.modalCancelButton} 
                onPress={() => setShowAddCardModal(false)}
              >
                <Text style={styles.modalCancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.modalAddButton} 
                onPress={handleAddCard}
              >
                <Text style={styles.modalAddButtonText}>Add Card</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Stripe Setup Modal */}
      <Modal
        visible={showStripeSetupModal}
        animationType="slide"
        transparent={true}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>⚡ Stripe Integration Setup</Text>
              <TouchableOpacity onPress={() => setShowStripeSetupModal(false)}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>
            
            <View style={styles.modalBody}>
              <Text style={styles.stripeDescription}>
                Configure Stripe payment processing for secure transactions
              </Text>
              
              <Text style={styles.inputLabel}>Stripe Secret Key</Text>
              <TextInput
                style={styles.input}
                value={stripeApiKey}
                onChangeText={setStripeApiKey}
                placeholder="sk_test_..."
                secureTextEntry={true}
                placeholderTextColor="#666"
              />
              
              <Text style={styles.inputLabel}>Stripe Publishable Key</Text>
              <TextInput
                style={styles.input}
                value={stripePublishableKey}
                onChangeText={setStripePublishableKey}
                placeholder="pk_test_..."
                placeholderTextColor="#666"
              />
              
              <View style={styles.stripeFeatures}>
                <Text style={styles.stripeFeaturesTitle}>Stripe Features:</Text>
                <Text style={styles.stripeFeature}>• Secure payment processing</Text>
                <Text style={styles.stripeFeature}>• Multiple payment methods</Text>
                <Text style={styles.stripeFeature}>• Fraud protection</Text>
                <Text style={styles.stripeFeature}>• Real-time analytics</Text>
                <Text style={styles.stripeFeature}>• Global payment support</Text>
              </View>
            </View>
            
            <View style={styles.modalActions}>
              <TouchableOpacity 
                style={styles.modalCancelButton} 
                onPress={() => setShowStripeSetupModal(false)}
              >
                <Text style={styles.modalCancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.modalStripeButton} 
                onPress={handleSetupStripe}
              >
                <Text style={styles.modalStripeButtonText}>Setup Stripe</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    padding: 10,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  headerRight: {
    alignItems: 'center',
  },
  stripeButton: {
    backgroundColor: 'rgba(99, 102, 241, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  stripeButtonText: {
    color: '#6366F1',
    fontSize: 12,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
  },
  section: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 20,
  },
  addButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
  },
  addButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: 'bold',
  },
  defaultCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    borderWidth: 2,
    borderColor: '#87CEEB',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cardIcon: {
    fontSize: 24,
    marginRight: 15,
  },
  cardInfo: {
    flex: 1,
  },
  cardName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
  },
  cardDetails: {
    fontSize: 14,
    color: '#B0E0E6',
    marginTop: 2,
  },
  defaultBadge: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  defaultBadgeText: {
    color: '#0A1929',
    fontSize: 10,
    fontWeight: 'bold',
  },
  paymentMethodCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
  },
  methodInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  methodIcon: {
    fontSize: 24,
    marginRight: 15,
  },
  methodDetails: {
    flex: 1,
  },
  methodName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
  },
  defaultIndicator: {
    backgroundColor: '#10B981',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  defaultIndicatorText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  methodActions: {
    flexDirection: 'row',
    gap: 10,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  removeButton: {
    flex: 1,
    backgroundColor: 'rgba(239, 68, 68, 0.2)',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#EF4444',
  },
  removeButtonText: {
    color: '#EF4444',
    fontSize: 14,
    fontWeight: '600',
  },
  securityCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
  },
  securityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  securityIcon: {
    fontSize: 24,
    marginRight: 15,
  },
  securityInfo: {
    flex: 1,
  },
  securityTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
  },
  securityDescription: {
    fontSize: 14,
    color: '#B0E0E6',
    marginTop: 2,
  },
  supportedMethods: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
  },
  methodGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 15,
  },
  methodItem: {
    width: (width - 90) / 3,
    alignItems: 'center',
    padding: 15,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 12,
  },
  methodItemIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  methodItemText: {
    fontSize: 12,
    color: '#B0E0E6',
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#0A1929',
    borderRadius: 20,
    width: width * 0.9,
    maxHeight: height * 0.8,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#F9FAFB',
  },
  closeButton: {
    fontSize: 24,
    color: '#B0E0E6',
  },
  modalBody: {
    padding: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#F9FAFB',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#1E3A8A',
    borderRadius: 10,
    padding: 15,
    fontSize: 16,
    color: '#F9FAFB',
    marginBottom: 20,
  },
  row: {
    flexDirection: 'row',
    gap: 15,
  },
  halfWidth: {
    flex: 1,
  },
  modalActions: {
    flexDirection: 'row',
    padding: 20,
    gap: 15,
  },
  modalCancelButton: {
    flex: 1,
    backgroundColor: '#6B7280',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalCancelButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalAddButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalAddButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalStripeButton: {
    flex: 1,
    backgroundColor: '#6366F1',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalStripeButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  stripeDescription: {
    fontSize: 16,
    color: '#B0E0E6',
    marginBottom: 20,
    textAlign: 'center',
  },
  stripeFeatures: {
    backgroundColor: 'rgba(99, 102, 241, 0.1)',
    borderRadius: 10,
    padding: 15,
    marginTop: 20,
  },
  stripeFeaturesTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 10,
  },
  stripeFeature: {
    fontSize: 14,
    color: '#B0E0E6',
    marginBottom: 5,
  },
});
