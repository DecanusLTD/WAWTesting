import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Image,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../../src/providers/enhanced-auth-context';

const { width, height } = Dimensions.get('window');

interface TeamMember {
  id: string;
  name: string;
  role: string;
  status: 'online' | 'offline' | 'busy';
  rating: number;
  jobsCompleted: number;
  earnings: number;
  avatar: string;
}

interface BusinessStats {
  totalRevenue: number;
  activeJobs: number;
  teamMembers: number;
  customerRating: number;
  monthlyGrowth: number;
}

export default function BusinessDashboard() {
  const { user, isBusinessOwner } = useAuth();
  const [selectedTab, setSelectedTab] = useState('overview');
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [businessStats, setBusinessStats] = useState<BusinessStats>({
    totalRevenue: 15420,
    activeJobs: 47,
    teamMembers: 12,
    customerRating: 4.8,
    monthlyGrowth: 23,
  });

  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    // Load team members
    const mockTeamMembers: TeamMember[] = [
      {
        id: '1',
        name: 'Mike Johnson',
        role: 'Senior Valeter',
        status: 'online',
        rating: 4.9,
        jobsCompleted: 156,
        earnings: 2840,
        avatar: '👨‍🔧',
      },
      {
        id: '2',
        name: 'Sarah Williams',
        role: 'Valeter',
        status: 'busy',
        rating: 4.7,
        jobsCompleted: 89,
        earnings: 1620,
        avatar: '👩‍🔧',
      },
      {
        id: '3',
        name: 'David Brown',
        role: 'Valeter',
        status: 'offline',
        rating: 4.8,
        jobsCompleted: 134,
        earnings: 2180,
        avatar: '👨‍🔧',
      },
      {
        id: '4',
        name: 'Emma Davis',
        role: 'Junior Valeter',
        status: 'online',
        rating: 4.6,
        jobsCompleted: 67,
        earnings: 980,
        avatar: '👩‍🔧',
      },
    ];
    setTeamMembers(mockTeamMembers);

    // Start animations
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handleTabPress = async (tab: string) => {
    setSelectedTab(tab);
  };

  const handleAddTeamMember = async () => {
    Alert.alert('Add Team Member', 'This would open the team member registration form.');
  };

  const handleViewAnalytics = async () => {
    router.push('/business-analytics');
  };

  const handleManageSchedule = async () => {
    router.push('/business-schedule');
  };

  const handleViewPayroll = async () => {
    router.push('/business-payroll');
  };

  const renderOverviewTab = () => (
    <View style={styles.tabContent}>
      {/* Business Stats Cards */}
      <View style={styles.statsGrid}>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>£{businessStats.totalRevenue.toLocaleString()}</Text>
          <Text style={styles.statLabel}>Total Revenue</Text>
          <Text style={styles.statGrowth}>+{businessStats.monthlyGrowth}% this month</Text>
        </View>
        
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{businessStats.activeJobs}</Text>
          <Text style={styles.statLabel}>Active Jobs</Text>
          <Text style={styles.statGrowth}>Currently in progress</Text>
        </View>
        
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{businessStats.teamMembers}</Text>
          <Text style={styles.statLabel}>Team Members</Text>
          <Text style={styles.statGrowth}>All verified & insured</Text>
        </View>
        
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{businessStats.customerRating}⭐</Text>
          <Text style={styles.statLabel}>Customer Rating</Text>
          <Text style={styles.statGrowth}>Excellent service</Text>
        </View>
      </View>

      {/* Quick Actions */}
      <View style={styles.quickActionsSection}>
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.quickActionsGrid}>
          <TouchableOpacity style={styles.quickActionCard} onPress={handleAddTeamMember}>
            <LinearGradient
              colors={['#10B981', '#059669']}
              style={styles.quickActionGradient}
            >
              <Text style={styles.quickActionIcon}>👥</Text>
              <Text style={styles.quickActionTitle}>Add Team Member</Text>
              <Text style={styles.quickActionSubtitle}>Hire new valeter</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity style={styles.quickActionCard} onPress={handleViewAnalytics}>
            <LinearGradient
              colors={['#8B5CF6', '#7C3AED']}
              style={styles.quickActionGradient}
            >
              <Text style={styles.quickActionIcon}>📊</Text>
              <Text style={styles.quickActionTitle}>View Analytics</Text>
              <Text style={styles.quickActionSubtitle}>Business insights</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity style={styles.quickActionCard} onPress={handleManageSchedule}>
            <LinearGradient
              colors={['#F59E0B', '#D97706']}
              style={styles.quickActionGradient}
            >
              <Text style={styles.quickActionIcon}>📅</Text>
              <Text style={styles.quickActionTitle}>Manage Schedule</Text>
              <Text style={styles.quickActionSubtitle}>Team scheduling</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity style={styles.quickActionCard} onPress={handleViewPayroll}>
            <LinearGradient
              colors={['#EF4444', '#DC2626']}
              style={styles.quickActionGradient}
            >
              <Text style={styles.quickActionIcon}>💰</Text>
              <Text style={styles.quickActionTitle}>Payroll</Text>
              <Text style={styles.quickActionSubtitle}>Manage payments</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  const renderTeamTab = () => (
    <View style={styles.tabContent}>
      <View style={styles.teamHeader}>
        <Text style={styles.sectionTitle}>Your Team</Text>
        <TouchableOpacity style={styles.addButton} onPress={handleAddTeamMember}>
          <Text style={styles.addButtonText}>+ Add Member</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.teamList}>
        {teamMembers.map((member) => (
          <View key={member.id} style={styles.teamMemberCard}>
            <View style={styles.memberInfo}>
              <Text style={styles.memberAvatar}>{member.avatar}</Text>
              <View style={styles.memberDetails}>
                <Text style={styles.memberName}>{member.name}</Text>
                <Text style={styles.memberRole}>{member.role}</Text>
                <View style={styles.memberStats}>
                  <Text style={styles.memberStat}>{member.jobsCompleted} jobs</Text>
                  <Text style={styles.memberStat}>•</Text>
                  <Text style={styles.memberStat}>{member.rating}⭐</Text>
                  <Text style={styles.memberStat}>•</Text>
                  <Text style={styles.memberStat}>£{member.earnings}</Text>
                </View>
              </View>
            </View>
            <View style={styles.memberStatus}>
              <View style={[
                styles.statusDot,
                { backgroundColor: member.status === 'online' ? '#10B981' : member.status === 'busy' ? '#F59E0B' : '#6B7280' }
              ]} />
              <Text style={styles.statusText}>{member.status}</Text>
            </View>
          </View>
        ))}
      </View>
    </View>
  );

  const renderJobsTab = () => (
    <View style={styles.tabContent}>
      <Text style={styles.sectionTitle}>Active Jobs</Text>
      <View style={styles.jobsList}>
        <View style={styles.jobCard}>
          <View style={styles.jobHeader}>
            <Text style={styles.jobId}>#JW-2024-001</Text>
            <Text style={styles.jobStatus}>In Progress</Text>
          </View>
          <Text style={styles.jobCustomer}>John Smith - BMW X5</Text>
          <Text style={styles.jobValeter}>Assigned to: Mike Johnson</Text>
          <Text style={styles.jobLocation}>📍 London, SW1A 1AA</Text>
          <Text style={styles.jobPrice}>£45.00</Text>
        </View>

        <View style={styles.jobCard}>
          <View style={styles.jobHeader}>
            <Text style={styles.jobId}>#JW-2024-002</Text>
            <Text style={styles.jobStatus}>Scheduled</Text>
          </View>
          <Text style={styles.jobCustomer}>Emma Wilson - Mercedes C-Class</Text>
          <Text style={styles.jobValeter}>Assigned to: Sarah Williams</Text>
          <Text style={styles.jobLocation}>📍 Manchester, M1 1AA</Text>
          <Text style={styles.jobPrice}>£38.00</Text>
        </View>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Text style={styles.greeting}>Good {getTimeGreeting()},</Text>
          <Text style={styles.userName}>{user?.name || 'Business Owner'}</Text>
        </View>
        <TouchableOpacity style={styles.profileButton} onPress={() => router.push('/owner-profile')}>
          <Text style={styles.profileButtonText}>👤</Text>
        </TouchableOpacity>
      </View>

      {/* Tab Navigation */}
      <View style={styles.tabNavigation}>
        <TouchableOpacity
          style={[styles.tabButton, selectedTab === 'overview' && styles.activeTabButton]}
          onPress={() => handleTabPress('overview')}
        >
          <Text style={[styles.tabButtonText, selectedTab === 'overview' && styles.activeTabButtonText]}>
            Overview
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabButton, selectedTab === 'team' && styles.activeTabButton]}
          onPress={() => handleTabPress('team')}
        >
          <Text style={[styles.tabButtonText, selectedTab === 'team' && styles.activeTabButtonText]}>
            Team
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabButton, selectedTab === 'jobs' && styles.activeTabButton]}
          onPress={() => handleTabPress('jobs')}
        >
          <Text style={[styles.tabButtonText, selectedTab === 'jobs' && styles.activeTabButtonText]}>
            Jobs
          </Text>
        </TouchableOpacity>
      </View>

      {/* Tab Content */}
      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <ScrollView showsVerticalScrollIndicator={false}>
          {selectedTab === 'overview' && renderOverviewTab()}
          {selectedTab === 'team' && renderTeamTab()}
          {selectedTab === 'jobs' && renderJobsTab()}
        </ScrollView>
      </Animated.View>


    </SafeAreaView>
  );
}

const getTimeGreeting = () => {
  const hour = new Date().getHours();
  if (hour < 12) return 'morning';
  if (hour < 17) return 'afternoon';
  return 'evening';
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  headerLeft: {
    flex: 1,
  },
  greeting: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  userName: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
  },
  profileButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileButtonText: {
    fontSize: 20,
  },
  tabNavigation: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
    marginHorizontal: 4,
  },
  activeTabButton: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
  },
  tabButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  activeTabButtonText: {
    color: '#F9FAFB',
  },
  content: {
    flex: 1,
  },
  tabContent: {
    padding: 20,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 30,
  },
  statCard: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  statValue: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  statGrowth: {
    color: '#10B981',
    fontSize: 12,
  },
  quickActionsSection: {
    marginBottom: 30,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  quickActionCard: {
    width: '48%',
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 8,
  },
  quickActionGradient: {
    padding: 16,
    alignItems: 'center',
  },
  quickActionIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  quickActionTitle: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 4,
  },
  quickActionSubtitle: {
    color: '#FFFFFF',
    fontSize: 12,
    opacity: 0.9,
    textAlign: 'center',
  },
  teamHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  addButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  teamList: {
    gap: 12,
  },
  teamMemberCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  memberInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  memberAvatar: {
    fontSize: 32,
    marginRight: 12,
  },
  memberDetails: {
    flex: 1,
  },
  memberName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  memberRole: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 4,
  },
  memberStats: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  memberStat: {
    color: '#B0E0E6',
    fontSize: 12,
    marginRight: 4,
  },
  memberStatus: {
    alignItems: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginBottom: 4,
  },
  statusText: {
    color: '#B0E0E6',
    fontSize: 12,
    textTransform: 'capitalize',
  },
  jobsList: {
    gap: 12,
  },
  jobCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
  },
  jobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  jobId: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
  },
  jobStatus: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: 'bold',
  },
  jobCustomer: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  jobValeter: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 4,
  },
  jobLocation: {
    color: '#B0E0E6',
    fontSize: 14,
    marginBottom: 8,
  },
  jobPrice: {
    color: '#F59E0B',
    fontSize: 18,
    fontWeight: 'bold',
  },

});
