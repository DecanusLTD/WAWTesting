// app/_layout.tsx (RootLayout)
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider /*, useAuth */ } from '../src/providers/enhanced-auth-context';
import { useEffect, useRef, useState } from 'react';
import { LogBox, Platform } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';

// Make splash manual and guard errors
(async () => {
  try {
    console.log('[Splash] preventAutoHideAsync()');
    await SplashScreen.preventAutoHideAsync();
  } catch (e) {
    console.warn('[Splash] preventAutoHideAsync error:', e);
  }
})();

LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'AsyncStorage has been extracted from react-native',
]);

export default function RootLayout() {
  const [appReady, setAppReady] = useState(false);
  const hideOnceRef = useRef(false);

  useEffect(() => {
    (async () => {
      try {
        console.log('[RootLayout] boot starting');
        // If you load fonts/assets, await them here.
        // await Font.loadAsync(...)

        // Give RN one paint so we don’t hide too early
        await new Promise(requestAnimationFrame);
        setAppReady(true);
      } catch (e) {
        console.error('[RootLayout] boot error:', e);
        setAppReady(true); // don’t deadlock the splash
      }
    })();
  }, []);

  useEffect(() => {
    // Hide splash once, when app is ready
    const hide = async () => {
      if (appReady && !hideOnceRef.current) {
        hideOnceRef.current = true;
        try {
          console.log('[Splash] hideAsync()');
          await SplashScreen.hideAsync();
        } catch (e) {
          console.warn('[Splash] hideAsync error:', e);
        }
      }
    };
    hide();
  }, [appReady]);

  return (
    <AuthProvider>
      <StatusBar style="light" backgroundColor="#1E3A8A" />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: '#0A1929' },
          animation: Platform.OS === 'android' ? 'slide_from_right' : 'default',
          gestureEnabled: true,
          gestureDirection: 'horizontal',
        }}
      />
    </AuthProvider>
  );
}