import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

interface RadiusOption {
  value: number;
  label: string;
  description: string;
  color: string;
  icon: string;
}

export default function DistanceCovering() {
  const { user } = useAuth();
  const [selectedRadius, setSelectedRadius] = useState(10);
  const [isLoading, setIsLoading] = useState(false);

  const radiusOptions: RadiusOption[] = [
    {
      value: 5,
      label: '5 km',
      description: 'Local area coverage',
      color: '#10B981',
      icon: '🏠',
    },
    {
      value: 10,
      label: '10 km',
      description: 'City district coverage',
      color: '#3B82F6',
      icon: '🏙️',
    },
    {
      value: 15,
      label: '15 km',
      description: 'Extended city coverage',
      color: '#8B5CF6',
      icon: '🌆',
    },
    {
      value: 20,
      label: '20 km',
      description: 'Metropolitan area coverage',
      color: '#F59E0B',
      icon: '🏢',
    },
    {
      value: 25,
      label: '25 km',
      description: 'Wide area coverage',
      color: '#EF4444',
      icon: '🌍',
    },
    {
      value: 30,
      label: '30 km',
      description: 'Maximum coverage area',
      color: '#7C3AED',
      icon: '🚀',
    },
  ];

  useEffect(() => {
    loadCurrentRadius();
  }, []);

  const loadCurrentRadius = async () => {
    try {
      const savedRadius = await AsyncStorage.getItem('workingRadius');
      if (savedRadius) {
        setSelectedRadius(parseInt(savedRadius));
      }
    } catch (error) {
      console.error('Error loading radius:', error);
    }
  };

  const handleRadiusSelect = async (radius: number) => {
    try {
      await hapticFeedback('light');
      setSelectedRadius(radius);
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleSaveRadius = async () => {
    try {
      setIsLoading(true);
      await hapticFeedback('medium');

      // Save to AsyncStorage
      await AsyncStorage.setItem('workingRadius', selectedRadius.toString());

      // Update user preferences (you can extend this to save to backend)
      if (user) {
        // Here you would typically update the user's radius in your backend
        console.log(`Updated radius for user ${user.id} to ${selectedRadius}km`);
      }

      Alert.alert(
        'Radius Updated',
        `Your working radius has been set to ${selectedRadius}km. You'll now receive jobs within this distance.`,
        [
          {
            text: 'OK',
            onPress: () => router.back(),
          },
        ]
      );
    } catch (error) {
      console.error('Error saving radius:', error);
      Alert.alert('Error', 'Failed to save radius. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getRadiusDescription = (radius: number) => {
    switch (radius) {
      case 5:
        return 'Perfect for local neighbourhood work';
      case 10:
        return 'Ideal for city district coverage';
      case 15:
        return 'Great for extended city areas';
      case 20:
        return 'Covers metropolitan areas';
      case 25:
        return 'Wide coverage for busy areas';
      case 30:
        return 'Maximum coverage for high-demand areas';
      default:
        return 'Select your preferred coverage area';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <Text style={styles.backIcon}>←</Text>
        </TouchableOpacity>
                  <Text style={styles.headerTitle}>Radius</Text>
        <View style={styles.headerSpacer} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Current Selection */}
        <View style={styles.currentSelection}>
          <Text style={styles.currentSelectionTitle}>Current Radius</Text>
          <View style={styles.currentRadiusCard}>
            <Text style={styles.currentRadiusValue}>{selectedRadius} km</Text>
            <Text style={styles.currentRadiusDescription}>
              {getRadiusDescription(selectedRadius)}
            </Text>
          </View>
        </View>

        {/* Radius Options */}
        <View style={styles.optionsSection}>
          <Text style={styles.sectionTitle}>Select Your Working Radius</Text>
          <Text style={styles.sectionSubtitle}>
            Choose how far you're willing to travel for jobs
          </Text>

          <View style={styles.optionsGrid}>
            {radiusOptions.map((option) => (
              <TouchableOpacity
                key={option.value}
                style={[
                  styles.radiusOption,
                  selectedRadius === option.value && styles.selectedOption,
                ]}
                onPress={() => handleRadiusSelect(option.value)}
              >
                <LinearGradient
                  colors={
                    selectedRadius === option.value
                      ? [option.color, option.color + 'CC']
                      : ['rgba(255, 255, 255, 0.1)', 'rgba(255, 255, 255, 0.05)']
                  }
                  style={styles.optionGradient}
                >
                  <Text style={styles.optionIcon}>{option.icon}</Text>
                  <Text
                    style={[
                      styles.optionLabel,
                      selectedRadius === option.value && styles.selectedOptionText,
                    ]}
                  >
                    {option.label}
                  </Text>
                  <Text
                    style={[
                      styles.optionDescription,
                      selectedRadius === option.value && styles.selectedOptionText,
                    ]}
                  >
                    {option.description}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Info Section */}
        <View style={styles.infoSection}>
          <Text style={styles.infoTitle}>💡 How it works</Text>
          <View style={styles.infoCard}>
            <Text style={styles.infoText}>
              • You'll receive job notifications within your selected radius
            </Text>
            <Text style={styles.infoText}>
              • Larger radius = more job opportunities but longer travel times
            </Text>
            <Text style={styles.infoText}>
              • Smaller radius = faster response times but fewer opportunities
            </Text>
            <Text style={styles.infoText}>
              • You can change this setting anytime
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* Save Button */}
      <View style={styles.bottomSection}>
        <TouchableOpacity
          style={[styles.saveButton, isLoading && styles.saveButtonDisabled]}
          onPress={handleSaveRadius}
          disabled={isLoading}
        >
          <LinearGradient
            colors={['#3B82F6', '#2563EB']}
            style={styles.saveButtonGradient}
          >
            <Text style={styles.saveButtonText}>
              {isLoading ? 'Saving...' : `Set ${selectedRadius}km Radius`}
            </Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerSpacer: {
    width: 40,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  currentSelection: {
    marginTop: 20,
    marginBottom: 30,
  },
  currentSelectionTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  currentRadiusCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
  },
  currentRadiusValue: {
    color: '#3B82F6',
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  currentRadiusDescription: {
    color: '#E0E7FF',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  optionsSection: {
    marginBottom: 30,
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  sectionSubtitle: {
    color: '#E0E7FF',
    fontSize: 14,
    marginBottom: 20,
    lineHeight: 20,
  },
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  radiusOption: {
    width: '48%',
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  selectedOption: {
    transform: [{ scale: 1.02 }],
  },
  optionGradient: {
    padding: 16,
    alignItems: 'center',
    minHeight: 120,
    justifyContent: 'center',
  },
  optionIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  optionLabel: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
    textAlign: 'center',
  },
  optionDescription: {
    color: '#E0E7FF',
    fontSize: 12,
    textAlign: 'center',
    lineHeight: 16,
  },
  selectedOptionText: {
    color: '#FFFFFF',
  },
  infoSection: {
    marginBottom: 30,
  },
  infoTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  infoCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
  },
  infoText: {
    color: '#E0E7FF',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 8,
  },
  bottomSection: {
    paddingHorizontal: 20,
    paddingVertical: 20,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
  saveButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  saveButtonDisabled: {
    opacity: 0.6,
  },
  saveButtonGradient: {
    paddingVertical: 16,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
