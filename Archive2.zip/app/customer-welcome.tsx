import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ScrollView,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import { useAuth } from '../src/providers/enhanced-auth-context';

const { width, height } = Dimensions.get('window');

interface WelcomeFeature {
  id: string;
  icon: string;
  title: string;
  description: string;
  color: string;
}

export default function CustomerWelcome() {
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(0);
  const [showFeatures, setShowFeatures] = useState(false);
  
  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;
  const waterDropAnim = useRef(new Animated.Value(0)).current;
  const featureAnim = useRef(new Animated.Value(0)).current;

  const welcomeSteps = [
    {
      title: `Welcome to Wish a Wash, ${user?.name?.split(' ')[0] || 'Valet Lover'}! 🚗✨`,
      subtitle: 'Your premium car valeting experience starts here',
      description: 'Get ready to experience the future of car care with professional valeters at your fingertips.',
      icon: '🚗',
      color: '#87CEEB',
    },
    {
      title: 'Professional Valeters, Guaranteed Quality 🧽',
      subtitle: 'Every valeter is verified and insured',
      description: 'Our valeters are background-checked, fully insured, and trained to deliver exceptional results.',
      icon: '👨‍🔧',
      color: '#10B981',
    },
    {
      title: 'Real-Time Tracking & Updates 📍',
      subtitle: 'Know exactly where your valeter is',
      description: 'Track your valeter in real-time, get live updates, and know exactly when they\'ll arrive.',
      icon: '📍',
      color: '#3B82F6',
    },
  ];

  const features: WelcomeFeature[] = [
    {
      id: '1',
      icon: '⚡',
      title: 'Instant Wash',
      description: 'Get your car cleaned in 15 minutes with our premium instant service',
      color: '#10B981',
    },
    {
      id: '2',
      icon: '🏆',
      title: 'Local Priority',
      description: 'Skip the queue with our premium priority service',
      color: '#8B5CF6',
    },
    {
      id: '3',
      icon: '📅',
      title: 'Scheduled Booking',
      description: 'Book in advance and plan your car care around your schedule',
      color: '#8B5CF6',
    },
    {
      id: '4',
      icon: '💰',
      title: 'Fair Pricing',
      description: 'Transparent pricing with no hidden fees or surprises',
      color: '#EF4444',
    },
    {
      id: '5',
      icon: '⭐',
      title: 'Premium Quality',
      description: 'Professional-grade products and attention to detail',
      color: '#06B6D4',
    },
    {
      id: '6',
      icon: '🛡️',
      title: 'Fully Insured',
      description: 'Complete coverage for your vehicle during service',
      color: '#84CC16',
    },
  ];

  useEffect(() => {
    // Initial animation
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
    ]).start();

    // Water drop animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(waterDropAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(waterDropAnim, {
          toValue: 0,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Show features after initial animation
    setTimeout(() => {
      setShowFeatures(true);
      Animated.timing(featureAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }).start();
    }, 2000);
  }, []);

  const handleGetStarted = async () => {
    try {
      await hapticFeedback('medium');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
    router.replace('/owner-dashboard');
  };

  const handleSkip = async () => {
    try {
      await hapticFeedback('light');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
    router.replace('/owner-dashboard');
  };

  const renderWelcomeStep = (step: any, index: number) => (
    <Animated.View
      key={index}
      style={[
        styles.welcomeStep,
        {
          opacity: fadeAnim,
          transform: [
            { translateY: slideAnim },
            { scale: scaleAnim },
          ],
        },
      ]}
    >
      <View style={[styles.stepIcon, { backgroundColor: step.color }]}>
        <Text style={styles.stepIconText}>{step.icon}</Text>
      </View>
      <Text style={styles.stepTitle}>{step.title}</Text>
      <Text style={styles.stepSubtitle}>{step.subtitle}</Text>
      <Text style={styles.stepDescription}>{step.description}</Text>
    </Animated.View>
  );

  const renderFeature = (feature: WelcomeFeature, index: number) => (
    <Animated.View
      key={feature.id}
      style={[
        styles.featureCard,
        {
          opacity: featureAnim,
          transform: [
            {
              translateY: featureAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [50, 0],
              }),
            },
          ],
        },
      ]}
    >
      <View style={[styles.featureIcon, { backgroundColor: feature.color }]}>
        <Text style={styles.featureIconText}>{feature.icon}</Text>
      </View>
      <View style={styles.featureContent}>
        <Text style={styles.featureTitle}>{feature.title}</Text>
        <Text style={styles.featureDescription}>{feature.description}</Text>
      </View>
    </Animated.View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Background with animated water drops */}
      <View style={styles.background}>
        <LinearGradient
          colors={['#0A1929', '#1E3A8A', '#0A1929']}
          style={styles.gradient}
        />
        
        {/* Animated water drops */}
        <Animated.View
          style={[
            styles.waterDrop,
            styles.waterDrop1,
            {
              opacity: waterDropAnim,
              transform: [
                {
                  translateY: waterDropAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-20, 20],
                  }),
                },
              ],
            },
          ]}
        />
        <Animated.View
          style={[
            styles.waterDrop,
            styles.waterDrop2,
            {
              opacity: waterDropAnim.interpolate({
                inputRange: [0, 0.5, 1],
                outputRange: [0, 1, 0],
              }),
              transform: [
                {
                  translateY: waterDropAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-30, 30],
                  }),
                },
              ],
            },
          ]}
        />
        <Animated.View
          style={[
            styles.waterDrop,
            styles.waterDrop3,
            {
              opacity: waterDropAnim.interpolate({
                inputRange: [0, 0.5, 1],
                outputRange: [0, 1, 0],
              }),
              transform: [
                {
                  translateY: waterDropAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-25, 25],
                  }),
                },
              ],
            },
          ]}
        />
      </View>

      {/* Content */}
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Logo and Brand */}
        <View style={styles.logoSection}>
          <Animated.View
            style={[
              styles.logoContainer,
              {
                opacity: fadeAnim,
                transform: [
                  { scale: scaleAnim },
                ],
              },
            ]}
          >
            <Text style={styles.logo}>🚗</Text>
            <Text style={styles.brandName}>Wish a Wash</Text>
            <Text style={styles.tagline}>Premium Car Valeting</Text>
          </Animated.View>
        </View>

        {/* Welcome Steps */}
        <View style={styles.welcomeSection}>
          {welcomeSteps.map((step, index) => renderWelcomeStep(step, index))}
        </View>

        {/* Features Grid */}
        {showFeatures && (
          <View style={styles.featuresSection}>
            <Text style={styles.featuresTitle}>What You Can Do</Text>
            <View style={styles.featuresGrid}>
              {features.map((feature, index) => renderFeature(feature, index))}
            </View>
          </View>
        )}

        {/* Action Buttons */}
        <View style={styles.actionSection}>
          <TouchableOpacity
            style={styles.getStartedButton}
            onPress={handleGetStarted}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={['#10B981', '#059669']}
              style={styles.getStartedGradient}
            >
              <Text style={styles.getStartedText}>Get Started</Text>
              <Text style={styles.getStartedSubtext}>Begin Your Journey</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.skipButton}
            onPress={handleSkip}
            activeOpacity={0.7}
          >
            <Text style={styles.skipButtonText}>Skip for now</Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Join thousands of satisfied customers who trust Wish a Wash for their car care needs
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  background: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  gradient: {
    flex: 1,
  },
  waterDrop: {
    position: 'absolute',
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(135, 206, 235, 0.6)',
    shadowColor: '#87CEEB',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
    elevation: 4,
  },
  waterDrop1: {
    left: '20%',
    top: '15%',
  },
  waterDrop2: {
    left: '70%',
    top: '25%',
  },
  waterDrop3: {
    left: '45%',
    top: '35%',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  logoSection: {
    alignItems: 'center',
    marginTop: 40,
    marginBottom: 40,
  },
  logoContainer: {
    alignItems: 'center',
  },
  logo: {
    fontSize: 80,
    marginBottom: 16,
  },
  brandName: {
    color: '#F9FAFB',
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  tagline: {
    color: '#87CEEB',
    fontSize: 18,
    fontWeight: '600',
  },
  welcomeSection: {
    marginBottom: 40,
  },
  welcomeStep: {
    alignItems: 'center',
    marginBottom: 30,
    paddingHorizontal: 20,
  },
  stepIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  stepIconText: {
    fontSize: 36,
  },
  stepTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
    lineHeight: 30,
  },
  stepSubtitle: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 12,
  },
  stepDescription: {
    color: '#B0E0E6',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  featuresSection: {
    marginBottom: 40,
  },
  featuresTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 24,
  },
  featuresGrid: {
    gap: 16,
  },
  featureCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  featureIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  featureIconText: {
    fontSize: 24,
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  featureDescription: {
    color: '#B0E0E6',
    fontSize: 14,
    lineHeight: 18,
  },
  actionSection: {
    marginBottom: 40,
  },
  getStartedButton: {
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  getStartedGradient: {
    paddingVertical: 20,
    paddingHorizontal: 32,
    alignItems: 'center',
  },
  getStartedText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  getStartedSubtext: {
    color: '#FFFFFF',
    fontSize: 14,
    opacity: 0.9,
  },
  skipButton: {
    alignItems: 'center',
    paddingVertical: 12,
  },
  skipButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    textDecorationLine: 'underline',
  },
  footer: {
    alignItems: 'center',
    paddingBottom: 40,
  },
  footerText: {
    color: '#B0E0E6',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    fontStyle: 'italic',
  },
});
