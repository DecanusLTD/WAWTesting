import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  SafeAreaView,
  Modal,
  TextInput,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { simulationService } from '../src/services/SimulationService';
import { paymentSystem } from '../src/services/PaymentSystem';
import { enhancedVehiclePricingService } from '../src/services/EnhancedVehiclePricingService';
import { aiPricingEngine } from '../src/services/AIPricingEngine';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

interface WashType {
  id: string;
  name: string;
  description: string;
  basePrice: number;
  duration: string;
  features: string[];
}

interface Addon {
  id: string;
  name: string;
  description: string;
  price: number;
  icon: string;
}

export default function InstantWash() {
    console.log('Instant Wash Page')
  const { user } = useAuth();
  const [selectedLocation, setSelectedLocation] = useState('Current Location');
  const [selectedWashType, setSelectedWashType] = useState<WashType | null>(null);
  const [selectedAddons, setSelectedAddons] = useState<Addon[]>([]);
  const [selectedVehicle, setSelectedVehicle] = useState('car');
  const [isBooking, setIsBooking] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [totalPrice, setTotalPrice] = useState(0);

  const locations = [
    'Current Location',
    'Central London',
    'West London', 
    'East London',
    'North London',
    'South London',
  ];

  const washTypes: WashType[] = [
    {
      id: 'express',
      name: 'Express Wash',
      description: 'Quick exterior wash and dry',
      basePrice: 12.99,
      duration: '10-15 minutes',
      features: ['Exterior wash', 'Drying', 'Window cleaning', 'Tire dressing']
    },
    {
      id: 'standard',
      name: 'Standard Wash',
      description: 'Complete exterior and interior clean',
      basePrice: 19.99,
      duration: '20-25 minutes',
      features: ['Exterior wash', 'Interior vacuum', 'Window cleaning', 'Tire dressing', 'Dashboard clean']
    },
    {
      id: 'premium',
      name: 'Premium Wash',
      description: 'Deep clean with premium products',
      basePrice: 29.99,
      duration: '30-35 minutes',
      features: ['Exterior wash', 'Interior deep clean', 'Premium products', 'Tire shine', 'Air freshener', 'Interior protection']
    },
    {
      id: 'luxury',
      name: 'Luxury Wash',
      description: 'Ultimate care for premium vehicles',
      basePrice: 49.99,
      duration: '45-50 minutes',
      features: ['Premium exterior wash', 'Interior detailing', 'Leather treatment', 'Paint protection', 'Ceramic coating prep', 'Premium air freshener']
    }
  ];

  const addons: Addon[] = [
    {
      id: 'wax',
      name: 'Wax Treatment',
      description: 'Protective wax coating',
      price: 8.99,
      icon: '✨'
    },
    {
      id: 'interior',
      name: 'Interior Deep Clean',
      description: 'Thorough interior cleaning',
      price: 12.99,
      icon: '🧽'
    },
    {
      id: 'engine',
      name: 'Engine Bay Clean',
      description: 'Engine compartment cleaning',
      price: 15.99,
      icon: '🔧'
    },
    {
      id: 'wheels',
      name: 'Wheel Deep Clean',
      description: 'Alloy wheel restoration',
      price: 9.99,
      icon: '🛞'
    },
    {
      id: 'glass',
      name: 'Glass Treatment',
      description: 'Water repellent glass coating',
      price: 6.99,
      icon: '🪟'
    },
    {
      id: 'fabric',
      name: 'Fabric Protection',
      description: 'Stain repellent treatment',
      price: 11.99,
      icon: '🛡️'
    }
  ];

  const vehicleTypes = [
    { id: 'small', name: 'Small Car', multiplier: 1.0, description: 'Hatchbacks, city cars' },
    { id: 'medium', name: 'Medium Car', multiplier: 1.25, description: 'Saloon cars, estates' },
    { id: 'large', name: 'Large Car/SUV', multiplier: 1.5, description: 'SUVs, 4x4s, large estates' },
    { id: 'van', name: 'Van', multiplier: 1.8, description: 'Commercial vans, minibuses' },
    { id: 'luxury', name: 'Luxury Vehicle', multiplier: 2.2, description: 'Premium cars, sports cars' }
  ];

  useEffect(() => {
    calculateTotal();
  }, [selectedWashType, selectedAddons, selectedVehicle]);

  const calculateTotal = () => {
    if (!selectedWashType) return;

    // Fair pricing system that balances customer affordability with valeter earnings
    const vehicleMultiplier = vehicleTypes.find(v => v.id === selectedVehicle)?.multiplier || 1.0;
    const basePrice = selectedWashType.basePrice * vehicleMultiplier;
    
    // Apply fair AI-powered dynamic pricing with balanced approach
    const aiPricing = aiPricingEngine.calculateAIPrice(
      selectedVehicle,
      selectedWashType.id,
      { lat: 51.5074, lng: -0.1278 }, // Current location (would be user's actual location)
      basePrice
    );
    
    // Apply fair pricing constraints to prevent overcharging or undercutting
    const fairPricing = applyFairPricingConstraints(aiPricing, basePrice, selectedVehicle);
    
    const addonsPrice = selectedAddons.reduce((sum, addon) => sum + addon.price, 0);
    const total = fairPricing.finalPrice + addonsPrice;
    
    setTotalPrice(total);
    
    // Log fair pricing insights
    console.log('⚖️ Fair Pricing System:', {
      basePrice,
      aiAdjustedPrice: aiPricing.finalPrice,
      fairAdjustedPrice: fairPricing.finalPrice,
      customerSavings: basePrice - fairPricing.finalPrice,
      valeterEarnings: calculateValeterEarnings(fairPricing.finalPrice),
      confidence: fairPricing.confidence,
      reasoning: fairPricing.reasoning
    });
  };

  const applyFairPricingConstraints = (aiPricing: any, basePrice: number, vehicleType: string) => {
    // Fair pricing constraints to ensure balanced pricing
    const maxIncrease = 1.3; // Maximum 30% increase
    const maxDecrease = 0.85; // Maximum 15% decrease
    const platformFee = 0.15; // 15% platform fee
    const valeterMinimum = getValeterMinimumEarnings(vehicleType);
    
    let adjustedPrice = aiPricing.finalPrice;
    
    // Ensure valeter gets fair minimum earnings
    const valeterEarnings = adjustedPrice * (1 - platformFee);
    if (valeterEarnings < valeterMinimum) {
      adjustedPrice = valeterMinimum / (1 - platformFee);
    }
    
    // Apply maximum increase/decrease constraints
    if (adjustedPrice > basePrice * maxIncrease) {
      adjustedPrice = basePrice * maxIncrease;
    } else if (adjustedPrice < basePrice * maxDecrease) {
      adjustedPrice = basePrice * maxDecrease;
    }
    
    // Ensure price is reasonable for vehicle type
    const vehicleConstraints = getVehiclePricingConstraints(vehicleType);
    if (adjustedPrice < vehicleConstraints.minPrice) {
      adjustedPrice = vehicleConstraints.minPrice;
    } else if (adjustedPrice > vehicleConstraints.maxPrice) {
      adjustedPrice = vehicleConstraints.maxPrice;
    }
    
    return {
      ...aiPricing,
      finalPrice: Math.round(adjustedPrice * 100) / 100,
      confidence: aiPricing.confidence * 0.9, // Slightly reduce confidence due to constraints
      reasoning: [
        ...aiPricing.reasoning,
        'Fair pricing constraints applied',
        `Valeter minimum earnings: £${valeterMinimum.toFixed(2)}`,
        `Platform fee: ${(platformFee * 100).toFixed(0)}%`
      ]
    };
  };

  const getValeterMinimumEarnings = (vehicleType: string): number => {
    // Minimum earnings for valeters based on vehicle type and effort
    const baseMinimum = 12; // Base minimum per hour
    const vehicleEffort = {
      'small': 1.0,
      'medium': 1.2,
      'large': 1.4,
      'van': 1.6,
      'luxury': 1.8
    };
    
    const effortMultiplier = vehicleEffort[vehicleType as keyof typeof vehicleEffort] || 1.0;
    return baseMinimum * effortMultiplier;
  };

  const getVehiclePricingConstraints = (vehicleType: string) => {
    // Fair price ranges for different vehicle types
    const constraints = {
      'small': { minPrice: 15, maxPrice: 35 },
      'medium': { minPrice: 18, maxPrice: 42 },
      'large': { minPrice: 22, maxPrice: 50 },
      'van': { minPrice: 28, maxPrice: 65 },
      'luxury': { minPrice: 35, maxPrice: 85 }
    };
    
    return constraints[vehicleType as keyof typeof constraints] || constraints.medium;
  };

  const calculateValeterEarnings = (totalPrice: number): number => {
    const platformFee = 0.15; // 15% platform fee
    return totalPrice * (1 - platformFee);
  };

  const handleWashTypeSelect = async (washType: WashType) => {
    try {
      await hapticFeedback('light');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
    setSelectedWashType(washType);
  };

  const handleAddonToggle = async (addon: Addon) => {
    try {
      await hapticFeedback('light');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
    setSelectedAddons(prev => {
      const isSelected = prev.find(a => a.id === addon.id);
      if (isSelected) {
        return prev.filter(a => a.id !== addon.id);
      } else {
        return [...prev, addon];
      }
    });
  };

  const handleVehicleSelect = async (vehicleId: string) => {
    try {
      await hapticFeedback('light');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
    setSelectedVehicle(vehicleId);
  };

  const handleBookWash = async () => {
    if (!selectedWashType) {
      try {
        await hapticFeedback('heavy');
      } catch (error) {
        console.log('Haptic feedback not available');
      }
      Alert.alert('Error', 'Please select a wash type');
      return;
    }

    if (!user) {
      try {
        await hapticFeedback('heavy');
      } catch (error) {
        console.log('Haptic feedback not available');
      }
      Alert.alert('Error', 'Please login to book a wash');
      return;
    }

    try {
      await hapticFeedback('medium');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
    setShowPaymentModal(true);
  };

  const handlePayment = async () => {
    if (!cardNumber || !expiryDate || !cvv) {
      try {
        await hapticFeedback('heavy');
      } catch (error) {
        console.log('Haptic feedback not available');
      }
      Alert.alert('Error', 'Please fill in all payment details');
      return;
    }

    setIsBooking(true);
    
    try {
      // Process payment
      const paymentResult = await paymentSystem.processPayment({
        amount: totalPrice,
        currency: 'GBP',
        paymentMethod: 'card',
        description: `${selectedWashType?.name} - ${selectedLocation}`,
        customerId: user.id
      });

      if (paymentResult.success) {
        // Create job
        const jobId = simulationService.createJob(
          user.id,
          'instant_wash',
          { lat: 51.5074, lng: -0.1278, address: selectedLocation },
          totalPrice,
          {
            washType: selectedWashType,
            addons: selectedAddons,
            vehicleType: selectedVehicle,
            estimatedDuration: selectedWashType?.duration
          }
        );

        setShowPaymentModal(false);
        
        try {
          await hapticFeedback('medium');
        } catch (error) {
          console.log('Haptic feedback not available');
        }
        Alert.alert(
          'Payment Successful! 🎉',
          `Your ${selectedWashType?.name} has been booked for £${totalPrice.toFixed(2)}. A valeter will be with you within 15 minutes!`,
          [
            { text: 'Track Valeter', onPress: () => router.push('/tracking') },
            { text: 'Back to Dashboard', onPress: () => router.push('/owner-dashboard') }
          ]
        );
      } else {
        try {
          await hapticFeedback('heavy');
        } catch (error) {
          console.log('Haptic feedback not available');
        }
        Alert.alert('Payment Failed', paymentResult.error || 'Please try again');
      }
    } catch (error) {
      try {
        await hapticFeedback('heavy');
      } catch (error) {
        console.log('Haptic feedback not available');
      }
      Alert.alert('Error', 'Failed to process payment. Please try again.');
    } finally {
      setIsBooking(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Instant Wash</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Service Info */}
        <View style={styles.infoSection}>
          <Text style={styles.infoIcon}>⚡</Text>
          <Text style={styles.infoTitle}>Express Service</Text>
          <Text style={styles.infoDescription}>
            Get your car washed quickly! Valeters arrive within 15 minutes.
          </Text>
        </View>

        {/* Vehicle Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Vehicle Type</Text>
          <View style={styles.vehicleGrid}>
            {vehicleTypes.map((vehicle) => (
              <TouchableOpacity
                key={vehicle.id}
                style={[
                  styles.vehicleCard,
                  selectedVehicle === vehicle.id && styles.selectedVehicleCard,
                  vehicle.id === 'luxury' && styles.luxuryVehicleCard,
                  selectedVehicle === vehicle.id && vehicle.id === 'luxury' && styles.selectedLuxuryVehicleCard
                ]}
                onPress={() => handleVehicleSelect(vehicle.id)}
              >
                <Text style={[
                  styles.vehicleName,
                  vehicle.id === 'luxury' && styles.luxuryVehicleName
                ]}>{vehicle.name}</Text>
                <Text style={[
                  styles.vehicleDescription,
                  vehicle.id === 'luxury' && styles.luxuryVehicleDescription
                ]}>{vehicle.description}</Text>
                <Text style={[
                  styles.vehicleMultiplier,
                  vehicle.id === 'luxury' && styles.luxuryVehicleMultiplier
                ]}>x{vehicle.multiplier}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Wash Type Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Select Wash Type</Text>
          {washTypes.map((washType) => (
            <TouchableOpacity
              key={washType.id}
              style={[
                styles.washTypeCard,
                selectedWashType?.id === washType.id && styles.selectedWashTypeCard
              ]}
              onPress={() => handleWashTypeSelect(washType)}
            >
              <View style={styles.washTypeHeader}>
                <View>
                  <Text style={styles.washTypeName}>{washType.name}</Text>
                  <Text style={styles.washTypeDescription}>{washType.description}</Text>
                  <Text style={styles.washTypeDuration}>⏱️ {washType.duration}</Text>
                </View>
                <Text style={styles.washTypePrice}>
                  £{(washType.basePrice * (vehicleTypes.find(v => v.id === selectedVehicle)?.multiplier || 1)).toFixed(2)}
                </Text>
              </View>
              <View style={styles.featuresList}>
                {washType.features.map((feature, index) => (
                  <Text key={index} style={styles.featureText}>• {feature}</Text>
                ))}
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* Add-ons */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Add-ons (Optional)</Text>
          <View style={styles.addonsGrid}>
            {addons.map((addon) => {
              const isSelected = selectedAddons.find(a => a.id === addon.id);
              return (
                <TouchableOpacity
                  key={addon.id}
                  style={[
                    styles.addonCard,
                    isSelected && styles.selectedAddonCard
                  ]}
                  onPress={() => handleAddonToggle(addon)}
                >
                  <Text style={styles.addonIcon}>{addon.icon}</Text>
                  <Text style={styles.addonName}>{addon.name}</Text>
                  <Text style={styles.addonDescription}>{addon.description}</Text>
                  <Text style={styles.addonPrice}>£{addon.price}</Text>
                  {isSelected && <Text style={styles.selectedAddonIcon}>✓</Text>}
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* Location Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Select Your Location</Text>
          {locations.map((location) => (
            <TouchableOpacity
              key={location}
              style={[
                styles.locationCard,
                selectedLocation === location && styles.selectedLocationCard
              ]}
              onPress={() => setSelectedLocation(location)}
            >
              <Text style={styles.locationText}>{location}</Text>
              {selectedLocation === location && (
                <Text style={styles.selectedIcon}>✓</Text>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* Fair Pricing Insights */}
        {selectedWashType && (
          <View style={styles.aiPricingSection}>
            <Text style={styles.aiPricingTitle}>⚖️ Fair Pricing System</Text>
            <View style={styles.aiPricingCard}>
              <Text style={styles.aiPricingText}>
                Balanced pricing that ensures fair earnings for valeters while keeping prices reasonable for customers
              </Text>
              <View style={styles.aiPricingFactors}>
                <Text style={styles.aiFactor}>🤖 AI-powered market analysis</Text>
                <Text style={styles.aiFactor}>👨‍🔧 Fair valeter earnings</Text>
                <Text style={styles.aiFactor}>💰 Competitive customer prices</Text>
                <Text style={styles.aiFactor}>⚖️ Balanced platform fees</Text>
              </View>
              <View style={styles.pricingBreakdown}>
                <Text style={styles.breakdownTitle}>Pricing Breakdown:</Text>
                <Text style={styles.breakdownText}>• Vehicle size/type adjustments</Text>
                <Text style={styles.breakdownText}>• Market demand analysis</Text>
                <Text style={styles.breakdownText}>• Valeter minimum earnings protection</Text>
                <Text style={styles.breakdownText}>• Platform fee: 15%</Text>
              </View>
            </View>
          </View>
        )}

        {/* Price Summary */}
        {selectedWashType && (
          <View style={styles.priceSection}>
            <Text style={styles.priceSectionTitle}>⚖️ Fair Price Summary</Text>
            <View style={styles.priceBreakdown}>
              <View style={styles.priceRow}>
                <Text style={styles.priceLabel}>Base {selectedWashType.name}</Text>
                <Text style={styles.priceValue}>£{selectedWashType.basePrice}</Text>
              </View>
              <View style={styles.priceRow}>
                <Text style={styles.priceLabel}>Vehicle Multiplier ({vehicleTypes.find(v => v.id === selectedVehicle)?.name})</Text>
                <Text style={styles.priceValue}>x{vehicleTypes.find(v => v.id === selectedVehicle)?.multiplier}</Text>
              </View>
              <View style={styles.priceRow}>
                <Text style={styles.priceLabel}>AI Market Adjustment</Text>
                <Text style={styles.priceValue}>±{Math.abs(selectedWashType.basePrice * (vehicleTypes.find(v => v.id === selectedVehicle)?.multiplier || 1) - totalPrice).toFixed(2)}</Text>
              </View>
              {selectedAddons.map((addon) => (
                <View key={addon.id} style={styles.priceRow}>
                  <Text style={styles.priceLabel}>+ {addon.name}</Text>
                  <Text style={styles.priceValue}>£{addon.price}</Text>
                </View>
              ))}
              <View style={styles.priceDivider} />
              <View style={styles.priceRow}>
                <Text style={styles.totalLabel}>Total (Fair Price)</Text>
                <Text style={styles.totalPrice}>£{totalPrice.toFixed(2)}</Text>
              </View>
              <View style={styles.fairPricingInfo}>
                <Text style={styles.fairPricingText}>👨‍🔧 Valeter earns: £{calculateValeterEarnings(totalPrice).toFixed(2)}</Text>
                <Text style={styles.fairPricingText}>🏢 Platform fee: £{(totalPrice * 0.15).toFixed(2)}</Text>
              </View>
            </View>
          </View>
        )}

        {/* Book Button */}
        <View style={styles.bookingSection}>
          <TouchableOpacity
            style={[styles.bookButton, (!selectedWashType || isBooking) && styles.bookButtonDisabled]}
            onPress={handleBookWash}
            disabled={!selectedWashType || isBooking}
          >
            <Text style={styles.bookButtonText}>
              {isBooking ? 'Processing...' : `Book Now - £${totalPrice.toFixed(2)}`}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Payment Modal */}
      <Modal
        visible={showPaymentModal}
        animationType="slide"
        transparent={true}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Payment Details</Text>
            <Text style={styles.modalSubtitle}>Total: £{totalPrice.toFixed(2)}</Text>
            
            <TextInput
              style={styles.input}
              placeholder="Card Number"
              placeholderTextColor="#9CA3AF"
              value={cardNumber}
              onChangeText={setCardNumber}
              keyboardType="numeric"
            />
            
            <View style={styles.inputRow}>
              <TextInput
                style={[styles.input, styles.halfInput]}
                placeholder="MM/YY"
                placeholderTextColor="#9CA3AF"
                value={expiryDate}
                onChangeText={setExpiryDate}
              />
              <TextInput
                style={[styles.input, styles.halfInput]}
                placeholder="CVV"
                placeholderTextColor="#9CA3AF"
                value={cvv}
                onChangeText={setCvv}
                keyboardType="numeric"
                maxLength={4}
              />
            </View>

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => setShowPaymentModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.payButton, isBooking && styles.payButtonDisabled]}
                onPress={handlePayment}
                disabled={isBooking}
              >
                <Text style={styles.payButtonText}>
                  {isBooking ? 'Processing...' : 'Pay Now'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 50,
  },
  infoSection: {
    alignItems: 'center',
    padding: 30,
    backgroundColor: '#1E3A8A',
    margin: 20,
    borderRadius: 15,
  },
  infoIcon: {
    fontSize: 48,
    marginBottom: 15,
  },
  infoTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  infoDescription: {
    color: '#87CEEB',
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 15,
  },
  vehicleGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  vehicleCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
  },
  selectedVehicleCard: {
    backgroundColor: '#3B82F6',
    borderWidth: 2,
    borderColor: '#87CEEB',
  },
  luxuryVehicleCard: {
    backgroundColor: '#DAA520',
    borderWidth: 2,
    borderColor: '#B8860B',
  },
  selectedLuxuryVehicleCard: {
    backgroundColor: '#B8860B',
    borderWidth: 3,
    borderColor: '#DAA520',
  },
  vehicleName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  vehicleDescription: {
    color: '#87CEEB',
    fontSize: 10,
    textAlign: 'center',
    marginTop: 2,
    marginBottom: 4,
  },
  luxuryVehicleDescription: {
    color: '#000000',
    fontSize: 10,
    textAlign: 'center',
    marginTop: 2,
    marginBottom: 4,
  },
  vehicleMultiplier: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 4,
  },
  luxuryVehicleName: {
    color: '#000000',
    fontWeight: 'bold',
  },
  luxuryVehicleMultiplier: {
    color: '#000000',
    fontWeight: 'bold',
  },
  washTypeCard: {
    backgroundColor: '#1E3A8A',
    padding: 20,
    borderRadius: 12,
    marginBottom: 15,
  },
  selectedWashTypeCard: {
    backgroundColor: '#3B82F6',
    borderWidth: 2,
    borderColor: '#87CEEB',
  },
  washTypeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 15,
  },
  washTypeName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  washTypeDescription: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 4,
  },
  washTypeDuration: {
    color: '#B0E0E6',
    fontSize: 12,
  },
  washTypePrice: {
    color: '#F59E0B',
    fontSize: 20,
    fontWeight: 'bold',
  },
  featuresList: {
    gap: 8,
  },
  featureText: {
    color: '#F9FAFB',
    fontSize: 14,
  },
  addonsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  addonCard: {
    width: '48%',
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    position: 'relative',
  },
  selectedAddonCard: {
    backgroundColor: '#3B82F6',
    borderWidth: 2,
    borderColor: '#87CEEB',
  },
  addonIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  addonName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 4,
  },
  addonDescription: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 8,
  },
  addonPrice: {
    color: '#F59E0B',
    fontSize: 16,
    fontWeight: 'bold',
  },
  selectedAddonIcon: {
    position: 'absolute',
    top: 8,
    right: 8,
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  locationCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
  },
  selectedLocationCard: {
    backgroundColor: '#3B82F6',
    borderWidth: 2,
    borderColor: '#87CEEB',
  },
  locationText: {
    color: '#F9FAFB',
    fontSize: 16,
  },
  selectedIcon: {
    color: '#87CEEB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  aiPricingSection: {
    padding: 20,
    margin: 20,
  },
  aiPricingTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  aiPricingCard: {
    backgroundColor: 'rgba(255, 215, 0, 0.1)',
    borderWidth: 2,
    borderColor: '#FFD700',
    borderRadius: 15,
    padding: 20,
  },
  aiPricingText: {
    color: '#FFD700',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 15,
    lineHeight: 20,
  },
  aiPricingFactors: {
    gap: 8,
  },
  aiFactor: {
    color: '#FFD700',
    fontSize: 12,
    textAlign: 'center',
  },
  pricingBreakdown: {
    marginTop: 15,
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 215, 0, 0.3)',
  },
  breakdownTitle: {
    color: '#FFD700',
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  breakdownText: {
    color: '#FFD700',
    fontSize: 11,
    textAlign: 'center',
    marginBottom: 2,
  },
  priceSection: {
    padding: 20,
    backgroundColor: '#1E3A8A',
    margin: 20,
    borderRadius: 15,
  },
  priceSectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  priceBreakdown: {
    gap: 12,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  priceLabel: {
    color: '#B0E0E6',
    fontSize: 16,
  },
  priceValue: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
  priceDivider: {
    height: 1,
    backgroundColor: '#87CEEB',
    marginVertical: 8,
  },
  totalLabel: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  totalPrice: {
    color: '#F59E0B',
    fontSize: 20,
    fontWeight: 'bold',
  },
  fairPricingInfo: {
    marginTop: 15,
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135, 206, 235, 0.3)',
    gap: 5,
  },
  fairPricingText: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  bookingSection: {
    padding: 20,
    paddingBottom: 40,
  },
  bookButton: {
    backgroundColor: '#F59E0B',
    padding: 18,
    borderRadius: 12,
    alignItems: 'center',
  },
  bookButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  bookButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 30,
    width: '90%',
    maxWidth: 400,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  modalSubtitle: {
    color: '#87CEEB',
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 25,
  },
  input: {
    backgroundColor: '#0A1929',
    borderRadius: 8,
    padding: 15,
    color: '#F9FAFB',
    fontSize: 16,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#87CEEB',
  },
  inputRow: {
    flexDirection: 'row',
    gap: 15,
  },
  halfInput: {
    flex: 1,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 15,
    marginTop: 10,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#6B7280',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
  payButton: {
    flex: 1,
    backgroundColor: '#10B981',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  payButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  payButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
