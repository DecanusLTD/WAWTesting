// app/jobs.tsx
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity, SafeAreaView,
  FlatList, RefreshControl, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import AsyncStorage from '@react-native-async-storage/async-storage';
import BookingService from '../src/services/BookingService';
import * as Location from 'expo-location';
import { supabase } from '../src/lib/supabase';

type Job = {
  id: string;
  user_id?: string;
  service_type?: string;
  service_name?: string; // app shape could be serviceName
  serviceName?: string;  // app shape
  price: number;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  location?: { address?: string | null; latitude?: number | null; longitude?: number | null }; // app shape
  scheduled_at?: string | null;
  scheduledAt?: string | null; // app shape
  status?: string;
  valeter_id?: string | null;
  vehicleType?: string | null;
  vehicleInfo?: string | null;
  specialInstructions?: string | null;
  // ephemeral field we add:
  _distanceKm?: number | null;
};

export default function Jobs() {
  const router = useRouter();
  const { user } = useAuth();

  const [jobs, setJobs] = useState<Job[]>([]);
  const [workingRadius, setWorkingRadius] = useState(15);
  const [refreshing, setRefreshing] = useState(false);
  const [myLoc, setMyLoc] = useState<{ lat: number; lng: number } | null>(null);

  // active job enforcement
  const [activeJobId, setActiveJobId] = useState<string | null>(null);

  // ---------------- helpers ----------------
  const kmBetween = (a: {lat:number;lng:number}, b: {lat:number;lng:number}) => {
    const R = 6371; // km
    const dLat = (b.lat - a.lat) * Math.PI / 180;
    const dLng = (b.lng - a.lng) * Math.PI / 180;
    const la1 = a.lat * Math.PI / 180;
    const la2 = b.lat * Math.PI / 180;
    const sinDLat = Math.sin(dLat/2), sinDLng = Math.sin(dLng/2);
    const h = sinDLat*sinDLat + Math.cos(la1)*Math.cos(la2)*sinDLng*sinDLng;
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
  };

  const pickServiceLabel = (row: any) =>
    row?.service_name || row?.serviceName || row?.service_type || row?.serviceType || 'Service';

  const pickAddress = (row: any) =>
    row?.location_address ?? row?.location?.address ?? null;

  const pickCoords = (row: any): { lat: number; lng: number } | null => {
    const lat =
      typeof row?.location_lat === 'number' ? row.location_lat :
      typeof row?.location?.latitude === 'number' ? row.location.latitude :
      null;
    const lng =
      typeof row?.location_lng === 'number' ? row.location_lng :
      typeof row?.location?.longitude === 'number' ? row.location.longitude :
      null;
    if (typeof lat === 'number' && typeof lng === 'number') return { lat, lng };
    return null;
  };

  const pickScheduledAt = (row: any) =>
    row?.scheduled_at || row?.scheduledAt || null;

  const pickVehicleInfo = (row: any) =>
    row?.vehicleInfo || row?.vehicle_type || row?.vehicleType || null;

  const withDistance = (rows: Job[], origin: {lat:number;lng:number}|null) =>
    rows.map(r => {
      const coords = pickCoords(r);
      const d = origin && coords ? kmBetween(origin, coords) : null;
      return { ...r, _distanceKm: d as number | null };
    });

  const fetchMyLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      setMyLoc({ lat: pos.coords.latitude, lng: pos.coords.longitude });
    } catch {
      // ignore; we’ll just show no distance
    }
  };

  const loadWorkingRadius = async () => {
    try {
      const radius = await AsyncStorage.getItem('workingRadius');
      if (radius) setWorkingRadius(parseInt(radius, 10));
    } catch {}
  };

  const fetchJobs = async () => {
    try {
      // rows where valeter_id IS NULL
      const available = await BookingService.getOpenBookings();
      setJobs(available as any);
    } catch (e) {
      console.error('Error fetching jobs:', e);
    }
  };

  const fetchActiveValeterJob = useCallback(async () => {
    if (!user?.id) {
      setActiveJobId(null);
      return;
    }
    try {
      // Active = scheduled or in_progress (your enum)
      const { data, error } = await supabase
        .from('bookings')
        .select('id')
        .eq('valeter_id', user.id)
        .in('status', ['scheduled', 'in_progress'])
        .order('created_at', { ascending: false })
        .limit(1);
      if (error) throw error;
      const row = data?.[0] ?? null;
      setActiveJobId(row?.id ?? null);
    } catch (e) {
      console.warn('[Jobs] fetchActiveValeterJob error:', (e as any)?.message || e);
      setActiveJobId(null);
    }
  }, [user?.id]);

  // --------------- effects ---------------
  useEffect(() => {
    loadWorkingRadius();
    fetchMyLocation();
    fetchJobs();
    fetchActiveValeterJob();
  }, [fetchActiveValeterJob]);

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([fetchMyLocation(), fetchJobs(), fetchActiveValeterJob()]);
    setRefreshing(false);
  };

  // compute distance + filter + sort
  const jobsWithDistance = useMemo(() => withDistance(jobs, myLoc), [jobs, myLoc]);

  const visibleJobs = useMemo(() => {
    return jobsWithDistance
      .filter(j => {
        if (j._distanceKm == null) return true; // show if we can’t compute
        return j._distanceKm <= workingRadius;
      })
      .sort((a, b) => {
        const da = a._distanceKm ?? Infinity;
        const db = b._distanceKm ?? Infinity;
        return da - db;
      });
  }, [jobsWithDistance, workingRadius]);

  const canAccept = !activeJobId;

  // --------------- actions ---------------
  const warnActiveJob = (existingId: string) => {
    Alert.alert(
      'You already have an active job',
      'Finish your current job before accepting a new one.',
      [
        { text: 'View Current Job', onPress: () => router.push(`/current-trip?bookingId=${existingId}`) },
        { text: 'OK' },
      ]
    );
  };

  const handleAccept = async (job: any) => {
    if (!user) return;
    await hapticFeedback('medium');

    // HARD GUARD (client): re-check just before attempting to claim
    await fetchActiveValeterJob();
    if (activeJobId) {
      warnActiveJob(activeJobId);
      return;
    }

    const label = pickServiceLabel(job);
    Alert.alert(
      'Accept Job',
      `Accept this ${label} for £${job.price}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Accept',
          onPress: async () => {
            try {
              // Server-side guard (DB): our BookingService.assignValeter only updates if valeter_id IS NULL.
              const res = await BookingService.assignValeter(job.id, user.id, {
                valeterId: user.id,
                valeterName: user.name,
              });

              // After success, set active job locally and refresh lists
              setActiveJobId(res?.id ?? job.id);
              Alert.alert('Accepted! 🎉', 'Job added to your trips.', [
                { text: '🚗 Start Trip', onPress: () => router.push(`/current-trip?bookingId=${res?.id ?? job.id}`) },
                { text: 'OK' },
              ]);
              fetchJobs();
            } catch (e: any) {
              // Friendly handling for race / RLS / taken job
              const code = e?.code || e?.message;
              if (code === 'JOB_TAKEN_OR_FORBIDDEN') {
                Alert.alert('Already Taken', 'Another valeter accepted this job a moment ago.');
              } else {
                Alert.alert('Error', 'Could not accept job, please retry.');
              }
              // Also re-check active status in case server accepted it but the client missed it
              await fetchActiveValeterJob();
            }
          },
        },
      ]
    );
  };

  // --------------- render ---------------
  const renderJob = ({ item }: { item: any }) => {
    const label = pickServiceLabel(item);
    const address = pickAddress(item);
    const scheduledAt = pickScheduledAt(item);
    const vehicleInfo = pickVehicleInfo(item);

    return (
      <View style={styles.card}>
        <LinearGradient colors={['rgba(255,255,255,0.05)', 'rgba(255,255,255,0.02)']} style={styles.cardGrad}>
          <Text style={styles.service}>{label}</Text>
          <Text style={styles.price}>💷 £{item.price}</Text>

          {address ? <Text style={styles.rowText}>📍 {address}</Text> : null}

          {typeof item._distanceKm === 'number' ? (
            <Text style={styles.rowSub}>
              📏 {item._distanceKm < 1 ? `${Math.round(item._distanceKm * 1000)} m` : `${item._distanceKm.toFixed(1)} km`} away
            </Text>
          ) : (
            <Text style={styles.rowSub}>📏 distance unavailable</Text>
          )}

          {vehicleInfo ? <Text style={styles.rowText}>🚗 {vehicleInfo}</Text> : null}

          {scheduledAt ? <Text style={styles.rowText}>⏰ {new Date(scheduledAt).toLocaleString()}</Text> : null}

          <TouchableOpacity
            style={[styles.acceptBtn, !canAccept && styles.acceptBtnDisabled]}
            onPress={() => (canAccept ? handleAccept(item) : warnActiveJob(activeJobId!))}
            activeOpacity={canAccept ? 0.9 : 1}
            disabled={!canAccept}
          >
            <LinearGradient
              colors={canAccept ? ['#10B981', '#059669'] : ['#6B7280', '#4B5563']}
              style={styles.acceptGrad}
            >
              <Text style={styles.acceptTxt}>{canAccept ? 'Accept Job' : 'Finish current job'}</Text>
            </LinearGradient>
          </TouchableOpacity>
        </LinearGradient>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        style={{ flex: 1 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={{ padding: 8 }}>
            <Text style={{ color: '#87CEEB', fontSize: 16 }}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.title}>Jobs</Text>
          <View style={{ width: 60 }} />
        </View>

        {/* Banner if the valeter already has an active job */}
        {activeJobId ? (
          <View style={styles.banner}>
            <Text style={styles.bannerText}>
              You have an active job. Complete it before accepting another.
            </Text>
            <TouchableOpacity style={styles.bannerBtn} onPress={() => router.push(`/current-trip?bookingId=${activeJobId}`)}>
              <Text style={styles.bannerBtnText}>Go to current job</Text>
            </TouchableOpacity>
          </View>
        ) : null}

        <FlatList
          data={visibleJobs}
          renderItem={renderJob}
          keyExtractor={(i) => i.id}
          scrollEnabled={false}
          contentContainerStyle={{ padding: 20 }}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={{ fontSize: 48, marginBottom: 16 }}>🚗</Text>
              <Text style={styles.emptyTitle}>No Available Jobs</Text>
              <Text style={styles.emptyText}>
                No wash requests available in your {workingRadius}km radius at the moment.
              </Text>
            </View>
          }
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    padding: 20, borderBottomWidth: 1, borderBottomColor: '#1E3A8A',
  },
  title: { color: '#F9FAFB', fontSize: 20, fontWeight: 'bold' },

  banner: {
    marginHorizontal: 20,
    marginTop: 14,
    padding: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  bannerText: { color: '#E5E7EB', fontSize: 14, marginBottom: 8 },
  bannerBtn: {
    alignSelf: 'flex-start',
    backgroundColor: '#10B981',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  bannerBtnText: { color: '#0A1929', fontWeight: '700' },

  card: { marginBottom: 16, borderRadius: 16, overflow: 'hidden' },
  cardGrad: { padding: 16, borderRadius: 16 },

  service: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  price: { color: '#10B981', fontSize: 16, marginTop: 4 },

  rowText: { color: '#E0E7FF', marginTop: 6 },
  rowSub: { color: '#87CEEB', marginTop: 4 },

  acceptBtn: { marginTop: 12, borderRadius: 8, overflow: 'hidden' },
  acceptBtnDisabled: { opacity: 0.6 },
  acceptGrad: { paddingVertical: 12, alignItems: 'center' },
  acceptTxt: { color: '#fff', fontSize: 14, fontWeight: 'bold' },

  empty: { alignItems: 'center', paddingVertical: 40 },
  emptyTitle: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  emptyText: { color: '#87CEEB', fontSize: 14, textAlign: 'center', lineHeight: 20 },
});