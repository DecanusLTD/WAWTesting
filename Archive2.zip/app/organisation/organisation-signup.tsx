import React, { useRef, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Dimensions,
  Animated,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StatusBar,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';

const { height } = Dimensions.get('window');

export default function OrganizationSignup() {
  const { register } = useAuth();

  const [orgName, setOrgName] = useState('');
  const [contactName, setContactName] = useState('');
  const [workEmail, setWorkEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Animations (match org login vibe)
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const scaleAnim = useRef(new Animated.Value(0.95)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 800, useNativeDriver: true }),
      Animated.timing(scaleAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
    ]).start();
  }, []);

  const handleBack = () => router.back();

  const validate = () => {
    if (!orgName.trim() || !contactName.trim() || !workEmail.trim() || !password.trim() || !confirm.trim()) {
      Alert.alert('Missing info', 'Please fill in all fields.');
      return false;
    }
    if (!workEmail.includes('@')) {
      Alert.alert('Invalid email', 'Please enter a valid work email.');
      return false;
    }
    if (password.length < 6) {
      Alert.alert('Weak password', 'Password must be at least 6 characters.');
      return false;
    }
    if (password !== confirm) {
      Alert.alert('Password mismatch', 'Passwords do not match.');
      return false;
    }
    return true;
  };

  const handleSignup = async () => {
    if (!validate()) return;

    setIsLoading(true);
    try {
      await hapticFeedback('light');
    } catch {}

    try {
      // Minimal payload: name maps to org name, userType is organization
      const ok = await register({
        email: workEmail,
        name: orgName,
        userType: 'organization',
        password,
        // If your register supports metadata, you can pass it here:
        // metadata: { contactName }
      });

      if (!ok) {
        try { await hapticFeedback('heavy'); } catch {}
        Alert.alert('Sign Up Failed', 'Could not create your organisation account. Please try again.');
        return;
      }

      try { await hapticFeedback('medium'); } catch {}

      Alert.alert('Success', 'Organisation account created! Please sign in.', [
        { text: 'OK', onPress: () => router.replace('/organization/login') },
      ]);
    } catch (e) {
      try { await hapticFeedback('heavy'); } catch {}
      Alert.alert('Error', 'Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView
        style={styles.keyboardAvoidingView}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        {/* Background (same family as org login) */}
        <View style={styles.background}>
          <View style={styles.gradient} />
        </View>

        <Animated.View
          style={[
            styles.container,
            { opacity: fadeAnim, transform: [{ translateY: slideAnim }, { scale: scaleAnim }] },
          ]}
        >
          <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
            {/* Header */}
            <View style={styles.header}>
              <TouchableOpacity onPress={handleBack} style={styles.backButton}>
                <Text style={styles.backButtonText}>← Back</Text>
              </TouchableOpacity>
              <Text style={styles.headerTitle}>Organisation Sign Up</Text>
              <View style={styles.placeholder} />
            </View>

            {/* Logo / Brand */}
            <View style={styles.logoSection}>
              <Text style={styles.logo}>🏢</Text>
              <Text style={styles.brandName}>Wish a Wash</Text>
              <Text style={styles.tagline}>Business & Admin Access</Text>
            </View>

            {/* Form */}
            <View style={styles.formContainer}>
              <Text style={styles.formTitle}>Create Your Organisation Account</Text>

              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Organisation Name</Text>
                <TextInput
                  style={styles.textInput}
                  value={orgName}
                  onChangeText={setOrgName}
                  placeholder="e.g. Elite Valet Ltd"
                  placeholderTextColor="#9CA3AF"
                  autoCapitalize="words"
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Primary Contact Name</Text>
                <TextInput
                  style={styles.textInput}
                  value={contactName}
                  onChangeText={setContactName}
                  placeholder="e.g. Jane Doe"
                  placeholderTextColor="#9CA3AF"
                  autoCapitalize="words"
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Work Email</Text>
                <TextInput
                  style={styles.textInput}
                  value={workEmail}
                  onChangeText={setWorkEmail}
                  placeholder="name@company.com"
                  placeholderTextColor="#9CA3AF"
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Password</Text>
                <TextInput
                  style={styles.textInput}
                  value={password}
                  onChangeText={setPassword}
                  placeholder="Create a password"
                  placeholderTextColor="#9CA3AF"
                  secureTextEntry
                  autoCapitalize="none"
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Confirm Password</Text>
                <TextInput
                  style={styles.textInput}
                  value={confirm}
                  onChangeText={setConfirm}
                  placeholder="Re-enter your password"
                  placeholderTextColor="#9CA3AF"
                  secureTextEntry
                  autoCapitalize="none"
                />
              </View>

              <TouchableOpacity
                style={[styles.signupButton, isLoading && styles.signupButtonDisabled]}
                onPress={handleSignup}
                disabled={isLoading}
                activeOpacity={0.85}
              >
                <Text style={styles.signupButtonText}>
                  {isLoading ? 'Creating Account...' : 'Create Organisation Account'}
                </Text>
              </TouchableOpacity>

              {/* Link to org login */}
              <View style={styles.loginRow}>
                <Text style={styles.loginText}>Already have a business account? </Text>
                <TouchableOpacity onPress={() => router.replace('/organization/login')}>
                  <Text style={styles.loginLink}>Sign In</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Info Section (matches org login styling) */}
            <View style={styles.infoContainer}>
              <Text style={styles.infoTitle}>Business Account Benefits:</Text>
              <Text style={styles.infoText}>
                • Manage multiple valeters under your business{'\n'}
                • View business analytics and earnings{'\n'}
                • Handle insurance and licensing for employees{'\n'}
                • Access business dashboard and reports{'\n'}
                • Manage staff schedules and assignments
              </Text>
            </View>

            {/* Contact Support */}
            <View style={styles.supportContainer}>
              <Text style={styles.supportText}>Questions? Contact us:</Text>
              <Text style={styles.supportEmail}>business@wishawash.com</Text>
            </View>
          </ScrollView>
        </Animated.View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#0A1929' },
  keyboardAvoidingView: { flex: 1 },

  background: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
  gradient: { flex: 1, backgroundColor: '#0A1929' },

  container: { flex: 1 },
  scrollContent: { flexGrow: 1, padding: 20 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 40,
  },
  backButton: { padding: 8 },
  backButtonText: { color: '#87CEEB', fontSize: 16 },
  headerTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: 'bold' },
  placeholder: { width: 60 },

  logoSection: { alignItems: 'center', marginBottom: 36 },
  logo: { fontSize: 80, marginBottom: 16 },
  brandName: { color: '#F9FAFB', fontSize: 28, fontWeight: 'bold', marginBottom: 8 },
  tagline: { color: '#87CEEB', fontSize: 16, fontWeight: '600' },

  formContainer: { marginBottom: 28 },
  formTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 28,
  },

  inputContainer: { marginBottom: 18 },
  inputLabel: { color: '#87CEEB', fontSize: 16, fontWeight: '600', marginBottom: 8 },
  textInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: '#F9FAFB',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },

  signupButton: {
    backgroundColor: '#10B981', // same green tone family as org login button
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 6,
    marginBottom: 12,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  signupButtonDisabled: { backgroundColor: '#6B7280', shadowOpacity: 0.1 },
  signupButtonText: { color: '#FFFFFF', fontSize: 18, fontWeight: 'bold' },

  loginRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 6 },
  loginText: { color: '#B0E0E6', fontSize: 14 },
  loginLink: { color: '#87CEEB', fontSize: 14, fontWeight: 'bold', textDecorationLine: 'underline' },

  infoContainer: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 12,
    padding: 20,
    marginBottom: 24,
  },
  infoTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: 'bold', marginBottom: 12 },
  infoText: { color: '#B0E0E6', fontSize: 14, lineHeight: 20 },

  supportContainer: { alignItems: 'center', marginBottom: 20 },
  supportText: { color: '#B0E0E6', fontSize: 14, marginBottom: 8 },
  supportEmail: { color: '#87CEEB', fontSize: 16, fontWeight: 'bold' },
});