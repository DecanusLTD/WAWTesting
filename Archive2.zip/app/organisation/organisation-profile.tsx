// app/organisation/OrganizationProfile.tsx
import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Switch,
  Image,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';

type DbOrganization = {
  id: string;
  name: string;
  registration_number?: string | null;
  address?: string | null;
  contact_email: string;
  contact_phone?: string | null;
  status: 'pending' | 'verified' | 'suspended' | string;
  is_verified: boolean;
  insurance_verified: boolean;
  license_verified: boolean;
  owner_user_id: string | null;
  created_at: string;
  updated_at: string;
};

export default function OrganizationProfile() {
  const { user, logout } = useAuth();

  const [isEditing, setIsEditing] = useState(false);
  const [org, setOrg] = useState<DbOrganization | null>(null);
  const [loading, setLoading] = useState(true);

  // faux toggles (local only for now—hook to real prefs later if needed)
  const [notifications, setNotifications] = useState(true);
  const [locationSharing, setLocationSharing] = useState(true);

  // Logo (optional local)
  const [logoUri, _setLogoUri] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    registration_number: '',
    address: '',
    contact_email: '',
    contact_phone: '',
  });

  const initials = useMemo(() => {
    const n = formData.name?.trim() || 'Org';
    const parts = n.split(/\s+/);
    if (parts.length >= 2) return `${parts[0][0] ?? ''}${parts[1][0] ?? ''}`.toUpperCase();
    return n.slice(0, 2).toUpperCase();
  }, [formData.name]);

  useEffect(() => {
    const loadOrg = async () => {
      if (!user?.id) {
        setLoading(false);
        return;
      }
      try {
        // 1) try owned org
        let q = supabase
          .from('organizations')
          .select('*')
          .eq('owner_user_id', user.id)
          .maybeSingle();

        let { data, error } = await q;
        if (error) throw error;

        // 2) fallback: if not owner, try by mirrored organizationId
        if (!data && user.organizationId) {
          const res = await supabase
            .from('organizations')
            .select('*')
            .eq('id', user.organizationId)
            .maybeSingle();
          if (res.error) throw res.error;
          data = res.data;
        }

        if (!data) {
          setOrg(null);
          setLoading(false);
          return;
        }

        setOrg(data as DbOrganization);
        setFormData({
          name: data.name ?? '',
          registration_number: data.registration_number ?? '',
          address: data.address ?? '',
          contact_email: data.contact_email ?? '',
          contact_phone: data.contact_phone ?? '',
        });
      } catch (e: any) {
        console.warn('[OrgProfile] load error:', e?.message || e);
        Alert.alert('Error', 'Failed to load organization.');
      } finally {
        setLoading(false);
      }
    };

    loadOrg();
  }, [user?.id, user?.organizationId]);

  const updateFormData = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    if (!org) return;
    try {
      const patch: Partial<DbOrganization> = {
        name: formData.name.trim(),
        registration_number: formData.registration_number.trim() || null,
        address: formData.address.trim() || null,
        contact_email: formData.contact_email.trim(),
        contact_phone: formData.contact_phone.trim() || null,
      };

      const { error } = await supabase
        .from('organizations')
        .update(patch)
        .eq('id', org.id);

      if (error) throw error;

      setOrg(prev => (prev ? { ...prev, ...patch } as DbOrganization : prev));
      setIsEditing(false);
      Alert.alert('Success', 'Organization updated successfully!');
    } catch (e: any) {
      console.warn('[OrgProfile] save error:', e?.message || e);
      Alert.alert('Error', 'Failed to update organization. Please try again.');
    }
  };

  const handleCancel = () => {
    if (!org) return;
    setFormData({
      name: org.name ?? '',
      registration_number: org.registration_number ?? '',
      address: org.address ?? '',
      contact_email: org.contact_email ?? '',
      contact_phone: org.contact_phone ?? '',
    });
    setIsEditing(false);
  };

  const handleLogout = async () => {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          try {
            await logout();
            router.replace('../organisation/organization-login');
          } catch {
            router.replace('../organisation/organization-login');
          }
        },
      },
    ]);
  };

  const handleUploadLogo = () => {
    Alert.alert('Upload Logo', 'Image picker coming soon 😊');
  };

  const handleChangePassword = () => {
    Alert.alert('Change Password', 'Password change functionality will be implemented');
  };

  const handleTermsOfService = () => router.push('/terms-of-service');
  const handlePrivacyPolicy = () => router.push('/privacy-policy');
  const handleHelpSupport = () => router.push('/help-support');

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ color: '#87CEEB' }}>Loading organization…</Text>
      </View>
    );
  }

  if (!org) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <View style={styles.headerTop}>
            <TouchableOpacity onPress={() => router.back()}>
              <Text style={styles.backButton}>← Back</Text>
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Organization</Text>
            <TouchableOpacity onPress={handleLogout}>
              <Text style={styles.logoutGlyph}>🚪</Text>
            </TouchableOpacity>
          </View>
        </View>
        <ScrollView style={styles.scrollContainer} contentContainerStyle={styles.scrollContent}>
          <Text style={{ color: '#fff', fontSize: 16 }}>
            No organization found for this account.
          </Text>
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <TouchableOpacity onPress={() => router.back()}>
            <Text style={styles.backButton}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Organization</Text>
          <TouchableOpacity onPress={handleLogout}>
            <Text style={styles.logoutGlyph}>🚪</Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.scrollContainer} contentContainerStyle={styles.scrollContent}>
        {/* Org Avatar / Name */}
        <View style={styles.profileSection}>
          <TouchableOpacity style={styles.profileImageContainer} onPress={handleUploadLogo}>
            {logoUri ? (
              <Image source={{ uri: logoUri }} style={styles.profileImage} />
            ) : (
              <View style={styles.profileImage}>
                <Text style={styles.profileInitial}>{initials}</Text>
              </View>
            )}
            <View style={styles.uploadOverlay}>
              <Text style={styles.uploadText}>📷</Text>
            </View>
          </TouchableOpacity>
          <Text style={styles.profileName}>{formData.name || 'Organization'}</Text>
          <Text style={styles.profileStatus}>
            {org.status === 'verified' || org.is_verified ? 'Verified Organization' : 'Pending Verification'}
          </Text>
        </View>

        {/* Organization Details */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Organization Details</Text>
            <TouchableOpacity
              style={styles.editButton}
              onPress={() => setIsEditing(!isEditing)}
            >
              <Text style={styles.editButtonText}>{isEditing ? 'Cancel' : 'Edit'}</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.formContainer}>
            <LabeledInput
              label="Organization Name"
              value={formData.name}
              onChangeText={(t) => updateFormData('name', t)}
              editable={isEditing}
            />
            <LabeledInput
              label="Registration Number"
              value={formData.registration_number}
              onChangeText={(t) => updateFormData('registration_number', t)}
              editable={isEditing}
              placeholder="(optional)"
            />
            <LabeledInput
              label="Address"
              value={formData.address}
              onChangeText={(t) => updateFormData('address', t)}
              editable={isEditing}
              placeholder="(optional)"
            />
            <LabeledInput
              label="Contact Email"
              value={formData.contact_email}
              onChangeText={(t) => updateFormData('contact_email', t)}
              editable={isEditing}
              keyboardType="email-address"
              autoCapitalize="none"
            />
            <LabeledInput
              label="Contact Phone"
              value={formData.contact_phone}
              onChangeText={(t) => updateFormData('contact_phone', t)}
              editable={isEditing}
              keyboardType="phone-pad"
              placeholder="(optional)"
            />
          </View>

          {isEditing && (
            <View style={styles.saveButtons}>
              <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
                <Text style={styles.saveButtonText}>Save Changes</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.cancelButton} onPress={handleCancel}>
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Verification Status */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Verification Status</Text>
          <View style={styles.badgeRow}>
            <StatusBadge
              label="Organization"
              ok={!!org.is_verified}
              okText="Verified"
              noText="Pending"
            />
            <StatusBadge
              label="Insurance"
              ok={!!org.insurance_verified}
              okText="Verified"
              noText="Pending"
            />
            <StatusBadge
              label="License"
              ok={!!org.license_verified}
              okText="Verified"
              noText="Pending"
            />
          </View>
        </View>

        {/* Account Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Information</Text>

          <View style={styles.accountInfoCard}>
            <InfoRow label="Organization ID" value={org.id} />
            <InfoRow label="Owner Email" value={user?.email || ''} />
            <InfoRow
              label="Member Since"
              value={new Date(org.created_at).toLocaleDateString()}
            />
          </View>
        </View>

        {/* Settings (local toggles for now) */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingIcon}>🔔</Text>
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Notifications</Text>
                <Text style={styles.settingDescription}>Receive organization updates</Text>
              </View>
            </View>
            <Switch
              value={notifications}
              onValueChange={setNotifications}
              trackColor={{ false: '#2d2d2d', true: '#87CEEB' }}
              thumbColor={notifications ? '#0A1929' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingIcon}>📍</Text>
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Location Sharing</Text>
                <Text style={styles.settingDescription}>Share org location with customers</Text>
              </View>
            </View>
            <Switch
              value={locationSharing}
              onValueChange={setLocationSharing}
              trackColor={{ false: '#2d2d2d', true: '#87CEEB' }}
              thumbColor={locationSharing ? '#0A1929' : '#f4f3f4'}
            />
          </View>
        </View>

        {/* Account Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account</Text>

          <TouchableOpacity style={styles.actionButton} onPress={handleChangePassword}>
            <Text style={styles.actionIcon}>🔒</Text>
            <Text style={styles.actionText}>Change Password</Text>
            <Text style={styles.actionArrow}>→</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push('/organization-documents')}
          >
            <Text style={styles.actionIcon}>📋</Text>
            <Text style={styles.actionText}>Required Documents</Text>
            <Text style={styles.actionArrow}>→</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionButton} onPress={handleTermsOfService}>
            <Text style={styles.actionIcon}>📄</Text>
            <Text style={styles.actionText}>Terms of Service</Text>
            <Text style={styles.actionArrow}>→</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionButton} onPress={handlePrivacyPolicy}>
            <Text style={styles.actionIcon}>🛡️</Text>
            <Text style={styles.actionText}>Privacy Policy</Text>
            <Text style={styles.actionArrow}>→</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionButton} onPress={handleHelpSupport}>
            <Text style={styles.actionIcon}>❓</Text>
            <Text style={styles.actionText}>Help & Support</Text>
            <Text style={styles.actionArrow}>→</Text>
          </TouchableOpacity>
        </View>

        {/* Logout Section */}
        <View style={styles.logoutSection}>
          <TouchableOpacity style={styles.logoutButtonLarge} onPress={handleLogout}>
            <Text style={styles.logoutButtonLargeText}>🚪 Log Out</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

/* ---------------- Small presentational helpers ---------------- */

const LabeledInput = ({
  label,
  value,
  onChangeText,
  editable,
  placeholder,
  keyboardType,
  autoCapitalize,
}: {
  label: string;
  value: string;
  onChangeText: (t: string) => void;
  editable: boolean;
  placeholder?: string;
  keyboardType?: 'default' | 'email-address' | 'numeric' | 'phone-pad';
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
}) => (
  <View style={styles.inputGroup}>
    <Text style={styles.inputLabel}>{label}</Text>
    <TextInput
      style={[styles.input, !editable && styles.inputDisabled]}
      value={value}
      onChangeText={onChangeText}
      editable={editable}
      placeholder={placeholder}
      placeholderTextColor="#87CEEB"
      keyboardType={keyboardType}
      autoCapitalize={autoCapitalize}
    />
  </View>
);

const StatusBadge = ({
  label,
  ok,
  okText,
  noText,
}: {
  label: string;
  ok: boolean;
  okText: string;
  noText: string;
}) => (
  <View style={styles.badge}>
    <Text style={styles.badgeLabel}>{label}</Text>
    <View style={[styles.badgePill, { backgroundColor: ok ? '#10B981' : '#F59E0B' }]}>
      <Text style={styles.badgePillText}>{ok ? okText : noText}</Text>
    </View>
  </View>
);

const InfoRow = ({ label, value }: { label: string; value: string }) => (
  <View style={styles.accountInfoRow}>
    <Text style={styles.accountInfoLabel}>{label}:</Text>
    <Text style={styles.accountInfoValue} numberOfLines={1}>{value}</Text>
  </View>
);

/* ---------------- Styles ---------------- */

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    backgroundColor: '#1E3A8A',
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backButton: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  logoutGlyph: {
    color: '#87CEEB',
    fontSize: 20,
  },
  scrollContainer: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  profileSection: {
    alignItems: 'center',
    marginBottom: 30,
  },
  profileImageContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#1E3A8A',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 3,
    borderColor: '#87CEEB',
    position: 'relative',
  },
  profileImage: {
    width: 94,
    height: 94,
    borderRadius: 47,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInitial: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0A1929',
  },
  uploadOverlay: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#87CEEB',
    borderRadius: 15,
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  uploadText: {
    fontSize: 16,
    color: '#0A1929',
  },
  profileName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 5,
  },
  profileStatus: {
    fontSize: 16,
    color: '#87CEEB',
  },

  section: {
    marginBottom: 30,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#87CEEB',
  },
  editButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 8,
  },
  editButtonText: {
    color: '#0A1929',
    fontWeight: 'bold',
  },

  formContainer: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
  },
  inputGroup: {
    marginBottom: 15,
  },
  inputLabel: {
    fontSize: 16,
    color: '#87CEEB',
    marginBottom: 8,
    fontWeight: '600',
  },
  input: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 15,
    fontSize: 16,
    color: '#fff',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  inputDisabled: {
    opacity: 0.7,
  },
  saveButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 15,
  },
  saveButton: {
    backgroundColor: '#87CEEB',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 10,
    flex: 1,
    marginRight: 10,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#0A1929',
    fontWeight: 'bold',
  },
  cancelButton: {
    backgroundColor: '#FF6B6B',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 10,
    flex: 1,
    marginLeft: 10,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },

  badgeRow: {
    flexDirection: 'row',
    gap: 10,
    flexWrap: 'wrap',
  },
  badge: {
    backgroundColor: '#1E3A8A',
    borderRadius: 12,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  badgeLabel: {
    color: '#fff',
    fontWeight: '600',
    marginRight: 10,
  },
  badgePill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
  },
  badgePillText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 12,
  },

  accountInfoCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
  },
  accountInfoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  accountInfoLabel: {
    fontSize: 14,
    color: '#B0E0E6',
    fontWeight: '500',
    marginRight: 8,
  },
  accountInfoValue: {
    fontSize: 14,
    color: '#87CEEB',
    fontWeight: '600',
    maxWidth: '60%',
    textAlign: 'right',
  },

  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    fontSize: 20,
    marginRight: 15,
  },
  settingText: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '600',
    marginBottom: 2,
  },
  settingDescription: {
    fontSize: 14,
    color: '#B0E0E6',
  },

  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
  },
  actionIcon: {
    fontSize: 20,
    marginRight: 15,
  },
  actionText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '600',
    flex: 1,
  },
  actionArrow: {
    fontSize: 18,
    color: '#87CEEB',
  },

  logoutSection: {
    marginTop: 20,
  },
  logoutButtonLarge: {
    backgroundColor: '#FF6B6B',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  logoutButtonLargeText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});