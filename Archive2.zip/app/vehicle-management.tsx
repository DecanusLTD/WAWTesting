// app/VehicleManagement.tsx
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Modal,
  ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { supabase } from '../src/lib/supabase';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

type VehicleType =
  | 'Car' | 'SUV' | 'Van' | 'Truck' | 'Motorcycle' | 'Bicycle'
  | 'Luxury Car' | 'Sports Car' | 'Electric Car' | 'Hybrid Car';

interface VehicleRow {
  id: string;
  user_id: string;
  type: VehicleType | null;
  make: string | null;
  model: string | null;
  color: string | null;
  registration: string;
  is_default: boolean;
  photo: string | null;
  created_at: string;
  updated_at: string;
}

interface VehicleForm {
  type: VehicleType | '';
  make: string;
  model: string;
  color: string;
  registration: string;
}

// --- Options (trimmed; extend as needed) ---
const vehicleTypes: VehicleType[] = [
  'Car','SUV','Van','Truck','Motorcycle','Bicycle','Luxury Car','Sports Car','Electric Car','Hybrid Car'
];

const vehicleColors = [
  'White','Black','Silver','Gray','Red','Blue','Green','Yellow','Orange','Purple','Pink','Brown','Beige','Gold','Bronze','Navy Blue','Dark Green','Light Blue','Cream','Pearl White','Metallic Black','Chrome Silver','Gunmetal Gray','Racing Red','Electric Blue','Forest Green','Sunset Orange','Royal Purple','Rose Gold','Copper'
];

const vehicleMakesByType: Record<string, string[]> = {
  Car: ['Toyota','Honda','Ford','BMW','Mercedes-Benz','Audi','Volkswagen','Nissan','Hyundai','Kia'],
  SUV: ['Range Rover','BMW','Mercedes','Audi','Volkswagen','Toyota','Honda','Ford','Nissan','Hyundai','Kia'],
};
const vehicleModelsByMake: Record<string, string[]> = {
  Toyota: ['Corolla','Camry','Prius','RAV4','Yaris'],
  BMW: ['1 Series','3 Series','5 Series','X3','X5','i3','i4'],
};

// --- DVLA direct (you said no edge function) ---
const DVLA_API_KEY = process.env.EXPO_PUBLIC_DVLA_API_KEY; // set this in your .env
async function dvlaLookup(registrationRaw: string): Promise<Partial<VehicleForm>> {
  const registration = registrationRaw.replace(/\s+/g, '').toUpperCase();
  if (!DVLA_API_KEY) throw new Error('DVLA API key not set (EXPO_PUBLIC_DVLA_API_KEY).');

  const res = await fetch('https://driver-vehicle-licensing.api.gov.uk/vehicle-enquiry/v1/vehicles', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': DVLA_API_KEY,
    },
    body: JSON.stringify({ registrationNumber: registration }),
  });

  if (!res.ok) {
    let msg = `DVLA error ${res.status}`;
    try {
      const j = await res.json();
      if (j?.message) msg = j.message;
    } catch {}
    throw new Error(msg);
  }

  const data = await res.json();
  return {
    make: data?.make ?? '',
    model: data?.model ?? '',
    color: data?.colour ?? data?.color ?? '',
    registration,
  };
}

export default function VehicleManagement() {
  const { user } = useAuth();
  const [vehicles, setVehicles] = useState<VehicleRow[]>([]);
  const [loading, setLoading] = useState(true);

  const [showModal, setShowModal] = useState(false);
  const [flow, setFlow] = useState<'choice' | 'dvla' | 'manual'>('choice');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [dvlaLoading, setDvlaLoading] = useState(false);

  const [form, setForm] = useState<VehicleForm>({
    type: '',
    make: '',
    model: '',
    color: '',
    registration: '',
  });

  useEffect(() => {
    if (!user?.id) return;
    (async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false })
        .order('created_at', { ascending: true });
      if (error) {
        console.error(error);
        setVehicles([]);
      } else {
        setVehicles(data as VehicleRow[]);
      }
      setLoading(false);
    })();
  }, [user?.id]);

  const refresh = async () => {
    if (!user?.id) return;
    const { data, error } = await supabase
      .from('customer_vehicles')
      .select('*')
      .eq('user_id', user.id)
      .order('is_default', { ascending: false })
      .order('created_at', { ascending: true });
    if (!error && data) setVehicles(data as VehicleRow[]);
  };

  const resetForm = () => {
    setForm({ type: '', make: '', model: '', color: '', registration: '' });
    setEditingId(null);
    setFlow('choice');
  };

  const openAdd = () => {
    resetForm();
    setShowModal(true);
  };

  const openEdit = (v: VehicleRow) => {
    setEditingId(v.id);
    setForm({
      type: (v.type as VehicleType) || '',
      make: v.make || '',
      model: v.model || '',
      color: v.color || '',
      registration: v.registration || '',
    });
    setFlow('manual');
    setShowModal(true);
  };

  const saveVehicle = async () => {
    if (!user?.id) return;
    const reg = form.registration.trim().toUpperCase();
    if (!reg) {
      await hapticFeedback('medium');
      return Alert.alert('Registration required', 'Please enter a registration.');
    }
    if (!form.type) {
      await hapticFeedback('medium');
      return Alert.alert('Vehicle type required', 'Please select a vehicle type.');
    }

    setSaving(true);
    await hapticFeedback('medium');
    try {
      if (editingId) {
        const { error } = await supabase
          .from('customer_vehicles')
          .update({
            type: form.type,
            make: form.make || null,
            model: form.model || null,
            color: form.color || null,
            registration: reg,
            updated_at: new Date().toISOString(),
          })
          .eq('id', editingId)
          .eq('user_id', user.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('customer_vehicles').insert({
          user_id: user.id,
          type: form.type,
          make: form.make || null,
          model: form.model || null,
          color: form.color || null,
          registration: reg,
          is_default: vehicles.length === 0,
        });
        if (error) throw error;
      }
      await refresh();
      setShowModal(false);
      resetForm();
      await hapticFeedback('light');
      Alert.alert('Success', editingId ? 'Vehicle updated.' : 'Vehicle added.');
    } catch (e: any) {
      console.error(e);
      Alert.alert('Error', e?.message || 'Failed to save vehicle.');
    } finally {
      setSaving(false);
    }
  };

  const deleteVehicle = (id: string) => {
    Alert.alert('Delete Vehicle', 'Are you sure you want to delete this vehicle?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          await hapticFeedback('medium');
          const { error } = await supabase
            .from('customer_vehicles')
            .delete()
            .eq('id', id)
            .eq('user_id', user?.id || '');
          if (error) {
            Alert.alert('Error', error.message);
          } else {
            await refresh();
            await hapticFeedback('light');
            Alert.alert('Deleted', 'Vehicle removed.');
          }
        },
      },
    ]);
  };

  const setDefault = async (id: string) => {
    await hapticFeedback('medium');
    try {
      // Try RPC (see SQL below). If you don't create it, fallback runs.
      const { error: rpcErr } = await supabase.rpc('set_default_vehicle', {
        p_user_id: user?.id,
        p_vehicle_id: id,
      });
      if (rpcErr) {
        await supabase.from('customer_vehicles').update({ is_default: false }).eq('user_id', user?.id || '');
        const { error } = await supabase
          .from('customer_vehicles')
          .update({ is_default: true })
          .eq('id', id)
          .eq('user_id', user?.id || '');
        if (error) throw error;
      }
      await refresh();
      await hapticFeedback('light');
      Alert.alert('Updated', 'Default vehicle set.');
    } catch (e: any) {
      console.error(e);
      Alert.alert('Error', e?.message || 'Could not set default vehicle.');
    }
  };

  const doDvlaLookup = async () => {
    const reg = form.registration.trim();
    if (!reg) {
      await hapticFeedback('medium');
      return Alert.alert('Registration required', 'Enter a registration to look up.');
    }
    setDvlaLoading(true);
    try {
      const data = await dvlaLookup(reg);
      setForm(f => ({
        ...f,
        registration: data.registration || f.registration.toUpperCase(),
        make: data.make || f.make,
        model: data.model || f.model,
        color: data.color || f.color,
      }));
      await hapticFeedback('light');
      Alert.alert('Found', 'Vehicle details fetched. Please review and select type.');
      setFlow('manual'); // confirm type + any missing fields
    } catch (e: any) {
      await hapticFeedback('medium');
      Alert.alert('Lookup failed', e?.message || 'Could not fetch vehicle details for that registration.');
    } finally {
      setDvlaLoading(false);
    }
  };

  const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <View style={styles.inputGroup}>
      <Text style={styles.inputLabel}>{label}</Text>
      {children}
    </View>
  );

  const PillOptions = ({
    options, value, onSelect,
  }: { options: string[]; value: string; onSelect: (v: string) => void }) => (
    <View style={styles.pillRow}>
      {options.map(opt => (
        <TouchableOpacity
          key={opt}
          style={[styles.pill, value === opt && styles.pillSelected]}
          onPress={() => onSelect(opt)}
        >
          <Text style={[styles.pillText, value === opt && styles.pillTextSelected]}>{opt}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>My Vehicles</Text>
        <TouchableOpacity style={styles.addButton} onPress={openAdd}>
          <Text style={styles.addButtonText}>+ Add</Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <View style={styles.content}>
        {loading ? (
          <View style={[styles.emptyState, { paddingVertical: 40 }]}>
            <ActivityIndicator />
            <Text style={[styles.emptyStateText, { marginTop: 12 }]}>Loading vehicles…</Text>
          </View>
        ) : vehicles.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateIcon}>🚗</Text>
            <Text style={styles.emptyStateTitle}>No Vehicles Added</Text>
            <Text style={styles.emptyStateText}>Add your first vehicle to get started with quick bookings</Text>
            <TouchableOpacity style={styles.addFirstButton} onPress={openAdd}>
              <Text style={styles.addFirstButtonText}>Add Your First Vehicle</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <ScrollView style={styles.vehicleList}>
            {vehicles.map(v => (
              <View key={v.id} style={styles.vehicleCard}>
                <View style={styles.vehicleHeader}>
                  <View style={styles.vehicleInfo}>
                    <Text style={styles.vehicleTitle}>
                      {[v.make, v.model].filter(Boolean).join(' ') || 'Vehicle'}
                    </Text>
                    <Text style={styles.vehicleSubtitle}>
                      {[v.type, v.color, v.registration].filter(Boolean).join(' • ')}
                    </Text>
                    {v.is_default && (
                      <View style={styles.defaultBadge}>
                        <Text style={styles.defaultBadgeText}>Default</Text>
                      </View>
                    )}
                  </View>
                  <View style={styles.vehicleActions}>
                    {!v.is_default && (
                      <TouchableOpacity style={styles.actionButton} onPress={() => setDefault(v.id)}>
                        <Text style={styles.actionButtonText}>Set Default</Text>
                      </TouchableOpacity>
                    )}
                    <TouchableOpacity style={[styles.actionButton, styles.editButton]} onPress={() => openEdit(v)}>
                      <Text style={styles.actionButtonText}>Edit</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.actionButton, styles.deleteButton]} onPress={() => deleteVehicle(v.id)}>
                      <Text style={styles.actionButtonText}>Delete</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            ))}
          </ScrollView>
        )}
      </View>

      {/* Add/Edit Modal */}
      <Modal visible={showModal} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setShowModal(false)}>
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity style={styles.modalCloseButton} onPress={() => setShowModal(false)}>
              <Text style={styles.modalCloseButtonText}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>{editingId ? 'Edit Vehicle' : 'Add Vehicle'}</Text>
            <TouchableOpacity
              style={[styles.modalSaveButton, (flow === 'choice' || saving) && styles.disabledButton]}
              onPress={saveVehicle}
              disabled={flow === 'choice' || saving}
            >
              {saving ? <ActivityIndicator /> : <Text style={styles.modalSaveButtonText}>{editingId ? 'Save' : 'Add'}</Text>}
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            {/* Choice */}
            {flow === 'choice' && (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>How would you like to add your vehicle?</Text>

                <TouchableOpacity style={styles.choiceCard} onPress={() => setFlow('dvla')}>
                  <Text style={styles.choiceIcon}>🔎</Text>
                  <Text style={styles.choiceTitle}>Use registration (DVLA)</Text>
                  <Text style={styles.choiceText}>
                    Enter your reg and we’ll fetch details automatically. You can review and edit before saving.
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.choiceCard} onPress={() => setFlow('manual')}>
                  <Text style={styles.choiceIcon}>✍️</Text>
                  <Text style={styles.choiceTitle}>Enter details manually</Text>
                  <Text style={styles.choiceText}>
                    Pick type, make, model and colour, then enter your registration.
                  </Text>
                </TouchableOpacity>
              </View>
            )}

            {/* DVLA */}
            {flow === 'dvla' && (
              <View className="section">
                <Text style={styles.sectionTitle}>Lookup by Registration</Text>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Registration</Text>
                  <TextInput
                    style={styles.input}
                    value={form.registration}
                    onChangeText={(t) => setForm({ ...form, registration: t })}
                    placeholder="e.g., AB12 CDE"
                    placeholderTextColor="#9CA3AF"
                    autoCapitalize="characters"
                  />
                </View>
                <TouchableOpacity style={styles.lookupButton} onPress={doDvlaLookup} disabled={dvlaLoading}>
                  {dvlaLoading ? <ActivityIndicator /> : <Text style={styles.lookupButtonText}>Lookup</Text>}
                </TouchableOpacity>
                <Text style={styles.sectionHint}>
                  We’ll fetch make/model/colour when available. You’ll confirm the type and any missing fields next.
                </Text>
              </View>
            )}

            {/* Manual / Post-DVLA confirm */}
            {flow === 'manual' && (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Vehicle Details</Text>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Vehicle Type</Text>
                  <PillOptions
                    options={vehicleTypes}
                    value={form.type}
                    onSelect={(v) => setForm({ ...form, type: v as VehicleType })}
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Make</Text>
                  <PillOptions
                    options={vehicleMakesByType[form.type] || []}
                    value={form.make}
                    onSelect={(v) => setForm({ ...form, make: v })}
                  />
                  <TextInput
                    style={[styles.input, { marginTop: 8 }]}
                    value={form.make}
                    onChangeText={(t) => setForm({ ...form, make: t })}
                    placeholder="Or type a make"
                    placeholderTextColor="#9CA3AF"
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Model</Text>
                  <PillOptions
                    options={vehicleModelsByMake[form.make] || []}
                    value={form.model}
                    onSelect={(v) => setForm({ ...form, model: v })}
                  />
                  <TextInput
                    style={[styles.input, { marginTop: 8 }]}
                    value={form.model}
                    onChangeText={(t) => setForm({ ...form, model: t })}
                    placeholder="Or type a model"
                    placeholderTextColor="#9CA3AF"
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Color (optional)</Text>
                  <PillOptions
                    options={vehicleColors}
                    value={form.color}
                    onSelect={(v) => setForm({ ...form, color: v })}
                  />
                  <TextInput
                    style={[styles.input, { marginTop: 8 }]}
                    value={form.color}
                    onChangeText={(t) => setForm({ ...form, color: t })}
                    placeholder="Or type a color"
                    placeholderTextColor="#9CA3AF"
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Registration</Text>
                  <TextInput
                    style={styles.input}
                    value={form.registration}
                    onChangeText={(t) => setForm({ ...form, registration: t })}
                    placeholder="e.g., AB12 CDE"
                    placeholderTextColor="#9CA3AF"
                    autoCapitalize="characters"
                  />
                </View>
              </View>
            )}
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 20, backgroundColor: '#1E3A8A',
  },
  backButton: { padding: 8 },
  backButtonText: { color: '#87CEEB', fontSize: 16 },
  headerTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: 'bold' },
  addButton: { backgroundColor: '#10B981', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 },
  addButtonText: { color: '#FFFFFF', fontSize: 14, fontWeight: '600' },
  content: { flex: 1, padding: 20 },

  emptyState: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: 60 },
  emptyStateIcon: { fontSize: 60, marginBottom: 20 },
  emptyStateTitle: { color: '#F9FAFB', fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  emptyStateText: { color: '#87CEEB', fontSize: 16, textAlign: 'center', marginBottom: 30 },
  addFirstButton: { backgroundColor: '#10B981', paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 },
  addFirstButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },

  vehicleList: { flex: 1 },
  vehicleCard: { backgroundColor: '#1E3A8A', borderRadius: 12, padding: 16, marginBottom: 16 },
  vehicleHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 },
  vehicleInfo: { flex: 1 },
  vehicleTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: 'bold', marginBottom: 4 },
  vehicleSubtitle: { color: '#87CEEB', fontSize: 14, marginBottom: 4 },
  vehicleActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  defaultBadge: { backgroundColor: '#10B981', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, alignSelf: 'flex-start', marginTop: 6 },
  defaultBadgeText: { color: '#FFFFFF', fontSize: 10, fontWeight: '600' },
  actionButton: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)', borderRadius: 8, paddingVertical: 8, paddingHorizontal: 12,
    alignItems: 'center', borderWidth: 1, borderColor: 'transparent',
  },
  actionButtonText: { color: '#87CEEB', fontSize: 14, fontWeight: '600' },
  editButton: { backgroundColor: 'rgba(135, 206, 235, 0.1)', borderColor: '#87CEEB' },
  deleteButton: { backgroundColor: 'rgba(239, 68, 68, 0.1)', borderColor: '#EF4444' },

  modalContainer: { flex: 1, backgroundColor: '#0A1929' },
  modalHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 20, backgroundColor: '#1E3A8A',
  },
  modalCloseButton: { padding: 8 },
  modalCloseButtonText: { color: '#87CEEB', fontSize: 16 },
  modalTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: 'bold' },
  modalSaveButton: { backgroundColor: '#10B981', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 },
  modalSaveButtonText: { color: '#FFFFFF', fontSize: 14, fontWeight: '600' },
  disabledButton: { opacity: 0.5 },

  modalContent: { flex: 1, padding: 20 },

  section: { marginBottom: 30 },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: 'bold', marginBottom: 16 },
  sectionHint: { color: '#87CEEB', fontSize: 12, marginTop: 12 },

  inputGroup: { marginBottom: 16 },
  inputLabel: { color: '#F9FAFB', fontSize: 14, fontWeight: '600', marginBottom: 8 },
  input: {
    backgroundColor: '#1E3A8A', borderRadius: 8, padding: 12, color: '#F9FAFB',
    fontSize: 16, borderWidth: 1, borderColor: '#3B82F6',
  },

  pillRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  pill: {
    paddingVertical: 8, paddingHorizontal: 12, borderRadius: 9999,
    borderWidth: 1, borderColor: 'rgba(135,206,235,0.4)',
  },
  pillSelected: { backgroundColor: 'rgba(135,206,235,0.2)', borderColor: '#87CEEB' },
  pillText: { color: '#B0E0E6', fontSize: 13 },
  pillTextSelected: { color: '#F9FAFB' },

  choiceCard: {
    backgroundColor: '#1E3A8A', borderRadius: 12, padding: 16, marginBottom: 12,
    borderWidth: 1, borderColor: 'rgba(135,206,235,0.35)',
  },
  choiceIcon: { fontSize: 22, marginBottom: 6 },
  choiceTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', marginBottom: 4 },
  choiceText: { color: '#87CEEB', fontSize: 13 },

  lookupButton: {
    marginTop: 10, backgroundColor: '#2563EB', paddingVertical: 10, borderRadius: 8, alignItems: 'center',
  },
  lookupButtonText: { color: '#FFFFFF', fontSize: 14, fontWeight: '600' },
});