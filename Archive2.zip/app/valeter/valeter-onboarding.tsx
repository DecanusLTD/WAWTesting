import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Animated,
  Dimensions,
  ScrollView,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';

const { width, height } = Dimensions.get('window');

export default function ValeterOnboarding() {
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(0);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;



  const steps = [
    {
      title: "Welcome to the Wish a Wash Team! 👨‍🔧✨",
      subtitle: "Your professional valeting journey begins here",
      description: "You're now part of an elite network of professional valeters. Get ready to build your business and deliver exceptional service to customers.",
      icon: "🌟",
      color: "#10B981"
    },
    {
      title: "Flexible Work, Maximum Earnings 💰",
      subtitle: "Work when you want, earn what you deserve",
      description: "Set your own schedule, choose your working area, and keep up to 85% of your earnings. Build your business on your terms.",
      icon: "💰",
      color: "#F59E0B"
    },
    {
      title: "Professional Tools & Support 🛠️",
      subtitle: "Everything you need to succeed",
      description: "Access to professional equipment, training resources, and dedicated support. We're here to help you grow your valeting business.",
      icon: "🛠️",
      color: "#3B82F6"
    },
    {
      title: "Build Your Reputation ⭐",
      subtitle: "Earn reviews and grow your customer base",
      description: "Every satisfied customer helps build your reputation. Great reviews lead to more bookings and higher earnings potential.",
      icon: "⭐",
      color: "#8B5CF6"
    },
    {
      title: "Rewards & Recognition 🏆",
      subtitle: "Earn points and unlock exclusive benefits",
      description: "Complete washes, earn positive reviews, and unlock rewards like equipment upgrades, training courses, and priority support.",
      icon: "🏆",
      color: "#EF4444"
    },
    {
      title: "You're Ready to Start! 🚀",
      subtitle: "Your professional journey awaits",
      description: "Your account is set up and ready! Go online to start accepting bookings and begin your journey as a Wish a Wash professional.",
      icon: "🚀",
      color: "#10B981"
    }
  ];

  useEffect(() => {
    animateStep();
  }, [currentStep]);

  const animateStep = () => {
    fadeAnim.setValue(0);
    slideAnim.setValue(50);

    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const completeOnboarding = async () => {
    try {
      // Mark valeter onboarding as seen
      await AsyncStorage.setItem('valeter_onboarding_seen', 'true');
      router.replace('driver/driver-dashboard');
    } catch (error) {
      console.error('Error marking onboarding as seen:', error);
      router.replace('driver/driver-dashboard');
    }
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Complete onboarding
      completeOnboarding();
    }
  };

  const skipOnboarding = () => {
    completeOnboarding();
  };

  const currentStepData = steps[currentStep];

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={skipOnboarding} style={styles.skipButton}>
          <Text style={styles.skipText}>Skip</Text>
        </TouchableOpacity>
        
        <View style={styles.progressContainer}>
          {steps.map((_, index) => (
            <View
              key={index}
              style={[
                styles.progressDot,
                index === currentStep && styles.progressDotActive,
                index < currentStep && styles.progressDotCompleted
              ]}
            />
          ))}
        </View>
        
        <View style={styles.placeholder} />
      </View>

      {/* Content */}
      <View style={styles.content}>
        <Animated.View
          style={[
            styles.stepContainer,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <View style={styles.iconContainer}>
            <Text style={styles.stepIcon}>{currentStepData.icon}</Text>
          </View>

          <Text style={styles.stepTitle}>{currentStepData.title}</Text>
          <Text style={styles.stepSubtitle}>{currentStepData.subtitle}</Text>
          
          <Text style={styles.stepDescription}>{currentStepData.description}</Text>

          {/* Step-specific content */}
          {currentStep === 0 && (
            <View style={styles.welcomeCard}>
              <Text style={styles.welcomeText}>
                Hello, {user?.name || 'Professional Valeter'}! 👋
              </Text>
              <Text style={styles.welcomeSubtext}>
                Welcome to the most trusted valeting network in the UK.
              </Text>
            </View>
          )}

          {currentStep === 1 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Your Benefits:</Text>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>⏰</Text>
                <Text style={styles.featureText}>Set your own schedule</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>📍</Text>
                <Text style={styles.featureText}>Choose your working area</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>💸</Text>
                <Text style={styles.featureText}>Keep 85% of earnings</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>💰</Text>
                <Text style={styles.featureText}>Receive tips directly</Text>
              </View>
            </View>
          )}

          {currentStep === 2 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Professional Support:</Text>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>🛠️</Text>
                <Text style={styles.featureText}>Equipment recommendations</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>📚</Text>
                <Text style={styles.featureText}>Training resources</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>🎯</Text>
                <Text style={styles.featureText}>Dedicated support team</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>🛡️</Text>
                <Text style={styles.featureText}>Insurance guidance</Text>
              </View>
            </View>
          )}

          {currentStep === 3 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Build Your Business:</Text>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>⭐</Text>
                <Text style={styles.featureText}>Customer reviews & ratings</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>📈</Text>
                <Text style={styles.featureText}>Performance analytics</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>👥</Text>
                <Text style={styles.featureText}>Growing customer base</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>🏆</Text>
                <Text style={styles.featureText}>Professional certification</Text>
              </View>
            </View>
          )}

          {currentStep === 4 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Earn Rewards:</Text>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>🎁</Text>
                <Text style={styles.featureText}>Equipment upgrades</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>📚</Text>
                <Text style={styles.featureText}>Advanced training courses</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>🎯</Text>
                <Text style={styles.featureText}>Priority support access</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>🤝</Text>
                <Text style={styles.featureText}>Networking events</Text>
              </View>
            </View>
          )}

          {currentStep === 5 && (
            <View style={styles.finalCard}>
              <Text style={styles.finalTitle}>Ready to Go Online?</Text>
              <Text style={styles.finalText}>
                Your professional valeting business is ready to launch. Start accepting bookings and building your reputation today!
              </Text>
            </View>
          )}
        </Animated.View>
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.nextButton}
          onPress={nextStep}
        >
          <Text style={styles.nextButtonText}>
            {currentStep === steps.length - 1 ? 'Start Working' : 'Next'}
          </Text>
        </TouchableOpacity>
        

      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
  },
  skipButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  skipText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  progressDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    marginHorizontal: 4,
  },
  progressDotActive: {
    backgroundColor: '#FFFFFF',
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  progressDotCompleted: {
    backgroundColor: '#10B981',
  },
  placeholder: {
    width: 60,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 30,
  },
  stepContainer: {
    alignItems: 'center',
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 40,
  },
  stepIcon: {
    fontSize: 60,
  },
  stepTitle: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 12,
    lineHeight: 36,
  },
  stepSubtitle: {
    color: '#87CEEB',
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 24,
    fontWeight: '600',
  },
  stepDescription: {
    color: '#FFFFFF',
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 40,
    opacity: 0.9,
  },
  welcomeCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 24,
    marginTop: 20,
    alignItems: 'center',
  },
  welcomeText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  welcomeSubtext: {
    color: '#87CEEB',
    fontSize: 16,
    textAlign: 'center',
  },
  featureCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 24,
    marginTop: 20,
    width: '100%',
  },
  featureTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  featureIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  featureText: {
    color: '#FFFFFF',
    fontSize: 16,
    flex: 1,
  },
  finalCard: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
    borderWidth: 1,
    borderColor: '#4CAF50',
    borderRadius: 16,
    padding: 24,
    marginTop: 20,
    alignItems: 'center',
  },
  finalTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  finalText: {
    color: '#FFFFFF',
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
  },
  footer: {
    paddingHorizontal: 30,
    paddingBottom: 60,
  },
  nextButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  nextButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
