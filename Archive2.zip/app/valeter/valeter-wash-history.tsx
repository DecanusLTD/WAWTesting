// app/valeter/wash-history.tsx (or wherever this screen lives)
import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView,
  StatusBar, ActivityIndicator, Alert, RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';

type BookingRow = {
  id: string;
  status: 'scheduled' | 'valeter_assigned' | 'en_route' | 'arrived' | 'in_progress' | 'completed' | 'cancelled';
  service_type: string;
  price: number | null;
  location_address: string | null;
  updated_at: string | null;
  completed_at?: string | null;        // optional column
  rating?: number | null;              // optional
  tip_amount?: number | null;          // optional
  customer_review?: string | null;     // optional
};

const PAGE_SIZE = 25;

export default function ValeterWashHistoryScreen() {
  const { user } = useAuth();

  const [rows, setRows] = useState<BookingRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);

  const [stats, setStats] = useState({
    totalWashes: 0,
    totalTips: 0,
    averageRating: 0,
    totalEarnings: 0,
  });

  useEffect(() => {
    if (!user) return;
    freshLoad();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const freshLoad = async () => {
    setLoading(true);
    setPage(0);
    setHasMore(true);
    try {
      const first = await fetchPage(0);
      setRows(first);
      setHasMore(first.length === PAGE_SIZE);
      recomputeStats(first);
    } catch (e) {
      console.error('load error', e);
      Alert.alert('Error', 'Failed to load wash history');
    } finally {
      setLoading(false);
    }
  };

  const fetchPage = async (pageIndex: number) => {
    if (!user) return [];
    const from = pageIndex * PAGE_SIZE;
    const to = from + PAGE_SIZE - 1;

    // Select explicit columns; optional ones included safely
    const { data, error } = await supabase
      .from('bookings')
      .select('id,status,service_type,price,location_address,updated_at,completed_at,rating,tip_amount,customer_review')
      .eq('valeter_id', user.id)
      .eq('status', 'completed')
      .order('completed_at', { ascending: false, nullsFirst: false })
      .order('updated_at', { ascending: false, nullsFirst: false })
      .range(from, to);

    if (error) throw error;
    return (data ?? []) as BookingRow[];
  };

  const onRefresh = useCallback(async () => {
    if (!user) return;
    setRefreshing(true);
    try {
      const first = await fetchPage(0);
      setRows(first);
      setPage(0);
      setHasMore(first.length === PAGE_SIZE);
      recomputeStats(first);
    } catch (e) {
      console.error('refresh error', e);
    } finally {
      setRefreshing(false);
    }
  }, [user?.id]);

  const onLoadMore = async () => {
    if (loadingMore || !hasMore) return;
    setLoadingMore(true);
    try {
      const nextPage = page + 1;
      const next = await fetchPage(nextPage);
      setRows(prev => {
        const seen = new Set(prev.map(p => p.id));
        const merged = [...prev];
        next.forEach(r => { if (!seen.has(r.id)) merged.push(r); });
        return merged;
      });
      setPage(nextPage);
      setHasMore(next.length === PAGE_SIZE);
      recomputeStats(); // on merged rows
    } catch (e) {
      console.error('load more error', e);
    } finally {
      setLoadingMore(false);
    }
  };

  const recomputeStats = (known?: BookingRow[]) => {
    const list = known ?? rows;
    const totalWashes = list.length;
    const tips = list.reduce((sum, r) => sum + (Number(r.tip_amount ?? 0) || 0), 0);
    const rated = list.filter(r => typeof r.rating === 'number');
    const avgRating = rated.length
      ? rated.reduce((s, r) => s + (r.rating as number), 0) / rated.length
      : 0;

    // Earnings: if you pay per booking price + tips; fallback to £25 base
    const washEarnings = list.reduce((sum, r) => sum + (Number(r.price ?? 0) || 25), 0);
    const totalEarnings = washEarnings + tips;

    setStats({
      totalWashes,
      totalTips: tips,
      averageRating: avgRating,
      totalEarnings,
    });
  };

  const formatDate = (dateLike?: string | null) => {
    const d = dateLike ? new Date(dateLike) : null;
    return (d ?? new Date()).toLocaleString('en-GB', {
      day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false,
    });
  };

  const getRatingText = (rating?: number | null) => {
    switch (rating) {
      case 1: return 'Poor';
      case 2: return 'Fair';
      case 3: return 'Good';
      case 4: return 'Very Good';
      case 5: return 'Excellent';
      default: return 'Not Rated';
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FFFFFF" />
        <Text style={styles.loadingText}>Loading wash history...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Your Washes</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#fff" />}
        onMomentumScrollEnd={async (e: any) => {
          const target = e.nativeEvent;
          const bottom = target.contentOffset.y + target.layoutMeasurement.height >= target.contentSize.height - 64;
          if (bottom) await onLoadMore();
        }}
      >
        {rows.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyIcon}>🧽</Text>
            <Text style={styles.emptyTitle}>No Wash History</Text>
            <Text style={styles.emptyText}>
              You haven’t completed any washes yet. They’ll appear here once you finish a job.
            </Text>
          </View>
        ) : (
          <>
            <View style={styles.statsContainer}>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{stats.totalWashes}</Text>
                <Text style={styles.statLabel}>Total Washes</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>£{stats.totalTips}</Text>
                <Text style={styles.statLabel}>Total Tips</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{stats.averageRating.toFixed(1)}</Text>
                <Text style={styles.statLabel}>Avg Rating</Text>
              </View>
            </View>

            <View style={styles.earningsCard}>
              <Text style={styles.earningsTitle}>💰 Total Earnings</Text>
              <Text style={styles.earningsAmount}>£{stats.totalEarnings}</Text>
              <Text style={styles.earningsBreakdown}>
                (price or £25 base) × {stats.totalWashes} + tips
              </Text>
            </View>

            <Text style={styles.sectionTitle}>Completed washes</Text>

            {rows.map((b) => (
              <View key={b.id} style={styles.washCard}>
                <View style={styles.washHeader}>
                  <View style={styles.washInfo}>
                    <Text style={styles.washDate}>
                      {formatDate(b.completed_at ?? b.updated_at)}
                    </Text>
                    <Text style={styles.washId}>#{b.id.slice(-6)}</Text>
                  </View>
                  <View style={styles.washStatus}>
                    <Text style={styles.statusCompleted}>Completed</Text>
                  </View>
                </View>

                <View style={{ marginBottom: 8 }}>
                  <Text style={{ color: '#87CEEB', fontSize: 12 }}>
                    {b.location_address || '—'}
                  </Text>
                  <Text style={{ color: '#FFFFFF', marginTop: 4 }}>
                    {b.service_type} • £{Number(b.price ?? 25).toFixed(2)}
                  </Text>
                </View>

                <View style={styles.ratingContainer}>
                  <View style={styles.ratingInfo}>
                    <Text style={styles.ratingStars}>{'⭐'.repeat(b.rating || 0)}</Text>
                    <Text style={styles.ratingText}>{getRatingText(b.rating)}</Text>
                  </View>
                  {b.customer_review ? (
                    <Text style={styles.reviewText}>"{b.customer_review}"</Text>
                  ) : null}
                  {!!b.tip_amount && b.tip_amount > 0 ? (
                    <View style={styles.tipContainer}>
                      <Text style={styles.tipIcon}>💰</Text>
                      <Text style={styles.tipText}>£{b.tip_amount} tip received</Text>
                    </View>
                  ) : null}
                </View>
              </View>
            ))}

            {hasMore && (
              <View style={{ alignItems: 'center', marginTop: 8, marginBottom: 24 }}>
                {loadingMore ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <TouchableOpacity style={styles.loadMoreBtn} onPress={onLoadMore}>
                    <Text style={styles.loadMoreText}>Load more</Text>
                  </TouchableOpacity>
                )}
              </View>
            )}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

/* ---------------- styles ---------------- */
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  loadingContainer: { flex: 1, backgroundColor: '#0A1929', justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: '#FFFFFF', fontSize: 16, marginTop: 16 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: 20, paddingBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)', borderBottomColor: 'rgba(255, 255, 255, 0.2)', borderBottomWidth: 1,
  },
  backButton: { paddingVertical: 8, paddingHorizontal: 12 },
  backButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
  headerTitle: { color: '#FFFFFF', fontSize: 20, fontWeight: 'bold', textAlign: 'center' },
  placeholder: { width: 60 },
  content: { flex: 1, paddingHorizontal: 20 },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: 60 },
  emptyIcon: { fontSize: 64, marginBottom: 16 },
  emptyTitle: { color: '#FFFFFF', fontSize: 24, fontWeight: 'bold', marginBottom: 8 },
  emptyText: { color: '#87CEEB', fontSize: 16, textAlign: 'center', marginBottom: 32, paddingHorizontal: 20 },
  statsContainer: { flexDirection: 'row', justifyContent: 'space-between', marginVertical: 20 },
  statCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)', borderRadius: 12, padding: 16, alignItems: 'center', flex: 1, marginHorizontal: 4,
  },
  statNumber: { color: '#FFFFFF', fontSize: 20, fontWeight: 'bold', marginBottom: 4 },
  statLabel: { color: '#87CEEB', fontSize: 12 },
  earningsCard: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)', borderWidth: 1, borderColor: '#4CAF50',
    borderRadius: 12, padding: 20, marginBottom: 20, alignItems: 'center',
  },
  earningsTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: '600', marginBottom: 8 },
  earningsAmount: { color: '#4CAF50', fontSize: 32, fontWeight: 'bold', marginBottom: 4 },
  earningsBreakdown: { color: '#87CEEB', fontSize: 14, textAlign: 'center' },
  sectionTitle: { color: '#FFFFFF', fontSize: 20, fontWeight: 'bold', marginVertical: 20 },
  washCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)', borderRadius: 12, padding: 16, marginBottom: 16,
    borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  washHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  washInfo: { flex: 1 },
  washDate: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
  washId: { color: '#87CEEB', fontSize: 12, marginTop: 2 },
  washStatus: { alignItems: 'flex-end' },
  statusCompleted: { color: '#4CAF50', fontSize: 12, fontWeight: '600' },
  statusRated: { color: '#FFD700', fontSize: 12, fontWeight: '600' },
  statusTipped: { color: '#10B981', fontSize: 12, fontWeight: '600' },
  notesContainer: { backgroundColor: 'rgba(255, 255, 255, 0.05)', borderRadius: 8, padding: 12, marginBottom: 12 },
  notesTitle: { color: '#FFFFFF', fontSize: 14, fontWeight: '600', marginBottom: 4 },
  notesText: { color: '#87CEEB', fontSize: 14, lineHeight: 20 },
  photosContainer: { marginBottom: 12 },
  photosTitle: { color: '#FFFFFF', fontSize: 14, fontWeight: '600', marginBottom: 8 },
  photoContainer: { marginRight: 8 },
  photoPlaceholder: {
    width: 80, height: 80, backgroundColor: 'rgba(255, 255, 255, 0.1)', borderRadius: 8, alignItems: 'center',
    justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  photoPlaceholderText: { fontSize: 20, marginBottom: 2 },
  photoPlaceholderLabel: { color: '#87CEEB', fontSize: 10 },
  ratingContainer: { backgroundColor: 'rgba(255, 255, 255, 0.05)', borderRadius: 8, padding: 12 },
  ratingInfo: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  ratingStars: { fontSize: 16, marginRight: 8 },
  ratingText: { color: '#FFFFFF', fontSize: 14, fontWeight: '600' },
  reviewText: { color: '#87CEEB', fontSize: 14, fontStyle: 'italic', marginBottom: 8 },
  tipContainer: { flexDirection: 'row', alignItems: 'center' },
  tipIcon: { fontSize: 16, marginRight: 4 },
  tipText: { color: '#10B981', fontSize: 14, fontWeight: '600' },
  loadMoreBtn: {
    backgroundColor: 'rgba(255,255,255,0.12)', borderColor: 'rgba(255,255,255,0.3)', borderWidth: 1,
    paddingVertical: 10, paddingHorizontal: 16, borderRadius: 8,
  },
  loadMoreText: { color: '#fff', fontWeight: '600' },
});