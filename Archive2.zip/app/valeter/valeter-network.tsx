import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  TextInput,
  FlatList,
  Modal,
  Linking,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';

interface ValeterContact {
  id: string;
  name: string;
  email: string;
  phone: string;
  rating: number;
  jobsCompleted: number;
  specializations: string[];
  isOnline: boolean;
  lastSeen: string;
  isConnected: boolean;
  location: string;
  jointValets: number;
  availability: string;
}

export default function ValeterNetwork() {
  const router = useRouter();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'online' | 'connected' | 'joint'>('all');
  const [valeters, setValeters] = useState<ValeterContact[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [emailSearch, setEmailSearch] = useState('');
  const [phoneSearch, setPhoneSearch] = useState('');
  const [showJointValetModal, setShowJointValetModal] = useState(false);
  const [selectedValeter, setSelectedValeter] = useState<ValeterContact | null>(null);

  useEffect(() => {
    loadValeterNetwork();
  }, []);

  const loadValeterNetwork = () => {
    // Simulate valeter network data
    const mockValeters: ValeterContact[] = [
      {
        id: '1',
        name: 'John Smith',
        email: 'john.smith@email.com',
        phone: '+44 7700 900123',
        rating: 4.8,
        jobsCompleted: 156,
        specializations: ['Luxury Cars', 'Interior Detailing'],
        isOnline: true,
        lastSeen: '2 minutes ago',
        isConnected: true,
        location: 'Central London',
        jointValets: 12,
        availability: 'Weekdays 9AM-6PM',
      },
      {
        id: '2',
        name: 'Sarah Johnson',
        email: 'sarah.j@email.com',
        phone: '+44 7700 900456',
        rating: 4.9,
        jobsCompleted: 203,
        specializations: ['Exterior Wash', 'Waxing'],
        isOnline: true,
        lastSeen: '5 minutes ago',
        isConnected: false,
        location: 'West London',
        jointValets: 8,
        availability: 'Weekends & Evenings',
      },
      {
        id: '3',
        name: 'Mike Wilson',
        email: 'mike.wilson@email.com',
        phone: '+44 7700 900789',
        rating: 4.7,
        jobsCompleted: 89,
        specializations: ['Quick Wash', 'Tire Shine'],
        isOnline: false,
        lastSeen: '1 hour ago',
        isConnected: true,
        location: 'East London',
        jointValets: 5,
        availability: 'Flexible Hours',
      },
      {
        id: '4',
        name: 'Emma Davis',
        email: 'emma.davis@email.com',
        phone: '+44 7700 900012',
        rating: 4.6,
        jobsCompleted: 134,
        specializations: ['Full Valet', 'Ceramic Coating'],
        isOnline: true,
        lastSeen: '10 minutes ago',
        isConnected: false,
        location: 'North London',
        jointValets: 15,
        availability: 'Full Time',
      },
      {
        id: '5',
        name: 'David Brown',
        email: 'david.brown@email.com',
        phone: '+44 7700 900345',
        rating: 4.5,
        jobsCompleted: 67,
        specializations: ['Standard Wash', 'Interior Clean'],
        isOnline: false,
        lastSeen: '3 hours ago',
        isConnected: false,
        location: 'South London',
        jointValets: 3,
        availability: 'Part Time',
      },
    ];

    setValeters(mockValeters);
  };

  const filteredValeters = valeters.filter(valeter => {
    const matchesSearch = valeter.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (selectedFilter === 'online') {
      return matchesSearch && valeter.isOnline;
    } else if (selectedFilter === 'connected') {
      return matchesSearch && valeter.isConnected;
    } else if (selectedFilter === 'joint') {
      return matchesSearch && valeter.jointValets > 0;
    }
    
    return matchesSearch;
  });

  const handleConnect = (valeterId: string) => {
    setValeters(prev => 
      prev.map(v => 
        v.id === valeterId ? { ...v, isConnected: true } : v
      )
    );
    Alert.alert('Connected!', 'You are now connected with this valeter.');
  };

  const handleDisconnect = (valeterId: string) => {
    Alert.alert(
      'Disconnect',
      'Are you sure you want to disconnect from this valeter?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Disconnect',
          style: 'destructive',
          onPress: () => {
            setValeters(prev => 
              prev.map(v => 
                v.id === valeterId ? { ...v, isConnected: false } : v
              )
            );
          }
        }
      ]
    );
  };

  const handleMessage = (valeter: ValeterContact) => {
    Alert.alert('Message', `This would open a chat with ${valeter.name}`);
  };

  const handleViewProfile = (valeter: ValeterContact) => {
    Alert.alert('Profile', `This would show ${valeter.name}'s detailed profile`);
  };

  const handleJointValet = async (valeter: ValeterContact) => {
    try {
      await hapticFeedback('medium');
      setSelectedValeter(valeter);
      setShowJointValetModal(true);
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleCall = async (phone: string) => {
    try {
      await hapticFeedback('light');
      const url = `tel:${phone}`;
      const supported = await Linking.canOpenURL(url);
      
      if (supported) {
        await Linking.openURL(url);
      } else {
        Alert.alert('Error', 'Phone calls are not supported on this device');
      }
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleEmail = async (email: string) => {
    try {
      await hapticFeedback('light');
      const url = `mailto:${email}`;
      const supported = await Linking.canOpenURL(url);
      
      if (supported) {
        await Linking.openURL(url);
      } else {
        Alert.alert('Error', 'Email is not supported on this device');
      }
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleSearchByEmail = async () => {
    try {
      await hapticFeedback('medium');
      if (!emailSearch.trim()) {
        Alert.alert('Error', 'Please enter an email address');
        return;
      }
      
      // Simulate searching for valeter by email
      const foundValeter = valeters.find(v => 
        v.email.toLowerCase().includes(emailSearch.toLowerCase())
      );
      
      if (foundValeter) {
        Alert.alert(
          'Valeter Found',
          `Found ${foundValeter.name} (${foundValeter.email})`,
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Connect', onPress: () => handleConnect(foundValeter.id) }
          ]
        );
      } else {
        Alert.alert('Not Found', 'No valeter found with this email address');
      }
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleSearchByPhone = async () => {
    try {
      await hapticFeedback('medium');
      if (!phoneSearch.trim()) {
        Alert.alert('Error', 'Please enter a phone number');
        return;
      }
      
      // Simulate searching for valeter by phone
      const foundValeter = valeters.find(v => 
        v.phone.includes(phoneSearch.replace(/\s/g, ''))
      );
      
      if (foundValeter) {
        Alert.alert(
          'Valeter Found',
          `Found ${foundValeter.name} (${foundValeter.phone})`,
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Connect', onPress: () => handleConnect(foundValeter.id) }
          ]
        );
      } else {
        Alert.alert('Not Found', 'No valeter found with this phone number');
      }
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const initiateJointValet = async () => {
    if (!selectedValeter) return;
    
    try {
      await hapticFeedback('medium');
      Alert.alert(
        'Joint Valet Request',
        `Send joint valet request to ${selectedValeter.name}?`,
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Send Request', 
            onPress: () => {
              Alert.alert(
                'Request Sent',
                `Joint valet request sent to ${selectedValeter.name}. They will be notified and can accept or decline.`
              );
              setShowJointValetModal(false);
            }
          }
        ]
      );
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const renderValeterCard = ({ item }: { item: ValeterContact }) => (
    <View style={styles.valeterCard}>
      <View style={styles.valeterHeader}>
        <View style={styles.valeterInfo}>
          <Text style={styles.valeterName}>{item.name}</Text>
          <View style={styles.ratingContainer}>
            <Text style={styles.ratingText}>⭐ {item.rating}</Text>
            <Text style={styles.jobsText}>• {item.jobsCompleted} jobs</Text>
            <Text style={styles.jointValetsText}>• {item.jointValets} joint valets</Text>
          </View>
          <Text style={styles.locationText}>📍 {item.location}</Text>
          <Text style={styles.availabilityText}>⏰ {item.availability}</Text>
        </View>
        <View style={styles.statusContainer}>
          <View style={[
            styles.onlineIndicator,
            { backgroundColor: item.isOnline ? '#4CAF50' : '#666' }
          ]} />
          <Text style={styles.statusText}>
            {item.isOnline ? 'Online' : item.lastSeen}
          </Text>
        </View>
      </View>

      <View style={styles.specializationsContainer}>
        {item.specializations.map((spec, index) => (
          <View key={index} style={styles.specializationTag}>
            <Text style={styles.specializationText}>{spec}</Text>
          </View>
        ))}
      </View>

      <View style={styles.contactButtons}>
        <TouchableOpacity
          style={[styles.contactButton, styles.callButton]}
          onPress={() => handleCall(item.phone)}
        >
          <Text style={styles.contactButtonText}>📞 Call</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.contactButton, styles.emailButton]}
          onPress={() => handleEmail(item.email)}
        >
          <Text style={styles.contactButtonText}>📧 Email</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.actionButtons}>
        {item.isConnected ? (
          <>
            <TouchableOpacity
              style={[styles.actionButton, styles.messageButton]}
              onPress={() => handleMessage(item)}
            >
              <Text style={styles.actionButtonText}>Message</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionButton, styles.jointValetButton]}
              onPress={() => handleJointValet(item)}
            >
              <Text style={styles.actionButtonText}>🤝 Joint Valet</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionButton, styles.disconnectButton]}
              onPress={() => handleDisconnect(item.id)}
            >
              <Text style={styles.actionButtonText}>Disconnect</Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            <TouchableOpacity
              style={[styles.actionButton, styles.connectButton]}
              onPress={() => handleConnect(item.id)}
            >
              <Text style={styles.actionButtonText}>Connect</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionButton, styles.jointValetButton]}
              onPress={() => handleJointValet(item)}
            >
              <Text style={styles.actionButtonText}>🤝 Joint Valet</Text>
            </TouchableOpacity>
          </>
        )}
        
        <TouchableOpacity
          style={[styles.actionButton, styles.profileButton]}
          onPress={() => handleViewProfile(item)}
        >
          <Text style={styles.actionButtonText}>View Profile</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Network</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <TextInput
            style={styles.searchInput}
            placeholder="Search valeters..."
            placeholderTextColor="#87CEEB"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {/* Add Valeter Button */}
        <View style={styles.addValeterContainer}>
          <TouchableOpacity
            style={styles.addValeterButton}
            onPress={() => setShowAddModal(true)}
          >
            <LinearGradient
              colors={['#10B981', '#059669']}
              style={styles.addValeterGradient}
            >
              <Text style={styles.addValeterIcon}>+</Text>
              <Text style={styles.addValeterText}>Add Valeter</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Filter Buttons */}
        <View style={styles.filterContainer}>
          <TouchableOpacity
            style={[
              styles.filterButton,
              selectedFilter === 'all' && styles.filterButtonActive
            ]}
            onPress={() => setSelectedFilter('all')}
          >
            <Text style={[
              styles.filterButtonText,
              selectedFilter === 'all' && styles.filterButtonTextActive
            ]}>
              All ({valeters.length})
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.filterButton,
              selectedFilter === 'online' && styles.filterButtonActive
            ]}
            onPress={() => setSelectedFilter('online')}
          >
            <Text style={[
              styles.filterButtonText,
              selectedFilter === 'online' && styles.filterButtonTextActive
            ]}>
              Online ({valeters.filter(v => v.isOnline).length})
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.filterButton,
              selectedFilter === 'connected' && styles.filterButtonActive
            ]}
            onPress={() => setSelectedFilter('connected')}
          >
            <Text style={[
              styles.filterButtonText,
              selectedFilter === 'connected' && styles.filterButtonTextActive
            ]}>
              Connected ({valeters.filter(v => v.isConnected).length})
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.filterButton,
              selectedFilter === 'joint' && styles.filterButtonActive
            ]}
            onPress={() => setSelectedFilter('joint')}
          >
            <Text style={[
              styles.filterButtonText,
              selectedFilter === 'joint' && styles.filterButtonTextActive
            ]}>
              Joint Valets ({valeters.filter(v => v.jointValets > 0).length})
            </Text>
          </TouchableOpacity>
        </View>

        {/* Network Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{valeters.length}</Text>
            <Text style={styles.statLabel}>Total Valeters</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{valeters.filter(v => v.isOnline).length}</Text>
            <Text style={styles.statLabel}>Online Now</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{valeters.filter(v => v.isConnected).length}</Text>
            <Text style={styles.statLabel}>Your Connections</Text>
          </View>
        </View>

        {/* Valeters List */}
        <View style={styles.listContainer}>
          <Text style={styles.listTitle}>
            {selectedFilter === 'all' ? 'All Valeters' : 
             selectedFilter === 'online' ? 'Online Valeters' : 'Your Connections'}
          </Text>
          
          {filteredValeters.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyIcon}>👥</Text>
              <Text style={styles.emptyTitle}>No Valeters Found</Text>
              <Text style={styles.emptyText}>
                Try adjusting your search or filters
              </Text>
            </View>
          ) : (
            <FlatList
              data={filteredValeters}
              renderItem={renderValeterCard}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
            />
          )}
        </View>

        {/* Network Tips */}
        <View style={styles.tipsContainer}>
          <Text style={styles.tipsTitle}>💡 Network Tips</Text>
          <View style={styles.tipItem}>
            <Text style={styles.tipText}>• Connect with valeters in your area for job referrals</Text>
          </View>
          <View style={styles.tipItem}>
            <Text style={styles.tipText}>• Share tips and best practices with your network</Text>
          </View>
          <View style={styles.tipItem}>
            <Text style={styles.tipText}>• Build relationships for collaborative projects</Text>
          </View>
        </View>
      </ScrollView>

      {/* Add Valeter Modal */}
      <Modal
        visible={showAddModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowAddModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Valeter</Text>
              <TouchableOpacity
                onPress={() => setShowAddModal(false)}
                style={styles.modalCloseButton}
              >
                <Text style={styles.modalCloseText}>✕</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.searchSection}>
              <Text style={styles.searchSectionTitle}>Search by Email</Text>
              <View style={styles.searchInputContainer}>
                <TextInput
                  style={styles.modalSearchInput}
                  placeholder="Enter email address..."
                  placeholderTextColor="#87CEEB"
                  value={emailSearch}
                  onChangeText={setEmailSearch}
                />
                <TouchableOpacity
                  style={styles.searchButton}
                  onPress={handleSearchByEmail}
                >
                  <Text style={styles.searchButtonText}>Search</Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.searchSection}>
              <Text style={styles.searchSectionTitle}>Search by Phone</Text>
              <View style={styles.searchInputContainer}>
                <TextInput
                  style={styles.modalSearchInput}
                  placeholder="Enter phone number..."
                  placeholderTextColor="#87CEEB"
                  value={phoneSearch}
                  onChangeText={setPhoneSearch}
                  keyboardType="phone-pad"
                />
                <TouchableOpacity
                  style={styles.searchButton}
                  onPress={handleSearchByPhone}
                >
                  <Text style={styles.searchButtonText}>Search</Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.modalInfo}>
              <Text style={styles.modalInfoText}>
                💡 Tip: You can search for valeters using their email address or phone number. 
                If they're registered on the platform, you'll be able to connect with them.
              </Text>
            </View>
          </View>
        </View>
      </Modal>

      {/* Joint Valet Modal */}
      <Modal
        visible={showJointValetModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowJointValetModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Joint Valet Request</Text>
              <TouchableOpacity
                onPress={() => setShowJointValetModal(false)}
                style={styles.modalCloseButton}
              >
                <Text style={styles.modalCloseText}>✕</Text>
              </TouchableOpacity>
            </View>

            {selectedValeter && (
              <View style={styles.jointValetInfo}>
                <Text style={styles.jointValetTitle}>Request to work with:</Text>
                <Text style={styles.jointValetName}>{selectedValeter.name}</Text>
                <Text style={styles.jointValetDetails}>
                  Rating: ⭐ {selectedValeter.rating} • {selectedValeter.jobsCompleted} jobs completed
                </Text>
                <Text style={styles.jointValetDetails}>
                  Location: {selectedValeter.location}
                </Text>
                <Text style={styles.jointValetDetails}>
                  Availability: {selectedValeter.availability}
                </Text>
                
                <View style={styles.jointValetBenefits}>
                  <Text style={styles.jointValetBenefitsTitle}>🤝 Benefits of Joint Valets:</Text>
                  <Text style={styles.jointValetBenefitText}>• Share large jobs and increase earnings</Text>
                  <Text style={styles.jointValetBenefitText}>• Learn new techniques from each other</Text>
                  <Text style={styles.jointValetBenefitText}>• Build professional relationships</Text>
                  <Text style={styles.jointValetBenefitText}>• Expand your service area</Text>
                </View>

                <TouchableOpacity
                  style={styles.sendRequestButton}
                  onPress={initiateJointValet}
                >
                  <LinearGradient
                    colors={['#3B82F6', '#2563EB']}
                    style={styles.sendRequestGradient}
                  >
                    <Text style={styles.sendRequestText}>Send Joint Valet Request</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 60,
  },
  searchContainer: {
    padding: 20,
  },
  searchInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    color: '#F9FAFB',
    fontSize: 16,
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  filterButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginHorizontal: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    alignItems: 'center',
  },
  filterButtonActive: {
    backgroundColor: '#87CEEB',
  },
  filterButtonText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  filterButtonTextActive: {
    color: '#0A1929',
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  listContainer: {
    padding: 20,
  },
  listTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  valeterCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  valeterHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  valeterInfo: {
    flex: 1,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    color: '#FFD700',
    fontSize: 14,
    marginRight: 8,
  },
  jobsText: {
    color: '#87CEEB',
    fontSize: 14,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  onlineIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  statusText: {
    color: '#87CEEB',
    fontSize: 12,
  },
  specializationsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 12,
  },
  specializationTag: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginRight: 8,
    marginBottom: 4,
  },
  specializationText: {
    color: '#87CEEB',
    fontSize: 12,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  connectButton: {
    backgroundColor: '#4CAF50',
  },
  disconnectButton: {
    backgroundColor: '#EF4444',
  },
  messageButton: {
    backgroundColor: '#2196F3',
  },
  profileButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  emptyText: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
  },
  tipsContainer: {
    padding: 20,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    margin: 20,
    borderRadius: 12,
  },
  tipsTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  tipItem: {
    marginBottom: 8,
  },
  tipText: {
    color: '#E5E7EB',
    fontSize: 14,
  },
  // New styles for enhanced features
  addValeterContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  addValeterButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  addValeterGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  addValeterIcon: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginRight: 8,
  },
  addValeterText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  jointValetsText: {
    color: '#FFD700',
    fontSize: 14,
    marginLeft: 8,
  },
  locationText: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 4,
  },
  availabilityText: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 2,
  },
  contactButtons: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 12,
  },
  contactButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  callButton: {
    backgroundColor: '#4CAF50',
  },
  emailButton: {
    backgroundColor: '#2196F3',
  },
  contactButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  jointValetButton: {
    backgroundColor: '#8B5CF6',
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#0A1929',
    borderRadius: 20,
    padding: 20,
    margin: 20,
    maxWidth: 400,
    width: '100%',
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  modalCloseButton: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalCloseText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  searchSection: {
    marginBottom: 20,
  },
  searchSectionTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  searchInputContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  modalSearchInput: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
    padding: 12,
    color: '#F9FAFB',
    fontSize: 14,
  },
  searchButton: {
    backgroundColor: '#3B82F6',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    justifyContent: 'center',
  },
  searchButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  modalInfo: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 8,
    padding: 12,
  },
  modalInfoText: {
    color: '#E0E7FF',
    fontSize: 12,
    lineHeight: 16,
  },
  // Joint Valet Modal styles
  jointValetInfo: {
    alignItems: 'center',
  },
  jointValetTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    marginBottom: 8,
  },
  jointValetName: {
    color: '#3B82F6',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  jointValetDetails: {
    color: '#E0E7FF',
    fontSize: 14,
    marginBottom: 4,
    textAlign: 'center',
  },
  jointValetBenefits: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    marginVertical: 20,
    width: '100%',
  },
  jointValetBenefitsTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  jointValetBenefitText: {
    color: '#E0E7FF',
    fontSize: 14,
    marginBottom: 8,
    lineHeight: 18,
  },
  sendRequestButton: {
    borderRadius: 12,
    overflow: 'hidden',
    width: '100%',
  },
  sendRequestGradient: {
    paddingVertical: 16,
    alignItems: 'center',
  },
  sendRequestText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
