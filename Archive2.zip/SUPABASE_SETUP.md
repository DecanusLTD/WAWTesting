# Supabase Setup Guide for Wish a Wash

## 🚀 **Step 1: Create Supabase Project**

1. **Go to [supabase.com](https://supabase.com)**
2. **Sign up/Login** with your account
3. **Create New Project**
   - Project name: `wish-a-chwash`
   - Database password: Choose a strong password
   - Region: Select closest to your users
4. **Wait for project to be ready** (2-3 minutes)

## 🔑 **Step 2: Get API Keys**

1. **Go to Settings → API**
2. **Copy these values:**
   - **Project URL** (e.g., `https://your-project.supabase.co`)
   - **Anon Public Key** (starts with `eyJ...`)

## 🌍 **Step 3: Configure Environment Variables**

1. **Create `.env` file** in your project root:
```bash
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
```

2. **Add to `.gitignore`:**
```bash
.env
```

## 🗄️ **Step 4: Set Up Database Schema**

1. **Go to SQL Editor** in Supabase Dashboard
2. **Copy and paste** the entire content of `supabase-schema.sql`
3. **Run the script** - this creates all tables, policies, and functions

## 🔐 **Step 5: Configure Authentication**

1. **Go to Authentication → Settings**
2. **Configure Email Templates:**
   - **Confirm signup email**
   - **Reset password email**
   - **Change email address email**

3. **Set up Email Provider:**
   - Use Supabase's built-in email service
   - Or configure your own SMTP provider

## 🛡️ **Step 6: Set Up Row Level Security (RLS)**

The schema already includes RLS policies, but verify they're working:

1. **Go to Authentication → Policies**
2. **Check that all tables have RLS enabled**
3. **Verify policies are created correctly**

## 📱 **Step 7: Update App Configuration**

1. **Replace the auth context** in your app:
```typescript
// In _layout.tsx or App.tsx
import { SupabaseAuthProvider } from './app/supabase-auth-context';

export default function App() {
  return (
    <SupabaseAuthProvider>
      {/* Your app components */}
    </SupabaseAuthProvider>
  );
}
```

2. **Update login screen** to use Supabase auth:
```typescript
import { useSupabaseAuth } from './app/supabase-auth-context';

const { signIn, signUp } = useSupabaseAuth();
```

## 🧪 **Step 8: Test the Setup**

1. **Create a test user:**
   - Use the signup form
   - Verify email confirmation works
   - Test login functionality

2. **Test Super Admin access:**
   - Login with `Reeceyrackz@gmail.com`
   - Use access code `REECEYRACKZ2026`
   - Verify admin dashboard loads

3. **Test booking system:**
   - Create a booking
   - Verify real-time updates
   - Test valeter assignment

## 🔧 **Step 9: Production Configuration**

1. **Set up custom domain** (optional):
   - Go to Settings → General
   - Add custom domain

2. **Configure backups:**
   - Go to Settings → Database
   - Set up automated backups

3. **Set up monitoring:**
   - Go to Settings → Monitoring
   - Configure alerts

## 📊 **Step 10: Database Management**

### **Tables Created:**
- `users` - User profiles and authentication
- `bookings` - All booking data
- `valeter_profiles` - Valeter-specific data
- `organizations` - Business organizations
- `admin_access_logs` - Security audit trail

### **Functions Created:**
- `get_booking_stats(user_uuid)` - Booking statistics
- `get_user_with_profile(user_uuid)` - User with profile data

### **Policies Created:**
- Users can only access their own data
- Super admins can access all data
- Valeters can update bookings they're assigned to

## 🚨 **Important Security Notes**

1. **Never commit API keys** to version control
2. **Use environment variables** for all sensitive data
3. **Regularly rotate** service role keys
4. **Monitor access logs** for suspicious activity
5. **Backup database** regularly

## 🔄 **Migration from Mock Data**

1. **Export existing data** (if any)
2. **Import to Supabase** using the SQL editor
3. **Update all service imports** to use Supabase services
4. **Remove mock data files**
5. **Test all functionality**

## 📞 **Support**

- **Supabase Documentation**: [supabase.com/docs](https://supabase.com/docs)
- **Discord Community**: [supabase.com/discord](https://supabase.com/discord)
- **GitHub Issues**: [github.com/supabase/supabase](https://github.com/supabase/supabase)

## ✅ **Checklist**

- [ ] Supabase project created
- [ ] Environment variables configured
- [ ] Database schema deployed
- [ ] Authentication configured
- [ ] RLS policies verified
- [ ] App updated to use Supabase
- [ ] Test user created
- [ ] Super admin access tested
- [ ] Booking system tested
- [ ] Real-time updates working
- [ ] Production settings configured
- [ ] Backups enabled
- [ ] Monitoring set up

---

**Your Supabase setup is now complete! 🎉**

The app will now use real data instead of mock data, with proper authentication, real-time updates, and secure access controls.
