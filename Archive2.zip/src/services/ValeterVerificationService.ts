export interface ValeterDocument {
  id: string;
  type: 'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed';
  name: string;
  description: string;
  required: boolean;
  status: 'pending' | 'approved' | 'rejected' | 'not_uploaded';
  uploadedAt?: Date;
  approvedAt?: Date;
  rejectionReason?: string;
  fileUrl?: string;
}

export interface ValeterProfileData {
  id: string;
  name: string;
  email: string;
  phone: string;
  profilePhoto?: string;
  bio: string;
  experience: string;
  specializations: string[];
  vehicleDetails: {
    make: string;
    model: string;
    year: string;
    registration: string;
    color: string;
    insuranceProvider: string;
    insurancePolicyNumber: string;
  };
  documents: ValeterDocument[];
  verificationStatus: 'pending' | 'verified' | 'rejected';
  verifiedAt?: Date;
  verificationBadge: boolean;
  rating: number;
  jobsCompleted: number;
  isOnline: boolean;
  workingRadius: number;
  hourlyRate: number;
  availability: {
    monday: { start: string; end: string; available: boolean };
    tuesday: { start: string; end: string; available: boolean };
    wednesday: { start: string; end: string; available: boolean };
    thursday: { start: string; end: string; available: boolean };
    friday: { start: string; end: string; available: boolean };
    saturday: { start: string; end: string; available: boolean };
    sunday: { start: string; end: string; available: boolean };
  };
}

export class ValeterVerificationService {
  private static instance: ValeterVerificationService;
  private valeterProfiles: Map<string, ValeterProfileData> = new Map();

  static getInstance(): ValeterVerificationService {
    if (!ValeterVerificationService.instance) {
      ValeterVerificationService.instance = new ValeterVerificationService();
    }
    return ValeterVerificationService.instance;
  }

  // Required documents based on UK legal requirements for mobile valeting
  // Check if valeter is part of an organization (pure function)
  isOrganizationMember(profile: ValeterProfileData | null): { isMember: boolean; organizationName?: string } {
    if (!profile) return { isMember: false };
    
    // In a real app, this would check against organization database
    // For now, we'll simulate based on email domain or stored data
    if (profile.email?.includes('@company.com') || profile.email?.includes('@organization.com')) {
      return { isMember: true, organizationName: 'Professional Valeting Co.' };
    }
    return { isMember: false };
  }

  // Pure function to compute required documents (no side effects)
  computeRequiredDocuments(isMember: boolean, organizationName?: string): ValeterDocument[] {
    if (isMember) {
      // Simplified requirements for organization members - company handles liability
      return [
        {
          id: 'id_proof',
          type: 'id_proof',
          name: 'Proof of Identity',
          description: 'Valid government-issued ID (passport, driving license, or national ID)',
          required: true,
          status: 'not_uploaded'
        },
        {
          id: 'selfie',
          type: 'selfie',
          name: 'Selfie Photo',
          description: 'Clear selfie for identity verification',
          required: true,
          status: 'not_uploaded'
        },
        {
          id: 'profile_photo',
          type: 'profile_photo',
          name: 'Profile Photo',
          description: 'Professional headshot for customer trust',
          required: true,
          status: 'not_uploaded'
        },
        {
          id: 'disclaimer_signed',
          type: 'disclaimer_signed',
          name: 'Terms & Conditions',
          description: 'Signed agreement to Wish a Wash terms and conditions',
          required: true,
          status: 'not_uploaded'
        }
      ];
    } else {
      // Individual valeters need the same simplified requirements
      return [
        {
          id: 'id_proof',
          type: 'id_proof',
          name: 'Proof of Identity',
          description: 'Valid government-issued ID (passport, driving license, or national ID)',
          required: true,
          status: 'not_uploaded'
        },
        {
          id: 'selfie',
          type: 'selfie',
          name: 'Selfie Photo',
          description: 'Clear selfie for identity verification',
          required: true,
          status: 'not_uploaded'
        },
        {
          id: 'profile_photo',
          type: 'profile_photo',
          name: 'Profile Photo',
          description: 'Professional headshot for customer trust',
          required: true,
          status: 'not_uploaded'
        },
        {
          id: 'disclaimer_signed',
          type: 'disclaimer_signed',
          name: 'Terms & Conditions',
          description: 'Signed agreement to Wish a Wash terms and conditions',
          required: true,
          status: 'not_uploaded'
        }
      ];
    }
  }

    getRequiredDocuments(valeterId: string): ValeterDocument[] {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return [];
    
    // If documents are already populated, return them
    if (profile.documents.length > 0) {
      return profile.documents;
    }
    
    const { isMember, organizationName } = this.isOrganizationMember(profile);
    const documents = this.computeRequiredDocuments(isMember, organizationName);
    
    // Populate the profile's documents array to avoid future calls
    profile.documents = documents;
    
    return documents;
  }

  // Check if valeter can go online (all required documents approved)
  canGoOnline(valeterId: string): { canGoOnline: boolean; missingDocuments: string[]; reason?: string } {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) {
      return {
        canGoOnline: false,
        missingDocuments: ['Profile not found'],
        reason: 'Profile not found'
      };
    }
    
    const requiredDocuments = this.getRequiredDocuments(valeterId);
    const uploadedDocuments = profile.documents || [];
    
    const missingDocuments: string[] = [];
    
    for (const requiredDoc of requiredDocuments) {
      if (requiredDoc.required) {
        const uploadedDoc = uploadedDocuments.find(doc => doc.type === requiredDoc.type);
        if (!uploadedDoc || uploadedDoc.status !== 'approved') {
          missingDocuments.push(requiredDoc.name);
        }
      }
    }
    
    const canGoOnline = missingDocuments.length === 0;
    
    return {
      canGoOnline,
      missingDocuments,
      reason: canGoOnline ? undefined : `Cannot go online: ${missingDocuments.length} document(s) pending approval`
    };
  }

  // Check if valeter can receive jobs
  canReceiveJobs(valeterId: string): boolean {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return false;
    
    const { canGoOnline } = this.canGoOnline(valeterId);
    
    // Must be online and have all documents approved
    return canGoOnline && profile.isOnline === true;
  }

  getValeterProfile(valeterId: string): ValeterProfileData | undefined {
    if (!this.valeterProfiles.has(valeterId)) {
      // Create default profile
      const defaultProfile: ValeterProfileData = {
        id: valeterId,
        name: 'New Valeter',
        email: '',
        phone: '',
        bio: 'Professional mobile valeter with years of experience in car care and detailing.',
        experience: '3+ years',
        specializations: ['Exterior Wash', 'Interior Cleaning', 'Wax & Polish'],
        vehicleDetails: {
          make: '',
          model: '',
          year: '',
          registration: '',
          color: '',
          insuranceProvider: '',
          insurancePolicyNumber: ''
        },
        documents: [], // Will be populated when needed
        verificationStatus: 'pending',
        verificationBadge: false,
        rating: 0,
        jobsCompleted: 0,
        isOnline: false,
        workingRadius: 10,
        hourlyRate: 25,
        availability: {
          monday: { start: '09:00', end: '17:00', available: true },
          tuesday: { start: '09:00', end: '17:00', available: true },
          wednesday: { start: '09:00', end: '17:00', available: true },
          thursday: { start: '09:00', end: '17:00', available: true },
          friday: { start: '09:00', end: '17:00', available: true },
          saturday: { start: '09:00', end: '17:00', available: true },
          sunday: { start: '10:00', end: '16:00', available: false }
        }
      };
      this.valeterProfiles.set(valeterId, defaultProfile);
    }
    return this.valeterProfiles.get(valeterId);
  }

  updateValeterProfile(valeterId: string, updates: Partial<ValeterProfileData>): boolean {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return false;

    Object.assign(profile, updates);
    return true;
  }

  uploadDocument(valeterId: string, documentType: ValeterDocument['type'], fileUrl: string): boolean {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return false;

    const document = profile.documents.find(d => d.type === documentType);
    if (!document) return false;

    document.status = 'pending';
    document.uploadedAt = new Date();
    document.fileUrl = fileUrl;

    // Auto-approve for demo (in real app, this would go through admin review)
    setTimeout(() => {
      this.approveDocument(valeterId, documentType);
    }, 2000);

    return true;
  }

  approveDocument(valeterId: string, documentType: ValeterDocument['type']): boolean {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return false;

    const document = profile.documents.find(d => d.type === documentType);
    if (!document) return false;

    document.status = 'approved';
    document.approvedAt = new Date();

    // Check if all required documents are approved
    this.checkVerificationStatus(valeterId);

    return true;
  }

  rejectDocument(valeterId: string, documentType: ValeterDocument['type'], reason: string): boolean {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return false;

    const document = profile.documents.find(d => d.type === documentType);
    if (!document) return false;

    document.status = 'rejected';
    document.rejectionReason = reason;

    return true;
  }

  private checkVerificationStatus(valeterId: string): void {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return;

    const requiredDocuments = profile.documents.filter(d => d.required);
    const approvedDocuments = requiredDocuments.filter(d => d.status === 'approved');

    if (approvedDocuments.length === requiredDocuments.length && profile.profilePhoto) {
      profile.verificationStatus = 'verified';
      profile.verificationBadge = true;
      profile.verifiedAt = new Date();
    }
  }

  getVerificationProgress(valeterId: string): {
    total: number;
    completed: number;
    percentage: number;
    missing: string[];
  } {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) return { total: 0, completed: 0, percentage: 0, missing: [] };

    const requiredDocuments = profile.documents.filter(d => d.required);
    const completed = requiredDocuments.filter(d => d.status === 'approved').length;
    const missing = requiredDocuments
      .filter(d => d.status !== 'approved')
      .map(d => d.name);

    // Add profile photo requirement
    const total = requiredDocuments.length + (profile.profilePhoto ? 1 : 0);
    const actualCompleted = completed + (profile.profilePhoto ? 1 : 0);

    return {
      total,
      completed: actualCompleted,
      percentage: Math.round((actualCompleted / total) * 100),
      missing
    };
  }

  // Legal compliance check
  isLegallyCompliant(valeterId: string): {
    compliant: boolean;
    issues: string[];
    recommendations: string[];
  } {
    const profile = this.getValeterProfile(valeterId);
    if (!profile) {
      return {
        compliant: false,
        issues: ['Profile not found'],
        recommendations: ['Contact support']
      };
    }

    const issues: string[] = [];
    const recommendations: string[] = [];

    // Check required documents
    const requiredDocs = profile.documents.filter(d => d.required);
    const missingDocs = requiredDocs.filter(d => d.status !== 'approved');

    if (missingDocs.length > 0) {
      issues.push(`Missing required documents: ${missingDocs.map(d => d.name).join(', ')}`);
      recommendations.push('Upload all required documents for verification');
    }

    // Check profile photo
    if (!profile.profilePhoto) {
      issues.push('Profile photo required');
      recommendations.push('Upload a clear headshot against plain background');
    }

    // Check vehicle details
    if (!profile.vehicleDetails.registration || !profile.vehicleDetails.insuranceProvider) {
      issues.push('Vehicle details incomplete');
      recommendations.push('Complete vehicle registration and insurance information');
    }

    // Check public liability insurance
    const liabilityInsurance = profile.documents.find(d => d.type === 'public_liability_insurance');
    if (!liabilityInsurance || liabilityInsurance.status !== 'approved') {
      issues.push('Public liability insurance required (£2M minimum)');
      recommendations.push('Obtain public liability insurance for mobile valeting');
    }

    // Check DBS check
    const dbsCheck = profile.documents.find(d => d.type === 'dbs_check');
    if (!dbsCheck || dbsCheck.status !== 'approved') {
      issues.push('DBS background check required');
      recommendations.push('Complete enhanced DBS check for customer safety');
    }

    return {
      compliant: issues.length === 0,
      issues,
      recommendations
    };
  }

  // Check if valeter can go online (requires all documents verified)
  canGoOnline(valeterId: string): { canGo: boolean; reason?: string } {
    const profile = this.valeterProfiles.get(valeterId);
    if (!profile) {
      return { canGo: false, reason: 'Profile not found' };
    }

    // Check if all required documents are approved
    const requiredDocuments = this.getRequiredDocuments();
    const approvedDocuments = profile.documents.filter(doc => doc.status === 'approved');
    const pendingDocuments = profile.documents.filter(doc => doc.status === 'pending');
    const rejectedDocuments = profile.documents.filter(doc => doc.status === 'rejected');

    if (approvedDocuments.length < requiredDocuments.length) {
      return { 
        canGo: false, 
        reason: `Missing ${requiredDocuments.length - approvedDocuments.length} verified documents` 
      };
    }

    if (rejectedDocuments.length > 0) {
      return { 
        canGo: false, 
        reason: `${rejectedDocuments.length} documents rejected - please resubmit` 
      };
    }

    if (pendingDocuments.length > 0) {
      return { 
        canGo: false, 
        reason: `${pendingDocuments.length} documents pending verification` 
      };
    }

    return { canGo: true };
  }
}

export const valeterVerificationService = ValeterVerificationService.getInstance();
