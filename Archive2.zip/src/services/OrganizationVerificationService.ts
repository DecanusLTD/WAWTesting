// Organization Verification Service for Wish a Wash
export interface OrganizationDocument {
  id: string;
  type: 'business_license' | 'insurance_certificate' | 'tax_registration' | 'disclaimer_signed';
  name: string;
  description: string;
  required: boolean;
  uploaded: boolean;
  fileUrl?: string;
  uploadedAt?: Date;
  verified: boolean;
  verifiedAt?: Date;
}

export interface OrganizationValeter {
  id: string;
  name: string;
  email: string;
  phone: string;
  profilePicture?: string;
  idProof?: string;
  selfie?: string;
  status: 'pending' | 'approved' | 'rejected' | 'active';
  joinedAt: Date;
  approvedAt?: Date;
  documents: {
    idProof: boolean;
    selfie: boolean;
    detailsCompleted: boolean;
  };
}

export interface Organization {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  businessType: 'car_wash' | 'detailing' | 'valeting' | 'multi_service';
  documents: OrganizationDocument[];
  valeters: OrganizationValeter[];
  status: 'pending' | 'verified' | 'suspended' | 'active';
  createdAt: Date;
  verifiedAt?: Date;
  disclaimerSigned: boolean;
  disclaimerSignedAt?: Date;
}

class OrganizationVerificationService {
  private static instance: OrganizationVerificationService;
  private organizations: Map<string, Organization> = new Map();

  static getInstance(): OrganizationVerificationService {
    if (!OrganizationVerificationService.instance) {
      OrganizationVerificationService.instance = new OrganizationVerificationService();
    }
    return OrganizationVerificationService.instance;
  }

  // Required documents for organizations
  private getRequiredDocuments(): OrganizationDocument[] {
    return [
      {
        id: 'business_license',
        type: 'business_license',
        name: 'Business License',
        description: 'Valid business license or registration certificate',
        required: true,
        uploaded: false,
        verified: false,
      },
      {
        id: 'insurance_certificate',
        type: 'insurance_certificate',
        name: 'Public Liability Insurance',
        description: 'Certificate of public liability insurance (minimum £2M coverage)',
        required: true,
        uploaded: false,
        verified: false,
      },
      {
        id: 'tax_registration',
        type: 'tax_registration',
        name: 'Tax Registration',
        description: 'VAT registration or tax identification number',
        required: true,
        uploaded: false,
        verified: false,
      },
      {
        id: 'disclaimer_signed',
        type: 'disclaimer_signed',
        name: 'Terms & Conditions Agreement',
        description: 'Signed agreement to Wish a Wash terms and conditions',
        required: true,
        uploaded: false,
        verified: false,
      },
    ];
  }

  // Create new organization
  async createOrganization(orgData: Partial<Organization>): Promise<Organization> {
    const organization: Organization = {
      id: Date.now().toString(),
      name: orgData.name || '',
      email: orgData.email || '',
      phone: orgData.phone || '',
      address: orgData.address || '',
      businessType: orgData.businessType || 'valeting',
      documents: this.getRequiredDocuments(),
      valeters: [],
      status: 'pending',
      createdAt: new Date(),
      disclaimerSigned: false,
    };

    this.organizations.set(organization.id, organization);
    return organization;
  }

  // Get organization by ID
  async getOrganization(orgId: string): Promise<Organization | null> {
    return this.organizations.get(orgId) || null;
  }

  // Upload organization document
  async uploadDocument(orgId: string, documentType: string, fileUrl: string): Promise<boolean> {
    const organization = await this.getOrganization(orgId);
    if (!organization) return false;

    const document = organization.documents.find(doc => doc.type === documentType);
    if (document) {
      document.uploaded = true;
      document.fileUrl = fileUrl;
      document.uploadedAt = new Date();
      
      // Auto-verify disclaimer if signed
      if (documentType === 'disclaimer_signed') {
        document.verified = true;
        document.verifiedAt = new Date();
        organization.disclaimerSigned = true;
        organization.disclaimerSignedAt = new Date();
      }

      this.organizations.set(orgId, organization);
      return true;
    }
    return false;
  }

  // Verify organization document
  async verifyDocument(orgId: string, documentType: string): Promise<boolean> {
    const organization = await this.getOrganization(orgId);
    if (!organization) return false;

    const document = organization.documents.find(doc => doc.type === documentType);
    if (document && document.uploaded) {
      document.verified = true;
      document.verifiedAt = new Date();
      this.organizations.set(orgId, organization);
      return true;
    }
    return false;
  }

  // Check if organization can operate (all documents verified)
  async canOrganizationOperate(orgId: string): Promise<boolean> {
    const organization = await this.getOrganization(orgId);
    if (!organization) return false;

    const requiredDocuments = organization.documents.filter(doc => doc.required);
    const allVerified = requiredDocuments.every(doc => doc.verified);
    
    if (allVerified && organization.status === 'pending') {
      organization.status = 'verified';
      organization.verifiedAt = new Date();
      this.organizations.set(orgId, organization);
    }

    return allVerified;
  }

  // Add valeter to organization
  async addValeter(orgId: string, valeterData: Partial<OrganizationValeter>): Promise<OrganizationValeter | null> {
    const organization = await this.getOrganization(orgId);
    if (!organization) return null;

    const valeter: OrganizationValeter = {
      id: Date.now().toString(),
      name: valeterData.name || '',
      email: valeterData.email || '',
      phone: valeterData.phone || '',
      status: 'pending',
      joinedAt: new Date(),
      documents: {
        idProof: false,
        selfie: false,
        detailsCompleted: false,
      },
    };

    organization.valeters.push(valeter);
    this.organizations.set(orgId, organization);
    return valeter;
  }

  // Update valeter documents
  async updateValeterDocuments(orgId: string, valeterId: string, updates: Partial<OrganizationValeter>): Promise<boolean> {
    const organization = await this.getOrganization(orgId);
    if (!organization) return false;

    const valeter = organization.valeters.find(v => v.id === valeterId);
    if (!valeter) return false;

    // Update valeter data
    Object.assign(valeter, updates);

    // Check if all required documents are provided
    const allDocumentsComplete = valeter.idProof && valeter.selfie && valeter.detailsCompleted;
    
    if (allDocumentsComplete && valeter.status === 'pending') {
      valeter.status = 'approved';
      valeter.approvedAt = new Date();
    }

    this.organizations.set(orgId, organization);
    return true;
  }

  // Check if valeter can work (organization verified + valeter approved)
  async canValeterWork(orgId: string, valeterId: string): Promise<boolean> {
    const organization = await this.getOrganization(orgId);
    if (!organization) return false;

    const canOrgOperate = await this.canOrganizationOperate(orgId);
    if (!canOrgOperate) return false;

    const valeter = organization.valeters.find(v => v.id === valeterId);
    if (!valeter) return false;

    return valeter.status === 'approved' || valeter.status === 'active';
  }

  // Get all organizations
  async getAllOrganizations(): Promise<Organization[]> {
    return Array.from(this.organizations.values());
  }

  // Get organizations by status
  async getOrganizationsByStatus(status: Organization['status']): Promise<Organization[]> {
    return Array.from(this.organizations.values()).filter(org => org.status === status);
  }

  // Get pending verifications
  async getPendingVerifications(): Promise<Organization[]> {
    return Array.from(this.organizations.values()).filter(org => org.status === 'pending');
  }

  // Activate organization
  async activateOrganization(orgId: string): Promise<boolean> {
    const organization = await this.getOrganization(orgId);
    if (!organization || organization.status !== 'verified') return false;

    organization.status = 'active';
    this.organizations.set(orgId, organization);
    return true;
  }

  // Suspend organization
  async suspendOrganization(orgId: string): Promise<boolean> {
    const organization = await this.getOrganization(orgId);
    if (!organization) return false;

    organization.status = 'suspended';
    this.organizations.set(orgId, organization);
    return true;
  }

  // Get organization statistics
  async getOrganizationStats(orgId: string): Promise<{
    totalValeters: number;
    activeValeters: number;
    pendingValeters: number;
    documentsComplete: boolean;
    canOperate: boolean;
  }> {
    const organization = await this.getOrganization(orgId);
    if (!organization) {
      return {
        totalValeters: 0,
        activeValeters: 0,
        pendingValeters: 0,
        documentsComplete: false,
        canOperate: false,
      };
    }

    const totalValeters = organization.valeters.length;
    const activeValeters = organization.valeters.filter(v => v.status === 'active').length;
    const pendingValeters = organization.valeters.filter(v => v.status === 'pending').length;
    const documentsComplete = organization.documents.every(doc => doc.verified);
    const canOperate = await this.canOrganizationOperate(orgId);

    return {
      totalValeters,
      activeValeters,
      pendingValeters,
      documentsComplete,
      canOperate,
    };
  }
}

export const organizationVerificationService = OrganizationVerificationService.getInstance();
