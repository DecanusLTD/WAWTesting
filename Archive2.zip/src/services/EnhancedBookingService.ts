export interface VehicleDetails {
  registration: string;
  make: string;
  model: string;
  year: number;
  color: string;
  size: 'small' | 'medium' | 'large' | 'luxury';
  type: 'car' | 'van' | 'bike' | 'coach' | 'truck';
  photo?: string;
}

export interface ServiceCustomization {
  cleaningProducts: string[];
  specialInstructions: string;
  interiorFocus: boolean;
  exteriorFocus: boolean;
  engineBay: boolean;
  wheels: boolean;
  windows: boolean;
  upholstery: boolean;
}

export interface AddressSuggestion {
  placeId: string;
  description: string;
  mainText: string;
  secondaryText: string;
  location: {
    latitude: number;
    longitude: number;
  };
}

export interface EnhancedBookingData {
  id: string;
  customerId: string;
  serviceType: string;
  vehicleDetails: VehicleDetails;
  location: {
    address: string;
    latitude: number;
    longitude: number;
    placeId?: string;
  };
  serviceCustomization: ServiceCustomization;
  scheduledTime?: Date;
  priority: boolean;
  estimatedPrice: number;
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  createdAt: Date;
  updatedAt: Date;
}

export class EnhancedBookingService {
  private static instance: EnhancedBookingService;
  private bookings: Map<string, EnhancedBookingData> = new Map();
  private addressCache: Map<string, AddressSuggestion[]> = new Map();

  static getInstance(): EnhancedBookingService {
    if (!EnhancedBookingService.instance) {
      EnhancedBookingService.instance = new EnhancedBookingService();
    }
    return EnhancedBookingService.instance;
  }

  // Create a new booking
  createBooking(
    customerId: string,
    serviceType: string,
    vehicleDetails: VehicleDetails,
    location: { address: string; latitude: number; longitude: number; placeId?: string },
    serviceCustomization: ServiceCustomization,
    scheduledTime?: Date,
    priority: boolean = false
  ): EnhancedBookingData {
    const booking: EnhancedBookingData = {
      id: `booking_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      customerId,
      serviceType,
      vehicleDetails,
      location,
      serviceCustomization,
      scheduledTime,
      priority,
      estimatedPrice: this.calculatePrice(serviceType, vehicleDetails, serviceCustomization, priority),
      status: 'pending',
      createdAt: new Date(),
      updatedAt: new Date()
    };

    this.bookings.set(booking.id, booking);
    return booking;
  }

  // Get booking by ID
  getBooking(bookingId: string): EnhancedBookingData | undefined {
    return this.bookings.get(bookingId);
  }

  // Get all bookings for a user
  getUserBookings(userId: string): EnhancedBookingData[] {
    return Array.from(this.bookings.values()).filter(booking => booking.customerId === userId);
  }

  // Update booking status
  updateBookingStatus(bookingId: string, status: EnhancedBookingData['status']): boolean {
    const booking = this.bookings.get(bookingId);
    if (!booking) return false;

    booking.status = status;
    booking.updatedAt = new Date();
    this.bookings.set(bookingId, booking);
    return true;
  }

  // Cancel booking
  cancelBooking(bookingId: string, reason?: string): boolean {
    const booking = this.bookings.get(bookingId);
    if (!booking) return false;

    booking.status = 'cancelled';
    booking.updatedAt = new Date();
    this.bookings.set(bookingId, booking);
    return true;
  }

  // Search addresses (simulated Google Places API)
  searchAddresses(query: string): Promise<AddressSuggestion[]> {
    return new Promise((resolve) => {
      // Check cache first
      if (this.addressCache.has(query)) {
        resolve(this.addressCache.get(query)!);
        return;
      }

      // Simulate API delay
      setTimeout(() => {
        const suggestions: AddressSuggestion[] = this.generateAddressSuggestions(query);
        this.addressCache.set(query, suggestions);
        resolve(suggestions);
      }, 300);
    });
  }

  // Validate vehicle registration
  validateVehicleRegistration(registration: string): { isValid: boolean; error?: string } {
    // UK registration format validation
    const ukFormat = /^[A-Z]{2}[0-9]{2}\s?[A-Z]{3}$|^[A-Z][0-9]{3}\s?[A-Z]{3}$|^[A-Z]{3}[0-9]{3}$/;
    
    if (!registration) {
      return { isValid: false, error: 'Registration number is required' };
    }
    
    if (!ukFormat.test(registration.replace(/\s/g, ''))) {
      return { isValid: false, error: 'Invalid UK registration format' };
    }
    
    return { isValid: true };
  }

  // Detect vehicle details from photo (simulated AI)
  detectVehicleFromPhoto(photoBase64: string): Promise<Partial<VehicleDetails>> {
    return new Promise((resolve) => {
      // Simulate AI processing delay
      setTimeout(() => {
        const detectedDetails: Partial<VehicleDetails> = {
          make: this.getRandomMake(),
          model: this.getRandomModel(),
          color: this.getRandomColor(),
          size: this.getRandomSize(),
          type: 'car'
        };
        resolve(detectedDetails);
      }, 2000);
    });
  }

  // Get available cleaning products
  getCleaningProducts(): string[] {
    return [
      'Premium Car Shampoo',
      'Microfiber Wash Mitts',
      'Clay Bar Kit',
      'Wax & Polish',
      'Tire Shine',
      'Glass Cleaner',
      'Interior Cleaner',
      'Leather Conditioner',
      'Engine Bay Cleaner',
      'Wheel Cleaner',
      'Odor Eliminator',
      'UV Protection Spray'
    ];
  }

  // Calculate booking price
  private calculatePrice(
    serviceType: string,
    vehicleDetails: VehicleDetails,
    serviceCustomization: ServiceCustomization,
    priority: boolean
  ): number {
    let basePrice = this.getBasePrice(serviceType, vehicleDetails.size);
    
    // Add customization costs
    if (serviceCustomization.engineBay) basePrice += 15;
    if (serviceCustomization.wheels) basePrice += 10;
    if (serviceCustomization.windows) basePrice += 5;
    if (serviceCustomization.upholstery) basePrice += 20;
    
    // Priority surcharge
    if (priority) basePrice *= 1.3;
    
    return Math.round(basePrice);
  }

  // Get base price for service and vehicle size
  private getBasePrice(serviceType: string, vehicleSize: string): number {
    const basePrices: Record<string, Record<string, number>> = {
      'exterior_only': {
        'small': 25,
        'medium': 35,
        'large': 45,
        'luxury': 60
      },
      'standard': {
        'small': 40,
        'medium': 55,
        'large': 70,
        'luxury': 95
      },
      'luxury_exterior': {
        'small': 50,
        'medium': 65,
        'large': 80,
        'luxury': 110
      },
      'luxury_full': {
        'small': 75,
        'medium': 95,
        'large': 115,
        'luxury': 150
      }
    };
    
    return basePrices[serviceType]?.[vehicleSize] || 40;
  }

  // Generate address suggestions
  private generateAddressSuggestions(query: string): AddressSuggestion[] {
    const mockAddresses = [
      {
        placeId: 'place_1',
        description: '123 High Street, London, UK',
        mainText: '123 High Street',
        secondaryText: 'London, UK',
        location: { latitude: 51.5074, longitude: -0.1278 }
      },
      {
        placeId: 'place_2',
        description: '456 Oxford Street, London, UK',
        mainText: '456 Oxford Street',
        secondaryText: 'London, UK',
        location: { latitude: 51.5154, longitude: -0.1419 }
      },
      {
        placeId: 'place_3',
        description: '789 Regent Street, London, UK',
        mainText: '789 Regent Street',
        secondaryText: 'London, UK',
        location: { latitude: 51.5136, longitude: -0.1364 }
      },
      {
        placeId: 'place_4',
        description: '321 Baker Street, London, UK',
        mainText: '321 Baker Street',
        secondaryText: 'London, UK',
        location: { latitude: 51.5237, longitude: -0.1586 }
      },
      {
        placeId: 'place_5',
        description: '654 Fleet Street, London, UK',
        mainText: '654 Fleet Street',
        secondaryText: 'London, UK',
        location: { latitude: 51.5139, longitude: -0.0984 }
      }
    ];

    return mockAddresses.filter(addr => 
      addr.description.toLowerCase().includes(query.toLowerCase())
    );
  }

  // Random vehicle data generators
  private getRandomMake(): string {
    const makes = ['BMW', 'Mercedes', 'Audi', 'Volkswagen', 'Ford', 'Toyota', 'Honda', 'Nissan'];
    return makes[Math.floor(Math.random() * makes.length)];
  }

  private getRandomModel(): string {
    const models = ['3 Series', 'C-Class', 'A4', 'Golf', 'Focus', 'Corolla', 'Civic', 'Qashqai'];
    return models[Math.floor(Math.random() * models.length)];
  }

  private getRandomColor(): string {
    const colors = ['Black', 'White', 'Silver', 'Blue', 'Red', 'Grey', 'Green'];
    return colors[Math.floor(Math.random() * colors.length)];
  }

  private getRandomSize(): 'small' | 'medium' | 'large' | 'luxury' {
    const sizes: ('small' | 'medium' | 'large' | 'luxury')[] = ['small', 'medium', 'large', 'luxury'];
    return sizes[Math.floor(Math.random() * sizes.length)];
  }

  // Get booking statistics
  getBookingStats(userId: string): {
    total: number;
    pending: number;
    completed: number;
    cancelled: number;
    totalSpent: number;
  } {
    const userBookings = this.getUserBookings(userId);
    
    return {
      total: userBookings.length,
      pending: userBookings.filter(b => b.status === 'pending').length,
      completed: userBookings.filter(b => b.status === 'completed').length,
      cancelled: userBookings.filter(b => b.status === 'cancelled').length,
      totalSpent: userBookings
        .filter(b => b.status === 'completed')
        .reduce((sum, b) => sum + b.estimatedPrice, 0)
    };
  }

  // Cleanup
  cleanup(): void {
    this.bookings.clear();
    this.addressCache.clear();
  }
}

export const enhancedBookingService = EnhancedBookingService.getInstance();
