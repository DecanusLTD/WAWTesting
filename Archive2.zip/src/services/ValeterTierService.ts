export interface ValeterTier {
  name: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  color: string;
  icon: string;
  minJobs: number;
  minExperience: number; // in months
  minRating: number;
  benefits: string[];
  nextTierProgress: number; // percentage to next tier
}

export interface ValeterStats {
  totalJobs: number;
  experienceMonths: number;
  averageRating: number;
  totalEarnings: number;
  jobsThisMonth: number;
  customerReviews: number;
  onTimePercentage: number;
  cancellationRate: number;
}

export class ValeterTierService {
  private static tiers: ValeterTier[] = [
    {
      name: 'Bronze',
      color: '#CD7F32',
      icon: '🥉',
      minJobs: 0,
      minExperience: 0,
      minRating: 0,
      benefits: [
        'Basic job access',
        'Standard customer support',
        'Basic training materials'
      ],
      nextTierProgress: 0
    },
    {
      name: 'Silver',
      color: '#C0C0C0',
      icon: '🥈',
      minJobs: 25,
      minExperience: 3,
      minRating: 4.0,
      benefits: [
        'Priority job access',
        'Enhanced customer support',
        'Advanced training materials',
        '5% bonus on jobs'
      ],
      nextTierProgress: 0
    },
    {
      name: 'Gold',
      color: '#FFD700',
      icon: '🥇',
      minJobs: 100,
      minExperience: 6,
      minRating: 4.5,
      benefits: [
        'Premium job access',
        'Priority customer support',
        'Exclusive training materials',
        '10% bonus on jobs',
        'Early access to new features'
      ],
      nextTierProgress: 0
    },
    {
      name: 'Platinum',
      color: '#E5E4E2',
      icon: '💎',
      minJobs: 250,
      minExperience: 12,
      minRating: 4.8,
      benefits: [
        'VIP job access',
        '24/7 dedicated support',
        'Premium training materials',
        '15% bonus on jobs',
        'Exclusive features access',
        'Priority scheduling',
        'Mentorship opportunities'
      ],
      nextTierProgress: 0
    }
  ];

  static calculateTier(stats: ValeterStats): ValeterTier {
    let currentTier = this.tiers[0]; // Start with Bronze
    
    for (let i = this.tiers.length - 1; i >= 0; i--) {
      const tier = this.tiers[i];
      if (this.meetsTierRequirements(stats, tier)) {
        currentTier = tier;
        break;
      }
    }

    // Calculate progress to next tier
    const nextTierIndex = this.tiers.findIndex(t => t.name === currentTier.name) + 1;
    if (nextTierIndex < this.tiers.length) {
      const nextTier = this.tiers[nextTierIndex];
      const progress = this.calculateProgressToNextTier(stats, currentTier, nextTier);
      currentTier = { ...currentTier, nextTierProgress: progress };
    }

    return currentTier;
  }

  private static meetsTierRequirements(stats: ValeterStats, tier: ValeterTier): boolean {
    return (
      stats.totalJobs >= tier.minJobs &&
      stats.experienceMonths >= tier.minExperience &&
      stats.averageRating >= tier.minRating
    );
  }

  private static calculateProgressToNextTier(
    stats: ValeterStats, 
    currentTier: ValeterTier, 
    nextTier: ValeterTier
  ): number {
    const jobProgress = Math.min(100, (stats.totalJobs / nextTier.minJobs) * 100);
    const experienceProgress = Math.min(100, (stats.experienceMonths / nextTier.minExperience) * 100);
    const ratingProgress = stats.averageRating >= nextTier.minRating ? 100 : 
      Math.max(0, ((stats.averageRating - currentTier.minRating) / (nextTier.minRating - currentTier.minRating)) * 100);

    // Average of all progress indicators
    return Math.round((jobProgress + experienceProgress + ratingProgress) / 3);
  }

  static getTierBenefits(tierName: string): string[] {
    const tier = this.tiers.find(t => t.name === tierName);
    return tier ? tier.benefits : [];
  }

  static getAllTiers(): ValeterTier[] {
    return this.tiers;
  }

  static getNextTier(currentTierName: string): ValeterTier | null {
    const currentIndex = this.tiers.findIndex(t => t.name === currentTierName);
    if (currentIndex >= 0 && currentIndex < this.tiers.length - 1) {
      return this.tiers[currentIndex + 1];
    }
    return null;
  }

  static getTierColor(tierName: string): string {
    const tier = this.tiers.find(t => t.name === tierName);
    return tier ? tier.color : '#CD7F32';
  }

  static getTierIcon(tierName: string): string {
    const tier = this.tiers.find(t => t.name === tierName);
    return tier ? tier.icon : '🥉';
  }
}
