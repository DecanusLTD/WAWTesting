import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
  SafeAreaView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';

interface Employee {
  id: string;
  name: string;
  email: string;
  phone: string;
  position: string;
  salary: number;
  status: 'active' | 'inactive';
  performance: number;
}

interface PayrollRecord {
  id: string;
  employeeName: string;
  period: string;
  baseSalary: number;
  bonuses: number;
  deductions: number;
  netPay: number;
  status: 'pending' | 'paid';
}

export default function HRSystem() {
  const [activeTab, setActiveTab] = useState<'employees' | 'payroll' | 'schedule'>('employees');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [payrollRecords, setPayrollRecords] = useState<PayrollRecord[]>([]);
  const [showAddEmployee, setShowAddEmployee] = useState(false);
  const [showPayrollModal, setShowPayrollModal] = useState(false);
  
  const [newEmployee, setNewEmployee] = useState({
    name: '',
    email: '',
    phone: '',
    position: '',
    salary: '',
  });

  useEffect(() => {
    loadMockData();
  }, []);

  const loadMockData = () => {
    const mockEmployees: Employee[] = [
      {
        id: '1',
        name: 'Mike Johnson',
        email: 'mike@company.com',
        phone: '+44 7700 900001',
        position: 'Senior Valeter',
        salary: 28000,
        status: 'active',
        performance: 4.8,
      },
      {
        id: '2',
        name: 'Sarah Williams',
        email: 'sarah@company.com',
        phone: '+44 7700 900002',
        position: 'Valeter',
        salary: 24000,
        status: 'active',
        performance: 4.5,
      },
    ];

    const mockPayroll: PayrollRecord[] = [
      {
        id: '1',
        employeeName: 'Mike Johnson',
        period: 'January 2024',
        baseSalary: 28000,
        bonuses: 2000,
        deductions: 1500,
        netPay: 28500,
        status: 'paid',
      },
    ];

    setEmployees(mockEmployees);
    setPayrollRecords(mockPayroll);
  };

  const handleAddEmployee = () => {
    if (!newEmployee.name || !newEmployee.email || !newEmployee.salary) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    const employee: Employee = {
      id: Date.now().toString(),
      name: newEmployee.name,
      email: newEmployee.email,
      phone: newEmployee.phone,
      position: newEmployee.position,
      salary: parseFloat(newEmployee.salary),
      status: 'active',
      performance: 0,
    };

    setEmployees(prev => [...prev, employee]);
    setNewEmployee({ name: '', email: '', phone: '', position: '', salary: '' });
    setShowAddEmployee(false);
    Alert.alert('Success', 'Employee added successfully!');
  };

  const getTotalPayroll = () => {
    return payrollRecords.reduce((sum, record) => sum + record.netPay, 0);
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
      
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>HR System</Text>
        <View style={styles.placeholder} />
      </View>

      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{employees.length}</Text>
          <Text style={styles.statLabel}>Employees</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>£{getTotalPayroll().toLocaleString()}</Text>
          <Text style={styles.statLabel}>Total Payroll</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>
            {(employees.reduce((sum, emp) => sum + emp.performance, 0) / employees.length || 0).toFixed(1)}⭐
          </Text>
          <Text style={styles.statLabel}>Avg Performance</Text>
        </View>
      </View>

      <View style={styles.tabContainer}>
        {[
          { key: 'employees', label: '👥 Employees' },
          { key: 'payroll', label: '💰 Payroll' },
          { key: 'schedule', label: '📅 Schedule' },
        ].map((tab) => (
          <TouchableOpacity
            key={tab.key}
            style={[styles.tab, activeTab === tab.key && styles.activeTab]}
            onPress={() => setActiveTab(tab.key as any)}
          >
            <Text style={[styles.tabText, activeTab === tab.key && styles.activeTabText]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.content}>
        {activeTab === 'employees' && (
          <View style={styles.tabContent}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Employee Management</Text>
              <TouchableOpacity style={styles.addButton} onPress={() => setShowAddEmployee(true)}>
                <Text style={styles.addButtonText}>➕ Add Employee</Text>
              </TouchableOpacity>
            </View>
            
            {employees.map((employee) => (
              <View key={employee.id} style={styles.employeeCard}>
                <View style={styles.employeeHeader}>
                  <View style={styles.employeeInfo}>
                    <Text style={styles.employeeName}>{employee.name}</Text>
                    <Text style={styles.employeePosition}>{employee.position}</Text>
                    <Text style={styles.employeeEmail}>{employee.email}</Text>
                  </View>
                  <View style={[styles.statusBadge, { backgroundColor: employee.status === 'active' ? '#10B981' : '#6B7280' }]}>
                    <Text style={styles.statusText}>{employee.status}</Text>
                  </View>
                </View>
                <View style={styles.employeeDetails}>
                  <Text style={styles.employeeDetail}>📞 {employee.phone}</Text>
                  <Text style={styles.employeeDetail}>💰 £{employee.salary.toLocaleString()}/year</Text>
                  <Text style={styles.employeeDetail}>⭐ {employee.performance} rating</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {activeTab === 'payroll' && (
          <View style={styles.tabContent}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Payroll Management</Text>
              <TouchableOpacity style={styles.addButton} onPress={() => setShowPayrollModal(true)}>
                <Text style={styles.addButtonText}>💰 Process Payroll</Text>
              </TouchableOpacity>
            </View>
            
            {payrollRecords.map((record) => (
              <View key={record.id} style={styles.payrollCard}>
                <View style={styles.payrollHeader}>
                  <Text style={styles.payrollEmployee}>{record.employeeName}</Text>
                  <Text style={styles.payrollPeriod}>{record.period}</Text>
                </View>
                <View style={styles.payrollDetails}>
                  <Text style={styles.payrollDetail}>Base: £{record.baseSalary.toLocaleString()}</Text>
                  <Text style={styles.payrollDetail}>Bonus: £{record.bonuses.toLocaleString()}</Text>
                  <Text style={styles.payrollDetail}>Deductions: £{record.deductions.toLocaleString()}</Text>
                  <Text style={styles.payrollNet}>Net: £{record.netPay.toLocaleString()}</Text>
                </View>
                <View style={[styles.payrollStatus, { backgroundColor: record.status === 'paid' ? '#10B981' : '#F59E0B' }]}>
                  <Text style={styles.payrollStatusText}>{record.status.toUpperCase()}</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {activeTab === 'schedule' && (
          <View style={styles.tabContent}>
            <Text style={styles.sectionTitle}>Schedule Management</Text>
            <View style={styles.scheduleCard}>
              <Text style={styles.scheduleTitle}>📅 Weekly Schedule</Text>
              <Text style={styles.scheduleText}>Schedule management coming soon...</Text>
              <Text style={styles.scheduleText}>• Shift scheduling</Text>
              <Text style={styles.scheduleText}>• Time tracking</Text>
              <Text style={styles.scheduleText}>• Attendance monitoring</Text>
            </View>
          </View>
        )}
      </ScrollView>

      {/* Add Employee Modal */}
      <Modal visible={showAddEmployee} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Add New Employee</Text>
            
            <TextInput
              style={styles.input}
              placeholder="Full Name"
              placeholderTextColor="#87CEEB"
              value={newEmployee.name}
              onChangeText={(text) => setNewEmployee(prev => ({ ...prev, name: text }))}
            />
            
            <TextInput
              style={styles.input}
              placeholder="Email"
              placeholderTextColor="#87CEEB"
              value={newEmployee.email}
              onChangeText={(text) => setNewEmployee(prev => ({ ...prev, email: text }))}
              keyboardType="email-address"
            />
            
            <TextInput
              style={styles.input}
              placeholder="Phone"
              placeholderTextColor="#87CEEB"
              value={newEmployee.phone}
              onChangeText={(text) => setNewEmployee(prev => ({ ...prev, phone: text }))}
              keyboardType="phone-pad"
            />
            
            <TextInput
              style={styles.input}
              placeholder="Position"
              placeholderTextColor="#87CEEB"
              value={newEmployee.position}
              onChangeText={(text) => setNewEmployee(prev => ({ ...prev, position: text }))}
            />
            
            <TextInput
              style={styles.input}
              placeholder="Annual Salary"
              placeholderTextColor="#87CEEB"
              value={newEmployee.salary}
              onChangeText={(text) => setNewEmployee(prev => ({ ...prev, salary: text }))}
              keyboardType="numeric"
            />
            
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowAddEmployee(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={handleAddEmployee}
              >
                <Text style={styles.saveButtonText}>Add Employee</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderBottomColor: 'rgba(255, 255, 255, 0.2)',
    borderBottomWidth: 1,
  },
  backButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  placeholder: {
    width: 60,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  statCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    minWidth: 100,
  },
  statNumber: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  tabContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 8,
    alignItems: 'center',
    borderRadius: 8,
    marginHorizontal: 2,
  },
  activeTab: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
  },
  tabText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '500',
  },
  activeTabText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  tabContent: {
    paddingVertical: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
  },
  addButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  employeeCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  employeeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  employeeInfo: {
    flex: 1,
  },
  employeeName: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  employeePosition: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 2,
  },
  employeeEmail: {
    color: '#B0E0E6',
    fontSize: 12,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '600',
  },
  employeeDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  employeeDetail: {
    color: '#B0E0E6',
    fontSize: 12,
  },
  payrollCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  payrollHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  payrollEmployee: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  payrollPeriod: {
    color: '#87CEEB',
    fontSize: 14,
  },
  payrollDetails: {
    marginBottom: 10,
  },
  payrollDetail: {
    color: '#B0E0E6',
    fontSize: 12,
    marginBottom: 2,
  },
  payrollNet: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: 'bold',
  },
  payrollStatus: {
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  payrollStatusText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '600',
  },
  scheduleCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
  },
  scheduleTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  scheduleText: {
    color: '#B0E0E6',
    fontSize: 14,
    marginBottom: 8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 25,
    width: '90%',
  },
  modalTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    color: '#FFFFFF',
    fontSize: 16,
    marginBottom: 15,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  modalButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
    marginHorizontal: 5,
  },
  cancelButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  saveButton: {
    backgroundColor: '#10B981',
  },
  cancelButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
});
