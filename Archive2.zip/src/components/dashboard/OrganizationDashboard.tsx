import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  SafeAreaView,
  Alert,
  Modal,
  TextInput,
  Image,
  ActivityIndicator,
  FlatList,
} from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '../../providers/enhanced-auth-context';
import {
  organizationVerificationService,
  Organization,
  OrganizationDocument,
  OrganizationValeter,
} from '../../services/OrganizationVerificationService';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import LoadingScreen from '../LoadingScreen';
import { supabase } from '../../lib/supabase';

const { width } = Dimensions.get('window');

/** ---------- Locations table wiring ---------- */
const LOCATIONS_TABLE = 'car_wash_locations';
type OrgIdColumn = 'organization_id' | 'org_id';

interface DocumentCardProps {
  document: OrganizationDocument;
  onUpload: (documentType: string) => void;
}

const DocumentCard: React.FC<DocumentCardProps> = ({ document, onUpload }) => {
  const getStatusColor = () => {
    if (document.verified) return '#10B981';
    if (document.uploaded) return '#F59E0B';
    return '#6B7280';
  };

  const getStatusText = () => {
    if (document.verified) return '✓ Verified';
    if (document.uploaded) return '⏳ Pending';
    return '📄 Required';
  };

  const getDocumentIcon = () => {
    switch (document.type) {
      case 'business_license':
        return '🏢';
      case 'insurance_certificate':
        return '🛡️';
      case 'tax_registration':
        return '💰';
      case 'disclaimer_signed':
        return '📋';
      default:
        return '📄';
    }
  };

  return (
    <View style={[styles.documentCard, { borderColor: getStatusColor() }]}>
      <View style={styles.documentHeader}>
        <View style={styles.documentInfo}>
          <Text style={styles.documentIcon}>{getDocumentIcon()}</Text>
          <View style={styles.documentTextContainer}>
            <Text style={styles.documentName}>{document.name}</Text>
            <Text style={styles.documentDescription}>{document.description}</Text>
          </View>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor() }]}>
          <Text style={styles.statusText}>{getStatusText()}</Text>
        </View>
      </View>

      {document.uploaded && (
        <Text style={styles.uploadedText}>
          Uploaded: {document.uploadedAt?.toLocaleDateString()}
        </Text>
      )}

      {!document.uploaded && (
        <TouchableOpacity
          style={[styles.uploadButton, { backgroundColor: getStatusColor() }]}
          onPress={() => onUpload(document.type)}
        >
          <Text style={styles.uploadButtonText}>📷 Upload {document.name}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

interface ValeterCardProps {
  valeter: OrganizationValeter;
  onViewDetails: (valeterId: string) => void;
}

const ValeterCard: React.FC<ValeterCardProps> = ({ valeter, onViewDetails }) => {
  const getStatusColor = () => {
    switch (valeter.status) {
      case 'active':
        return '#10B981';
      case 'approved':
        return '#3B82F6';
      case 'pending':
        return '#F59E0B';
      case 'rejected':
        return '#EF4444';
      default:
        return '#6B7280';
    }
  };

  const getStatusText = () => {
    switch (valeter.status) {
      case 'active':
        return '🟢 Active';
      case 'approved':
        return '🔵 Approved';
      case 'pending':
        return '🟡 Pending';
      case 'rejected':
        return '🔴 Rejected';
      default:
        return '⚪ Unknown';
    }
  };

  return (
    <TouchableOpacity
      style={[styles.valeterCard, { borderColor: getStatusColor() }]}
      onPress={() => onViewDetails(valeter.id)}
    >
      <View style={styles.valeterHeader}>
        <View style={styles.valeterInfo}>
          <Text style={styles.valeterName}>{valeter.name}</Text>
          <Text style={styles.valeterEmail}>{valeter.email}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor() }]}>
          <Text style={styles.statusText}>{getStatusText()}</Text>
        </View>
      </View>
      <View style={styles.valeterDetails}>
        <Text style={styles.valeterPhone}>📞 {valeter.phone}</Text>
        <Text style={styles.valeterJoined}>
          Joined: {valeter.joinedAt.toLocaleDateString()}
        </Text>
      </View>
      <View style={styles.documentsStatus}>
        <Text style={styles.documentsTitle}>Documents:</Text>
        <View style={styles.documentChecks}>
          <Text
            style={[
              styles.documentCheck,
              valeter.documents.idProof && styles.documentComplete,
            ]}
          >
            {valeter.documents.idProof ? '✓' : '○'} ID Proof
          </Text>
          <Text
            style={[
              styles.documentCheck,
              valeter.documents.selfie && styles.documentComplete,
            ]}
          >
            {valeter.documents.selfie ? '✓' : '○'} Selfie
          </Text>
          <Text
            style={[
              styles.documentCheck,
              valeter.documents.detailsCompleted && styles.documentComplete,
            ]}
          >
            {valeter.documents.detailsCompleted ? '✓' : '○'} Details
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

/** ---------- UPDATED: Locations Types ---------- */
type CarWashLocation = {
  id: string;
  organization_id?: string; // FK variant A
  org_id?: string; // FK variant B
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  base_price: number; // required by schema
  priority_price: number; // required by schema
  status?: string | null; // default 'green'
  wait_time_minutes?: number | null;
  created_at: string;
};

export default function OrganizationDashboard() {
  const { user } = useAuth();
  const [organization, setOrganization] = useState<Organization | null>(null);
  const [stats, setStats] = useState({
    totalValeters: 0,
    activeValeters: 0,
    pendingValeters: 0,
    documentsComplete: false,
    canOperate: false,
  });
  const [loading, setLoading] = useState(true);
  const [showAddValeter, setShowAddValeter] = useState(false);
  const [showDocumentUpload, setShowDocumentUpload] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<string>('');

  // --- New: search/link state (profiles table; valeters only)
  type ValeterProfile = {
    id: string;
    full_name: string | null;
    email: string | null;
    phone: string | null;
    user_type: string | null;
    organization_id: string | null;
  };

  const [searchTerm, setSearchTerm] = useState('');
  const [searching, setSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<ValeterProfile[]>([]);
  const [selectedValeterId, setSelectedValeterId] = useState<string | null>(null);
  const [linking, setLinking] = useState(false);
  const searchDebounceRef = useRef<NodeJS.Timeout | null>(null);

  /** ---------- UPDATED: Locations State ---------- */
  const [locations, setLocations] = useState<CarWashLocation[]>([]);
  const [locationsLoading, setLocationsLoading] = useState(false);
  const [showAddLocation, setShowAddLocation] = useState(false);
  const [creatingLocation, setCreatingLocation] = useState(false);
  const [orgIdColumn, setOrgIdColumn] = useState<OrgIdColumn | null>(null);
  const [locationForm, setLocationForm] = useState({
    name: '',
    address: '',
    latitude: '',
    longitude: '',
    basePrice: '',
    priorityPrice: '',
  });

  /** ---------- NEW: Edit Location State ---------- */
  const [showEditLocation, setShowEditLocation] = useState(false);
  const [editingLocation, setEditingLocation] = useState<CarWashLocation | null>(null);
  const [editForm, setEditForm] = useState({
    name: '',
    address: '',
    latitude: '',
    longitude: '',
    basePrice: '',
    priorityPrice: '',
    status: 'green',
    waitTime: '',
  });
  const [savingEdit, setSavingEdit] = useState(false);
  const [deleting, setDeleting] = useState(false);

  // header anim
  const scrollY = useRef(new Animated.Value(0)).current;
  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [200, 120],
    extrapolate: 'clamp',
  });
  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 50, 100],
    outputRange: [1, 0.8, 0.6],
    extrapolate: 'clamp',
  });

  useEffect(() => {
    loadOrganizationData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    (async () => {
      const oid = await resolveOrgId();
      if (oid) await loadLocations(oid);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.organizationId, organization?.id]);

  /** ---------- NEW: Resolve the correct organization id ---------- */
  const resolveOrgId = async (): Promise<string | null> => {
    if (user?.organizationId) return user.organizationId;
    if (organization?.id) return organization.id;

    try {
      if (!user?.id) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('organization_id')
        .eq('id', user.id)
        .maybeSingle();
      if (error) throw error;
      return data?.organization_id ?? null;
    } catch (e) {
      console.warn('[Org] resolveOrgId failed:', (e as any)?.message || e);
      return null;
    }
  };

  const loadOrganizationData = async () => {
    try {
      const orgId = await resolveOrgId();
      if (!orgId) {
        setLoading(false);
        Alert.alert('No Organization', 'Your account is not linked to an organization yet.');
        return;
      }

      let org = await organizationVerificationService.getOrganization(orgId);

      // Optional bootstrap
      if (!org) {
        org = await organizationVerificationService.createOrganization({
          name: 'Professional Valeting Co.',
          email: user?.email ?? 'admin@provaleting.co.uk',
          phone: user?.phone ?? '+44 800 123 4567',
          address: '123 Business Street, London, UK',
          businessType: 'valeting',
        });
      }

      setOrganization(org);

      const orgStats = await organizationVerificationService.getOrganizationStats(orgId);
      setStats(orgStats);

      await loadLocations(orgId);
    } catch (error) {
      console.error('Error loading organization data:', error);
      Alert.alert('Error', 'Failed to load organization data');
    } finally {
      setLoading(false);
    }
  };

  /** ---------- UPDATED: Load Locations from car_wash_locations ---------- */
  const loadLocations = async (orgId: string) => {
    try {
      setLocationsLoading(true);

      // Try organization_id first
      let { data, error } = await supabase
        .from(LOCATIONS_TABLE)
        .select('*')
        .eq('organization_id', orgId)
        .order('created_at', { ascending: false });

      if (error && /organization_id/.test(error.message || '')) {
        // fallback to org_id
        const res2 = await supabase
          .from(LOCATIONS_TABLE)
          .select('*')
          .eq('org_id', orgId)
          .order('created_at', { ascending: false });

        if (!res2.error) setOrgIdColumn('org_id');
        if (res2.error) throw res2.error;
        setLocations((res2.data || []) as CarWashLocation[]);
        return;
      }

      if (error) throw error;

      setOrgIdColumn('organization_id');
      setLocations((data || []) as CarWashLocation[]);
    } catch (e: any) {
      console.warn('[Locations] load error:', e?.message || e);
      Alert.alert('Error', 'Failed to load locations.');
    } finally {
      setLocationsLoading(false);
    }
  };

  /** ---------- UPDATED: Create Location into car_wash_locations ---------- */
  const handleCreateLocation = async () => {
    const oid = await resolveOrgId();
    if (!oid) return;

    const name = locationForm.name.trim();
    const address = locationForm.address.trim();
    const latStr = locationForm.latitude.trim();
    const lngStr = locationForm.longitude.trim();
    const bpStr = locationForm.basePrice.trim();
    const ppStr = locationForm.priorityPrice.trim();

    if (!name || !address || !latStr || !lngStr || !bpStr || !ppStr) {
      Alert.alert('Missing fields', 'Name, address, lat/lng and both prices are required.');
      return;
    }

    const latitude = Number(latStr);
    const longitude = Number(lngStr);
    const basePrice = Number(bpStr);
    const priorityPrice = Number(ppStr);

    if ([latitude, longitude, basePrice, priorityPrice].some((n) => Number.isNaN(n))) {
      Alert.alert(
        'Invalid values',
        'Please enter valid numbers for coordinates and prices.'
      );
      return;
    }

    try {
      setCreatingLocation(true);

      // ensure we know which FK column to use
      let fk: OrgIdColumn | null = orgIdColumn;
      if (!fk) {
        const probe = await supabase
          .from(LOCATIONS_TABLE)
          .select('organization_id')
          .limit(1);
        fk = probe.error ? 'org_id' : 'organization_id';
        setOrgIdColumn(fk);
      }

      const payload: Record<string, any> = {
        name,
        address,
        latitude,
        longitude,
        base_price: basePrice,
        priority_price: priorityPrice,
      };
      payload[fk] = oid;

      const { error } = await supabase.from(LOCATIONS_TABLE).insert(payload);
      if (error) throw error;

      hapticFeedback('success');
      setShowAddLocation(false);
      setLocationForm({
        name: '',
        address: '',
        latitude: '',
        longitude: '',
        basePrice: '',
        priorityPrice: '',
      });
      await loadLocations(oid);
      Alert.alert('Success', 'Location created.');
    } catch (e: any) {
      console.warn('[Locations] create error:', e?.message || e);
      Alert.alert('Error', 'Failed to create location.');
    } finally {
      setCreatingLocation(false);
    }
  };

  /** ---------- EDITING: open / save / delete ---------- */
  const openEditLocation = (loc: CarWashLocation) => {
    setEditingLocation(loc);
    setEditForm({
      name: loc.name || '',
      address: loc.address || '',
      latitude: loc.latitude != null ? String(loc.latitude) : '',
      longitude: loc.longitude != null ? String(loc.longitude) : '',
      basePrice: Number(loc.base_price).toFixed(2),
      priorityPrice: Number(loc.priority_price).toFixed(2),
      status: (loc.status as string) || 'green',
      waitTime: loc.wait_time_minutes != null ? String(loc.wait_time_minutes) : '',
    });
    setShowEditLocation(true);
  };

  const handleUpdateLocation = async () => {
    if (!editingLocation) return;
    const name = editForm.name.trim();
    const address = editForm.address.trim();
    const latStr = editForm.latitude.trim();
    const lngStr = editForm.longitude.trim();
    const bpStr = editForm.basePrice.trim();
    const ppStr = editForm.priorityPrice.trim();
    const status = editForm.status.trim() || 'green';
    const waitStr = editForm.waitTime.trim();

    if (!name || !address || !latStr || !lngStr || !bpStr || !ppStr) {
      Alert.alert('Missing fields', 'Name, address, lat/lng and both prices are required.');
      return;
    }

    const latitude = Number(latStr);
    const longitude = Number(lngStr);
    const basePrice = Number(bpStr);
    const priorityPrice = Number(ppStr);
    const wait = waitStr ? Number(waitStr) : null;

    if (
      [latitude, longitude, basePrice, priorityPrice].some((n) => Number.isNaN(n)) ||
      (waitStr && Number.isNaN(wait))
    ) {
      Alert.alert('Invalid values', 'Please enter valid numbers.');
      return;
    }

    try {
      setSavingEdit(true);
      const { error } = await supabase
        .from(LOCATIONS_TABLE)
        .update({
          name,
          address,
          latitude,
          longitude,
          base_price: basePrice,
          priority_price: priorityPrice,
          status,
          wait_time_minutes: wait,
        })
        .eq('id', editingLocation.id);
      if (error) throw error;

      hapticFeedback('success');
      setShowEditLocation(false);
      setEditingLocation(null);
      const oid = await resolveOrgId();
      if (oid) await loadLocations(oid);
      Alert.alert('Updated', 'Location saved.');
    } catch (e: any) {
      console.warn('[Locations] update error:', e?.message || e);
      Alert.alert('Error', 'Failed to update location.');
    } finally {
      setSavingEdit(false);
    }
  };

  const handleDeleteLocation = async () => {
    if (!editingLocation) return;
    Alert.alert('Delete location?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            setDeleting(true);
            const { error } = await supabase
              .from(LOCATIONS_TABLE)
              .delete()
              .eq('id', editingLocation.id);
            if (error) throw error;
            hapticFeedback('success');
            setShowEditLocation(false);
            setEditingLocation(null);
            const oid = await resolveOrgId();
            if (oid) await loadLocations(oid);
            Alert.alert('Deleted', 'Location removed.');
          } catch (e: any) {
            console.warn('[Locations] delete error:', e?.message || e);
            Alert.alert('Error', 'Failed to delete location.');
          } finally {
            setDeleting(false);
          }
        },
      },
    ]);
  };

  /** ---------- Existing document upload ---------- */
  const handleDocumentUpload = (documentType: string) => {
    setSelectedDocument(documentType);
    setShowDocumentUpload(true);
  };

  const uploadDocument = async () => {
    if (!organization || !selectedDocument) return;

    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert(
          'Permission needed',
          'Please grant permission to access your media library'
        );
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (result.canceled) return;

      const documentName =
        organization.documents.find((doc) => doc.type === selectedDocument)?.name ||
        selectedDocument;

      // TODO: replace with real upload
      const fileUrl = `https://example.com/documents/${selectedDocument}_${Date.now()}.jpg`;

      const success = await organizationVerificationService.uploadDocument(
        organization.id,
        selectedDocument,
        fileUrl
      );

      if (success) {
        hapticFeedback('success');
        Alert.alert('Success', `${documentName} uploaded successfully!`);
        await loadOrganizationData();
      } else {
        Alert.alert('Error', `Failed to upload ${documentName}`);
      }
    } catch (error) {
      console.error('Error uploading document:', error);
      Alert.alert('Error', 'Failed to upload document');
    } finally {
      setShowDocumentUpload(false);
      setSelectedDocument('');
    }
  };

  /** ---------- Debounced valeter search ---------- */
  useEffect(() => {
    if (!showAddValeter || !organization) return;

    setSelectedValeterId(null);

    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);

    const term = searchTerm.trim();
    if (term.length < 2) {
      setSearching(false);
      setSearchResults([]);
      return;
    }

    searchDebounceRef.current = setTimeout(async () => {
      try {
        setSearching(true);

        const { data, error } = await supabase
          .from('profiles')
          .select('id, full_name, email, phone, user_type, organization_id')
          .eq('user_type', 'valeter')
          .or(`full_name.ilike.%${term}%,email.ilike.%${term}%`)
          .order('full_name', { ascending: true })
          .limit(25);

        if (error) throw error;

        const filtered = (data || []).filter(
          (v) => !v.organization_id || v.organization_id === organization.id
        );

        setSearchResults(filtered as ValeterProfile[]);
      } catch (e) {
        console.error('Valeter search failed', e);
        Alert.alert('Search failed', 'Could not search valeters right now.');
        setSearchResults([]);
      } finally {
        setSearching(false);
      }
    }, 300);

    return () => {
      if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    };
  }, [searchTerm, showAddValeter, organization]);

  /** ---------- Link valeter ---------- */
  const linkExistingValeter = async () => {
    if (!organization || !selectedValeterId) return;

    try {
      setLinking(true);

      const { data: updated, error: updErr } = await supabase
        .from('profiles')
        .update({ organization_id: organization.id })
        .eq('id', selectedValeterId)
        .is('organization_id', null)
        .eq('user_type', 'valeter')
        .select('id');

      if (updErr) throw updErr;

      if (!updated || updated.length === 0) {
        const { data: v, error: fetchErr } = await supabase
          .from('profiles')
          .select('organization_id')
          .eq('id', selectedValeterId)
          .eq('user_type', 'valeter')
          .single();

        if (fetchErr) throw fetchErr;

        if (v?.organization_id === organization.id) {
          hapticFeedback('success');
          Alert.alert('Already linked', 'This valeter is already linked to your organization.');
        } else if (v?.organization_id) {
          Alert.alert('Cannot link', 'This valeter is already linked to another organization.');
          return;
        } else {
          Alert.alert(
            'Linking blocked',
            'Could not link this valeter due to a permission or constraint issue.'
          );
          return;
        }
      } else {
        hapticFeedback('success');
        Alert.alert('Linked', 'Valeter linked to your organization.');
      }

      setShowAddValeter(false);
      setSearchTerm('');
      setSearchResults([]);
      setSelectedValeterId(null);
      await loadOrganizationData();
    } catch (e) {
      console.error('Link valeter error', e);
      Alert.alert('Error', 'Failed to link valeter.');
    } finally {
      setLinking(false);
    }
  };

  const handleViewValeterDetails = (valeterId: string) => {
    router.push(`/valeter-details/${valeterId}`);
  };

  const handleGoOnline = async () => {
    if (!organization) return;

    const canOperate = await organizationVerificationService.canOrganizationOperate(
      organization.id
    );

    if (canOperate) {
      const activated = await organizationVerificationService.activateOrganization(
        organization.id
      );
      if (activated) {
        hapticFeedback('success');
        Alert.alert('Success', 'Organization is now active!');
        await loadOrganizationData();
      }
    } else {
      Alert.alert('Cannot Go Online', 'Please complete all required documents first');
    }
  };

  if (loading) {
    return <LoadingScreen message="Loading organization dashboard..." />;
  }

  if (!organization) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Organization not found</Text>
        <TouchableOpacity style={styles.errorButton} onPress={() => router.back()}>
          <Text style={styles.errorButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaView style={styles.container}>
        {/* Animated Header */}
        <Animated.View
          style={[
            styles.header,
            {
              height: headerHeight,
              opacity: headerOpacity,
            },
          ]}
        >
          <LinearGradient
            colors={['#0A1929', '#1E3A8A']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />

          <View style={styles.headerContent}>
            <View style={styles.headerTop}>
              <View style={styles.headerLeft}>
                <View style={styles.headerTextContainer}>
                  <Text style={styles.greeting}>
                    {new Date().getHours() < 12
                      ? 'Good morning! 👋'
                      : new Date().getHours() < 17
                      ? 'Good afternoon! 🌟'
                      : 'Good evening! 🌙'}
                  </Text>
                  <Text style={styles.organizationName}>{organization.name}</Text>
                  <Text style={styles.subtitle}>
                    Status:{' '}
                    {organization.status === 'active'
                      ? '🟢 Active'
                      : organization.status === 'verified'
                      ? '🔵 Verified'
                      : organization.status === 'pending'
                      ? '🟡 Pending'
                      : '🔴 Suspended'}
                  </Text>
                </View>
              </View>

              <View style={styles.headerActions}>
                <TouchableOpacity
                  style={styles.profileButton}
                  onPress={() => router.push('/organisation/organisation-profile')}
                >
                  {user?.profilePicture ? (
                    <Image
                      source={{ uri: user.profilePicture }}
                      style={styles.profileImage}
                    />
                  ) : (
                    <Text style={styles.profileIcon}>👤</Text>
                  )}
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.poweredByContainer}>
              <Text style={styles.poweredByText}>Powered by Wish a Wash ⚡</Text>
            </View>
          </View>
        </Animated.View>

        <Animated.ScrollView
          style={styles.scrollView}
          onScroll={Animated.event(
            [{ nativeEvent: { contentOffset: { y: scrollY } } }],
            { useNativeDriver: false }
          )}
          scrollEventThrottle={16}
        >
          {/* Stats Section */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Organization Stats</Text>
            <View style={styles.statsGrid}>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{stats.totalValeters}</Text>
                <Text style={styles.statLabel}>Total Valeters</Text>
              </View>

              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{stats.activeValeters}</Text>
                <Text style={styles.statLabel}>Active</Text>
              </View>

              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{stats.pendingValeters}</Text>
                <Text style={styles.statLabel}>Pending</Text>
              </View>

              <View style={styles.statCard}>
                <Text style={styles.statNumber}>
                  {stats.documentsComplete ? '✓' : '✗'}
                </Text>
                <Text style={styles.statLabel}>Documents</Text>
              </View>
            </View>
          </View>

          {/* Action Buttons */}
          <View style={styles.section}>
            <View style={styles.actionButtons}>
              <TouchableOpacity
                style={[styles.actionButton, !stats.canOperate && styles.actionButtonDisabled]}
                onPress={handleGoOnline}
                disabled={!stats.canOperate}
              >
                <Text style={styles.actionButtonIcon}>🚀</Text>
                <Text style={styles.actionButtonText}>Go Online</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => setShowAddValeter(true)}
              >
                <Text style={styles.actionButtonIcon}>👥</Text>
                <Text style={styles.actionButtonText}>Add Valeter</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => router.push('/organization-rewards-system')}
              >
                <Text style={styles.actionButtonIcon}>🎁</Text>
                <Text style={styles.actionButtonText}>Rewards</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Required Documents */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Required Documents</Text>
            <Text style={styles.sectionSubtitle}>
              Complete these documents to activate your organization
            </Text>
            {organization.documents.map((document) => (
              <DocumentCard
                key={document.id}
                document={document}
                onUpload={handleDocumentUpload}
              />
            ))}
          </View>

          {/* ---------- UPDATED: Locations Section ---------- */}
          <View className="locations" style={styles.section}>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <Text style={styles.sectionTitle}>
                Locations {locations.length ? `(${locations.length})` : ''}
              </Text>
              <TouchableOpacity
                style={styles.smallAddButton}
                onPress={() => setShowAddLocation(true)}
              >
                <Text style={styles.smallAddButtonText}>＋ Add Location</Text>
              </TouchableOpacity>
            </View>

            {locationsLoading ? (
              <View style={{ paddingVertical: 16 }}>
                <ActivityIndicator />
              </View>
            ) : locations.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateIcon}>📍</Text>
                <Text style={styles.emptyStateText}>No locations yet</Text>
                <TouchableOpacity
                  style={styles.emptyStateButton}
                  onPress={() => setShowAddLocation(true)}
                >
                  <Text style={styles.emptyStateButtonText}>
                    Create your first location
                  </Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View>
                {locations.map((loc) => (
                  <TouchableOpacity
                    key={loc.id}
                    style={styles.locationCard}
                    onPress={() => openEditLocation(loc)}
                  >
                    <View style={{ flex: 1 }}>
                      <Text style={styles.locationName}>{loc.name}</Text>
                      {!!loc.address && (
                        <Text style={styles.locationAddress}>{loc.address}</Text>
                      )}
                      <Text style={styles.locationMeta}>
                        {loc.latitude != null && loc.longitude != null
                          ? `Lat: ${loc.latitude}, Lng: ${loc.longitude}`
                          : 'No coordinates'}
                      </Text>
                      <Text style={styles.locationMeta}>
                        Base £{Number(loc.base_price).toFixed(2)} • Priority £
                        {Number(loc.priority_price).toFixed(2)}
                      </Text>
                      {typeof loc.wait_time_minutes === 'number' || loc.status ? (
                        <Text style={styles.locationMeta}>
                          {loc.status ? `Status: ${String(loc.status).toUpperCase()}` : ''}
                          {typeof loc.wait_time_minutes === 'number'
                            ? `${loc.status ? ' • ' : ''}Wait: ${
                                loc.wait_time_minutes
                              }m`
                            : ''}
                        </Text>
                      ) : null}
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>

          {/* Valeters List */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>
              Valeters ({organization.valeters.length})
            </Text>
            {organization.valeters.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateIcon}>👥</Text>
                <Text style={styles.emptyStateText}>No valeters added yet</Text>
                <TouchableOpacity
                  style={styles.emptyStateButton}
                  onPress={() => setShowAddValeter(true)}
                >
                  <Text style={styles.emptyStateButtonText}>
                    Add Your First Valeter
                  </Text>
                </TouchableOpacity>
              </View>
            ) : (
              organization.valeters.map((valeter) => (
                <ValeterCard
                  key={valeter.id}
                  valeter={valeter}
                  onViewDetails={handleViewValeterDetails}
                />
              ))
            )}
          </View>
        </Animated.ScrollView>

        {/* Add Valeter Modal (Search & Link existing via profiles) */}
        <Modal visible={showAddValeter} animationType="slide" presentationStyle="pageSheet">
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Link Existing Valeter</Text>
              <TouchableOpacity
                onPress={() => {
                  setShowAddValeter(false);
                  setSearchTerm('');
                  setSearchResults([]);
                  setSelectedValeterId(null);
                }}
              >
                <Text style={styles.modalClose}>✕</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.modalContent}>
              <Text style={styles.inputLabel}>Search by name or email</Text>
              <TextInput
                style={styles.textInput}
                value={searchTerm}
                onChangeText={setSearchTerm}
                placeholder="e.g. Jane Doe or jane@valet.co"
                placeholderTextColor="#6B7280"
                autoCapitalize="none"
                autoCorrect={false}
              />

              {searching ? (
                <View style={{ paddingVertical: 12 }}>
                  <ActivityIndicator />
                </View>
              ) : (
                searchTerm.trim().length >= 2 && (
                  <FlatList
                    data={searchResults}
                    keyExtractor={(item) => item.id}
                    ListEmptyComponent={
                      <Text style={{ color: '#87CEEB', marginTop: 8 }}>
                        No matching valeters found (or they’re linked to another org).
                      </Text>
                    }
                    renderItem={({ item }) => {
                      const selected = item.id === selectedValeterId;
                      const alreadyLinkedHere =
                        item.organization_id === organization.id;

                      return (
                        <TouchableOpacity
                          onPress={() =>
                            setSelectedValeterId(selected ? null : item.id)
                          }
                          style={[
                            styles.searchResultRow,
                            selected && styles.searchResultRowSelected,
                          ]}
                        >
                          <View style={{ flex: 1 }}>
                            <Text style={styles.searchResultName}>
                              {item.full_name || 'Unnamed user'}
                            </Text>
                            <Text style={styles.searchResultEmail}>
                              {item.email || ''}
                            </Text>
                            {item.phone ? (
                              <Text style={styles.searchResultPhone}>
                                {item.phone}
                              </Text>
                            ) : null}
                            {alreadyLinkedHere ? (
                              <Text
                                style={{
                                  color: '#10B981',
                                  fontSize: 12,
                                  marginTop: 2,
                                }}
                              >
                                Already linked to this organization
                              </Text>
                            ) : null}
                          </View>
                          <Text style={styles.searchResultTick}>
                            {selected ? '✓' : ''}
                          </Text>
                        </TouchableOpacity>
                      );
                    }}
                  />
                )
              )}
            </View>

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[
                  styles.modalButton,
                  (!selectedValeterId || linking) && { opacity: 0.6 },
                ]}
                disabled={!selectedValeterId || linking}
                onPress={linkExistingValeter}
              >
                <Text style={styles.modalButtonText}>
                  {linking ? 'Linking…' : 'Link Valeter'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        {/* Document Upload Modal */}
        <Modal
          visible={showDocumentUpload}
          animationType="slide"
          presentationStyle="pageSheet"
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Upload Document</Text>
              <TouchableOpacity onPress={() => setShowDocumentUpload(false)}>
                <Text style={styles.modalClose}>✕</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.modalContent}>
              <Text style={styles.uploadText}>
                Upload{' '}
                {organization?.documents.find(
                  (doc) => doc.type === selectedDocument
                )?.name || selectedDocument.replace('_', ' ')}
              </Text>
              <Text style={styles.uploadSubtext}>
                Select an image from your photo library
              </Text>

              <View style={styles.uploadOptions}>
                <TouchableOpacity
                  style={styles.uploadOption}
                  onPress={uploadDocument}
                >
                  <Text style={styles.uploadOptionIcon}>📷</Text>
                  <Text style={styles.uploadOptionText}>Choose Image</Text>
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => setShowDocumentUpload(false)}
              >
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        {/* ---------- Add Location Modal ---------- */}
        <Modal visible={showAddLocation} animationType="slide" presentationStyle="pageSheet">
          <View style={styles.modalContainer}>
            <View className="modalHeader" style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Location</Text>
              <TouchableOpacity onPress={() => setShowAddLocation(false)}>
                <Text style={styles.modalClose}>✕</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.modalContent}>
              <Text style={styles.inputLabel}>Name</Text>
              <TextInput
                style={styles.textInput}
                value={locationForm.name}
                onChangeText={(t) => setLocationForm((p) => ({ ...p, name: t }))}
                placeholder="e.g. Trafford Park"
                placeholderTextColor="#6B7280"
              />

              <Text style={styles.inputLabel}>Address</Text>
              <TextInput
                style={styles.textInput}
                value={locationForm.address}
                onChangeText={(t) => setLocationForm((p) => ({ ...p, address: t }))}
                placeholder="123 Business Street, Manchester"
                placeholderTextColor="#6B7280"
              />

              <Text style={styles.inputLabel}>Latitude</Text>
              <TextInput
                style={styles.textInput}
                value={locationForm.latitude}
                onChangeText={(t) => setLocationForm((p) => ({ ...p, latitude: t }))}
                placeholder="53.4794"
                placeholderTextColor="#6B7280"
                keyboardType="decimal-pad"
              />

              <Text style={styles.inputLabel}>Longitude</Text>
              <TextInput
                style={styles.textInput}
                value={locationForm.longitude}
                onChangeText={(t) => setLocationForm((p) => ({ ...p, longitude: t }))}
                placeholder="-2.2453"
                placeholderTextColor="#6B7280"
                keyboardType="decimal-pad"
              />

              <Text style={styles.inputLabel}>Base Price (£)</Text>
              <TextInput
                style={styles.textInput}
                value={locationForm.basePrice}
                onChangeText={(t) => setLocationForm((p) => ({ ...p, basePrice: t }))}
                placeholder="15.00"
                placeholderTextColor="#6B7280"
                keyboardType="decimal-pad"
              />

              <Text style={styles.inputLabel}>Priority Price (£)</Text>
              <TextInput
                style={styles.textInput}
                value={locationForm.priorityPrice}
                onChangeText={(t) => setLocationForm((p) => ({ ...p, priorityPrice: t }))}
                placeholder="20.00"
                placeholderTextColor="#6B7280"
                keyboardType="decimal-pad"
              />
            </View>

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[styles.modalButton, creatingLocation && { opacity: 0.6 }]}
                disabled={creatingLocation}
                onPress={handleCreateLocation}
              >
                <Text style={styles.modalButtonText}>
                  {creatingLocation ? 'Creating…' : 'Create Location'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        {/* ---------- EDIT LOCATION MODAL ---------- */}
        <Modal visible={showEditLocation} animationType="slide" presentationStyle="pageSheet">
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Edit Location</Text>
              <TouchableOpacity onPress={() => setShowEditLocation(false)}>
                <Text style={styles.modalClose}>✕</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.modalContent}>
              <Text style={styles.inputLabel}>Name</Text>
              <TextInput
                style={styles.textInput}
                value={editForm.name}
                onChangeText={(t) => setEditForm((p) => ({ ...p, name: t }))}
                placeholder="Name"
                placeholderTextColor="#6B7280"
              />
              <Text style={styles.inputLabel}>Address</Text>
              <TextInput
                style={styles.textInput}
                value={editForm.address}
                onChangeText={(t) => setEditForm((p) => ({ ...p, address: t }))}
                placeholder="Address"
                placeholderTextColor="#6B7280"
              />
              <Text style={styles.inputLabel}>Latitude</Text>
              <TextInput
                style={styles.textInput}
                value={editForm.latitude}
                onChangeText={(t) => setEditForm((p) => ({ ...p, latitude: t }))}
                placeholder="53.4794"
                placeholderTextColor="#6B7280"
                keyboardType="decimal-pad"
              />
              <Text style={styles.inputLabel}>Longitude</Text>
              <TextInput
                style={styles.textInput}
                value={editForm.longitude}
                onChangeText={(t) => setEditForm((p) => ({ ...p, longitude: t }))}
                placeholder="-2.2453"
                placeholderTextColor="#6B7280"
                keyboardType="decimal-pad"
              />
              <Text style={styles.inputLabel}>Base Price (£)</Text>
              <TextInput
                style={styles.textInput}
                value={editForm.basePrice}
                onChangeText={(t) => setEditForm((p) => ({ ...p, basePrice: t }))}
                placeholder="15.00"
                placeholderTextColor="#6B7280"
                keyboardType="decimal-pad"
              />
              <Text style={styles.inputLabel}>Priority Price (£)</Text>
              <TextInput
                style={styles.textInput}
                value={editForm.priorityPrice}
                onChangeText={(t) => setEditForm((p) => ({ ...p, priorityPrice: t }))}
                placeholder="20.00"
                placeholderTextColor="#6B7280"
                keyboardType="decimal-pad"
              />
              <Text style={styles.inputLabel}>Status (green/amber/red)</Text>
              <TextInput
                style={styles.textInput}
                value={editForm.status}
                onChangeText={(t) => setEditForm((p) => ({ ...p, status: t }))}
                placeholder="green"
                placeholderTextColor="#6B7280"
                autoCapitalize="none"
              />
              <Text style={styles.inputLabel}>Wait Time (minutes)</Text>
              <TextInput
                style={styles.textInput}
                value={editForm.waitTime}
                onChangeText={(t) => setEditForm((p) => ({ ...p, waitTime: t }))}
                placeholder="15"
                placeholderTextColor="#6B7280"
                keyboardType="number-pad"
              />
            </View>

            <View style={[styles.modalActions, { flexDirection: 'row', gap: 12 }]}>
              <TouchableOpacity
                style={[
                  styles.modalButton,
                  { flex: 1, backgroundColor: '#EF4444' },
                  (savingEdit || deleting) && { opacity: 0.6 },
                ]}
                disabled={savingEdit || deleting}
                onPress={handleDeleteLocation}
              >
                <Text style={[styles.modalButtonText, { color: '#fff' }]}>
                  {deleting ? 'Deleting…' : 'Delete'}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.modalButton,
                  { flex: 2 },
                  (savingEdit || deleting) && { opacity: 0.6 },
                ]}
                disabled={savingEdit || deleting}
                onPress={handleUpdateLocation}
              >
                <Text style={styles.modalButtonText}>
                  {savingEdit ? 'Saving…' : 'Save Changes'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </SafeAreaView>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0A1929',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 16,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0A1929',
  },
  errorText: {
    color: '#F9FAFB',
    fontSize: 16,
    marginBottom: 20,
  },
  errorButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  errorButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  headerContent: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  headerLeft: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  backButtonIcon: {
    fontSize: 24,
    color: '#F9FAFB',
    fontWeight: 'bold',
  },
  headerTextContainer: {
    flex: 1,
  },
  greeting: {
    fontSize: 16,
    color: '#F9FAFB',
    opacity: 0.9,
  },
  organizationName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginTop: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#87CEEB',
    marginTop: 4,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 12,
  },
  profileButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileIcon: {
    fontSize: 20,
  },
  poweredByContainer: {
    alignItems: 'flex-end',
    marginTop: 8,
  },
  poweredByText: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 10,
    fontWeight: '400',
  },
  scrollView: {
    flex: 1,
    paddingTop: 200,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  sectionSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 11,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  actionButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  actionButtonIcon: {
    fontSize: 20,
    marginBottom: 8,
  },
  actionButtonText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: '600',
  },
  documentCard: {
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 2,
  },
  documentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  documentInfo: {
    flexDirection: 'row',
    flex: 1,
    alignItems: 'flex-start',
  },
  documentIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  documentTextContainer: {
    flex: 1,
  },
  documentName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '600',
  },
  documentDescription: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 8,
  },
  uploadedText: {
    color: '#9CA3AF',
    fontSize: 11,
  },
  uploadButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    alignSelf: 'flex-start',
    marginTop: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  uploadButtonText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '600',
  },
  valeterCard: {
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 2,
  },
  valeterHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  valeterInfo: {
    flex: 1,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  valeterEmail: {
    color: '#87CEEB',
    fontSize: 12,
  },
  valeterDetails: {
    marginBottom: 8,
  },
  valeterPhone: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 4,
  },
  valeterJoined: {
    color: '#9CA3AF',
    fontSize: 12,
  },
  documentsStatus: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    paddingTop: 8,
  },
  documentsTitle: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 4,
  },
  documentChecks: {
    flexDirection: 'row',
    gap: 16,
  },
  documentCheck: {
    color: '#9CA3AF',
    fontSize: 12,
  },
  documentComplete: {
    color: '#10B981',
  },
  emptyState: {
    alignItems: 'center',
    padding: 40,
  },
  emptyStateIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  emptyStateText: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 16,
  },
  emptyStateButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  emptyStateButtonText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: '600',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalClose: {
    color: '#F9FAFB',
    fontSize: 20,
  },
  modalContent: {
    padding: 20,
  },
  inputLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
  },
  textInput: {
    backgroundColor: '#1E3A8A',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
    padding: 12,
    color: '#F9FAFB',
    fontSize: 14,
    marginBottom: 16,
  },
  uploadText: {
    color: '#F9FAFB',
    fontSize: 14,
    marginBottom: 8,
  },
  uploadSubtext: {
    color: '#87CEEB',
    fontSize: 12,
  },
  uploadOptions: {
    marginTop: 20,
  },
  uploadOption: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  uploadOptionIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  uploadOptionText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  modalActions: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },

  // --- New styles for search results
  searchResultRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E3A8A',
    padding: 14,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
    marginBottom: 10,
  },
  searchResultRowSelected: {
    borderColor: '#87CEEB',
  },
  searchResultName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  searchResultEmail: {
    color: '#87CEEB',
    fontSize: 12,
  },
  searchResultPhone: {
    color: '#9CA3AF',
    fontSize: 12,
  },
  searchResultTick: {
    color: '#87CEEB',
    fontSize: 18,
    fontWeight: '700',
    paddingLeft: 8,
  },

  // --- New styles for locations
  smallAddButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  smallAddButtonText: {
    color: '#0A1929',
    fontWeight: '700',
    fontSize: 12,
  },
  locationCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  locationName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  locationAddress: {
    color: '#87CEEB',
    fontSize: 13,
    marginTop: 2,
  },
  locationMeta: {
    color: '#9CA3AF',
    fontSize: 12,
    marginTop: 2,
  },
});