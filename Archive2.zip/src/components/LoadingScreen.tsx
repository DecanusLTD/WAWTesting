import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Dimensions,
  Easing,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const { width, height } = Dimensions.get('window');

interface RaindropProps {
  delay: number;
  duration: number;
  x: number;
}

const Raindrop: React.FC<RaindropProps> = ({ delay, duration, x }) => {
  const translateY = useRef(new Animated.Value(-50)).current;
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const startAnimation = () => {
      Animated.parallel([
        Animated.timing(translateY, {
          toValue: height + 50,
          duration,
          delay,
          easing: Easing.linear,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 1,
          duration: 500,
          delay,
          useNativeDriver: true,
        }),
      ]).start(() => {
        // Reset and restart animation
        translateY.setValue(-50);
        opacity.setValue(0);
        startAnimation();
      });
    };

    startAnimation();
  }, [delay, duration, translateY, opacity]);

  return (
    <Animated.View
      style={[
        styles.raindrop,
        {
          left: x,
          transform: [{ translateY }],
          opacity,
        },
      ]}
    />
  );
};

interface LoadingScreenProps {
  message?: string;
}

export default function LoadingScreen({ message = "Loading..." }: LoadingScreenProps) {
  const spongeRotation = useRef(new Animated.Value(0)).current;
  const spongeScale = useRef(new Animated.Value(1)).current;
  const bubbleAnim = useRef(new Animated.Value(0)).current;
  const waveAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Spinning sponge animation
    Animated.loop(
      Animated.timing(spongeRotation, {
        toValue: 1,
        duration: 2000,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    ).start();

    // Sponge bounce animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(spongeScale, {
          toValue: 1.1,
          duration: 1000,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(spongeScale, {
          toValue: 1,
          duration: 1000,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Bubble animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(bubbleAnim, {
          toValue: 1,
          duration: 3000,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(bubbleAnim, {
          toValue: 0,
          duration: 3000,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Wave animation
    Animated.loop(
      Animated.timing(waveAnim, {
        toValue: 1,
        duration: 4000,
        easing: Easing.inOut(Easing.ease),
        useNativeDriver: true,
      })
    ).start();
  }, [spongeRotation, spongeScale, bubbleAnim, waveAnim]);

  // Generate raindrops
  const raindrops = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    delay: i * 200,
    duration: 2000 + Math.random() * 1000,
    x: Math.random() * width,
  }));

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A', '#0C4A6E']}
        style={StyleSheet.absoluteFill}
      />
      
      {/* Animated raindrops */}
      {raindrops.map((drop) => (
        <Raindrop
          key={drop.id}
          delay={drop.delay}
          duration={drop.duration}
          x={drop.x}
        />
      ))}

      {/* Animated waves */}
      <Animated.View
        style={[
          styles.wave,
          {
            transform: [
              {
                translateX: waveAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [-width, width],
                }),
              },
            ],
            opacity: waveAnim.interpolate({
              inputRange: [0, 0.5, 1],
              outputRange: [0, 0.3, 0],
            }),
          },
        ]}
      />

      {/* Bubbles */}
      <Animated.View
        style={[
          styles.bubble,
          {
            transform: [
              {
                translateY: bubbleAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0, -20],
                }),
              },
              {
                scale: bubbleAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [1, 1.2],
                }),
              },
            ],
            opacity: bubbleAnim.interpolate({
              inputRange: [0, 0.5, 1],
              outputRange: [0.6, 1, 0.6],
            }),
          },
        ]}
      />

      {/* Main content */}
      <View style={styles.content}>
        {/* Spinning sponge */}
        <Animated.View
          style={[
            styles.spongeContainer,
            {
              transform: [
                {
                  rotate: spongeRotation.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['0deg', '360deg'],
                  }),
                },
                {
                  scale: spongeScale,
                },
              ],
            },
          ]}
        >
          <Text style={styles.sponge}>🧽</Text>
        </Animated.View>

        {/* Loading text */}
        <Text style={styles.loadingText}>{message}</Text>
        
        {/* Brand text */}
        <View style={styles.brandContainer}>
          <Text style={styles.brandTitle}>Wish a Wash</Text>
          <Text style={styles.brandSubtitle}>Your Wish Our Wash 🚿</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  content: {
    alignItems: 'center',
    zIndex: 10,
  },
  spongeContainer: {
    marginBottom: 30,
  },
  sponge: {
    fontSize: 80,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 4,
  },
  loadingText: {
    fontSize: 18,
    color: '#87CEEB',
    fontWeight: '600',
    marginBottom: 40,
    textAlign: 'center',
  },
  brandContainer: {
    alignItems: 'center',
  },
  brandTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 8,
  },
  brandSubtitle: {
    fontSize: 14,
    color: '#87CEEB',
    textAlign: 'center',
  },
  raindrop: {
    position: 'absolute',
    width: 2,
    height: 20,
    backgroundColor: 'rgba(135, 206, 235, 0.6)',
    borderRadius: 1,
    zIndex: 1,
  },
  wave: {
    position: 'absolute',
    bottom: 0,
    width: width * 2,
    height: 60,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 30,
    zIndex: 2,
  },
  bubble: {
    position: 'absolute',
    right: 50,
    bottom: 100,
    width: 20,
    height: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 10,
    zIndex: 3,
  },
});
