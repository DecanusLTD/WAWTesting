// src/providers/enhanced-auth-context.tsx
import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../lib/supabase';
import type { Session, User as SbUser } from '@supabase/supabase-js';
// import { organizationVerificationService } from '../services/OrganizationVerificationService'; // not needed anymore here

/* ---------------- Types ---------------- */

export interface Organization {
  id: string;
  name: string;
  registrationNumber?: string;
  address?: string;
  contactEmail: string;
  contactPhone?: string;
  isVerified: boolean;
  insuranceVerified: boolean;
  licenseVerified: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  userType: 'customer' | 'valeter' | 'organization';
  organizationId?: string;
  organizationType?: 'independent' | 'registered';
  profilePicture?: string;
  isVerified: boolean;
  verificationType: 'none' | 'profile' | 'car';
  totalWashes: number;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  tierPoints: number;
  joinDate: string;
}

interface AuthContextType {
  user: User | null;
  /** True while we’re bootstrapping session/profile OR mid-auth mutations. */
  isLoading: boolean;
  /** True when the role (userType) is reliable; use this for routing. */
  authReady: boolean;

  login: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  register: (userData: Omit<User, 'id' | 'joinDate'> & {
    password: string;
    isIndividualValeter?: boolean;
    organizationId?: string;
    /** NEW: for org signups */
    orgName?: string;
    contactName?: string;
  }) => Promise<boolean>;
  updateUser: (updates: Partial<User>) => Promise<void>;
  updatePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  updateProfile: (updates: Partial<User>) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  autoLoginCustomer: () => Promise<void>;
  autoLoginValeter: () => Promise<void>;
  hasAdminAccess: () => boolean;
  isBusinessOwner: () => boolean;
  markWelcomeSeen: (userType: 'customer' | 'valeter') => Promise<void>;
  hasSeenWelcome: (userType: 'customer' | 'valeter') => Promise<boolean>;
  isIndividualValeter: () => boolean;
  isOrganizationValeter: () => boolean;
  requiresIndividualDocuments: () => boolean;
  requiresOrganizationDocuments: () => boolean;
  getOrganization: () => Organization | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
const SESSION_KEY = 'user_session';

/* ---------------- Utils ---------------- */

function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => {
      console.warn(`[Auth TIMEOUT] ${label} timed out after ${ms}ms`);
      reject(new Error(`timeout:${label}`));
    }, ms);
    p.then(v => { clearTimeout(t); resolve(v); })
     .catch(e => { clearTimeout(t); reject(e); });
  });
}

/* ---------------- Helpers ---------------- */

const hasReliableRole = (profile: any | null, md: any): boolean => {
  // “Reliable” if we explicitly see a role in either profile.user_type or metadata.userType
  return !!(profile?.user_type || md?.userType);
};

const toAppUser = (sbUser: SbUser, profile: any): User => {
  const md = sbUser.user_metadata ?? {};
  const role: User['userType'] =
    (profile?.user_type ??
      md.userType ??
      'customer') as User['userType'];

  return {
    id: sbUser.id,
    email: sbUser.email ?? '',
    name: profile?.full_name ?? md.full_name ?? md.name ?? '',
    phone: profile?.phone ?? md.phone ?? '',
    userType: role,
    organizationId: profile?.organization_id ?? md.organizationId ?? undefined,
    organizationType: (profile?.organization_type ?? md.organizationType) as User['organizationType'],
    profilePicture: profile?.profile_picture ?? md.profilePicture ?? undefined,
    isVerified: !!profile?.is_verified,
    verificationType: (profile?.verification_type ?? 'none') as User['verificationType'],
    totalWashes: profile?.total_washes ?? 0,
    tier: (profile?.tier ?? 'bronze') as User['tier'],
    tierPoints: profile?.tier_points ?? 0,
    joinDate: (profile?.created_at ?? sbUser.created_at ?? new Date().toISOString()),
  };
};

const upsertProfile = async (sbUser: SbUser, seed?: Partial<User>) => {
  console.log('[Auth DEBUG] upsertProfile called');

  const payload: Record<string, any> = {
    id: sbUser.id,
    email: sbUser.email,
    full_name:
      seed?.name ??
      sbUser.user_metadata?.full_name ??
      sbUser.user_metadata?.name ??
      null,
    phone: seed?.phone ?? sbUser.user_metadata?.phone ?? null,
    user_type: seed?.userType ?? sbUser.user_metadata?.userType ?? 'customer',
    is_verified: seed?.isVerified ?? false,
    verification_type: seed?.verificationType ?? 'none',
    total_washes: seed?.totalWashes ?? 0,
    tier: seed?.tier ?? 'bronze',
    tier_points: seed?.tierPoints ?? 0,
  };

  const orgId = seed?.organizationId ?? sbUser.user_metadata?.organizationId;
  if (orgId !== undefined && orgId !== null) {
    payload.organization_id = orgId;
  }

  const orgType = seed?.organizationType ?? sbUser.user_metadata?.organizationType;
  if (orgType !== undefined && orgType !== null) {
    payload.organization_type = orgType;
  }

  const { error } = await supabase.from('profiles').upsert(payload, { onConflict: 'id' });
  if (error) console.warn('[Auth DEBUG] profiles upsert error:', error.message);
  else console.log('[Auth DEBUG] profiles upsert success');
};

const fetchProfile = async (userId: string) => {
  console.log('[Auth DEBUG] fetchProfile for', userId);
  const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
  if (error) {
    console.warn('[Auth DEBUG] fetchProfile error:', error.message);
    return null;
  }
  console.log('[Auth DEBUG] fetchProfile result exists?', !!data);
  return data;
};

/** Create & link organization after first login (email confirmation safe). */
async function ensureOrgAfterLogin(u: SbUser) {
  const md = u.user_metadata ?? {};
  const isOrgUser = md.userType === 'organization';
  const hasOrgId = !!md.organizationId;

  if (!isOrgUser || hasOrgId) return;

  const orgName = md.pendingOrgName ?? 'Organization';
  const contactName = md.pendingContactName ?? md.full_name ?? 'Owner';

  // 1) Create organization
  const { data: orgRow, error: orgErr } = await supabase
    .from('organizations')
    .insert({
      name: orgName,
      contact_name: contactName,
      contact_email: u.email,
      //created_by: u.id,
      //business_type: 'valeting',
    })
    .select('id')
    .maybeSingle();

  if (orgErr || !orgRow?.id) {
    console.warn('[Auth DEBUG] ensureOrgAfterLogin: org insert failed:', orgErr?.message);
    return;
  }

  const orgId = orgRow.id as string;

  // 2) Link profile
  const { error: profErr } = await supabase
    .from('profiles')
    .update({ organization_id: orgId, user_type: 'organization' })
    .eq('id', u.id);

  if (profErr) {
    console.warn('[Auth DEBUG] ensureOrgAfterLogin: profile link failed:', profErr.message);
    return;
  }

  // 3) Update auth metadata
  await supabase.auth.updateUser({
    data: {
      organizationId: orgId,
      pendingOrgName: null,
      pendingContactName: null,
    },
  });

  console.log('[Auth DEBUG] ensureOrgAfterLogin: org created and linked', orgId);
}

/* ---------------- Provider ---------------- */

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  // isLoading: true while bootstrapping + while any auth action runs.
  const [isLoading, setIsLoading] = useState(true);

  // authReady: true when we know userType reliably (metadata OR profile),
  // OR when there’s no logged-in user.
  const [authReady, setAuthReady] = useState(false);

  // prevent double-setting on boot
  const bootDoneRef = useRef(false);

  // initial session + listener
  useEffect(() => {
    let mounted = true;

    (async () => {
      console.log('[Auth] bootstrap start');
      setIsLoading(true);
      setAuthReady(false);

      try {
        const { data } = await withTimeout(
          supabase.auth.getSession(),
          3000,
          'getSession'
        );

        const s: Session | null = data?.session ?? null;
        console.log('[Auth DEBUG] getSession -> hasSession?', !!s);

        if (s?.user) {
          const md = s.user.user_metadata ?? {};

          // If metadata has userType we can render minimal immediately.
          const mdHasRole = !!md.userType;

          if (mdHasRole) {
            const minimal = toAppUser(s.user, null);
            if (mounted) {
              setUser(minimal);
              await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(minimal));
              setAuthReady(true); // role is reliable from metadata
              console.log('[Auth] minimal user set (metadata role present) -> authReady=true');
            }
          }

          // Regardless, try to enrich with profile (don’t block > 3s total).
          try {
            const profile = await withTimeout(fetchProfile(s.user.id), 3000, 'fetchProfile(bootstrap)');
            const enriched = toAppUser(s.user, profile);
            await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(enriched));
            if (mounted) {
              setUser(enriched);
              setAuthReady(true); // role now reliable from profile
              console.log('[Auth] user enriched -> authReady=true');
            }
          } catch (e: any) {
            console.warn('[Auth DEBUG] bootstrap profile fetch failed:', e?.message || e);
            // If we didn’t already mark authReady via metadata, try cache as fallback
            if (!mdHasRole) {
              const cached = await AsyncStorage.getItem(SESSION_KEY);
              if (cached && mounted) {
                const cachedUser = JSON.parse(cached) as User;
                setUser(cachedUser);
                setAuthReady(!!cachedUser?.userType);
                console.log('[Auth] restored cached user (fallback). authReady=', !!cachedUser?.userType);
              } else {
                // Still no reliable userType, keep user but mark ready to avoid permanent block
                setAuthReady(true);
              }
            }
          }
        } else {
          // No live session: try cache quickly.
          console.log('[Auth DEBUG] no live session, reading cached user');
          const cached = await AsyncStorage.getItem(SESSION_KEY);
          if (cached && mounted) {
            const cachedUser = JSON.parse(cached) as User;
            setUser(cachedUser);
            setAuthReady(true);
            console.log('[Auth] restored cached user (no live session). authReady=true');
          } else {
            if (mounted) {
              setUser(null);
              setAuthReady(true);
              console.log('[Auth] no session/cached user. authReady=true');
            }
          }
        }
      } catch (e: any) {
        console.warn('[Auth WARN] getSession failed:', e?.message || e);
        const cached = await AsyncStorage.getItem(SESSION_KEY);
        if (cached && mounted) {
          const cachedUser = JSON.parse(cached) as User;
          setUser(cachedUser);
          setAuthReady(true);
          console.log('[Auth] restored cached user after getSession fail. authReady=true');
        } else if (mounted) {
          setUser(null);
          setAuthReady(true);
        }
      } finally {
        if (mounted) {
          setIsLoading(false);
          bootDoneRef.current = true;
          console.log('[Auth] bootstrap complete. isLoading=false');
        }
      }
    })();

    const { data: sub } = supabase.auth.onAuthStateChange((event, newSession) => {
      console.log('[Auth DEBUG] onAuthStateChange event:', event);
      // Avoid race with bootstrap: we still handle but rely on mounted flags
      (async () => {
        try {
          if (!newSession?.user) {
            console.log('[Auth DEBUG] onAuthStateChange -> no user; clearing cache');
            await AsyncStorage.removeItem(SESSION_KEY);
            setUser(null);
            setAuthReady(true);
            return;
          }

          // 🔹 Create+link org after first login if needed (email confirmation safe)
          if (event === 'SIGNED_IN') {
            await ensureOrgAfterLogin(newSession.user);
          }

          const md = newSession.user.user_metadata ?? {};
          const mdHasRole = !!md.userType;

          // Minimal immediately if metadata role exists
          if (mdHasRole) {
            const minimal = toAppUser(newSession.user, null);
            await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(minimal)); // fixed typo
            setUser(minimal);
            setAuthReady(true);
            console.log('[Auth] onAuthStateChange -> minimal user set. authReady=true');
          } else {
            // hold authReady until profile fetch completes or times out
            setAuthReady(false);
          }

          // Enrich in background
          try {
            const profile = await withTimeout(fetchProfile(newSession.user.id), 3000, 'fetchProfile(onChange)');
            const enriched = toAppUser(newSession.user, profile);
            await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(enriched));
            setUser(enriched);
            setAuthReady(true);
            console.log('[Auth] onAuthStateChange -> user enriched. authReady=true');
          } catch (e: any) {
            console.warn('[Auth DEBUG] onAuthStateChange enrich failed:', e?.message || e);
            if (!mdHasRole) {
              // Fall back to cached reliability
              const cached = await AsyncStorage.getItem(SESSION_KEY);
              if (cached) {
                const cachedUser = JSON.parse(cached) as User;
                setUser(cachedUser);
                setAuthReady(!!cachedUser?.userType);
              } else {
                setAuthReady(true);
              }
            }
          }
        } catch (e: any) {
          console.warn('[Auth DEBUG] onAuthStateChange handler error:', e?.message || e);
          setAuthReady(true);
        } finally {
          // We don't toggle isLoading here; it's for UI spinners during explicit actions
        }
      })();
    });

    return () => {
      console.log('[Auth DEBUG] cleaning up auth subscription');
      sub.subscription.unsubscribe();
      // mounted=false to avoid setting state after unmount
    };
  }, []);

  /* -------- API -------- */

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    setAuthReady(false);
    console.log('[Auth DEBUG] login called for', email);
    try {
      const { data, error } = await withTimeout(
        supabase.auth.signInWithPassword({ email, password }),
        5000,
        'signInWithPassword'
      );
      console.log('[Auth DEBUG] signInWithPassword -> user?', !!data?.user, 'error=', error?.message);

      if (error || !data.user) {
        setAuthReady(true);
        return false;
      }

      // Minimal now if metadata has role
      const md = data.user.user_metadata ?? {};
      const mdHasRole = !!md.userType;
      if (mdHasRole) {
        const minimal = toAppUser(data.user, null);
        await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(minimal));
        setUser(minimal);
        setAuthReady(true);
      }

      // Enrich in background
      (async () => {
        try {
          await upsertProfile(data.user);
          const profile = await withTimeout(fetchProfile(data.user.id), 3000, 'fetchProfile(login)');
          const enriched = toAppUser(data.user, profile);
          await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(enriched));
          setUser(enriched);
          setAuthReady(true);
          console.log('[Auth DEBUG] login enriched user set');
        } catch (e: any) {
          console.warn('[Auth DEBUG] login enrichment failed:', e?.message || e);
          if (!mdHasRole) {
            setAuthReady(true);
          }
        }
      })();

      return true;
    } catch (e: any) {
      console.warn('[Auth DEBUG] login error:', e?.message || e);
      setAuthReady(true);
      return false;
    } finally {
      setIsLoading(false);
      console.log('[Auth DEBUG] login -> isLoading=false');
    }
  };

  const logout = async (): Promise<void> => {
    console.log('[Auth DEBUG] logout called');
    setIsLoading(true);
    setAuthReady(false);
    try {
      await withTimeout(supabase.auth.signOut(), 3000, 'signOut');
      await AsyncStorage.removeItem(SESSION_KEY);
      setUser(null);
      console.log('[Auth DEBUG] logout complete');
    } catch (e: any) {
      console.warn('[Auth DEBUG] logout error:', e?.message || e);
    } finally {
      setIsLoading(false);
      setAuthReady(true);
    }
  };

  const register: AuthContextType['register'] = async (userData) => {
    setIsLoading(true);
    setAuthReady(false);
    console.log('[Auth DEBUG] register called with userType=', userData.userType);
    try {
      const {
        email, password, name, phone, userType,
        organizationId, organizationType, profilePicture,
        orgName, contactName,
      } = userData;

      // With email confirmation ON, we only stash intent here.
      const { data, error } = await withTimeout(
        supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              full_name: contactName ?? name, // human's name
              name: contactName ?? name,
              phone,
              userType,
              organizationId,      // probably null for org sign-up
              organizationType,
              profilePicture,
              // used post-login
              pendingOrgName: userType === 'organization' ? (orgName ?? name) : null,
              pendingContactName: userType === 'organization' ? (contactName ?? name) : null,
            },
          },
        }),
        5000,
        'signUp'
      );
      console.log('[Auth DEBUG] signUp -> user?', !!data?.user, 'error=', error?.message);
      if (error) {
        setAuthReady(true);
        return false;
      }

      if (data.user) {
        // Minimal now if metadata has role
        const md = data.user.user_metadata ?? {};
        const mdHasRole = !!md.userType;
        if (mdHasRole) {
          const minimal = toAppUser(data.user, null);
          await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(minimal));
          setUser(minimal);
          setAuthReady(true);
        }

        // Enrich later (profile upsert with whatever we have)
        (async () => {
          try {
            await upsertProfile(data.user, {
              name: contactName ?? name,
              phone,
              userType,
              organizationId,
              organizationType,
              profilePicture,
              verificationType: 'none',
              isVerified: false,
              totalWashes: 0,
              tier: 'bronze',
              tierPoints: 0,
            });
            const profile = await withTimeout(fetchProfile(data.user.id), 3000, 'fetchProfile(register)');
            const enriched = toAppUser(data.user, profile);
            await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(enriched));
            setUser(enriched);
            setAuthReady(true);
            console.log('[Auth DEBUG] register enriched user set');
          } catch (e: any) {
            console.warn('[Auth DEBUG] register enrichment failed:', e?.message || e);
            if (!mdHasRole) {
              setAuthReady(true);
            }
          }
        })();
      } else {
        setAuthReady(true);
      }

      return true;
    } catch (e: any) {
      console.warn('[Auth DEBUG] register error:', e?.message || e);
      setAuthReady(true);
      return false;
    } finally {
      setIsLoading(false);
      console.log('[Auth DEBUG] register -> isLoading=false');
    }
  };

  const updateUser = async (updates: Partial<User>): Promise<void> => {
    if (!user) {
      console.log('[Auth DEBUG] updateUser called with no user; ignoring');
      return;
    }
    console.log('[Auth DEBUG] updateUser called with', updates);

    const md: Record<string, any> = {};
    if (updates.name) md.full_name = updates.name;
    if (updates.phone) md.phone = updates.phone;
    if (updates.userType) md.userType = updates.userType;
    if (updates.organizationId) md.organizationId = updates.organizationId;
    if (updates.organizationType) md.organizationType = updates.organizationType;
    if (updates.profilePicture) md.profilePicture = updates.profilePicture;

    try {
      setIsLoading(true);
      if (Object.keys(md).length) {
        console.log('[Auth DEBUG] updating supabase auth metadata');
        await withTimeout(supabase.auth.updateUser({ data: md }), 3000, 'updateUser(auth)');
      }

      const patch: any = {};
      if (updates.name) patch.full_name = updates.name;
      if (updates.phone) patch.phone = updates.phone;
      if (updates.userType) patch.user_type = updates.userType;
      if (updates.organizationId) patch.organization_id = updates.organizationId;
      if (updates.organizationType) patch.organization_type = updates.organizationType;
      if (updates.profilePicture) patch.profile_picture = updates.profilePicture;
      if (typeof updates.isVerified === 'boolean') patch.is_verified = updates.isVerified;
      if (updates.verificationType) patch.verification_type = updates.verificationType;
      if (typeof updates.totalWashes === 'number') patch.total_washes = updates.totalWashes;
      if (updates.tier) patch.tier = updates.tier;
      if (typeof updates.tierPoints === 'number') patch.tier_points = updates.tierPoints;

      if (Object.keys(patch).length) {
        console.log('[Auth DEBUG] updating profiles row');
        await withTimeout(supabase.from('profiles').update(patch).eq('id', user.id), 4000, 'updateProfile(row)');
      }

      console.log('[Auth DEBUG] refreshing local snapshot');
      const { data } = await withTimeout(supabase.auth.getUser(), 3000, 'getUser(refresh)');
      const profile = data.user ? await withTimeout(fetchProfile(data.user.id), 3000, 'fetchProfile(refresh)') : null;
      const appUser = data.user ? toAppUser(data.user, profile) : null;
      if (appUser) await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(appUser));
      setUser(appUser);
      console.log('[Auth DEBUG] updateUser complete');
    } catch (e: any) {
      console.warn('[Auth DEBUG] updateUser error:', e?.message || e);
    } finally {
      setIsLoading(false);
    }
  };

  const updatePassword = async (_currentPassword: string, newPassword: string): Promise<void> => {
    console.log('[Auth DEBUG] updatePassword called');
    const { error } = await withTimeout(supabase.auth.updateUser({ password: newPassword }), 3000, 'updatePassword');
    if (error) {
      console.warn('[Auth DEBUG] updatePassword error:', error.message);
      throw error;
    }
    console.log('[Auth DEBUG] updatePassword success');
  };

  const updateProfile = async (updates: Partial<User>): Promise<void> => updateUser(updates);

  const resetPassword = async (email: string): Promise<void> => {
    console.log('[Auth DEBUG] resetPassword called for', email);
    const { error } = await withTimeout(
      supabase.auth.resetPasswordForEmail(email, { redirectTo: 'yourapp://reset-password' }),
      3000,
      'resetPassword'
    );
    if (error) {
      console.warn('[Auth DEBUG] resetPassword error:', error.message);
      throw error;
    }
    console.log('[Auth DEBUG] resetPassword dispatched');
  };

  const autoLoginCustomer = async () => {
    console.log('[Auth DEBUG] autoLoginCustomer');
    await login('customer@test.com', 'password123');
  };
  const autoLoginValeter = async () => {
    console.log('[Auth DEBUG] autoLoginValeter');
    await login('valeter@test.com', 'password123');
  };

  const hasAdminAccess = (): boolean => (user?.email?.toLowerCase?.() ?? '') === 'admin@wishawash.com';
  const isBusinessOwner = (): boolean => user?.userType === 'organization';

  const markWelcomeSeen = async (userType: 'customer' | 'valeter') => {
    console.log('[Auth DEBUG] markWelcomeSeen', userType);
    await AsyncStorage.setItem(`welcome_seen_${userType}`, 'true');
  };
  const hasSeenWelcome = async (userType: 'customer' | 'valeter') => {
    const seen = await AsyncStorage.getItem(`welcome_seen_${userType}`);
    console.log('[Auth DEBUG] hasSeenWelcome', userType, '->', seen === 'true');
    return seen === 'true';
  };

  const isIndividualValeter = (): boolean =>
    user?.userType === 'valeter' && user?.organizationType !== 'registered';

  const isOrganizationValeter = (): boolean =>
    user?.userType === 'valeter' && user?.organizationType === 'registered';

  const requiresIndividualDocuments = (): boolean =>
    user?.userType === 'valeter' && !user?.isVerified && user?.organizationType !== 'registered';

  const requiresOrganizationDocuments = (): boolean =>
    user?.userType === 'valeter' && user?.organizationType === 'registered' && !user?.isVerified;

  const getOrganization = (): Organization | null => {
    if (!user?.organizationId) return null;
    return {
      id: user.organizationId,
      name: 'Organization',
      contactEmail: user.email,
      isVerified: false,
      insuranceVerified: false,
      licenseVerified: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    } as Organization;
  };

  const value: AuthContextType = useMemo(() => ({
    user,
    isLoading,
    authReady,

    login,
    logout,
    register,
    updateUser,
    updatePassword,
    updateProfile,
    resetPassword,
    autoLoginCustomer,
    autoLoginValeter,
    hasAdminAccess,
    isBusinessOwner,
    markWelcomeSeen,
    hasSeenWelcome,
    isIndividualValeter,
    isOrganizationValeter,
    requiresIndividualDocuments,
    requiresOrganizationDocuments,
    getOrganization,
  }), [user, isLoading, authReady]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};

export default AuthProvider;